PSO2 旧国私服源码冻结备份 — U136

本包保存当前已部署验收版的完整服务端源码和配套数据。376个原始文件与部署候选、开发副本逐一核对 SHA-256 一致；原有文件未为打包改写。新增 freeze 目录保存交接资料。

一、包含及排除
包含 Rust 工作区、Cargo.lock、数据编译器、data 数据、源码内回归测试和证据夹具、原上游 LICENSE/README，以及原有 GitHub 工作流。
data/com_data.mp 是本版本随源保存的编译数据，也一并保留，便于对照或重新生成。
不包含 target、可执行文件、依赖缓存、账号/角色数据库、运行日志、客户端资源、运行密钥、运行目录的真实配置、Git历史。
data/*.toml 是源码自带示例配置。示例中的 master_ship_psk 是占位文字，并非本机运行密钥。
这是源码备份；它不能恢复当前账号存档或直接替代运行目录备份。
源码证据夹具中可能保留原取证文件路径，这是来源注记；相关外部客户端文件不在本包。

二、版本与状态
基于上游 df1994ee75ff7a78fbd8b560d1278fce65d6a0d6 的本地修复，冻结版本 U136。
原 README.MD / DOWNLOAD-INFO.txt 是上游快照说明，并未描述此后全部本地修复；当前状态以 freeze/STATUS.json 为准。
464项后台回归、15项部署工具测试和编译/启停回退演练有既存通过记录。打包只重做文件一致性、归档完整性核对，没有重跑这些测试。
Hr已有部分实机通过记录；U100–U136累计功能仍待用户本轮验收。切勿把后台通过或原始数据导入视为全功能验收完成。
freeze/CLIENT-ACCEPTANCE.json 给出20组待测项目。未完成机制和继续顺序见 STATUS.json。
项目按用户要求冻结，恢复开发需用户后续指示。冻结并不表示最终修复完成。

三、复现构建（Windows PowerShell，源码根目录）
本次已验证环境为 Windows x86_64，Rust/Cargo 1.99.0，MSVC C/C++构建工具及Windows SDK。
上游 README 的旧版 Rust 1.75 提示不适用于当前使用 edition 2024 的源码；使用记录的工具链重现。
首次安装依赖需要联网，保留 Cargo.lock。以下命令不启动服务、不修改现有运行目录：

  $env:RUST_MIN_STACK = '33554432'
  cargo test --locked --workspace local_ -- --test-threads=1
  cargo build --locked --release --workspace
  cargo run --locked --release -p data_compiler -- data

每步检查退出码，失败时不要继续发布。local_ 是本次464项回归使用的筛选条件；另有4项需专门场景的进程探针被忽略。
输出位于 target/release；编译数据位于 data/com_data.mp。上述命令会重新生成数据，验证原始冻结文件请先核对 SOURCE-SHA256.json。
Linux构建未在本次冻结时验证，源码 .cargo/config.toml 对Linux指定了 clang/lld。
这里没有供应商依赖源码或编译器本身，也没有宣称跨环境二进制逐字节可复现。

四、上传与继续
解压后 PhantasyServer 目录就是源码仓库根目录，可在该目录建立新的Git仓库并自行上传；本包不含原仓库提交历史。保留 LICENSE 和来源说明。
外部 .sha256 文件用于核对整个ZIP；freeze/SOURCE-SHA256.json 对应376个原始文件；freeze/PACKAGE-SHA256.json 对应包内除清单本身外的所有文件。
仅为打包未启动/停止服务、改账号存档或触碰正式服、Documents/SEGA。
