//! Structural checks only: these do not certify original game balance or completeness.
use data_structs::{
    ServerData,
    map::{EnemySpawnType, MapData},
    stats::{AttackStatsReadable, DamageTypeReadable, EnemyLevelBaseStats},
};
use std::{collections::HashSet, error::Error, path::Path};

pub fn validate(data: &ServerData) -> Result<(), Box<dyn Error>> {
    for (name, map) in &data.maps {
        validate_map(map, data, &format!("map {name:?}"))?;
    }
    let mut quest_ids = HashSet::new();
    let mut quest_names = HashSet::new();
    for quest in &data.quests {
        let id = quest.definition.quest_obj.id;
        let name = quest.definition.name_id;
        if !quest_ids.insert(id) || !quest_names.insert(name) {
            return Err(format!("Duplicate quest identity: object {id}, name {name}").into());
        }
        if quest.difficulties.quest_obj.id != id || quest.difficulties.name_id != name {
            return Err(format!("Quest {id}: difficulty identity does not match definition").into());
        }
        validate_map(&quest.map, data, &format!("quest {id}"))?;
        for enemy in &quest.enemies {
            if !quest.map.zones.iter().any(|z| z.zone_id == enemy.mapid) {
                return Err(format!("Quest {id}: enemy references missing zone {}", enemy.mapid).into());
            }
        }
    }
    let mut attacks = HashSet::new();
    for attack in &data.attack_stats {
        if !attacks.insert(attack.attack_id) {
            return Err(format!("Duplicate attack id/hash: {:#010x}", attack.attack_id).into());
        }
    }
    Ok(())
}

fn validate_map(map: &MapData, data: &ServerData, context: &str) -> Result<(), Box<dyn Error>> {
    let mut ids = HashSet::new();
    let mut names = HashSet::new();
    for zone in &map.zones {
        if !ids.insert(zone.zone_id) || !names.insert(&zone.name) {
            return Err(format!("{context}: duplicate zone id/name {}, {:?}", zone.zone_id, zone.name).into());
        }
        for enemy in &zone.enemies {
            if !data.enemy_stats.enemies.contains_key(&enemy.enemy_name) {
                return Err(format!("{context}, zone {}: missing enemy {:?}", zone.zone_id, enemy.enemy_name).into());
            }
        }
        let mut chunks = HashSet::new();
        for chunk in &zone.chunks {
            if !chunks.insert(chunk.chunk_id) {
                return Err(format!("{context}, zone {}: duplicate chunk {}", zone.zone_id, chunk.chunk_id).into());
            }
            match chunk.enemy_spawn_type {
                EnemySpawnType::Automatic { min, max }
                | EnemySpawnType::AutomaticWithRespawn { min, max, .. } if min > max => {
                    return Err(format!("{context}, zone {}, chunk {}: spawn minimum {min} exceeds maximum {max}", zone.zone_id, chunk.chunk_id).into());
                }
                _ => {}
            }
        }
    }
    if !ids.contains(&map.init_map) {
        return Err(format!("{context}: missing initial zone {}", map.init_map).into());
    }
    for (kind, zone_id) in map.objects.iter().map(|v| ("object", v.zone_id))
        .chain(map.events.iter().map(|v| ("event", v.zone_id)))
        .chain(map.npcs.iter().map(|v| ("NPC", v.zone_id)))
        .chain(map.transporters.iter().map(|v| ("transporter", v.zone_id)))
    {
        if !ids.contains(&zone_id) {
            return Err(format!("{context}: {kind} references missing zone {zone_id}").into());
        }
    }
    Ok(())
}

pub fn validate_levels(stats: &[EnemyLevelBaseStats], context: &str) -> Result<(), Box<dyn Error>> {
    if stats.first().map(|s| s.level) != Some(1) {
        return Err(format!("{context}: enemy levels must start at 1 (runtime indexes level - 1)").into());
    }
    if stats.windows(2).any(|pair| pair[0].level >= pair[1].level) {
        return Err(format!("{context}: duplicate or unordered enemy levels").into());
    }
    Ok(())
}

pub fn validate_attack(stat: &AttackStatsReadable, path: &Path) -> Result<(), Box<dyn Error>> {
    let mul = match &stat.damage {
        DamageTypeReadable::Generic { mul } => *mul,
        DamageTypeReadable::PA { name, mul } => {
            if name.trim().is_empty() {
                return Err(format!("{}: empty PA name", path.display()).into());
            }
            *mul
        }
    };
    if stat.attack_name.trim().is_empty() || stat.damage_name.trim().is_empty() {
        return Err(format!("{}: empty attack/damage name", path.display()).into());
    }
    if !mul.is_finite() || mul < 0.0 {
        return Err(format!("{}: invalid damage multiplier for {:?}", path.display(), stat.attack_name).into());
    }
    Ok(())
}
