//! User-authorized authored range, not an original quest reconstruction.
use crate::{Error,map::Map,mutex::Mutex};
use std::sync::Arc;
use data_structs::{quest::QuestData,map::{EnemySpawnType,NPCData}};
use pso2packetlib::protocol::{ObjectHeader,ObjectType,questlist::{QuestType,QuestDifficultyType},spawn::NPCSpawnPacket};
pub(crate) const QUEST_ID:u32=908700; // Local authored namespace, not an extracted original ID.
pub(crate) const NAME_ID:u32=161500; // Verified installed client quest title.
pub(crate) const GUIDE_ID:u32=908701;
pub(crate) const HELP:&str="[CUSTOM Rockbear Range / Original rules not fully reproduced]\nTake the campship exit to the field. Leader commands:\n!rockbear start = 20s | free = unlimited | static = 20s stationary test | staticfree = stationary unlimited\n!rockbear stop = finish | !rockbear status = results\nFive rounds per quest; 2s result review after stop/timeout. Abandon quest to return; accept again to reset.\nLv20 / HP400000000 / DEF100 / all hit regions x1.0 / no rewards.\nStationary animation/control is experimental. Element, talents and PA timing still incomplete. This is a repair test range.";

pub(crate) fn install(quests:&mut Vec<QuestData>) {
    if quests.iter().any(|q|q.definition.quest_obj.id==QUEST_ID || q.definition.name_id==NAME_ID) {return;}
    let Some(mut q)=quests.iter().find(|q|q.definition.name_id==200030).cloned() else{return;};
    let Some(field)=q.map.zones.iter().find(|z|z.name=="campship_down").cloned() else{return;};
    q.definition.quest_obj.id=QUEST_ID;q.definition.name_id=NAME_ID;
    q.definition.quest_type=QuestType::StandardTraining;
    q.definition.difficulties=QuestDifficultyType::NORMAL;
    q.definition.req_level=1;q.definition.enemy_level=20;
    q.difficulties.quest_obj=q.definition.quest_obj;q.difficulties.name_id=NAME_ID;
    q.difficulties.diffs[0].req_level=1;q.difficulties.diffs[0].monster_level=20;
    q.enemies.clear();q.completion.clear();
    for zone in &mut q.map.zones {
        zone.enemies.clear();
        for chunk in &mut zone.chunks {chunk.enemy_spawn_type=EnemySpawnType::Disabled;}
    }
    let mut position=field.default_location;
    position.pos_x=half::f16::from_f32(position.pos_x.to_f32()+4.0);
    // Reused known lobby NPC appearance. Its original shop/story menu is not used.
    q.map.npcs.push(NPCData {zone_id:field.zone_id,is_active:true,data:NPCSpawnPacket {
        object:ObjectHeader{id:GUIDE_ID,entity_type:ObjectType::Object,..Default::default()},
        name:"Npc_06".to_string().into(),position,unk8:1101004800,unk12:1,..Default::default()
    },lua_data:None});
    quests.push(q);
}

pub(crate) async fn command(map:&Arc<Mutex<Map>>,zone:usize,id:u32,action:&str,leader:bool)->Result<(),Error> {
    let token=map.lock().await.custom_command(zone,id,action,leader).await?;
    if let Some(token)=token {
        let weak=Arc::downgrade(map);
        tokio::spawn(async move {
            loop {
                tokio::time::sleep(std::time::Duration::from_millis(100)).await;
                let Some(map)=weak.upgrade() else {break;};
                if !map.lock().await.custom_tick(token).await {break;}
            }
        });
    }
    Ok(())
}

pub(crate) fn motion_targets(packet:&pso2packetlib::protocol::Packet,id:u32)->bool {
    use pso2packetlib::protocol::Packet;
    let is_target=|h:ObjectHeader|h.id==id && h.entity_type==ObjectType::Object;
    match packet {
        Packet::Movement(p)=>(p.ent1_id==Some(u64::from(id)) && p.ent1_type==Some(ObjectType::Object as u16)) || (p.ent2_id==Some(u64::from(id)) && p.ent2_type==Some(ObjectType::Object as u16)),
        Packet::MovementEnd(p)=>is_target(p.unk1) || is_target(p.unk2),
        Packet::MovementAction(p)=>is_target(p.performer),
        Packet::ActionUpdate(p)=>is_target(p.performer),
        _=>false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use data_structs::{SerDeFile,ServerData};
    #[test]
    fn local_custom_rockbear_motion_headers_never_suppress_players_or_other_targets() {
        use pso2packetlib::protocol::{Packet,objects::*};
        let enemy=ObjectHeader{id:77,entity_type:ObjectType::Object,..Default::default()};
        let player=ObjectHeader{id:77,entity_type:ObjectType::Player,..Default::default()};
        for actor in [enemy,player] {
            let packets=[Packet::Movement(MovementPacket{ent1_id:Some(77),ent1_type:Some(actor.entity_type as u16),..Default::default()}),
                Packet::MovementEnd(MovementEndPacket{unk2:actor,..Default::default()}),
                Packet::MovementAction(MovementActionPacket{performer:actor,..Default::default()}),
                Packet::ActionUpdate(ActionUpdatePacket{performer:actor,..Default::default()})];
            for p in packets {assert_eq!(motion_targets(&p,77),actor.entity_type==ObjectType::Object);assert!(!motion_targets(&p,78));}
        }
    }
    #[test]
    fn local_custom_rockbear_catalogue_is_separate_normal_only_no_spawns_or_rewards() {
        let data=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap();
        let original=serde_json::to_value(&data.quests).unwrap();let mut qs=data.quests;
        install(&mut qs);assert_eq!(qs.len(),original.as_array().unwrap().len()+1);
        assert_eq!(serde_json::to_value(&qs[..qs.len()-1]).unwrap(),original);
        install(&mut qs);assert_eq!(qs.len(),original.as_array().unwrap().len()+1);
        let q=qs.last().unwrap();assert_eq!(q.definition.quest_type,QuestType::StandardTraining);
        assert_eq!(q.definition.name_id,NAME_ID);assert_eq!(q.difficulties.quest_obj.id,QUEST_ID);
        assert_eq!(q.difficulties.diffs[0].monster_level,20);
        assert!(q.completion.is_empty() && q.enemies.is_empty());
        assert!(q.map.zones.iter().all(|z|z.enemies.is_empty() && z.chunks.iter().all(|c|matches!(c.enemy_spawn_type,EnemySpawnType::Disabled))));
        assert!(q.map.npcs.iter().any(|n|n.data.object.id==GUIDE_ID));
        let quest_obj=q.definition.quest_obj;
        let quests=crate::quests::Quests::load(qs);
        assert_eq!(quests.get_category(QuestType::StandardTraining,&[]).quests.len(),1);
        let ids=std::sync::atomic::AtomicU32::new(1);
        for diff in 1..=8 {assert!(quests.get_quest(pso2packetlib::protocol::questlist::AcceptQuestPacket {quest_obj,diff,..Default::default()},&ids).is_err());}
    }
}
