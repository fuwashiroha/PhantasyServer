//! Phantom Time owner-effect candidate. Named roots come from villain.ski;
//! 112018 from the isolated client's original registry. 20 s / 5 s from swiki.
//! Server-authoritative gear spending is NOT implemented by this response.
use std::time::{Duration,Instant};
use pso2packetlib::protocol::{Packet,ObjectHeader,ObjectType,objects::{Unk0424Packet,Unk0425Packet},playerstatus::DealDamagePacket};
#[derive(Default)]
pub(crate) struct PhantomTime {started:Option<Instant>,removed:bool,guard_removed:bool}
pub(crate) fn is_request(id:u32)->bool {matches!(id,2598426158|2551611144|4037881015|379524748|3033509506)}
fn remove(owner:ObjectHeader,id:u32)->Packet {Packet::Unk0425(Unk0425Packet{unk1:owner,unk2:owner,unk3:id,..Default::default()})}
fn apply(owner:ObjectHeader,id:u32,seconds:f32)->Packet {
    let mut tail=[0;12];tail[..4].copy_from_slice(&seconds.to_le_bytes());
    tail[4..8].copy_from_slice(&1u32.to_le_bytes());tail[8..].copy_from_slice(&4u32.to_le_bytes());
    Packet::Unk0424(Unk0424Packet{unk1:owner,unk2:owner,unk3:owner,unk4:id,unk5:u32::MAX,unk6:tail,unk7:[0;12]})
}
impl PhantomTime {
    pub(crate) fn invulnerable(&self,now:Instant)->bool {
        !self.removed && self.started.is_some_and(|t| now.saturating_duration_since(t)<Duration::from_secs(5))
    }
    fn clear_guard(&mut self,owner:ObjectHeader)->Vec<Packet> {
        if self.guard_removed || self.started.is_none() {return vec![];}
        self.guard_removed=true;
        vec![remove(owner,112022),remove(owner,112021)]
    }
    pub(crate) fn cancel(&mut self,owner:ObjectHeader)->Vec<Packet> {
        if self.started.is_none() || self.removed {return vec![];}
        self.removed=true;
        let mut replies=vec![remove(owner,112018)];replies.extend(self.clear_guard(owner));replies
    }
    pub(crate) fn expire(&mut self,owner:ObjectHeader,now:Instant)->Vec<Packet> {
        if self.removed {return vec![];}
        if self.started.is_some_and(|t|now.saturating_duration_since(t)>=Duration::from_secs(20)) {return self.cancel(owner);}
        if self.started.is_some_and(|t|now.saturating_duration_since(t)>=Duration::from_secs(5)) {return self.clear_guard(owner);}
        vec![]
    }
    pub(crate) fn handle(&mut self,owner:ObjectHeader,learned:bool,p:&DealDamagePacket,now:Instant)->Vec<Packet> {
        if !learned || owner.entity_type!=ObjectType::Player || p.inflicter!=owner || p.target!=owner {return vec![];}
        match p.attack_id {
            2598426158|2551611144 if p.hitbox_id==u32::MAX => {
                if self.started.is_some_and(|t|now.saturating_duration_since(t)<Duration::from_secs(5)
                    || (!self.removed&&now.saturating_duration_since(t)<Duration::from_secs(20))) {return vec![];}
                self.started=Some(now);self.removed=false;self.guard_removed=false;
                // Original villain.ski kind-13 chain applies all three effects.
                // Registry duration +28: Time=20, invulnerability/visual=5.
                vec![apply(owner,112018,20.0),apply(owner,112022,5.0),apply(owner,112021,5.0)]
            },
            4037881015|379524748|3033509506 if matches!(p.hitbox_id,0|u32::MAX)&&self.started.is_some()&&!self.removed=>{
                self.cancel(owner)
            },
            _=>vec![],
        }
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    fn owner()->ObjectHeader {ObjectHeader{id:1,entity_type:ObjectType::Player,..Default::default()}}
    fn start()->DealDamagePacket {DealDamagePacket{inflicter:owner(),target:owner(),attack_id:2598426158,hitbox_id:u32::MAX,..Default::default()}}
    #[test]
    fn local_phantom_time_owner_learning_recast_and_expiry() {
        let h=owner();let p=start();let now=Instant::now();let mut t=PhantomTime::default();
        assert!(t.handle(h,false,&p,now).is_empty());
        let mut bad=p.clone();bad.target.id=2;assert!(t.handle(h,true,&bad,now).is_empty());
        bad=p.clone();bad.inflicter.id=2;assert!(t.handle(h,true,&bad,now).is_empty());
        bad=p.clone();bad.hitbox_id=0;assert!(t.handle(h,true,&bad,now).is_empty());
        let replies=t.handle(h,true,&p,now);assert_eq!(replies.len(),3);
        for (packet,id,secs) in [(0,112018,20.0),(1,112022,5.0),(2,112021,5.0)] {
            let Packet::Unk0424(effect)=&replies[packet] else{panic!()};
            assert_eq!(effect.unk4,id);assert_eq!(f32::from_le_bytes(effect.unk6[..4].try_into().unwrap()),secs);
        }
        assert!(t.handle(h,true,&p,now+Duration::from_secs(6)).is_empty());
        let mut end=p.clone();end.attack_id=4037881015;end.hitbox_id=0;
        let removed=t.handle(h,true,&end,now+Duration::from_secs(2));assert_eq!(removed.len(),3);
        assert!(!t.invulnerable(now+Duration::from_secs(2)));
        assert!(t.handle(h,true,&p,now+Duration::from_secs(4)).is_empty());
        assert_eq!(t.handle(h,true,&p,now+Duration::from_secs(5)).len(),3);
        // A late tick clears both guard effects, but leaves the 20-second Time.
        assert_eq!(t.expire(h,now+Duration::from_secs(24)).len(),2);
        let ended=t.expire(h,now+Duration::from_secs(25));assert_eq!(ended.len(),1);
        assert!(matches!(&ended[0],Packet::Unk0425(p) if p.unk3==112018));
        assert!(t.expire(h,now+Duration::from_secs(26)).is_empty());
        assert_eq!(t.handle(h,true,&p,now+Duration::from_secs(30)).len(),3);
        assert_eq!(t.cancel(h).len(),3);assert!(t.cancel(h).is_empty());
        assert!(t.handle(h,true,&p,now+Duration::from_secs(34)).is_empty());
        assert_eq!(t.handle(h,true,&p,now+Duration::from_secs(35)).len(),3);
    }
    #[test]
    fn local_phantom_time_guard_deadline_does_not_depend_on_tick_or_rearm() {
        let mut t=PhantomTime::default();let now=Instant::now();let h=owner();let p=start();
        assert!(!t.invulnerable(now));t.handle(h,true,&p,now);
        assert!(t.invulnerable(now+Duration::from_millis(4999)));
        assert!(!t.invulnerable(now+Duration::from_secs(5)));
        assert!(t.handle(h,true,&p,now+Duration::from_secs(5)).is_empty());
        assert_eq!(t.expire(h,now+Duration::from_secs(5)).len(),2);
        assert!(t.expire(h,now+Duration::from_secs(6)).is_empty());
        assert_eq!(t.expire(h,now+Duration::from_secs(20)).len(),1);
        assert_eq!(t.handle(h,true,&p,now+Duration::from_secs(20)).len(),3);
        assert!(t.invulnerable(now+Duration::from_secs(21)));
    }
}
