//! Opt-in, process-bounded evidence for selected unsupported item/shop packets.
//! Defaults stay metadata-only. Never infers packet meaning or sends a reply.
use crate::Error;
use pso2packetlib::protocol::Packet;
use serde::{Deserialize, Serialize};
use std::{sync::{Mutex, OnceLock}, time::{Duration, Instant}};

// These exact unknown headers were observed in the local Classic InGame logs.
// Restrict the first evidence pass to item/shop categories, excluding all login,
// chat, friend, mail and symbol-art categories even if the operator lists them.
const ALLOWED: &[(u8,u16)] = &[(0x0f,0x28),(0x0f,0xaa),(0x0f,0xda),
    (0x1c,0x04),(0x1c,0x1e),(0x1c,0x46)];
const MAX_BYTES: usize = 256;
const MAX_PER_HEADER: u8 = 3;
const MAX_TOTAL: u8 = 12;
const MAX_SECONDS: u16 = 300;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(default, deny_unknown_fields)]
pub struct TraceConfig {
    pub enabled: bool,
    pub account_id: u32,
    pub label: String,
    pub headers: Vec<(u8,u16)>,
    pub max_bytes: usize,
    pub samples_per_header: u8,
    pub total_samples: u8,
    pub start_after_seconds: u16,
    pub window_seconds: u16,
}
impl Default for TraceConfig {
    fn default() -> Self {
        Self {enabled:false,account_id:0,label:String::new(),headers:vec![],
            max_bytes:128,samples_per_header:2,total_samples:12,start_after_seconds:0,window_seconds:120}
    }
}

#[derive(Debug, Serialize)]
struct Sample {
    schema_version: u8,
    label: String,
    account_id: u32,
    connection_id: usize,
    header: (u8,u16),
    flags: u8,
    original_len: usize,
    captured_len: usize,
    truncated: bool,
    payload_prefix_hex: String,
    header_sample: u8,
    total_sample: u8,
    elapsed_ms: u64,
}
struct TraceWindow {
    config: TraceConfig,
    counts: Vec<u8>,
    total: u8,
    started: Option<Instant>,
    armed_at: Instant,
}
impl TraceWindow {
    fn new(config: &TraceConfig) -> Result<Option<Self>,Error> {
        if !config.enabled {return Ok(None);}
        if config.account_id == 0 || config.label.is_empty() || config.label.len()>40
            || !config.label.bytes().all(|b| b.is_ascii_alphanumeric() || b==b'-' || b==b'_')
            || config.headers.is_empty() || config.headers.len()>ALLOWED.len()
            || config.max_bytes==0 || config.max_bytes>MAX_BYTES
            || config.samples_per_header==0 || config.samples_per_header>MAX_PER_HEADER
            || config.total_samples==0 || config.total_samples>MAX_TOTAL
            || config.window_seconds==0 || config.window_seconds>MAX_SECONDS
            || config.start_after_seconds>MAX_SECONDS {
            return Err(Error::InvalidInput("request_trace_limits"));
        }
        for (i,h) in config.headers.iter().enumerate() {
            if !ALLOWED.contains(h) || config.headers[..i].contains(h) {
                return Err(Error::InvalidInput("request_trace_headers"));
            }
        }
        Ok(Some(Self {config:config.clone(),counts:vec![0;config.headers.len()],total:0,started:None,armed_at:Instant::now()}))
    }
    fn sample(&mut self, account_id:u32, connection_id:usize, in_game:bool,
        packet:&Packet, now:Instant) -> Option<Sample> {
        if !in_game || account_id!=self.config.account_id || self.total>=self.config.total_samples {return None;}
        let since_arm=now.checked_duration_since(self.armed_at)?;
        let delay=Duration::from_secs(u64::from(self.config.start_after_seconds));
        if since_arm<delay || since_arm>=delay+Duration::from_secs(u64::from(self.config.window_seconds)) {return None;}
        // No arbitrary serialization of typed packets, authentication or text.
        let Packet::Unknown((header,body))=packet else {return None;};
        let key=(header.id,header.subid);
        let i=self.config.headers.iter().position(|h| *h==key)?;
        if self.counts[i]>=self.config.samples_per_header {return None;}
        let elapsed=match self.started {
            Some(start)=>now.checked_duration_since(start)?,
            None=>{self.started=Some(now);Duration::ZERO},
        };
        if elapsed>=Duration::from_secs(u64::from(self.config.window_seconds)) {return None;}
        let prefix=&body[..body.len().min(self.config.max_bytes)];
        let mut hex=String::with_capacity(prefix.len()*2);
        use std::fmt::Write;
        for b in prefix {let _=write!(hex,"{b:02x}");}
        self.counts[i]+=1;self.total+=1;
        Some(Sample {schema_version:1,label:self.config.label.clone(),account_id,connection_id,
            header:key,flags:header.flag.bits(),original_len:body.len(),captured_len:prefix.len(),
            truncated:prefix.len()!=body.len(),payload_prefix_hex:hex,
            header_sample:self.counts[i],total_sample:self.total,elapsed_ms:elapsed.as_millis() as u64})
    }
}

// One budget per server process, shared across blocks, connections and reconnects.
static TRACE: OnceLock<Mutex<TraceWindow>> = OnceLock::new();
pub(crate) fn configure(config: Option<&TraceConfig>) -> Result<(),Error> {
    if let Some(window)=config.map(TraceWindow::new).transpose()?.flatten() {
        log::warn!("request_trace_armed label={} account={} delay_seconds={} window_seconds={} headers={} max_samples={}",
            window.config.label,window.config.account_id,window.config.start_after_seconds,
            window.config.window_seconds,window.config.headers.len(),window.config.total_samples);
        TRACE.set(Mutex::new(window)).map_err(|_|Error::InvalidInput("request_trace_already_configured"))?;
    }
    Ok(())
}
pub(crate) fn observe(account_id:u32, connection_id:usize, in_game:bool, packet:&Packet) {
    let sample=TRACE.get().and_then(|trace| trace.lock().ok()
        .and_then(|mut window|window.sample(account_id,connection_id,in_game,packet,Instant::now())));
    if let Some(sample)=sample {
        if let Ok(json)=serde_json::to_string(&sample) {log::warn!("request_trace {json}");}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pso2packetlib::protocol::PacketHeader;
    fn config()->TraceConfig {TraceConfig {enabled:true,account_id:1,label:"telepipe-01".into(),headers:vec![(0x0f,0x28),(0x1c,4)],..Default::default()}}
    fn unknown(id:u8, subid:u16, body:&[u8])->Packet {Packet::Unknown((PacketHeader::new(id,subid,Default::default()),body.to_vec()))}
    #[test]
    fn local_request_trace_default_and_legacy_settings_disable_payload_capture() {
        assert!(TraceWindow::new(&TraceConfig::default()).unwrap().is_none());
        let old:crate::settings::Settings=toml::from_str("server_name='private test'").unwrap();
        assert!(old.request_trace.is_none());
        assert!(!toml::to_string(&old).unwrap().contains("request_trace"));
        assert!(TRACE.get().is_none());
    }
    #[test]
    fn local_request_trace_config_rejects_protected_unknown_duplicate_and_unbounded_inputs() {
        for h in [(0x11,0),(7,55),(0x18,20),(0x1a,6),(0x2f,2),(0x0f,0xff)] {
            let mut c=config();c.headers=vec![h];assert!(TraceWindow::new(&c).is_err());
        }
        for index in 0..10 {
            let mut c=config();match index {
                0=>c.headers.push(c.headers[0]),1=>c.headers.clear(),2=>c.account_id=0,
                3=>c.label="bad\nlabel".into(),4=>c.max_bytes=MAX_BYTES+1,
                5=>c.max_bytes=0,6=>c.samples_per_header=MAX_PER_HEADER+1,
                7=>c.total_samples=MAX_TOTAL+1,8=>c.window_seconds=MAX_SECONDS+1,
                _=>c.window_seconds=0,
            };assert!(TraceWindow::new(&c).is_err());
        }
    }
    #[test]
    fn local_request_trace_account_state_and_packet_type_gates_do_not_consume_budget() {
        let mut w=TraceWindow::new(&config()).unwrap().unwrap();let now=Instant::now();
        let p=unknown(0x0f,0x28,b"abc");
        assert!(w.sample(2,1,true,&p,now).is_none());assert!(w.sample(1,1,false,&p,now).is_none());
        assert!(w.sample(1,1,true,&Packet::SalonEntryRequest,now).is_none());
        assert!(w.sample(1,1,true,&unknown(7,55,b"chat"),now).is_none());
        assert!(w.sample(1,1,true,&unknown(0x11,0,b"secret"),now).is_none());
        assert!(w.started.is_none());assert_eq!(w.total,0);
        assert_eq!(w.sample(1,1,true,&p,now).unwrap().header_sample,1);
    }
    #[test]
    fn local_request_trace_prefix_flags_empty_payload_and_json_are_exact() {
        let mut c=config();c.max_bytes=3;let mut w=TraceWindow::new(&c).unwrap().unwrap();let now=Instant::now();
        let sample=w.sample(1,7,true,&unknown(0x0f,0x28,&[0,0xff,0x80,1]),now).unwrap();
        assert_eq!((sample.original_len,sample.captured_len,sample.truncated),(4,3,true));
        assert_eq!(sample.payload_prefix_hex,"00ff80");assert_eq!(sample.flags,0);
        let value:serde_json::Value=serde_json::from_str(&serde_json::to_string(&sample).unwrap()).unwrap();
        assert_eq!(value["connection_id"],7);assert_eq!(value["header"],serde_json::json!([15,40]));
        let empty=w.sample(1,7,true,&unknown(0x0f,0x28,&[]),now).unwrap();
        assert_eq!(empty.captured_len,0);assert!(!empty.truncated);assert_eq!(empty.header_sample,2);
    }
    #[test]
    fn local_request_trace_header_total_and_reconnect_budgets_are_shared() {
        let mut c=config();c.total_samples=3;let mut w=TraceWindow::new(&c).unwrap().unwrap();let now=Instant::now();
        let p=unknown(0x0f,0x28,b"a");let q=unknown(0x1c,4,b"b");
        assert!(w.sample(1,1,true,&p,now).is_some());assert!(w.sample(1,2,true,&p,now).is_some());
        assert!(w.sample(1,3,true,&p,now).is_none());
        assert_eq!(w.sample(1,3,true,&q,now).unwrap().total_sample,3);
        assert!(w.sample(1,4,true,&q,now).is_none());assert_eq!(w.counts,vec![2,1]);
    }
    #[test]
    fn local_request_trace_time_window_expires_without_reset_on_reconnect() {
        let mut c=config();c.window_seconds=1;let mut w=TraceWindow::new(&c).unwrap().unwrap();let now=Instant::now();
        let p=unknown(0x0f,0x28,b"a");let q=unknown(0x1c,4,b"b");
        assert!(w.sample(1,1,true,&p,now).is_some());
        assert!(w.sample(1,2,true,&q,now+Duration::from_secs(1)).is_none());
        assert!(w.sample(1,3,true,&q,now+Duration::from_secs(300)).is_none());assert_eq!(w.total,1);
    }
    #[test]
    fn local_request_trace_optional_configuration_roundtrips_without_runtime_activation() {
        let mut settings=crate::settings::Settings::default();settings.request_trace=Some(config());
        let text=toml::to_string_pretty(&settings).unwrap();
        let decoded:crate::settings::Settings=toml::from_str(&text).unwrap();
        let cfg=decoded.request_trace.unwrap();assert_eq!(cfg.headers,config().headers);
        assert!(TraceWindow::new(&cfg).unwrap().is_some());assert!(TRACE.get().is_none());
    }
    #[test]
    fn local_request_trace_delayed_window_ignores_login_noise_and_expires_even_without_samples() {
        let mut c=config();c.start_after_seconds=10;c.window_seconds=2;
        let mut w=TraceWindow::new(&c).unwrap().unwrap();let now=w.armed_at;
        let p=unknown(0x0f,0x28,b"probe");
        assert!(w.sample(1,1,true,&p,now+Duration::from_secs(9)).is_none());assert_eq!(w.total,0);
        assert!(w.sample(1,1,true,&p,now+Duration::from_secs(10)).is_some());
        assert!(w.sample(1,1,true,&p,now+Duration::from_secs(12)).is_none());
        let mut empty=TraceWindow::new(&c).unwrap().unwrap();let late=empty.armed_at+Duration::from_secs(13);
        assert!(empty.sample(1,1,true,&p,late).is_none());assert!(empty.started.is_none());
        c.start_after_seconds=MAX_SECONDS+1;assert!(TraceWindow::new(&c).is_err());
    }
}
