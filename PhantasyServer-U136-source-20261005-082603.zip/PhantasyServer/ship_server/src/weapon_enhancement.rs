//! Own-weapon powers, before affixes and class effects. No laboratory transaction.
use crate::Error;
use pso2packetlib::protocol::{items::{Item,ItemType},models::item_attrs::WeaponAttrs};
use std::{collections::HashMap,sync::OnceLock};
#[derive(serde::Deserialize)]
struct Row {id:u16,subid:u16,new_type:bool,rarity:u8,supported:bool}
#[derive(serde::Deserialize)]
struct Catalogue {weapon_rows:Vec<Row>}
fn catalogue()-> &'static HashMap<(u16,u16),Row> {
    static DATA:OnceLock<HashMap<(u16,u16),Row>>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-weapon-enhancement.json"))
        .expect("audited weapon generations").weapon_rows.into_iter().map(|r|((r.id,r.subid),r)).collect())
}
pub(crate) fn percent(new_type:bool,rarity:u8,level:u8)->Result<u32,Error> {
    if new_type {
        if level>35 {return Err(Error::InvalidInput("weapon_enhancement_level"));}
        return Ok(100+u32::from(level));
    }
    if level>10 {return Err(Error::InvalidInput("weapon_enhancement_level"));}
    let row=match rarity {
        1..=3=>[100,104,108,112,117,122,127,132,138,144,150],
        4..=6=>[100,104,108,112,117,122,129,136,144,152,160],
        7..=9=>[100,104,109,115,122,129,137,145,154,164,175],
        10=>[100,104,109,115,122,130,140,150,162,175,190],
        11=>[100,105,111,118,126,135,145,156,168,181,195],
        12=>[100,106,113,121,130,140,150,161,173,186,200],
        13=>[100,104,108,112,116,120,124,128,132,136,140],
        _=>return Err(Error::InvalidInput("weapon_enhancement_rarity")),
    };
    Ok(row[level as usize])
}
pub(crate) fn powers(item:&Item,attrs:&WeaponAttrs)->Result<[u32;3],Error> {
    let base=[u32::from(attrs.melee_dmg),u32::from(attrs.range_dmg),u32::from(attrs.gender_force_dmg.force_dmg)];
    let ItemType::Weapon(weapon)=&item.data else{return Err(Error::InvalidInput("weapon_enhancement_item_type"))};
    if weapon.grind==0 {return Ok(base);}
    if item.id.id!=attrs.id || item.id.subid!=attrs.subid {return Err(Error::InvalidInput("weapon_enhancement_identity"));}
    let row=catalogue().get(&(attrs.id,attrs.subid)).ok_or(Error::InvalidInput("weapon_enhancement_unverified_generation"))?;
    if !row.supported {return Err(Error::InvalidInput("weapon_enhancement_source_conflict"));}
    if row.rarity!=attrs.rarity {return Err(Error::InvalidInput("weapon_enhancement_rarity_mismatch"));}
    // Recompute from saved enhancement level. The adjacent grind_percent byte
    // cannot authorize an arbitrary multiplier. Affixes/potentials are separate.
    let percentage=percent(row.new_type,attrs.rarity,weapon.grind)?;
    Ok(base.map(|value|value*percentage/100))
}
