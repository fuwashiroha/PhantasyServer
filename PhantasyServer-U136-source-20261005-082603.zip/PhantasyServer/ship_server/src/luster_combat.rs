//! Lu individual hit requests. Runtime style/gear/Voltage/guard authority is
//! separate from damage descriptors and learned native skill prerequisites.
use crate::{Error,native_class_tree::ClassTree,sql::CharData};
use data_structs::stats::AttackType;
use pso2packetlib::protocol::models::character::Class;
use std::{collections::HashMap,sync::OnceLock};
#[derive(serde::Deserialize)]
pub(crate) struct Attack {pub id:u32,pub required_skills:Vec<String>}
#[derive(serde::Deserialize)]
struct Catalogue {attacks:Vec<Attack>}
pub(crate) fn attacks()-> &'static HashMap<u32,Attack> {
    static DATA:OnceLock<HashMap<u32,Attack>>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-luster-attacks.json"))
        .expect("pinned Lu damage descriptors").attacks.into_iter().map(|a|(a.id,a)).collect())
}
#[derive(Debug,Clone,Default)]
pub(crate) struct LusterCombat {tree:Option<ClassTree>,weapon:Option<u16>,main:bool,main_class:Class}
impl LusterCombat {
    pub(crate) fn build(c:&CharData,weapon:Option<u16>)->Result<Self,Error> {
        let main=c.character.classes.main_class==Class::Luster;
        if !main && c.character.classes.sub_class!=Class::Luster {return Ok(Self::default());}
        let info=&c.character.classes.luster_info;
        let tree=c.native_class_trees.get(&14).cloned().unwrap_or_default().at_level(14,info.level1)?;
        tree.validate(14,info.level1,info.level2)?;
        Ok(Self{tree:Some(tree),weapon,main,main_class:c.character.classes.main_class})
    }
    pub(crate) fn validate_attack(&self,id:u32)->Result<(),Error> {
        let Some(attack)=attacks().get(&id) else{return Ok(())};
        if !self.main {return Err(Error::InvalidInput("luster_attack_class"));}
        let tree=self.tree.as_ref().ok_or(Error::InvalidInput("luster_attack_class"))?;
        if self.weapon!=Some(7) {return Err(Error::InvalidInput("luster_attack_weapon"));}
        if attack.required_skills.iter().any(|n|tree.rank(n)==0) {
            return Err(Error::InvalidInput("luster_attack_skill"));
        }
        Ok(())
    }
    pub(crate) fn melee_region(&self,id:u32)->bool {
        self.main && self.tree.is_some() && self.weapon==Some(7) && attacks().contains_key(&id)
    }
    pub(crate) fn multiplier(&self,attribute:AttackType)->f32 {
        let Some(tree)=&self.tree else{return 1.0};
        let rank=tree.rank("SlayerAllAttackBonus") as usize;
        let mut power=match attribute {
            AttackType::Mel=>[1.0,1.52,1.54,1.56,1.58,1.60,1.62,1.64,1.66,1.68,1.70][rank],
            AttackType::Rng=>[1.0,1.32,1.34,1.36,1.38,1.40,1.42,1.44,1.46,1.48,1.50][rank],
            AttackType::Tec=>[1.0,1.37,1.39,1.41,1.43,1.45,1.47,1.49,1.51,1.53,1.55][rank],
        };
        power*=[1.0,1.01,1.02,1.03,1.04,1.05][tree.rank("SlayerHighLevelBonus") as usize];
        if self.main && self.weapon==Some(7) {
            power*=[1.0,1.10,1.20,1.30,1.40,1.45,1.50,1.55,1.60,1.65,1.70][tree.rank("SlayerWeaponBonus1") as usize]
                *[1.0,1.10,1.15,1.20,1.25,1.30,1.35,1.40,1.45,1.50,1.55][tree.rank("SlayerWeaponBonus2") as usize];
        }
        power*self.sub_gunslash(attribute)
    }
    pub(crate) fn sub_gunslash(&self,attribute:AttackType)->f32 {
        if self.main || self.weapon!=Some(7)
            || self.tree.as_ref().is_none_or(|t|t.rank("SlayerTalent")==0) {return 1.0;}
        // Raw skill factors: the swiki total columns also include Voltage and
        // All Attack Bonus, which must not be applied here a second time.
        let (melee,ranged)=match self.main_class {
            Class::Hunter=>(1.40,1.45), Class::Fighter=>(1.10,1.15),
            Class::Ranger=>(2.50,1.10), Class::Gunner=>(1.60,1.30),
            Class::Force=>(2.50,2.40), Class::Techer|Class::Braver=>(1.90,1.85),
            Class::Bouncer=>(1.80,1.70), Class::Summoner=>(1.55,1.50),
            _=>return 1.0,
        };
        match attribute {AttackType::Mel=>melee,AttackType::Rng=>ranged,AttackType::Tec=>1.0}
    }
}

#[cfg(test)]
mod bonus_tests {
    use super::*;
    #[test]
    fn local_luster_bonus_all_rank_tables_match_current_swiki_not_struck_history() {
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-luster-damage-skills.json")).unwrap();
        for (skill,heading,label,attribute) in [
            ("SlayerWeaponBonus1","Luウェポンボーナス1","Luウェポン1 威力",AttackType::Rng),
            ("SlayerWeaponBonus2","Luウェポンボーナス1","Luウェポン2 威力",AttackType::Rng),
            ("SlayerHighLevelBonus","ハイレベルボーナスLu","威力",AttackType::Rng),
            ("SlayerAllAttackBonus","オールアタックボーナスLu","打撃威力",AttackType::Mel),
            ("SlayerAllAttackBonus","オールアタックボーナスLu","射撃威力",AttackType::Rng),
            ("SlayerAllAttackBonus","オールアタックボーナスLu","法撃威力",AttackType::Tec),
        ] {
            let s=f["sections"].as_array().unwrap().iter().find(|s|s["title"].as_str().unwrap().starts_with(heading)).unwrap();
            let row=s["tables"].as_array().unwrap().iter().flat_map(|t|t.as_array().unwrap()).find(|r|r.as_array().unwrap().iter().any(|v|v==label)).unwrap();
            let cells:Vec<_>=row.as_array().unwrap().iter().filter_map(|c|c.as_str().unwrap().strip_suffix('%')).collect();
            assert_eq!(cells.len(),if skill=="SlayerHighLevelBonus" {5} else {10});
            for (i,value) in cells.iter().enumerate() {
                // Arithmetic in isolation; production build validates the complete tree.
                let mut tree=ClassTree::default();tree.ranks.insert(skill.into(),i as u8+1);
                let c=LusterCombat{tree:Some(tree),weapon:Some(7),main:true,main_class:Class::Luster};
                assert!((c.multiplier(attribute.clone())-value.parse::<f32>().unwrap()/100.0).abs()<1e-6);
            }
        }
    }
}
