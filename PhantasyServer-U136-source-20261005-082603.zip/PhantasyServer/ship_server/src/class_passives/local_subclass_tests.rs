use super::*;
use pso2packetlib::protocol::{models::character::{Class,ClassLevel},objects::ChangeClassRequestPacket};
use crate::native_class_tree::ClassTree;
fn learn(slot:u8,t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(slot,t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn character(learned:bool)->CharData {
    let mut c=CharData::default();
    for class in [Class::Hunter,Class::Fighter,Class::Gunner,Class::Techer,Class::Braver,Class::Force] {
        c.character.classes.main_class=class;*c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};
    }
    if learned {for e in subclass_effects() {let t=c.native_class_trees.remove(&e.slot).unwrap_or_default();
        c.native_class_trees.insert(e.slot,learn(e.slot,t,&e.name,if e.name=="ChargeShoot" {5}else{1}));}}
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;c
}
fn check(packets:&[Packet],main:Class,sub:Class,learned:bool) {
    for e in subclass_effects() {
        let cleared:Vec<_>=packets.iter().enumerate().filter(|(_,p)|matches!(p,Packet::Unk0425(p) if p.unk3==e.id)).collect();
        assert_eq!(cleared.len(),1,"must clear once: {}",e.name);
        let added:Vec<_>=packets.iter().enumerate().filter(|(_,p)|matches!(p,Packet::Unk0424(p) if p.unk4==e.id)).collect();
        let applicable=learned && (e.slot==main as u8 || (matches!(main as u8,0..=7|9) && e.slot==sub as u8));
        if !applicable {assert!(added.is_empty(),"unexpected {}",e.name);continue;}
        assert_eq!(added.len(),1);assert!(cleared[0].0<added[0].0);
        let Packet::Unk0424(p)=added[0].1 else{panic!()};let rank=if e.name=="ChargeShoot" {5u32}else{1u32};assert_eq!(p.unk6[4..8],rank.to_le_bytes());
    }
}
#[test]
fn local_subclass_effects_seven_original_bindings_and_role_transitions() {
    assert_eq!(subclass_effects().len(),7);let mut ids=std::collections::HashSet::new();
    for e in subclass_effects() {assert!(ids.insert(e.id));assert_eq!(e.kind,16);
        let original=effects().iter().find(|a|a.name==e.name && a.slot==e.slot).unwrap();assert_eq!((original.id,original.hash),(e.id,e.hash));}
    for learned in [false,true] {let mut c=character(learned);
        for (main,sub) in [(Class::Hunter,Class::Fighter),(Class::Hunter,Class::Gunner),(Class::Force,Class::Techer),(Class::Hunter,Class::Braver),
            (Class::Fighter,Class::Braver),(Class::Braver,Class::Fighter),(Class::Hunter,Class::Unknown),(Class::Hero,Class::Unknown),
            (Class::Hero,Class::Braver),(Class::Braver,Class::Braver)] {
            c.character.classes.main_class=main;c.character.classes.sub_class=sub;
            for old in [None,Some(3),Some(6)] {
                let p=synchronize(ObjectHeader::default(),&c,old).unwrap();check(&p,main,sub,learned);
                for other in effects().iter().filter(|e|e.slot==sub as u8 && e.slot!=main as u8 && !ids.contains(&e.id)) {
                    assert!(!p.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==other.id)),"unaudited {}",other.name);
                }
            }
        }
    }
}
#[test]
fn local_subclass_effects_saved_tree_validation_and_charge_rank_refresh() {
    let mut c=character(true);c.character.classes.sub_class=Class::Braver;
    for rank in 0..=5 {
        let t=c.native_class_trees.get_mut(&6).unwrap();if rank==0 {t.ranks.remove("ChargeShoot");}else{t.ranks.insert("ChargeShoot".into(),rank);}
        let p=synchronize(ObjectHeader::default(),&c,None).unwrap();let adds:Vec<_>=p.iter().filter_map(|p|match p {Packet::Unk0424(p) if p.unk4==170026=>Some(p),_=>None}).collect();
        if rank==0 {assert!(adds.is_empty());}else {assert_eq!(adds.len(),1);assert_eq!(adds[0].unk6[4..8],u32::from(rank).to_le_bytes());}
    }
    c.native_class_trees.get_mut(&6).unwrap().ranks.insert("ChargeShoot".into(),6);assert!(synchronize(ObjectHeader::default(),&c,None).is_err());
    c.native_class_trees.get_mut(&6).unwrap().ranks.insert("ChargeShoot".into(),5);c.native_class_trees.get_mut(&6).unwrap().ranks.remove("BraverDexUp1");
    assert!(synchronize(ObjectHeader::default(),&c,None).is_err());
}
#[tokio::test]
async fn local_subclass_effects_real_switch_socket_waits_for_commit_and_clears_old_subclass() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},User};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use std::time::Duration;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();let full=character(true);c.character.classes=full.character.classes;c.native_class_trees=full.native_class_trees;}
    crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:Class::Hunter,sub_class:Class::Fighter,..Default::default()})).await.unwrap();
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    User::tick(user.lock().await).await.unwrap();let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:commit.expected_revision+1,duplicate:false})).await.unwrap();
    auto_master(requests);
    for (index,sub) in [Class::Fighter,Class::Gunner,Class::Techer,Class::Braver,Class::Unknown].into_iter().enumerate() {
        if index>0 {crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:Class::Hunter,sub_class:sub,..Default::default()})).await.unwrap();
            assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());}
        finish(&user).await;
        let received=tokio::time::timeout(Duration::from_secs(2),async {
            let Packet::ChangeClass(p)=peer.read_packet_async().await.unwrap() else{panic!("class reply must precede effects")};assert_eq!(p.new_info.sub_class,sub);
            let mut packets=Vec::new();loop {let p=peer.read_packet_async().await.unwrap();if matches!(p,Packet::Unk042C(_)){break;}packets.push(p);}packets
        }).await.unwrap();check(&received,Class::Hunter,sub,true);
        let saved=saved_character(&sql,1,1).await;assert_eq!(saved.character.classes.sub_class,sub);assert_eq!(saved.native_class_trees[&6].rank("ChargeShoot"),5);
        check(&synchronize(ObjectHeader::default(),&saved,None).unwrap(),Class::Hunter,sub,true);
        assert_eq!(user.lock().await.get_stats().get_hp().0,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
