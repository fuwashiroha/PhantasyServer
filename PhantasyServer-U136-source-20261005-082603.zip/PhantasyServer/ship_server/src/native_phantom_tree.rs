//! Classic 6.1253.3 native tree contract, derived in U092 from private client code.
//! 04/28: mode, (count+0xA8)^0x49E3, 204-byte entries. See U092 evidence.
//! Native learning is separate from unimplemented Phantom combat effects.
use crate::Error;
use std::{collections::BTreeMap,sync::OnceLock};

pub(crate) const PHANTOM_SLOT:u8=12;
#[derive(serde::Deserialize)]
pub(crate) struct Node {
    pub name:String,pub x:u8,pub y:u8,pub max_rank:u8,pub cost:u8,pub initial:bool,
    pub minimum_level:u16,pub parent:Option<String>,pub parent_rank:u8,
    pub rank_byte:usize,pub rank_shift:u8,
}
#[derive(serde::Deserialize)]
struct Catalogue {nodes:Vec<Node>}
pub(crate) fn nodes()-> &'static [Node] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-phantom-native-tree.json")).expect("pinned Phantom SKT catalogue")).nodes
}
#[derive(Debug,Clone,Default,PartialEq,serde::Serialize,serde::Deserialize)]
#[serde(default)]
pub(crate) struct PhantomTree {pub name:String,pub ranks:BTreeMap<String,u8>}
impl PhantomTree {
    pub(crate) fn at_level(&self,level:u16)->Self {
        let mut tree=self.clone();
        if tree.name.is_empty(){tree.name="Phantom 1".into();}
        // Only raw rank-0 nodes are initial skills. Zero SP does not mean automatic acquisition.
        for node in nodes() {
            if node.initial && level>=node.minimum_level && tree.parent_met(node) {
                tree.ranks.insert(node.name.clone(),1);
            }
        }
        tree
    }
    pub(crate) fn rank(&self,name:&str)->u8 {self.ranks.get(name).copied().unwrap_or(0)}
    fn parent_met(&self,node:&Node)->bool {node.parent.as_ref().is_none_or(|name|self.rank(name)>=node.parent_rank)}
    pub(crate) fn spent(&self)->u16 {nodes().iter().map(|n|u16::from(self.rank(&n.name))*u16::from(n.cost)).sum()}
    pub(crate) fn validate(&self,level:u16,total_sp:u16)->Result<(),Error> {
        for (name,rank) in &self.ranks {
            let node=nodes().iter().find(|n|&n.name==name).ok_or(Error::InvalidInput("native_phantom_unknown_node"))?;
            if *rank>node.max_rank || (*rank>0 && (level<node.minimum_level || !self.parent_met(node))) {
                return Err(Error::InvalidInput("native_phantom_rank_gate"));
            }
        }
        if self.spent()>total_sp || self.spent()>i16::MAX as u16 {return Err(Error::InvalidInput("native_phantom_sp"));}
        Ok(())
    }
    pub(crate) fn learn(&self,x:u8,y:u8,amount:u8,level:u16,total_sp:u16)->Result<Self,Error> {
        let mut tree=self.at_level(level);tree.validate(level,total_sp)?;
        let node=nodes().iter().find(|n|n.x==x&&n.y==y).ok_or(Error::InvalidInput("native_phantom_coordinate"))?;
        if node.initial || amount==0 {return Err(Error::InvalidInput("native_phantom_not_allocatable"));}
        let next=tree.rank(&node.name).checked_add(amount).ok_or(Error::InvalidInput("native_phantom_rank_overflow"))?;
        tree.ranks.insert(node.name.clone(),next);tree.validate(level,total_sp)?;
        Ok(tree.at_level(level))
    }
    pub(crate) fn entry(&self,level:u16)->[u8;204] {
        let tree=self.at_level(level);let mut data=[0u8;204];
        data[0]=PHANTOM_SLOT;data[4]=12;data[5]=3; // class Phantom, occupied + selected
        data[6..8].copy_from_slice(&tree.spent().to_le_bytes());
        for (i,value) in tree.name.encode_utf16().take(31).enumerate(){data[8+i*2..10+i*2].copy_from_slice(&value.to_le_bytes());}
        for node in nodes(){data[4+node.rank_byte]|=(tree.rank(&node.name)&15)<<node.rank_shift;}
        data
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_phantom_tree_original_nodes_gates_and_sp_are_enforced() {
        assert_eq!(nodes().len(),44);
        let t=PhantomTree::default();
        assert!(t.learn(1,3,1,85,85).is_err()); // counter requires Marker
        let t=t.learn(0,0,1,85,85).unwrap().learn(1,3,2,85,85).unwrap();
        assert!(t.learn(1,4,1,85,85).is_ok()); // PP gain requires counter rank 2
        assert!(t.learn(1,3,4,85,85).is_err());
        assert!(t.learn(0,0,1,85,85).is_err());
        assert!(PhantomTree::default().learn(0,0,1,85,0).is_err());
        assert!(t.learn(2,1,1,79,85).is_err());
        assert_eq!(PhantomTree::default().at_level(84).rank("VillainGespenst"),0);
        assert_eq!(t.at_level(85).rank("VillainGespenst"),0);
        let n=nodes().iter().find(|n|n.name=="VillainGespenst").unwrap();
        assert!(t.learn(n.x,n.y,1,84,85).is_err());
        let learned=t.learn(n.x,n.y,1,85,85).unwrap();assert_eq!(learned.rank("VillainGespenst"),1);
        assert_eq!(learned.spent(),t.spent());assert_eq!(learned.at_level(85).rank("VillainGespenst"),1);
        assert_eq!(t.at_level(85).spent(),3);
        let mut seen=std::collections::BTreeSet::new();
        for n in nodes(){assert!(seen.insert((n.rank_byte,n.rank_shift)));}
    }
    #[test]
    fn local_phantom_native_rank_grid_and_legacy_save_roundtrip() {
        let t=PhantomTree::default().learn(0,0,1,85,85).unwrap();
        let b=t.entry(85);assert_eq!(&b[..8],&[12,0,0,0,12,3,1,0]);
        for n in nodes(){assert_eq!((b[4+n.rank_byte]>>n.rank_shift)&15,t.at_level(85).rank(&n.name));}
        let c=crate::sql::CharData::default();
        let bytes=rmp_serde::to_vec(&(&c.character,&c.inventory,&c.palette,&c.flags,&c.unlocked_quests,&c.unlocked_quests_notif,&c.play_time,&c.quest_meseta_receipts,&c.hero_test_skills,&c.native_hero_tree)).unwrap();
        let mut old:crate::sql::CharData=rmp_serde::from_slice(&bytes).unwrap();assert!(old.native_phantom_tree.is_none());
        old.native_phantom_tree=Some(t.clone());
        let next:crate::sql::CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&old).unwrap()).unwrap();
        assert_eq!(next.native_phantom_tree,Some(t));assert!(next.native_hero_tree.is_none());
    }
}
