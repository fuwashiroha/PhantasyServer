use super::*;
use crate::damage_measurement::{Mode,End};
use pso2packetlib::protocol::{ObjectHeader,ObjectType,playerstatus::DealDamagePacket};

#[tokio::test]
async fn local_measurement_real_combat_commit_failure_exclusion_replay_and_reset() {
    exercise_party_transfers(false,false,Some("measurement")).await;
}
pub(super) async fn exercise(players:&[Arc<Mutex<User>>],received:&[Arc<tokio::sync::Mutex<Vec<Packet>>>],quest_map:&Arc<Mutex<map::Map>>) {
    let zone=players[0].lock().await.zone_pos;
    for i in 0..2 {
        Box::pin(user::packet_handler(players[i].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
        wait_for_finish(&received[i]).await;received[i].lock().await.clear();
    }
    quest_map.lock().await.spawn_enemy(zone,"SoldierAnt",Default::default()).await.unwrap();
    let enemy=tokio::time::timeout(Duration::from_secs(2),async {
        loop {
            if let Some(e)=received[0].lock().await.iter().find_map(|p|match p {Packet::EnemySpawn(e)=>Some(e.object),_=>None}) {break e;}
            tokio::task::yield_now().await;
        }
    }).await.unwrap();
    let normal=data_structs::name_to_id("Rifle:A1");
    let excluded=data_structs::name_to_id("MeasurementFixtureExcluded");
    let kill=data_structs::name_to_id("MeasurementFixtureKill");
    let attack=|player,id|DealDamagePacket{inflicter:ObjectHeader{id:player,entity_type:ObjectType::Player,..Default::default()},target:enemy,attack_id:id,..Default::default()};
    {
        let mut map=quest_map.lock().await;
        assert!(map.damage_measurement_snapshot().is_none());
        assert!(map.start_damage_measurement(usize::MAX,enemy.id,&[1,2],Mode::TwentySeconds,&[]).is_err());
        assert!(map.start_damage_measurement(zone,enemy.id,&[1,3],Mode::TwentySeconds,&[]).is_err());
        assert!(map.start_damage_measurement(zone,0,&[1,2],Mode::TwentySeconds,&[]).is_err());
        assert!(map.damage_measurement_snapshot().is_none());
        map.start_damage_measurement(zone,enemy.id,&[1,2],Mode::TwentySeconds,&[excluded]).unwrap();
        assert!(map.start_damage_measurement(zone,enemy.id,&[1,2],Mode::Free,&[]).is_err());
    }
    let initial=quest_map.lock().await.damage_measurement_snapshot().unwrap();
    let err=Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack(1,u32::MAX)))).await;
    assert!(matches!(err,Err(Error::NoDamageInfo(_))));
    assert_eq!(quest_map.lock().await.damage_measurement_snapshot().unwrap(),initial);
    let mut hp=10_000;
    for (player,id) in [(1,normal),(2,normal),(1,excluded)] {
        Box::pin(user::packet_handler(players[(player-1) as usize].lock().await,Packet::DealDamage(attack(player,id)))).await.unwrap();
        let after=quest_map.lock().await.local_enemy_hp(zone,enemy.id).unwrap();assert!(after<hp && after>0);hp=after;
    }
    let before=quest_map.lock().await.damage_measurement_snapshot().unwrap();
    assert_eq!(before.totals.iter().map(|r|r.hits).collect::<Vec<_>>(),vec![1,1]);
    // A late EXP failure and a busy recipient must not increment the meter.
    let saved=players[1].lock().await.character.as_ref().unwrap().character.classes.clone();
    players[1].lock().await.character.as_mut().unwrap().character.get_level_mut().exp=u32::MAX;
    for _ in 0..2 {
        assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack(1,kill)))).await.is_err());
        assert_eq!(quest_map.lock().await.local_enemy_hp(zone,enemy.id),Some(hp));
        assert_eq!(quest_map.lock().await.damage_measurement_snapshot().unwrap(),before);
    }
    players[1].lock().await.character.as_mut().unwrap().character.classes=saved;
    let held=players[1].lock().await;
    assert!(matches!(Box::pin(quest_map.lock().await.deal_damage(zone,attack(1,kill))).await,Err(Error::CombatBusy)));
    drop(held);assert_eq!(quest_map.lock().await.damage_measurement_snapshot().unwrap(),before);
    Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack(1,kill)))).await.unwrap();
    let final_state=quest_map.lock().await.damage_measurement_snapshot().unwrap();
    assert_eq!(final_state.ended,Some(End::TargetKilled));
    assert_eq!(final_state.totals[0].hits,2);assert_eq!(final_state.totals[1].hits,1);
    assert!(final_state.totals[0].displayed>final_state.totals[0].hp_loss);
    assert!(!final_state.totals.iter().any(|r|r.invalid));
    Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack(1,kill)))).await.unwrap();
    assert_eq!(quest_map.lock().await.damage_measurement_snapshot().unwrap(),final_state);
    for i in 0..2 {
        Box::pin(user::packet_handler(players[i].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
        wait_for_finish(&received[i]).await;
        let packets=received[i].lock().await;
        let hits:Vec<_>=packets.iter().filter_map(|p|match p {Packet::DamageReceive(d)=>Some(d),_=>None}).collect();
        assert_eq!(hits.len(),4);assert_eq!(packets.iter().filter(|p|matches!(p,Packet::EnemyKilled(_))).count(),1);
        assert_eq!(final_state.totals[0].displayed,hits[0].dmg_amount as u64+hits[3].dmg_amount as u64);
        assert_eq!(final_state.totals[1].displayed,hits[1].dmg_amount as u64);
        assert_eq!(final_state.totals[0].hp_loss,10_000-u64::from(hits[0].new_hp)+u64::from(hits[2].new_hp));
        assert_eq!(packets.iter().filter(|p|matches!(p,Packet::GainedEXP(_))).count(),1);
    }
    // New round requires a live new target. Cancel retains the prior result.
    {
        let mut map=quest_map.lock().await;
        assert!(map.start_damage_measurement(zone,enemy.id,&[1,2],Mode::Free,&[]).is_err());
        map.cancel_damage_measurement();assert_eq!(map.damage_measurement_snapshot().unwrap(),final_state);
    }
    for r in received {r.lock().await.clear();}
    quest_map.lock().await.spawn_enemy(zone,"SoldierAnt",Default::default()).await.unwrap();
    let next=tokio::time::timeout(Duration::from_secs(2),async {
        loop {if let Some(e)=received[0].lock().await.iter().find_map(|p|match p {Packet::EnemySpawn(e)=>Some(e.object.id),_=>None}) {break e;}tokio::task::yield_now().await;}
    }).await.unwrap();
    let mut map=quest_map.lock().await;assert_ne!(next,enemy.id);
    map.start_damage_measurement(zone,next,&[1,2],Mode::Free,&[]).unwrap();
    assert!(map.damage_measurement_snapshot().unwrap().totals.iter().all(|r|r.hits==0));
    map.cancel_damage_measurement();assert_eq!(map.damage_measurement_snapshot().unwrap().ended,Some(End::Cancelled));
}
