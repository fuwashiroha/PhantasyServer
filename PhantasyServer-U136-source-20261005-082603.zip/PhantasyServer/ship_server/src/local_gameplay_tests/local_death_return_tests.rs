use super::*;
use crate::user::handlers::server;

struct Disable;
impl Drop for Disable {fn drop(&mut self){server::configure_death_experiment(None).unwrap();}}
#[tokio::test]
async fn local_death_campship_scoped_entry_repeat_and_party_continuity() {
    let _disable=Disable;server::configure_death_experiment(None).unwrap();
    exercise_party_transfers_with_revival(false,true,None,Some("normal")).await;
}
#[tokio::test]
async fn local_death_campship_missing_destination_does_not_heal_or_remove() {
    let _disable=Disable;server::configure_death_experiment(None).unwrap();
    exercise_party_transfers_with_revival(false,true,None,Some("missing_destination")).await;
}
#[test]
fn local_death_campship_configuration_defaults_off_and_rejects_zero() {
    let settings:settings::Settings=toml::from_str("").unwrap();
    assert_eq!(settings.death_campship_experiment_account,None);
    assert!(!toml::to_string(&settings).unwrap().contains("death_campship_experiment_account"));
    assert!(server::configure_death_experiment(Some(0)).is_err());
}
async fn request(player:&Arc<Mutex<User>>)->Result<Action,Error> {
    tokio::time::timeout(Duration::from_secs(2),user::packet_handler(player.lock().await,Packet::DeathToCampship(Default::default())))
        .await.expect("Death transfer must release requester and party locks")
}
async fn barrier(player:&Arc<Mutex<User>>,packets:&Arc<tokio::sync::Mutex<Vec<Packet>>>)->Vec<Packet> {
    player.lock().await.send_packet(&Packet::ServerPing).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {
            let mut list=packets.lock().await;
            if let Some(i)=list.iter().position(|p|*p==Packet::ServerPing) {return list.drain(..=i).filter(|p|*p!=Packet::ServerPing).collect();}
            drop(list);tokio::task::yield_now().await;
        }
    }).await.unwrap()
}
pub(super) async fn exercise_revival(players:&[Arc<Mutex<User>>],received:&[Arc<tokio::sync::Mutex<Vec<Packet>>>],
    quest_map:&Arc<Mutex<map::Map>>,party:&Arc<RwLock<party::Party>>,campship:usize,case:&str) {
    let field=players[0].lock().await.zone_pos;assert_ne!(field,campship);
    for i in 0..2 {
        user::packet_handler(players[i].lock().await,Packet::MapLoaded(Default::default())).await.unwrap();
        wait_for_finish(&received[i]).await;barrier(&players[i],&received[i]).await;
    }
    assert_eq!(players[0].lock().await.get_stats().get_hp(),(0,21));
    let other_hp=players[1].lock().await.get_stats().get_hp();assert_eq!(other_hp.0,79);
    let enemies=quest_map.lock().await.local_enemy_snapshot(field);assert!(!enemies.is_empty());
    let character=rmp_serde::to_vec(players[0].lock().await.character.as_ref().unwrap()).unwrap();
    // Disabled and another selected account do not activate the experiment.
    request(&players[0]).await.unwrap();assert!(barrier(&players[0],&received[0]).await.is_empty());
    server::configure_death_experiment(Some(2)).unwrap();
    request(&players[0]).await.unwrap();assert!(barrier(&players[0],&received[0]).await.is_empty());
    // The selected living teammate may not heal through this request.
    assert!(request(&players[1]).await.is_err());assert!(barrier(&players[1],&received[1]).await.is_empty());
    assert_eq!(players[1].lock().await.get_stats().get_hp(),other_hp);
    server::configure_death_experiment(Some(1)).unwrap();
    // An unrelated current map is rejected without HP or membership mutation.
    {let mut p=players[0].lock().await;let lobby=p.get_blockdata().lobby.clone();p.set_map(lobby);}
    assert!(request(&players[0]).await.is_err());
    players[0].lock().await.set_map(quest_map.clone());
    assert_eq!(players[0].lock().await.get_stats().get_hp().0,0);
    if case=="missing_destination" {
        quest_map.lock().await.local_rename_zone("campship","missing-campship");
        assert!(request(&players[0]).await.is_err());
        assert_eq!(players[0].lock().await.get_stats().get_hp().0,0);
        assert_eq!(players[0].lock().await.zone_pos,field);
        assert!(barrier(&players[0],&received[0]).await.is_empty());
        quest_map.lock().await.local_rename_zone("missing-campship","campship");
    }
    request(&players[0]).await.unwrap();
    assert_eq!(players[0].lock().await.get_stats().get_hp(),(21,21));
    assert_eq!(players[0].lock().await.zone_pos,campship);
    assert_eq!(players[1].lock().await.zone_pos,field);
    assert_eq!(players[1].lock().await.get_stats().get_hp(),other_hp);
    assert!(Arc::ptr_eq(&party.read().await.get_quest_map().unwrap(),quest_map));
    assert!(Arc::ptr_eq(&players[0].lock().await.get_current_party().unwrap(),party));
    assert_eq!(quest_map.lock().await.local_enemy_snapshot(field),enemies);
    assert_eq!(rmp_serde::to_vec(players[0].lock().await.character.as_ref().unwrap()).unwrap(),character);
    user::packet_handler(players[0].lock().await,Packet::MapLoaded(Default::default())).await.unwrap();
    wait_for_finish(&received[0]).await;
    let packets=barrier(&players[0],&received[0]).await;
    assert_eq!(packets.iter().filter(|p|matches!(p,Packet::MapTransfer(_))).count(),1);
    assert!(packets.iter().any(|p|matches!(p,Packet::CharacterSpawn(_))));
    assert!(packets.iter().any(|p|matches!(p,Packet::FinishLoading)));
    assert!(!barrier(&players[1],&received[1]).await.iter().any(|p|matches!(p,Packet::MapTransfer(_))));
    assert!(request(&players[0]).await.is_err());
    assert!(barrier(&players[0],&received[0]).await.is_empty());
    user::packet_handler(players[0].lock().await,Packet::CampshipDown(Default::default())).await.unwrap();
    assert_eq!(players[0].lock().await.zone_pos,field);
    assert_eq!(quest_map.lock().await.local_enemy_snapshot(field),enemies);
    // Continue actual server combat against the retained field enemy.
    user::packet_handler(players[0].lock().await,Packet::MapLoaded(Default::default())).await.unwrap();
    wait_for_finish(&received[0]).await;
    let packets=barrier(&players[0],&received[0]).await;
    let enemy=packets.iter().find_map(|p|match p {Packet::EnemySpawn(e) if e.object.id==enemies[0].0=>Some(e.object),_=>None}).unwrap();
    barrier(&players[1],&received[1]).await;
    let hit=pso2packetlib::protocol::playerstatus::DealDamagePacket {
        attack_id:data_structs::name_to_id("StrikeAdd"),inflicter:enemy,
        target:players[0].lock().await.create_object_header(),..Default::default()
    };
    user::packet_handler(players[0].lock().await,Packet::DealDamage(hit)).await.unwrap();
    assert_eq!(players[0].lock().await.get_stats().get_hp().0,0);
    assert_eq!(players[1].lock().await.get_stats().get_hp(),other_hp);
    for i in 0..2 {
        let packets=barrier(&players[i],&received[i]).await;
        assert!(packets.iter().any(|p|matches!(p,Packet::DamageReceive(d) if d.dmg_target.id==1 && d.new_hp==0)));
        assert!(!packets.iter().any(|p|matches!(p,Packet::EnemyKilled(_)|Packet::GainedEXP(_))));
    }
    server::configure_death_experiment(None).unwrap();
}
