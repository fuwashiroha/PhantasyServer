use super::*;
use crate::custom_rockbear;
use pso2packetlib::protocol::{chat::ChatMessage,ObjectHeader,ObjectType,playerstatus::DealDamagePacket};
#[tokio::test]
async fn local_custom_rockbear_two_players_commands_timer_five_rounds_no_rewards_and_abandon() {
    exercise_party_transfers(false,false,Some("custom_rockbear")).await;
}
pub(super) async fn chat(player:&Arc<Mutex<User>>,text:&str) {
    tokio::time::timeout(Duration::from_secs(3),Box::pin(user::packet_handler(player.lock().await,
        Packet::ChatMessage(ChatMessage{message:text.into(),..Default::default()})))).await.unwrap().unwrap();
}
pub(super) async fn exercise(players:&[Arc<Mutex<User>>],received:&[Arc<tokio::sync::Mutex<Vec<Packet>>>],map:&Arc<Mutex<map::Map>>) {
    let zone=players[0].lock().await.zone_pos;
    for i in 0..2 {
        Box::pin(user::packet_handler(players[i].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
        wait_for_finish(&received[i]).await;
        assert!(received[i].lock().await.iter().any(|p|matches!(p,Packet::NPCSpawn(n) if n.object.id==custom_rockbear::GUIDE_ID)));
        *players[i].lock().await.get_stats_mut()=battle_stats::local_training_player();
        received[i].lock().await.clear();
    }
    Box::pin(user::packet_handler(players[0].lock().await,Packet::Interact(pso2packetlib::protocol::objects::InteractPacket {
        object1:ObjectHeader{id:custom_rockbear::GUIDE_ID,entity_type:ObjectType::Object,..Default::default()},action:"TALK".into(),..Default::default()
    }))).await.unwrap();
    let before=players[0].lock().await.character.clone();
    chat(&players[1],"!rockbear start").await;assert!(map.lock().await.damage_measurement_snapshot().is_none());
    chat(&players[0],"!rockbear free").await;
    let enemy=tokio::time::timeout(Duration::from_secs(2),async {
        loop {if let Some(e)=received[0].lock().await.iter().find_map(|p|match p {Packet::EnemySpawn(e)=>Some(e.clone()),_=>None}){break e;}tokio::task::yield_now().await;}
    }).await.unwrap();
    assert_eq!(enemy.name.as_str(),"BigBeastA");assert_eq!(enemy.level,20);assert_eq!(enemy.hp,400_000_000);
    assert_eq!(enemy.unk9[12],0, "U089 model-slot experiment must reach the actual client socket");
    let hit=|id,attack|DealDamagePacket{inflicter:ObjectHeader{id,entity_type:ObjectType::Player,..Default::default()},target:enemy.object,attack_id:attack,hitbox_id:0xF00D,..Default::default()};
    let normal=data_structs::name_to_id("Rifle:A1");
    let initial=map.lock().await.damage_measurement_snapshot().unwrap();
    assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(hit(1,u32::MAX)))).await.is_err());
    assert_eq!(map.lock().await.damage_measurement_snapshot().unwrap(),initial);
    for id in [1,2] {Box::pin(user::packet_handler(players[(id-1) as usize].lock().await,Packet::DealDamage(hit(id,normal)))).await.unwrap();}
    let snap=map.lock().await.damage_measurement_snapshot().unwrap();assert_eq!(snap.totals.iter().map(|r|r.hits).collect::<Vec<_>>(),vec![1,1]);
    assert_eq!(snap.totals.iter().map(|r|r.displayed).collect::<Vec<_>>(),vec![246,246]);
    let killer=data_structs::name_to_id("MeasurementFixtureKill");
    for _ in 0..5 {
        Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(hit(1,killer)))).await.unwrap();
        if map.lock().await.damage_measurement_snapshot().unwrap().ended.is_some(){break;}
    }
    assert_eq!(map.lock().await.damage_measurement_snapshot().unwrap().ended,Some(crate::damage_measurement::End::TargetKilled));
    assert_eq!(map.lock().await.local_enemy_hp(zone,enemy.object.id),None);
    let final_state=map.lock().await.damage_measurement_snapshot().unwrap();
    Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(hit(1,killer)))).await.unwrap();
    assert_eq!(map.lock().await.damage_measurement_snapshot().unwrap(),final_state);
    chat(&players[0],"!rockbear start").await;
    // Generation fencing: a stale timer from round 1 cannot end round 2.
    map.lock().await.custom_finish(Some(1),true).await;
    assert!(map.lock().await.damage_measurement_snapshot().unwrap().ended.is_none());
    tokio::time::timeout(Duration::from_secs(23),async{
        loop {
            if received[0].lock().await.iter().any(|p|matches!(p,Packet::SystemMessage(m) if m.message.contains("Round 2/5 Elapsed"))){break;}
            tokio::time::sleep(Duration::from_millis(30)).await;
        }
    }).await.unwrap();
    // Frozen score stays unchanged during the separate authored result review.
    let frozen=map.lock().await.damage_measurement_snapshot().unwrap();
    Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(hit(1,normal)))).await.unwrap();
    assert_eq!(map.lock().await.damage_measurement_snapshot().unwrap(),frozen);
    tokio::time::sleep(Duration::from_millis(2200)).await;
    for command in ["!rockbear static","!rockbear staticfree","!rockbear free"] {
        chat(&players[0],command).await;
        chat(&players[0],"!rockbear stop").await;
        tokio::time::sleep(Duration::from_millis(2200)).await;
    }
    let fifth=map.lock().await.damage_measurement_snapshot().unwrap();
    chat(&players[0],"!rockbear free").await;assert_eq!(map.lock().await.damage_measurement_snapshot().unwrap(),fifth);
    chat(&players[1],"!rockbear status").await;
    for i in 0..2 {
        Box::pin(user::packet_handler(players[i].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();wait_for_finish(&received[i]).await;
        let packets=received[i].lock().await;
        assert!(!packets.iter().any(|p|matches!(p,Packet::GainedEXP(_)|Packet::QuestResult(_))));
        assert_eq!(packets.iter().filter(|p|matches!(p,Packet::EnemySpawn(_))).count(),5);
        assert_eq!(packets.iter().filter(|p|matches!(p,Packet::DespawnObject(_))).count(),5);
        assert!(packets.iter().any(|p|matches!(p,Packet::SystemMessage(m) if m.message.contains("Five rounds complete"))));
        if i==0 {assert!(packets.iter().any(|p|matches!(p,Packet::SystemMessage(m) if m.message==custom_rockbear::HELP)));}
    }
    assert_eq!(serde_json::to_value(&before).unwrap(),serde_json::to_value(&players[0].lock().await.character).unwrap());
    // The parent fixture now abandons through the real party handler and checks
    // both clients finish loading the lobby, twice across fresh quest instances.
}
