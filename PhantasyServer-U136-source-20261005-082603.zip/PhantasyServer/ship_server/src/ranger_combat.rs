//! Sourced Ra learned effects; movement, distance, bullet and trap state remain separate.
use crate::{Error,native_class_tree::ClassTree,sql::CharData};
use pso2packetlib::protocol::models::character::Class;
#[derive(Debug,Clone,Default)]
pub(crate) struct RangerCombat {tree:Option<ClassTree>}
const FLAT1:[u32;11]=[0,3,6,10,14,18,23,28,34,40,50];
const FLAT2:[u32;11]=[0,4,9,14,19,25,31,39,50,62,75];
// Ra's published DEX3 table differs from Hu HP3/ATK3. Do not reuse that table.
const DEX3:[u32;11]=[0,5,11,18,28,39,41,54,68,82,100];
impl RangerCombat {
    pub(crate) fn build(c:&CharData)->Result<Self,Error> {
        if c.character.classes.main_class!=Class::Ranger && c.character.classes.sub_class!=Class::Ranger {return Ok(Self::default());}
        let info=&c.character.classes.ranger_info;
        let tree=c.native_class_trees.get(&1).cloned().unwrap_or_default().at_level(1,info.level1)?;
        tree.validate(1,info.level1,info.level2)?;
        Ok(Self{tree:Some(tree)})
    }
    fn rank(&self,n:&str)->usize {self.tree.as_ref().map_or(0,|t|t.rank(n) as usize)}
    pub(crate) fn ranged(&self)->u32 {FLAT1[self.rank("RangerAtpFirearmUp1")]+FLAT2[self.rank("RangerAtpFirearmUp2")]}
    pub(crate) fn dex(&self)->u32 {FLAT1[self.rank("RangerDexUp1")]+FLAT2[self.rank("RangerDexUp2")]+DEX3[self.rank("RangerDexUp3")]}
    pub(crate) fn defense(&self)->u32 {FLAT1[self.rank("RangerDfpFirearmUp1")]}
    pub(crate) fn weak_hit(&self,id:u32,common_region:f32,ranged_base_region:f32)->f32 {
        // These are hit-region coefficients, not arbitrary final multipliers.
        // Weapon-element weakness is not WHA. A future Weak Bullet state must
        // explicitly implement its forced-activation exception.
        if common_region<1.15 && common_region*ranged_base_region<1.15 {return 1.0;}
        #[derive(serde::Deserialize)] struct Hit {id:u32}
        #[derive(serde::Deserialize)] struct Catalogue {attacks:Vec<Hit>}
        static IDS:std::sync::OnceLock<std::collections::HashSet<u32>>=std::sync::OnceLock::new();
        if !IDS.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-ranger-weak-hit.json"))
            .expect("audited ordinary ranged output types").attacks.into_iter().map(|h|h.id).collect()).contains(&id) {return 1.0;}
        let values=[1.0,1.06,1.07,1.08,1.09,1.10,1.11,1.12,1.13,1.14,1.15];
        values[self.rank("WeakSnipeBonus1")]*values[self.rank("WeakSnipeBonus2")]
    }
    pub(crate) fn outgoing(&self,target_hp:u32,target_max_hp:u32)->f32 {
        let high=[1.0,1.01,1.02,1.03,1.04,1.05][self.rank("RangerHighLevelBonus")];
        // Evaluate each hit against the target HP pool, not a player-local "first hit" flag.
        // Separate part pools and Falz Arms shared HP are not represented by current EnemyStats.
        high * if target_hp>0 && target_hp==target_max_hp {[1.0,1.04,1.08,1.12,1.16,1.20][self.rank("FirstHit")]}else{1.0}
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_ranger_all_eight_skill_rank_tables_match_pinned_swiki() {
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-ranger-passive-effects.json")).unwrap();
        for (name,title,label,kind) in [
            ("RangerAtpFirearmUp1","射撃アップ1","射撃アップ1 射撃力",0),
            ("RangerAtpFirearmUp2","射撃アップ1","射撃アップ2 射撃力",0),
            ("RangerDexUp1","技量アップ1","技量アップ1 技量",1),
            ("RangerDexUp2","技量アップ1","技量アップ2 技量",1),
            ("RangerDexUp3","技量アップ1","技量アップ3 技量",1),
            ("RangerDfpFirearmUp1","射撃防御アップ","射撃防御",2),
            ("RangerHighLevelBonus","ハイレベルボーナスRa","威力",3),
            ("FirstHit","ファーストヒット","威力",3),
        ] {
            let s=f["sections"].as_array().unwrap().iter().find(|s|s["title"].as_str().unwrap().starts_with(title)).unwrap();
            let r=s["tables"][0].as_array().unwrap().iter().find(|r|r.as_array().unwrap().iter().any(|c|c==label)).unwrap();
            let values:Vec<f32>=r.as_array().unwrap().iter().filter_map(|v|v.as_str().unwrap().trim_matches(['+','%']).parse().ok()).collect();
            let n=f["original_nodes"].as_array().unwrap().iter().find(|n|n["name"]==name).unwrap();assert_eq!(values.len(),n["max_rank"].as_u64().unwrap() as usize);
            for (i,v) in values.iter().enumerate() {
                let mut t=ClassTree::default();t.ranks.insert(name.into(),i as u8+1);let c=RangerCombat{tree:Some(t)};
                let actual=match kind {0=>c.ranged() as f32,1=>c.dex() as f32,2=>c.defense() as f32,_=>c.outgoing(100,100)*100.0};
                assert!((actual-v).abs()<0.0001,"{name} rank {}: {actual} != {v}",i+1);
            }
        }
    }
}
