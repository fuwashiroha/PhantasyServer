//! U100 linked skill gates and original Phantom hit coverage.
//! Full mark/gear authority and PP-stream formulas are tracked separately.
use crate::{Error,native_phantom_tree::PhantomTree};
use std::{collections::HashMap,sync::OnceLock};
#[derive(serde::Deserialize)]
pub(crate) struct Attack {pub id:u32,pub weapon:u8,pub category:String,pub required_skills:Vec<String>,pub conditions:Vec<String>}
#[derive(serde::Deserialize)]
struct Catalogue {attacks:Vec<Attack>}
pub(crate) fn attacks()-> &'static HashMap<u32,Attack> {
    static DATA:OnceLock<HashMap<u32,Attack>>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-phantom-attacks.json")).expect("pinned Phantom attacks").attacks.into_iter().map(|a|(a.id,a)).collect())
}
#[derive(Debug,Clone,Default)]
pub(crate) struct PhantomCombat {pub tree:Option<PhantomTree>,pub weapon:u8}
impl PhantomCombat {
    pub(crate) fn rod_melee_region(&self,id:u32)->bool {
        self.tree.is_some() && attacks().get(&id).is_some_and(|a|a.weapon==11)
    }
    // Stat selection is separate from attack attribute: Phantom Rod strikes
    // use TEC power but the melee bonus. Rifle marker explosions also use it.
    pub(crate) fn attribute_factor(&self,id:u32,fallback:data_structs::stats::AttackType)->f32 {
        use data_structs::stats::AttackType;
        let Some(t)=&self.tree else{return 1.0};
        let attribute=match attacks().get(&id) {
            Some(row) if row.weapon==8 && row.category!="marker"=>AttackType::Rng,
            Some(_)=>AttackType::Mel,
            None=>fallback,
        };
        let rank=t.rank("VillainAllAttackBonus") as usize;
        match attribute {
            AttackType::Mel=>[1.0,1.25,1.30,1.35,1.40,1.45][rank],
            AttackType::Rng=>[1.0,1.10,1.15,1.20,1.25,1.30][rank],
            AttackType::Tec=>[1.0,1.15,1.20,1.25,1.30,1.35][rank],
        }
    }
    pub(crate) fn multiplier(&self,id:u32)->Result<f32,Error> {
        let row=attacks().get(&id);
        // Old un-gated base hits keep their prior behavior. New conditional
        // attacks cannot bypass native allocation by naming a child descriptor.
        if let Some(row)=row {
            if !row.required_skills.is_empty() {
                let t=self.tree.as_ref().ok_or(Error::InvalidInput("phantom_attack_class"))?;
                if self.weapon!=row.weapon || row.required_skills.iter().any(|s|t.rank(s)==0) {
                    return Err(Error::InvalidInput("phantom_attack_skill_or_weapon"));
                }
            }
        }
        let Some(t)=&self.tree else{return Ok(1.0)};
        let mut power=1.0+0.01*f32::from(t.rank("VillainHighLevelBonus"));
        if matches!(self.weapon,8|11|14) {
            let bonus=[1.0,1.10,1.20,1.30,1.35,1.40,1.45,1.50,1.55,1.60,1.65];
            power*=bonus[t.rank("VillainWeaponBonus1") as usize]*bonus[t.rank("VillainWeaponBonus2") as usize];
        }
        if let Some(row)=row {
            if row.category=="counter" {
                power*=[1.0,1.0,1.05,1.09,1.13,1.15][t.rank("VillainDodgeCounterShot") as usize];
            }
            if row.category=="marker" || row.conditions.iter().any(|s|s=="VillainLoadOfThorn") {
                power*=[1.0,1.10,1.18,1.25,1.30,1.40,1.50,1.75,2.0,2.5,3.0][t.rank("VillainLoadOfThorn") as usize];
            }
        }
        Ok(power)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use data_structs::{name_to_id,SerDeFile,ServerData,stats::DamageType};
    #[test]
    fn local_phantom_all_original_hit_ids_and_pa_bits_are_compiled() {
        let data=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap();
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-phantom-attacks.json")).unwrap();
        assert_eq!(attacks().len(),322);
        for a in f["attacks"].as_array().unwrap() {
            let id=a["id"].as_u64().unwrap() as u32;
            let d=data.attack_stats.iter().find(|d|d.attack_id==id).unwrap();
            assert_eq!(d.damage_id,name_to_id(a["row"]["damage_name"].as_str().unwrap()));
            let bits=u32::from_str_radix(a["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match &d.damage {
                DamageType::Generic(m)=>{assert_eq!(m.to_bits(),bits);assert!(a["unique_pa_parent"].is_null());},
                DamageType::PA((pa,m))=>{assert_eq!(m.to_bits(),bits);assert_eq!(*pa,name_to_id(a["unique_pa_parent"].as_str().unwrap()));}
            }
        }
        for (name,table) in f["pa_tables"].as_object().unwrap() {
            for (index,bits) in table["standard_bits"].as_array().unwrap().iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),index as u8+1).unwrap().to_bits(),u32::from_str_radix(bits.as_str().unwrap(),16).unwrap());
            }
        }
    }
    #[test]
    fn local_phantom_counter_and_finish_cannot_bypass_unlearned_skills() {
        let mut c=PhantomCombat::default();
        let ids=["VillainCounterShotKatana","VillainCounterShotKatanaA","VlnKatana:Fin","VlnKatana:FinF"];
        for name in ids {assert!(c.multiplier(name_to_id(name)).is_err());}
        c.weapon=14;c.tree=Some(PhantomTree::default().learn(0,0,1,85,85).unwrap().learn(1,3,5,85,85).unwrap());
        assert!((c.multiplier(name_to_id(ids[0])).unwrap()-1.15).abs()<1e-6);
        assert!(c.multiplier(name_to_id(ids[2])).is_err());
        c.weapon=8;assert!(c.multiplier(name_to_id(ids[0])).is_err());
    }
    #[test]
    fn local_phantom_numeric_skill_tables_match_pinned_wiki() {
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-phantom-skill-catalogue.json")).unwrap();
        for (skill,anchor,rowname) in [("VillainWeaponBonus1","Ph_Weapon_Bonus","威力"),("VillainWeaponBonus2","Ph_Weapon_Bonus","威力"),("VillainHighLevelBonus","Highlevel_Bonus","威力"),("VillainDodgeCounterShot","Dodge_Counter_Shot","威力"),("VillainLoadOfThorn","Lord_Of_Thorn","威力")] {
            let s=f["skills"].as_array().unwrap().iter().find(|s|s["anchor"]==anchor).unwrap();
            let row=s["parameter_rows"].as_array().unwrap().iter().find(|r|r[1]==rowname).unwrap();
            for (index,cell) in row.as_array().unwrap().iter().skip(2).enumerate() {
                let mut t=PhantomTree::default();t.ranks.insert(skill.into(),index as u8+1);
                let id=if skill=="VillainDodgeCounterShot" {name_to_id("VillainCounterShotKatana")} else if skill=="VillainLoadOfThorn" {t.ranks.insert("VillainMarker".into(),1);name_to_id("VlnMarker:ExplosionKatanaLv1")} else {0};
                let actual=PhantomCombat{tree:Some(t),weapon:14}.multiplier(id).unwrap();
                let expected=cell.as_str().unwrap().trim_end_matches('%').parse::<f32>().unwrap()/100.0;
                assert!((actual-expected).abs()<1e-5,"{skill} rank {}",index+1);
            }
        }
    }
    #[test]
    fn local_phantom_rod_and_rifle_marker_use_melee_bonus_not_stat_type() {
        use data_structs::stats::AttackType;
        let mut tree=PhantomTree::default();tree.ranks.insert("VillainAllAttackBonus".into(),5);
        let c=PhantomCombat{tree:Some(tree),weapon:11};
        assert_eq!(c.attribute_factor(name_to_id("VlnRod:PA2N2"),AttackType::Tec),1.45);
        assert_eq!(c.attribute_factor(name_to_id("VlnRifle:A1"),AttackType::Rng),1.30);
        assert_eq!(c.attribute_factor(name_to_id("VlnMarker:ExplosionRifleLv2"),AttackType::Rng),1.45);
        assert_eq!(c.attribute_factor(0,AttackType::Tec),1.35);
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-phantom-skill-catalogue.json")).unwrap();
        let rows=&f["skills"].as_array().unwrap().iter().find(|s|s["anchor"]=="All_Attack_Bonus_Ph").unwrap()["parameter_rows"];
        for (label,attr) in [("打撃威力",AttackType::Mel),("射撃威力",AttackType::Rng),("法撃威力",AttackType::Tec)] {
            let row=rows.as_array().unwrap().iter().find(|r|r[1]==label).unwrap();
            for (i,cell) in row.as_array().unwrap().iter().skip(2).enumerate() {
                let mut t=PhantomTree::default();t.ranks.insert("VillainAllAttackBonus".into(),i as u8+1);
                let expected=cell.as_str().unwrap().trim_end_matches('%').parse::<f32>().unwrap()/100.0;
                assert_eq!(PhantomCombat{tree:Some(t),weapon:11}.attribute_factor(0,attr.clone()),expected);
            }
        }
    }
}
