//! Original ordinary and compound technique hits. Cast/gauge lifecycle is separate.
use crate::{Error,native_class_tree::ClassTree,sql::CharData};
use data_structs::stats::EnemyHitbox;
use pso2packetlib::protocol::models::character::Class;
use std::{collections::HashMap,sync::OnceLock};
#[derive(serde::Deserialize)]
pub(crate) struct Attack {pub id:u32,pub element:String,pub charged:bool}
#[derive(serde::Deserialize)]
struct Catalogue {attacks:Vec<Attack>}
pub(crate) fn attacks()-> &'static HashMap<u32,Attack> {
    static DATA:OnceLock<HashMap<u32,Attack>>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-technique-attacks.json"))
        .expect("pinned ordinary technique hits").attacks.into_iter().map(|a|(a.id,a)).collect())
}
#[derive(serde::Deserialize)]
pub(crate) struct CompoundAttack {pub id:u32,pub element:String,pub mastery_elements:Vec<String>}
#[derive(serde::Deserialize)]
struct CompoundCatalogue {attacks:Vec<CompoundAttack>}
pub(crate) fn compounds()-> &'static HashMap<u32,CompoundAttack> {
    static DATA:OnceLock<HashMap<u32,CompoundAttack>>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str::<CompoundCatalogue>(include_str!("../testdata/classic-compound-techniques.json"))
        .expect("pinned compound hits").attacks.into_iter().map(|a|(a.id,a)).collect())
}
pub(crate) fn contains(id:u32)->bool {attacks().contains_key(&id)||compounds().contains_key(&id)}
pub(crate) fn count()->usize {attacks().len()+compounds().len()}
pub(crate) fn region(id:u32,h:&EnemyHitbox)->Option<f32> {
    attacks().get(&id).map(|a|a.element.as_str()).or_else(||compounds().get(&id).map(|a|a.element.as_str())).map(|element|match element {
        "fire"=>h.fire_mul,"ice"=>h.ice_mul,"thunder"=>h.thunder_mul,
        "wind"=>h.wind_mul,"light"=>h.light_mul,"dark"=>h.dark_mul,_=>unreachable!("pinned element"),
    })
}
#[derive(Debug,Clone,Default)]
pub(crate) struct TechniqueCombat {force:Option<ClassTree>,techer:Option<ClassTree>,compound_class:bool,compound_weapon:bool,main_force:bool}
impl TechniqueCombat {
    pub(crate) fn build(c:&CharData)->Result<Self,Error> {
        let mut result=Self::default();
        result.main_force=c.character.classes.main_class==Class::Force;
        result.compound_class=matches!(c.character.classes.main_class,Class::Force|Class::Techer);
        result.compound_weapon=c.palette.get_current_item(&c.inventory)?.is_some_and(|item|matches!(item.id.id,11|12|13));
        for (class,slot) in [(Class::Force,2),(Class::Techer,5)] {
            if c.character.classes.main_class!=class && c.character.classes.sub_class!=class {continue;}
            let i=crate::native_class_tree::class_level(&c.character.classes,slot)?;
            let t=c.native_class_trees.get(&slot).cloned().unwrap_or_default().at_level(slot,i.level1)?;
            t.validate(slot,i.level1,i.level2)?;
            if slot==2 {result.force=Some(t);}else{result.techer=Some(t);}
        }
        Ok(result)
    }
    fn mastery(tree:&Option<ClassTree>,first:&str,second:&str)->f32 {
        let Some(t)=tree else{return 1.0};
        [1.0,1.05,1.08,1.10,1.12,1.14,1.16,1.17,1.18,1.19,1.20][t.rank(first) as usize]
            *[1.0,1.10,1.14,1.16,1.18,1.20][t.rank(second) as usize]
    }
    fn rank(tree:&Option<ClassTree>,name:&str)->usize {tree.as_ref().map_or(0,|t|t.rank(name) as usize)}
    fn flat1(tree:&Option<ClassTree>,name:&str)->u32 {[0,3,6,10,14,18,23,28,34,40,50][Self::rank(tree,name)]}
    fn flat2(tree:&Option<ClassTree>,name:&str)->u32 {[0,4,9,14,19,25,31,39,50,62,75][Self::rank(tree,name)]}
    pub(crate) fn hp(&self)->u32 {Self::flat1(&self.force,"ForceHPUp1")}
    pub(crate) fn melee(&self)->u32 {Self::flat1(&self.techer,"TecherAtpStrikeUp")}
    pub(crate) fn tech_power(&self)->u32 {
        Self::flat1(&self.force,"ForceAtpTechnicUp1")+Self::flat2(&self.force,"ForceAtpTechnicUp2")
        +[0,40,60,80,100,120][Self::rank(&self.force,"ForceAtpTechnicUp3")]
        +Self::flat1(&self.techer,"TecherAtpTechnicUp1")+Self::flat2(&self.techer,"TecherAtpTechnicUp2")
    }
    pub(crate) fn dex(&self)->u32 {Self::flat1(&self.force,"ForceDexUp1")+Self::flat1(&self.techer,"TecherDexUp1")}
    pub(crate) fn tech_defense(&self)->u32 {Self::flat1(&self.force,"ForceDfpTechnicUp1")+Self::flat1(&self.techer,"TecherDfpTechnicUp1")}
    // High-level bonuses cover all player attack types, including weapon normals.
    // Keep them outside the technique-ID-limited element/charge multiplier.
    pub(crate) fn outgoing(&self)->f32 {
        let values=[1.0,1.01,1.02,1.03,1.04,1.05];
        values[Self::rank(&self.force,"ForceHighLevelBonus")]*values[Self::rank(&self.techer,"TechterHighLevelBonus")]
    }
    pub(crate) fn element_weak(&self,id:u32,target:&str,weapon:crate::weapon_element::WeaponElement)->f32 {
        crate::element_weak::multiplier(Self::rank(&self.techer,"ElementalWeakPoint"),id,target,weapon)
    }
    pub(crate) fn element_conversion(&self,id:u32,weapon:crate::weapon_element::WeaponElement)->f32 {
        if !self.main_force {return 1.0;}
        let element=attacks().get(&id).map(|a|a.element.as_str()).or_else(||compounds().get(&id).map(|a|a.element.as_str()));
        element.map_or(1.0,|element|weapon.technique_conversion(Self::rank(&self.force,"ErementConversion"),element))
    }
    pub(crate) fn validate_attack(&self,id:u32)->Result<(),Error> {
        if compounds().contains_key(&id) && (!self.compound_class||!self.compound_weapon) {
            return Err(Error::InvalidInput("compound_technique_class_or_weapon"));
        }
        Ok(())
    }
    fn element_mastery(&self,element:&str)->f32 {
        match element {
            "fire"=>Self::mastery(&self.force,"MasteryFire1","MasteryFire2"),
            "ice"=>Self::mastery(&self.force,"MasteryIce1","MasteryIce2"),
            "thunder"=>Self::mastery(&self.force,"MasteryLightning1","MasteryLightning2"),
            "wind"=>Self::mastery(&self.techer,"MasteryWind1","MasteryWind2"),
            "light"=>Self::mastery(&self.techer,"MasteryLight1","MasteryLight2"),
            "dark"=>Self::mastery(&self.techer,"MasteryDark1","MasteryDark2"),
            _=>unreachable!("pinned ordinary technique element"),
        }
    }
    pub(crate) fn multiplier(&self,id:u32)->f32 {
        let (mastery,charged)=if let Some(a)=compounds().get(&id) {
            (a.mastery_elements.iter().map(|e|self.element_mastery(e)).product(),true)
        }else if let Some(a)=attacks().get(&id) {(self.element_mastery(&a.element),a.charged)}else{return 1.0};
        let Some(t)=&self.force else{return mastery};
        let ten=[1.0,1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10];
        mastery * if charged {ten[t.rank("TechChargeBonus1") as usize]*[1.0,1.01,1.03,1.05,1.07,1.10][t.rank("TechChargeBonus2") as usize]}
        else {ten[t.rank("TechNonChargeBonus1") as usize]}
    }
}
