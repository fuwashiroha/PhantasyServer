//! Classic 6.1253.3 owner-side passive effects (U097/U098).
//! A 04/28 tree sheet stores ranks; it does not install the actor's buff objects.
//! IDs/kind 16 were read from the original private client's skill descriptors.
//! Wire layout is from native 0xF8D5A0; defaults from 0x291110/0x2DD7230.
//! This narrow candidate still requires client acceptance of each newly synchronized action.
use crate::{Error, native_hero_tree::HeroTree, sql::CharData};
use pso2packetlib::protocol::{
    Packet, ObjectHeader, models::character::Class,
    objects::{Unk0424Packet, Unk0425Packet},
};

const EFFECTS: [(&str, u32); 5] = [
    ("WpnmanCounter", 111004),
    ("SwordShotCharge2", 111009),
    ("WpnmanTime", 111005),
    ("WpnmanTimeFinish", 111006),
    ("WpnmanStepJACombo", 111032),
];

pub(crate) fn synchronize(header: ObjectHeader, character: &CharData) -> Result<Vec<Packet>, Error> {
    let classes = &character.character.classes;
    let tree = character.native_hero_tree.clone().unwrap_or_default();
    tree.validate(classes.hero_info.level1, classes.hero_info.level2)?;
    Ok(effect_packets(header, &tree, classes.main_class == Class::Hero))
}

fn effect_packets(header: ObjectHeader, tree: &HeroTree, hero: bool) -> Vec<Packet> {
    let mut packets = Vec::new();
    for (name, id) in EFFECTS {
        // The native installer returns an existing effect unchanged. Remove it
        // first so rank changes do not retain the previous rank or duplicate it.
        // 04/25's ID at offset 0x20 is passed to native 0x2ADAA0.
        packets.push(Packet::Unk0425(Unk0425Packet {
            unk1: header, unk2: header, unk3: id, ..Default::default()
        }));
        let rank = tree.rank(name);
        if !hero || rank == 0 { continue; }
        // At absolute wire offsets: 0x2C descriptor ID, 0x30 native -1
        // sentinel, 0x34 default duration, 0x38 learned rank, 0x3C flags=4.
        // The last 16 bytes are the original passive context, not PA damage.
        let mut tail = [0u8; 12];
        tail[4..8].copy_from_slice(&u32::from(rank).to_le_bytes());
        tail[8..12].copy_from_slice(&4u32.to_le_bytes());
        packets.push(Packet::Unk0424(Unk0424Packet {
            unk1: header, unk2: header, unk3: header,
            unk4: id, unk5: u32::MAX, unk6: tail, unk7: [0; 12],
        }));
    }
    if !hero {
        packets.push(Packet::Unk0425(Unk0425Packet {unk1:header,unk2:header,unk3:111046,..Default::default()}));
    }
    packets
}

#[cfg(test)]
mod tests {
    use super::*;
    use pso2packetlib::protocol::{ProtocolRW, PacketType, ObjectType};

    #[test]
    fn local_hero_passive_wire_matches_native_installer_and_owner_routing() {
        let owner = ObjectHeader {id: 17, entity_type: ObjectType::Player, ..Default::default()};
        let mut tree = HeroTree::default();
        tree.ranks.insert("WpnmanCounter".into(), 5);
        tree.ranks.insert("SwordShotCharge2".into(), 2);
        let packets = effect_packets(owner, &tree, true);
        assert_eq!(packets.len(), 7);
        for (index, id, rank) in [(0,111004,5u32),(2,111009,2u32)] {
            let remove = packets[index].write(PacketType::Classic);
            assert_eq!(&remove[4..8], &[4,0x25,0x40,0]);
            assert_eq!(u32::from_le_bytes(remove[0x20..0x24].try_into().unwrap()), id);
            let wire = packets[index+1].write(PacketType::Classic);
            assert_eq!(wire.len(), 0x4c);
            assert_eq!(&wire[4..8], &[4,0x24,0x40,0]);
            for at in [8,0x14,0x20] {
                assert_eq!(u32::from_le_bytes(wire[at..at+4].try_into().unwrap()), 17);
            }
            assert_eq!(u32::from_le_bytes(wire[0x2c..0x30].try_into().unwrap()), id);
            assert_eq!(&wire[0x30..0x34], &[255;4]);
            assert_eq!(&wire[0x34..0x38], &[0;4]);
            assert_eq!(u32::from_le_bytes(wire[0x38..0x3c].try_into().unwrap()), rank);
            assert_eq!(&wire[0x3c..0x40], &[4,0,0,0]);
            assert_eq!(&wire[0x40..], &[0;12]);
            assert_eq!(Packet::read(&wire,PacketType::Classic).unwrap(), vec![packets[index+1].clone()]);
        }
    }

    #[test]
    fn local_hero_passive_unlearned_or_class_exit_removes_without_granting() {
        let mut tree = HeroTree::default();
        for hero in [true,false] {
            assert!(effect_packets(Default::default(), &tree, hero).iter().all(|p|matches!(p,Packet::Unk0425(_))));
        }
        tree.ranks.insert("WpnmanCounter".into(), 5);
        assert_eq!(effect_packets(Default::default(), &tree, true).len(), 6);
        assert!(effect_packets(Default::default(), &tree, false).iter().all(|p|matches!(p,Packet::Unk0425(_))));
    }
}

#[cfg(test)]
mod followup_tests {
    use super::*;
    #[test]
    fn local_hero_time_finish_step_ja_only_install_learned_effects_and_clear_on_exit() {
        let mut tree=HeroTree::default();
        for name in ["WpnmanTime","WpnmanTimeFinish","WpnmanStepJACombo"] {tree.ranks.insert(name.into(),1);}
        let packets=effect_packets(Default::default(),&tree,true);
        let applied:Vec<_>=packets.iter().filter_map(|p|if let Packet::Unk0424(p)=p {Some((p.unk4,u32::from_le_bytes(p.unk6[4..8].try_into().unwrap())))}else{None}).collect();
        assert_eq!(applied,vec![(111005,1),(111006,1),(111032,1)]);
        let exit=effect_packets(Default::default(),&tree,false);
        assert_eq!(exit.len(),6);
        assert!(exit.iter().all(|p|matches!(p,Packet::Unk0425(_))));
        tree.ranks.remove("WpnmanTimeFinish");
        assert!(!effect_packets(Default::default(),&tree,true).iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==111006)));
    }
}
