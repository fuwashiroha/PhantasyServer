//! Dispatcher/socket regressions for invitation validation and transitions.
use super::*;
use crate::{sql,user::{self,UserState}};
use pso2packetlib::{Connection,PrivateKey,PublicKey,protocol::PacketType};
use std::time::Duration;

struct Fixture {groups:Vec<Arc<RwLock<Party>>>,users:Vec<Arc<Mutex<User>>>,peers:Vec<Connection<Packet>>}
async fn recv(p:&mut Connection<Packet>)->Packet {
    tokio::time::timeout(Duration::from_secs(2),p.read_packet_async()).await.unwrap().unwrap()
}
async fn drain(f:&mut Fixture)->Vec<Vec<Packet>> {
    let mut out=vec![];
    for peer in &mut f.peers {
        let mut packets=vec![];
        while let Ok(p)=tokio::time::timeout(Duration::from_millis(15),peer.read_packet_async()).await {packets.push(p.unwrap());}
        out.push(packets);
    }out
}
async fn fixture(sizes:&[usize])->Fixture {fixture_with_block(sizes,None).await}
async fn fixture_with_block(sizes:&[usize],shared:Option<Arc<BlockData>>)->Fixture {
    let db=Arc::new(sql::Sql::in_memory_for_test().await.unwrap());
    let mut f=Fixture{groups:vec![],users:vec![],peers:vec![]};
    for id in 1..=sizes.iter().sum::<usize>() {
        let (mut u,socket)=if let Some(block)=&shared {
            let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
            let peer=tokio::net::TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
            let (stream,_)=listener.accept().await.unwrap();
            let (u,_)=User::new(stream,block.clone(),id).unwrap();(u,peer)
        }else{crate::sql::local_lifecycle_tests::connected_user(db.clone()).await};
        u.user_data.id=id as u32;u.state=UserState::InGame;
        let mut c=sql::CharData::default();c.character.player_id=id as u32;c.character.character_id=id as u32;
        u.character=Some(c);u.send_packet(&Packet::ServerPing).await.unwrap();
        let mut peer=Connection::new_async(socket,PacketType::Classic,PrivateKey::None,PublicKey::None);
        assert!(matches!(recv(&mut peer).await,Packet::ServerHello(_)));assert_eq!(recv(&mut peer).await,Packet::ServerPing);
        f.users.push(Arc::new(Mutex::new(u)));f.peers.push(peer);
    }
    let mut start=0;
    for (i,&size) in sizes.iter().enumerate() {
        Party::init_player(f.users[start].clone(),100+i as u32).await.unwrap();
        let party=f.users[start].lock().await.get_current_party().unwrap();
        for u in &f.users[start+1..start+size] {
            party.write().await.add_player(u.clone()).await.unwrap();u.lock().await.party=Some(party.clone());
        }
        f.groups.push(party);start+=size;
    }
    drain(&mut f).await;f
}
async fn snapshot(p:&Arc<RwLock<Party>>)->Vec<u8> {
    let p=p.read().await;
    rmp_serde::to_vec(&(p.id,p.leader,&p.settings,&p.questname,p.players.iter().map(|(id,_)|*id).collect::<Vec<_>>(),&p.colors)).unwrap()
}
async fn accept(u:&Arc<Mutex<User>>,id:u32)->Result<crate::Action,Error> {
    user::packet_handler(u.lock().await,Packet::AcceptInvite(party::AcceptInvitePacket{
        party_object:ObjectHeader{id,entity_type:ObjectType::Party,..Default::default()},..Default::default()
    })).await
}
async fn bounded_accept(u:&Arc<Mutex<User>>,id:u32)->Result<crate::Action,Error> {
    tokio::time::timeout(Duration::from_secs(2),accept(u,id)).await.expect("invitation must not deadlock")
}
async fn invite(f:&mut Fixture,from:usize,to:usize) {
    Party::send_invite(f.users[from].clone(),f.users[to].clone()).await.unwrap();
    let packets=drain(f).await;
    assert!(packets[to].iter().any(|p|matches!(p,Packet::NewInvite(_))));
}
async fn assert_preserved(f:&mut Fixture,before:&[Vec<u8>],actor:usize,old:usize,invites:usize) {
    for (p,b) in f.groups.iter().zip(before) {assert_eq!(&snapshot(p).await,b);}
    let u=f.users[actor].lock().await;
    assert!(Arc::ptr_eq(u.party.as_ref().unwrap(),&f.groups[old]));assert_eq!(u.party_invites.len(),invites);drop(u);
    assert!(drain(f).await.iter().all(Vec::is_empty),"rejected invitation must not broadcast membership changes");
}
async fn snapshots(f:&Fixture)->Vec<Vec<u8>> {let mut v=vec![];for p in &f.groups {v.push(snapshot(p).await);}v}

#[tokio::test]
async fn local_party_invite_unissued_keeps_original_membership() {
    let mut f=fixture(&[2,2]).await;let before=snapshots(&f).await;
    let _=bounded_accept(&f.users[0],101).await;
    assert_preserved(&mut f,&before,0,0,0).await;
}
#[tokio::test]
async fn local_party_invite_dead_target_keeps_original_membership() {
    let mut f=fixture(&[2,2]).await;let before=snapshots(&f).await;
    f.users[0].lock().await.party_invites.push(PartyInvite{id:999,party:Weak::new(),invite_time:1});
    let _=bounded_accept(&f.users[0],999).await;
    assert_preserved(&mut f,&before,0,0,1).await;
}
#[tokio::test]
async fn local_party_invite_full_target_keeps_original_and_invitation() {
    let mut f=fixture(&[2,4]).await;invite(&mut f,2,0).await;let before=snapshots(&f).await;
    let _=bounded_accept(&f.users[0],101).await;
    assert_preserved(&mut f,&before,0,0,1).await;
}
#[tokio::test]
async fn local_party_invite_same_party_and_replay_do_not_remove_member() {
    let mut f=fixture(&[2,2]).await;
    f.users[0].lock().await.party_invites.push(PartyInvite{id:100,party:Arc::downgrade(&f.groups[0]),invite_time:1});
    let before=snapshots(&f).await;let _=bounded_accept(&f.users[0],100).await;
    assert_preserved(&mut f,&before,0,0,1).await;
    invite(&mut f,2,0).await;bounded_accept(&f.users[0],101).await.unwrap();drain(&mut f).await;
    let before=snapshots(&f).await;let left=f.users[0].lock().await.party_invites.len();
    let _=bounded_accept(&f.users[0],101).await;
    assert_preserved(&mut f,&before,0,1,left).await;
}
#[tokio::test]
async fn local_party_invite_valid_transition_updates_both_groups_and_socket_setup() {
    let mut f=fixture(&[2,2]).await;invite(&mut f,2,0).await;
    bounded_accept(&f.users[0],101).await.unwrap();
    let old=f.groups[0].read().await;assert_eq!(old.players.iter().map(|(id,_)|*id).collect::<Vec<_>>(),vec![2]);
    assert_eq!(old.leader.id,2);assert!(!old.colors.iter().any(|(id,_)|*id==1));drop(old);
    let new=f.groups[1].read().await;assert_eq!(new.players.len(),3);assert_eq!(new.players.iter().filter(|(id,_)|*id==1).count(),1);
    assert_eq!(new.colors.iter().filter(|(id,_)|*id==1).count(),1);drop(new);
    let u=f.users[0].lock().await;assert!(Arc::ptr_eq(u.party.as_ref().unwrap(),&f.groups[1]));assert!(u.party_invites.is_empty());drop(u);
    let packets=drain(&mut f).await;
    assert_eq!(packets[0].iter().filter(|p|matches!(p,Packet::PartyInit(_))).count(),1);
    assert_eq!(packets[0].iter().filter(|p|matches!(p,Packet::PartySetupFinish(_))).count(),1);
    assert!(packets[1].iter().any(|p|matches!(p,Packet::RemoveMember(_))));
    for i in [2,3] {assert!(packets[i].iter().any(|p|matches!(p,Packet::AddMember(_))));}
}
#[tokio::test]
async fn local_party_invite_concurrent_last_slot_preserves_losing_party() {
    let mut f=fixture(&[2,3,2]).await;invite(&mut f,2,0).await;invite(&mut f,2,5).await;
    let before=snapshots(&f).await;
    let results=tokio::time::timeout(Duration::from_secs(3),async {tokio::join!(accept(&f.users[0],101),accept(&f.users[5],101))}).await.expect("last-slot admission must complete");
    let p=f.groups[1].read().await;assert_eq!(p.players.len(),4);
    let first=p.players.iter().any(|(id,_)|*id==1);let second=p.players.iter().any(|(id,_)|*id==6);assert_ne!(first,second);drop(p);
    let (loser,group)=if first {(5,2)}else{(0,0)};
    assert_eq!(snapshot(&f.groups[group]).await,before[group]);
    let u=f.users[loser].lock().await;assert!(Arc::ptr_eq(u.party.as_ref().unwrap(),&f.groups[group]));assert_eq!(u.party_invites.len(),1);
    assert_eq!(usize::from(results.0.is_ok())+usize::from(results.1.is_ok()),1);
}
#[tokio::test]
async fn local_party_invite_opposite_transfers_complete_without_duplicate_members() {
    let mut f=fixture(&[2,2]).await;invite(&mut f,2,0).await;invite(&mut f,0,2).await;
    let results=tokio::time::timeout(Duration::from_secs(3),async {tokio::join!(accept(&f.users[0],101),accept(&f.users[2],100))}).await.expect("opposite transfers must have consistent lock order");
    results.0.unwrap();results.1.unwrap();
    for (index,mut expected) in [(0,vec![2,3]),(1,vec![1,4])] {
        let p=f.groups[index].read().await;let mut ids=p.players.iter().map(|(id,_)|*id).collect::<Vec<_>>();ids.sort();expected.sort();assert_eq!(ids,expected);
        assert_eq!(p.colors.len(),2);assert!(ids.contains(&p.leader.id));
    }
    for (actor,group) in [(0,1),(2,0)] {assert!(Arc::ptr_eq(f.users[actor].lock().await.party.as_ref().unwrap(),&f.groups[group]));}
}

async fn query(u:&Arc<Mutex<User>>,ids:&[u32],details:bool)->Result<crate::Action,Error> {
    let parties=ids.iter().map(|id|ObjectHeader{id:*id,entity_type:ObjectType::Party,..Default::default()}).collect::<Vec<_>>();
    let p=if details {Packet::GetPartyDetails(party::GetPartyDetailsPacket{parties:parties.into(),..Default::default()})}
        else {Packet::GetPartyInfo(party::GetPartyInfoPacket{parties:parties.into(),..Default::default()})};
    user::packet_handler(u.lock().await,p).await
}
async fn bounded_query(u:&Arc<Mutex<User>>,ids:&[u32],details:bool) {
    tokio::time::timeout(Duration::from_secs(2),query(u,ids,details)).await.expect("party query deadlocked").unwrap();
}
#[tokio::test]
async fn local_party_query_current_member_details_do_not_relock_requester() {
    let mut f=fixture(&[2]).await;
    f.users[0].lock().await.party_invites.push(PartyInvite{id:100,party:Arc::downgrade(&f.groups[0]),invite_time:7});
    let before=snapshots(&f).await;bounded_query(&f.users[0],&[100],true).await;
    match recv(&mut f.peers[0]).await {
        Packet::PartyDetails(p)=>{assert_eq!(p.num_of_details,1);assert_eq!(p.details.len(),12);assert_eq!(p.details[0].party_id.id,100);
            assert_eq!(p.details[0].unk10[0].id.id,1);assert_eq!(p.details[0].unk10[1].id.id,2);},
        other=>panic!("unexpected {other:?}"),
    }
    assert_eq!(recv(&mut f.peers[0]).await,Packet::PartyDetailsStopper);
    assert_eq!(snapshots(&f).await,before);assert!(drain(&mut f).await.iter().all(Vec::is_empty));
}
#[tokio::test]
async fn local_party_query_waiting_for_party_releases_requester() {
    for details in [false,true] {
        let mut f=fixture(&[2,2]).await;invite(&mut f,2,0).await;
        let blocked=f.groups[1].write().await;
        let mut pending=Box::pin(query(&f.users[0],&[101],details));
        assert!(tokio::time::timeout(Duration::from_millis(25),&mut pending).await.is_err());
        let available=f.users[0].try_lock();assert!(available.is_some(),"query holds requester while waiting for party");drop(available);
        drop(blocked);tokio::time::timeout(Duration::from_secs(2),pending).await.unwrap().unwrap();
        let packets=drain(&mut f).await;assert_eq!(packets[0].len(),2);
    }
}
#[tokio::test]
async fn local_party_query_cancellation_leaves_requester_mutex_usable() {
    for details in [false,true] {
        let mut f=fixture(&[2,2]).await;invite(&mut f,2,0).await;
        let blocked=f.groups[1].write().await;
        assert!(tokio::time::timeout(Duration::from_millis(25),query(&f.users[0],&[101],details)).await.is_err());
        let available=f.users[0].try_lock();assert!(available.is_some());drop(available);drop(blocked);
        bounded_query(&f.users[0],&[101],details).await;
        let packets=drain(&mut f).await;assert_eq!(packets[0].len(),2,"cancelled query must not emit a partial reply");
    }
}
#[tokio::test]
async fn local_party_query_page_boundaries_and_empty_dead_filters_are_preserved() {
    let mut f=fixture(&[1;14]).await;
    for i in 1..14 {
        f.groups[i].write().await.settings.name=format!("party-{i}");
        f.groups[i].write().await.settings.comments=format!("comment-{i}");
        f.users[i].lock().await.user_data.nickname=format!("nickname-{i}");
        f.users[0].lock().await.party_invites.push(PartyInvite{id:100+i as u32,party:Arc::downgrade(&f.groups[i]),invite_time:1000+i as u32});
    }
    f.users[0].lock().await.party_invites.push(PartyInvite{id:999,party:Weak::new(),invite_time:0});
    let ids=(101..=113).chain([999]).collect::<Vec<_>>();
    bounded_query(&f.users[0],&ids,false).await;
    let packets=drain(&mut f).await;let mut count=0;
    for (index,expected) in [(0,10),(1,3)] {
        match &packets[0][index] {
            Packet::PartyInfo(p)=>{assert_eq!(p.num_of_infos,expected);
                for r in &p.infos[..expected as usize] {count+=1;assert_eq!(r.party_object.id,100+count);assert_eq!(r.invite_time,1000+count);assert_eq!(r.name,format!("party-{count}"));}
            },other=>panic!("unexpected {other:?}"),
        }
    }
    assert_eq!(packets[0].len(),3);assert!(matches!(packets[0][2],Packet::PartyInfoStopper(_)));
    bounded_query(&f.users[0],&ids,true).await;
    let packets=drain(&mut f).await;count=0;
    for (index,expected) in [(0,12),(1,1)] {
        match &packets[0][index] {
            Packet::PartyDetails(p)=>{assert_eq!(p.num_of_details,expected);assert_eq!(p.details.len(),12);
                for r in &p.details[..expected as usize] {count+=1;assert_eq!(r.party_id.id,100+count);assert_eq!(r.party_desc,format!("comment-{count}"));assert_eq!(r.unk10[0].id.id,count+1);assert_eq!(r.unk10[0].nickname,format!("nickname-{count}"));}
            },other=>panic!("unexpected {other:?}"),
        }
    }
    assert_eq!(packets[0].len(),3);assert_eq!(packets[0][2],Packet::PartyDetailsStopper);
    for details in [false,true] {for ids in [vec![],vec![999],vec![777]] {
        bounded_query(&f.users[0],&ids,details).await;let packets=drain(&mut f).await;assert_eq!(packets[0].len(),1);
        if details {assert_eq!(packets[0][0],Packet::PartyDetailsStopper)}else{assert!(matches!(packets[0][0],Packet::PartyInfoStopper(_)));}
    }}
}
#[tokio::test]
async fn local_party_query_and_opposite_member_transfer_finish_together() {
    let mut f=fixture(&[2,2]).await;invite(&mut f,2,0).await;invite(&mut f,0,2).await;
    let before=f.users[0].lock().await.party_invites.len();
    let (queried,joined)=tokio::time::timeout(Duration::from_secs(3),async {
        tokio::join!(query(&f.users[0],&[101],true),accept(&f.users[2],100))
    }).await.expect("query and transfer must not form a lock cycle");
    queried.unwrap();joined.unwrap();
    assert_eq!(f.users[0].lock().await.party_invites.len(),before);
    assert!(Arc::ptr_eq(f.users[2].lock().await.party.as_ref().unwrap(),&f.groups[0]));
    assert_eq!(f.groups[0].read().await.players.len(),3);assert_eq!(f.groups[1].read().await.players.len(),1);
    assert!(drain(&mut f).await[0].iter().any(|p|matches!(p,Packet::PartyDetailsStopper)));
}

async fn disband(u:&Arc<Mutex<User>>)->Result<crate::Action,Error> {
    user::packet_handler(u.lock().await,Packet::DisbandParty(Default::default())).await
}
async fn disband_fixture(sizes:&[usize])->(Fixture,Arc<BlockData>) {
    use crate::{Quests,ServerData,SerDeFile,map::Map};
    use std::sync::atomic::AtomicU32;
    let db=Arc::new(sql::Sql::in_memory_for_test().await.unwrap());
    let data=Arc::new(ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap());
    let ids=AtomicU32::new(1);let lobby=Map::new_from_data(data.maps["lobby"].clone(),&ids).unwrap();
    let block=Arc::new(BlockData{sql:db,block_id:1,block_name:"disband tests".into(),
        blocks:Arc::new(RwLock::new(vec![])),lobby:Arc::new(Mutex::new(lobby)),key:PrivateKey::None,
        latest_mapid:ids,latest_partyid:AtomicU32::new(1000),server_data:data.clone(),
        quests:Arc::new(Quests::load(data.quests.clone())),clients:Mutex::new(vec![])});
    (fixture_with_block(sizes,Some(block.clone())).await,block)
}
async fn solo_party_ids(f:&Fixture)->Vec<u32> {
    let mut ids=vec![];
    for (index,u) in f.users.iter().enumerate() {
        let group=u.lock().await.get_current_party().unwrap();let p=group.read().await;
        assert_eq!(p.players.len(),1);assert_eq!(p.players[0].0,index as u32+1);
        assert_eq!(p.leader.id,index as u32+1);assert_eq!(p.colors.len(),1);
        ids.push(p.id.id);
    }ids
}
#[tokio::test]
async fn local_party_disband_distinct_solo_ids_and_matching_wire_setup() {
    let (mut f,block)=disband_fixture(&[4]).await;
    tokio::time::timeout(Duration::from_secs(3),disband(&f.users[0])).await.unwrap().unwrap();
    let ids=solo_party_ids(&f).await;
    assert_eq!(ids.iter().copied().collect::<std::collections::HashSet<_>>().len(),4,"each recreated party needs its own ID");
    assert_eq!(block.latest_partyid.load(std::sync::atomic::Ordering::Relaxed),1004);
    assert!(f.groups[0].read().await.players.is_empty());
    let packets=drain(&mut f).await;
    for (i,ps) in packets.iter().enumerate() {
        assert_eq!(ps.iter().filter(|p|matches!(p,Packet::PartyDisbandedMarker)).count(),1);
        let setups=ps.iter().filter_map(|p|if let Packet::PartyInit(p)=p {Some(p)}else{None}).collect::<Vec<_>>();
        assert_eq!(setups.len(),1);assert_eq!(setups[0].party_object.id,ids[i]);
        assert_eq!(setups[0].people_amount,1);assert_eq!(setups[0].leader.id,i as u32+1);
    }
}
#[tokio::test]
async fn local_party_disband_concurrent_groups_share_unique_allocator() {
    let (mut f,block)=disband_fixture(&[2,2]).await;
    let (a,b)=tokio::time::timeout(Duration::from_secs(3),async{tokio::join!(disband(&f.users[0]),disband(&f.users[2]))}).await.unwrap();
    a.unwrap();b.unwrap();let ids=solo_party_ids(&f).await;
    assert_eq!(ids.iter().copied().collect::<std::collections::HashSet<_>>().len(),4);
    assert_eq!(block.latest_partyid.load(std::sync::atomic::Ordering::Relaxed),1004);
    for g in &f.groups {assert!(g.read().await.players.is_empty());}
    drain(&mut f).await;
}
#[tokio::test]
async fn local_party_disband_separate_invitations_resolve_selected_solo_party() {
    let (mut f,_)=disband_fixture(&[4]).await;
    tokio::time::timeout(Duration::from_secs(3),disband(&f.users[0])).await.unwrap().unwrap();drain(&mut f).await;
    for i in 0..3 {invite(&mut f,i,3).await;}
    let invites=f.users[3].lock().await.party_invites.iter().map(|p|p.id).collect::<Vec<_>>();assert_eq!(invites.len(),3);
    bounded_query(&f.users[3],&invites,false).await;let packets=drain(&mut f).await;
    let listed=packets[3].iter().find_map(|p|if let Packet::PartyInfo(p)=p {Some(p)}else{None}).unwrap();
    assert_eq!(listed.num_of_infos,3);
    let target=f.users[1].lock().await.get_current_party().unwrap();let id=target.read().await.id.id;
    bounded_accept(&f.users[3],id).await.unwrap();
    assert!(Arc::ptr_eq(f.users[3].lock().await.party.as_ref().unwrap(),&target));
    assert_eq!(target.read().await.players.len(),2);
    for i in [0,2] {let p=f.users[i].lock().await.get_current_party().unwrap();assert_eq!(p.read().await.players.len(),1);}
}
