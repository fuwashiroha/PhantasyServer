//! Real dispatcher and Classic socket replies; no client/UI or complete party acceptance.
use super::*;
use crate::{sql, user::{self, UserState}};
use pso2packetlib::{Connection, PrivateKey, PublicKey, protocol::PacketType};
use std::time::Duration;

struct Fixture {
    party: Arc<RwLock<Party>>,
    users: Vec<Arc<Mutex<User>>>,
    peers: Vec<Connection<Packet>>,
}
async fn receive(peer:&mut Connection<Packet>)->Packet {
    tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap()
}
async fn quiet(peers:&mut [Connection<Packet>]) {
    for peer in peers {
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err(),"unexpected party broadcast");
    }
}
async fn fixture()->Fixture {
    let sql=Arc::new(sql::Sql::in_memory_for_test().await.unwrap());
    let mut users=vec![];let mut peers=vec![];
    for id in 1..=4 {
        let (mut u,socket)=crate::sql::local_lifecycle_tests::connected_user(sql.clone()).await;
        u.user_data.id=id;u.state=UserState::InGame;
        let mut character=sql::CharData::default();
        character.character.player_id=id;character.character.character_id=id;
        u.character=Some(character);u.send_packet(&Packet::ServerPing).await.unwrap();
        let mut peer=Connection::new_async(socket,PacketType::Classic,PrivateKey::None,PublicKey::None);
        assert!(matches!(receive(&mut peer).await,Packet::ServerHello(_)));
        assert_eq!(receive(&mut peer).await,Packet::ServerPing);
        users.push(Arc::new(Mutex::new(u)));peers.push(peer);
    }
    Party::init_player(users[0].clone(),1).await.unwrap();
    let party=users[0].lock().await.get_current_party().unwrap();
    for u in &users[1..] {party.write().await.add_player(u.clone()).await.unwrap();u.lock().await.party=Some(party.clone());}
    // Drain actual join/setup packets, retaining the sockets for settings assertions.
    for peer in &mut peers {
        while let Ok(packet)=tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await {packet.unwrap();}
    }
    Fixture{party,users,peers}
}
fn settings(name:&str)->party::NewPartySettingsPacket {
    party::NewPartySettingsPacket{name:name.into(),password:"fixture-pass".into(),comments:"fixture-comment".into(),
        questname:"fixture-quest".into(),min_level:10,max_level:80,playstyle:1,..Default::default()}
}
async fn send(u:&Arc<Mutex<User>>,name:&str)->Result<crate::Action,Error> {
    tokio::time::timeout(Duration::from_secs(2),user::packet_handler(u.lock().await,Packet::NewPartySettings(settings(name))))
        .await.expect("settings handler must release user before acquiring party/broadcast locks")
}
async fn snapshot(party:&Arc<RwLock<Party>>)->Vec<u8> {
    let p=party.read().await;
    rmp_serde::to_vec(&(p.id,p.leader,&p.settings,&p.questname,p.players.iter().map(|(id,_)|*id).collect::<Vec<_>>(),&p.colors)).unwrap()
}
async fn assert_broadcast(f:&mut Fixture,name:&str) {
    let expected=party::PartySettingsPacket{name:name.into(),password:"fixture-pass".into(),comments:"fixture-comment".into(),
        min_level:10,max_level:80,playstyle:1,..Default::default()};
    {
        let p=f.party.read().await;assert_eq!(p.settings,expected);assert_eq!(p.questname,"fixture-quest");
    }
    for peer in &mut f.peers {assert_eq!(receive(peer).await,Packet::PartySettings(expected.clone()));}
    quiet(&mut f.peers).await;
}
#[tokio::test]
async fn local_party_settings_members_cannot_mutate_or_broadcast() {
    let mut f=fixture().await;
    let before=snapshot(&f.party).await;
    for index in 1..4 {
        assert!(send(&f.users[index],"unauthorized").await.is_err(),"ordinary member must not overwrite party settings");
        assert_eq!(snapshot(&f.party).await,before);quiet(&mut f.peers).await;
    }
}
#[tokio::test]
async fn local_party_settings_leader_broadcasts_exact_settings_to_all_four_members() {
    let mut f=fixture().await;
    assert!(matches!(send(&f.users[0],"leader-settings").await.unwrap(),crate::Action::Nothing));
    assert_broadcast(&mut f,"leader-settings").await;
}
#[tokio::test]
async fn local_party_settings_authority_follows_leader_transfer() {
    let mut f=fixture().await;
    let target=f.users[1].lock().await.create_object_header();
    tokio::time::timeout(Duration::from_secs(2),user::packet_handler(f.users[0].lock().await,
        Packet::TransferLeader(party::TransferLeaderPacket{target}))).await.unwrap().unwrap();
    for peer in &mut f.peers {assert_eq!(receive(peer).await,Packet::NewLeader(party::NewLeaderPacket{leader:target}));}
    let before=snapshot(&f.party).await;
    assert!(send(&f.users[0],"former-leader").await.is_err());
    assert_eq!(snapshot(&f.party).await,before);quiet(&mut f.peers).await;
    send(&f.users[1],"new-leader").await.unwrap();assert_broadcast(&mut f,"new-leader").await;
}
#[tokio::test]
async fn local_party_settings_orphaned_leader_is_rejected_without_mutation() {
    let mut f=fixture().await;
    // Stale membership must not grant authority from the leader id alone.
    f.party.write().await.players.retain(|(id,_)|*id!=1);
    let before=snapshot(&f.party).await;
    assert!(send(&f.users[0],"orphaned-leader").await.is_err());
    assert_eq!(snapshot(&f.party).await,before);quiet(&mut f.peers).await;
}

async fn transfer(u:&Arc<Mutex<User>>,target:ObjectHeader)->Result<crate::Action,Error> {
    tokio::time::timeout(Duration::from_secs(2),user::packet_handler(u.lock().await,
        Packet::TransferLeader(party::TransferLeaderPacket{target})))
        .await.expect("leadership transfer must release user lock before party broadcast")
}
#[tokio::test]
async fn local_party_leader_unknown_and_expired_members_cannot_become_leader() {
    let mut f=fixture().await;
    for target in [0,999] {
        let before=snapshot(&f.party).await;
        assert!(transfer(&f.users[0],ObjectHeader{id:target,entity_type:ObjectType::Player,..Default::default()}).await.is_err(),
            "nonmember target must not become party leader");
        assert_eq!(snapshot(&f.party).await,before);quiet(&mut f.peers).await;
    }
    // A dead weak entry is not a live party member.
    f.party.write().await.players.push((999,Weak::new()));
    let before=snapshot(&f.party).await;
    assert!(transfer(&f.users[0],ObjectHeader{id:999,entity_type:ObjectType::Player,..Default::default()}).await.is_err());
    assert_eq!(snapshot(&f.party).await,before);quiet(&mut f.peers).await;
}
#[tokio::test]
async fn local_party_leader_departed_player_keeps_own_party_and_cannot_be_target() {
    let mut f=fixture().await;
    let target=f.users[3].lock().await.create_object_header();
    tokio::time::timeout(Duration::from_secs(2),user::packet_handler(f.users[3].lock().await,Packet::LeaveParty)).await.unwrap().unwrap();
    let own=f.users[3].lock().await.get_current_party().unwrap();
    assert!(!Arc::ptr_eq(&own,&f.party));
    for peer in &mut f.peers {
        while let Ok(packet)=tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await {packet.unwrap();}
    }
    let before=snapshot(&f.party).await;let other=snapshot(&own).await;
    assert!(transfer(&f.users[0],target).await.is_err(),"departed member must not become old party leader");
    assert_eq!(snapshot(&f.party).await,before);assert_eq!(snapshot(&own).await,other);quiet(&mut f.peers).await;
}
#[tokio::test]
async fn local_party_leader_live_target_uses_canonical_identity_and_gains_settings_authority() {
    let mut f=fixture().await;
    let expected=f.users[1].lock().await.create_object_header();
    let supplied=ObjectHeader{id:expected.id,unk:55,entity_type:ObjectType::Party,map_id:77};
    transfer(&f.users[0],supplied).await.unwrap();
    assert_eq!(f.party.read().await.leader,expected,"client object metadata must not redefine the player leader");
    for peer in &mut f.peers {assert_eq!(receive(peer).await,Packet::NewLeader(party::NewLeaderPacket{leader:expected}));}
    quiet(&mut f.peers).await;
    send(&f.users[1],"canonical-leader").await.unwrap();assert_broadcast(&mut f,"canonical-leader").await;
}
