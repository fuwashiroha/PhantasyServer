//! Bounded diagnostics for unsupported requests; this does not implement them.
use super::{UserState, packet_identity::PacketIdentity};

const MAX_IDENTITIES: usize = 64;

#[derive(Default)]
pub(super) struct UnhandledPackets {
    entries: Vec<(UserState, PacketIdentity, u64)>,
    overflow: u64,
}

#[derive(Debug, PartialEq, Eq)]
pub(super) enum Observation {
    IdentityCount(u64),
    OverflowCount(u64),
}

impl UnhandledPackets {
    // The first occurrence and exponentially spaced repetitions remain visible
    // in release logs without dumping payloads or growing per-session memory.
    pub(super) fn observe(&mut self, state: UserState, identity: PacketIdentity) -> Option<Observation> {
        if let Some((_, _, count)) = self.entries.iter_mut().find(|(s, p, _)| *s == state && *p == identity) {
            *count = count.saturating_add(1);
            return count.is_power_of_two().then_some(Observation::IdentityCount(*count));
        }
        if self.entries.len() < MAX_IDENTITIES {
            self.entries.push((state, identity, 1));
            return Some(Observation::IdentityCount(1));
        }
        self.overflow = self.overflow.saturating_add(1);
        self.overflow.is_power_of_two().then_some(Observation::OverflowCount(self.overflow))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::user::packet_identity::identify;
    use pso2packetlib::protocol::{Packet, PacketHeader};

    #[test]
    fn local_diagnostics_repetitions_are_bounded_and_state_specific() {
        let mut tracker = UnhandledPackets::default();
        let identity = identify(&Packet::SalonEntryRequest);
        let emitted: Vec<_> = (1..=1000)
            .filter_map(|_|tracker.observe(UserState::InGame, identity)).collect();
        assert_eq!(emitted, [1,2,4,8,16,32,64,128,256,512].map(Observation::IdentityCount));
        assert_eq!(tracker.observe(UserState::CharacterSelect, identity), Some(Observation::IdentityCount(1)));
        assert_eq!(tracker.entries.len(), 2);
    }

    #[test]
    fn local_diagnostics_unknown_headers_have_bounded_storage() {
        let mut tracker = UnhandledPackets::default();
        let mut overflow_reports = 0;
        for subid in 0..1000 {
            let packet = Packet::Unknown((PacketHeader::new(0xfe, subid, Default::default()), vec![42; 100]));
            let id = identify(&packet);
            assert_eq!(id.header, Some((0xfe, subid)));
            if matches!(tracker.observe(UserState::InGame, id), Some(Observation::OverflowCount(_))) {
                overflow_reports += 1;
            }
        }
        assert_eq!(tracker.entries.len(), MAX_IDENTITIES);
        assert_eq!(tracker.overflow, 1000 - MAX_IDENTITIES as u64);
        assert_eq!(overflow_reports, 10);
    }

    #[test]
    fn local_diagnostics_metadata_excludes_payloads() {
        let packet = Packet::Unknown((PacketHeader::new(0xff, 0xab, Default::default()), b"private-payload-marker".to_vec()));
        let description = format!("{:?}", identify(&packet));
        assert!(description.contains("Unknown"));
        assert!(!description.contains("private-payload-marker"));
        assert_eq!(identify(&Packet::SalonEntryRequest).header, Some((0x11, 0x66)));
    }
}
