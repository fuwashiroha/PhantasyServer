use super::HResult;
use crate::{Action, Error, User, mutex::MutexGuard};
use pso2packetlib::protocol::{
    self, Packet,
    items::{
        DiscardItemRequestPacket, DiscardStorageItemRequestPacket, EquipItemPacket,
        EquipItemRequestPacket, GetItemDescriptionPacket, ItemType, LoadItemDescriptionPacket,
        MoveMesetaPacket, MoveStoragesRequestPacket, MoveToInventoryRequestPacket,
        MoveToStorageRequestPacket, UnequipItemPacket, UnequipItemRequestPacket,
    },
    login::Language,
};

pub async fn move_to_storage(user: &mut User, packet: MoveToStorageRequestPacket) -> HResult {
    user.queue_asset_change(|inventory, uuid| Ok(vec![inventory.move_to_storage(packet, uuid)?]))?;
    Ok(Action::Nothing)
}

pub async fn move_to_inventory(user: &mut User, packet: MoveToInventoryRequestPacket) -> HResult {
    user.queue_asset_change(|inventory, uuid| Ok(vec![inventory.move_to_inventory(packet, uuid)?]))?;
    Ok(Action::Nothing)
}

pub async fn move_meseta(user: &mut User, packet: MoveMesetaPacket) -> HResult {
    user.queue_asset_change(|inventory, _uuid| Ok(inventory.move_meseta(packet)?))?;
    Ok(Action::Nothing)
}

pub async fn discard_inventory(user: &mut User, packet: DiscardItemRequestPacket) -> HResult {
    user.queue_asset_change(|inventory, _uuid| Ok(vec![inventory.discard_inventory(packet)?]))?;
    Ok(Action::Nothing)
}

pub async fn discard_storage(user: &mut User, packet: DiscardStorageItemRequestPacket) -> HResult {
    user.queue_asset_change(|inventory, _uuid| Ok(vec![inventory.discard_storage(packet)?]))?;
    Ok(Action::Nothing)
}

pub async fn move_storages(user: &mut User, packet: MoveStoragesRequestPacket) -> HResult {
    user.queue_asset_change(|inventory, uuid| Ok(vec![inventory.move_storages(packet, uuid)?]))?;
    Ok(Action::Nothing)
}

pub async fn get_description(user: &mut User, packet: GetItemDescriptionPacket) -> HResult {
    let names_ref = &user.blockdata.server_data.item_params;
    match names_ref.names.iter().find(|x| x.id == packet.item) {
        Some(name) => {
            let packet = LoadItemDescriptionPacket {
                unk1: 1,
                item: packet.item,
                desc: match user.user_data.lang {
                    Language::English => name.en_desc.clone(),
                    Language::Japanese => name.jp_desc.clone(),
                },
            };
            user.send_packet(&protocol::Packet::LoadItemDescription(packet))
                .await?;
        }
        None => log::debug!("No item description for {:?}", packet.item),
    }

    Ok(Action::Nothing)
}

pub async fn equip_item(mut user: MutexGuard<'_, User>, packet: EquipItemRequestPacket) -> HResult {
    let Some(char) = &user.character else {
        unreachable!("User should be in state >= `PreInGame`")
    };
    let item = char.inventory.get_inv_item(packet.uuid)?;
    let costume = if let ItemType::Clothing(data) = &item.data {
        //BUG: a (0x0F, 0x2B) packet should also be sent, but let's not worry about it at this time
        let block_data = user.get_blockdata();
        let clothing_stats = block_data
            .server_data
            .item_params
            .attrs
            .human_costumes
            .iter()
            .find(|a| a.id == item.id.id && a.subid == item.id.subid)
            .cloned()
            .ok_or(Error::NoItemInAttrs(item.id.id, item.id.subid))?;
        Some((clothing_stats.model, data.color.clone()))
    } else {
        None
    };
    // All fallible lookups finish before equipment or appearance changes.
    // The user lock covers this commit; there is no await between the fields.
    let mut char = user.character.as_ref().unwrap().clone();
    char.inventory.equip_item(packet.uuid, packet.equipment_pos)?;
    if let Some((model, color)) = costume {
        char.character.look.costume_id = model;
        char.character.look.costume_color = color;
    }

    let equip_packet = Packet::EquipItem(EquipItemPacket {
        player_equiped: user.create_object_header(),
        equiped_item: item.clone(),
        equipment_pos: packet.equipment_pos,
        ..Default::default()
    });
    let stats = if matches!(item.data, ItemType::Unit(_))
        || !user.character.as_ref().unwrap().inventory.equipped_units()?.is_empty() {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(&user, &char)?)
    } else { None };
    user.queue_equipment_change(char, stats, vec![], vec![equip_packet])?;

    Ok(Action::Nothing)
}

pub async fn unequip_item(
    mut user: MutexGuard<'_, User>,
    packet: UnequipItemRequestPacket,
) -> HResult {
    let Some(char) = &user.character else {
        unreachable!("User should be in state >= `PreInGame`")
    };
    let item = char.inventory.get_inv_item(packet.uuid)?;
    let mut char = char.clone();
    char.inventory.unequip_item(packet.uuid)?;
    let equip_packet = Packet::UnequipItem(UnequipItemPacket {
        player_unequiped: user.create_object_header(),
        unequiped_item: item.clone(),
        equipment_pos: packet.equipment_pos,
        ..Default::default()
    });
    let stats = if matches!(item.data, ItemType::Unit(_)) {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(&user, &char)?)
    } else { None };
    user.queue_equipment_change(char, stats, vec![], vec![equip_packet])?;

    Ok(Action::Nothing)
}

#[cfg(test)]
mod local_equip_tests;
