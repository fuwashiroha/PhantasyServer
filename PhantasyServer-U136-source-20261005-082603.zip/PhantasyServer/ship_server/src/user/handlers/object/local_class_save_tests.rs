//! Real packet sockets and SQLite prove save ordering, not HP or class eligibility.
use crate::user::*;
use crate::user::local_equipment_save_tests::finish;
use crate::sql::local_checkpoint_tests::{Requests, ack, saved_character};
use data_structs::master_ship::{AccountCommitResult, MasterShipAction};
use pso2packetlib::protocol::{models::character::{Class,ClassLevel},objects::*};
use std::time::Duration;

async fn fixture()->(Arc<sql::Sql>,Requests,Mutex<User>,Connection<Packet>) {
    let result=crate::user::local_equipment_save_tests::fixture().await;
    {
        let mut u=result.2.lock().await;
        let c=u.character.as_mut().unwrap();
        c.character.classes.ranger_info=ClassLevel{level1:2,level2:2,exp:123};
        c.character.classes.force_info=ClassLevel{level1:9,level2:9,exp:456};
    }
    result
}
fn request(main:Class,sub:Class)->Packet {
    Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})
}
async fn quiet(peer:&mut Connection<Packet>) {
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err(),
        "class success arrived before its durable receipt");
}
async fn receive(peer:&mut Connection<Packet>)->Packet {
    tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap()
}
async fn close(sql:&sql::Sql,requests:&mut Requests,user:&Mutex<User>,revision:u64) {
    user.lock().await.queue_disconnect();
    let (r,_)=tokio::time::timeout(Duration::from_secs(2),async{tokio::join!(sql.drain_session_saves(),ack(requests,revision,false))}).await.unwrap();r.unwrap();
}
async fn success(peer:&mut Connection<Packet>,expected:&CharData) {
    let Packet::ChangeClass(p)=receive(peer).await else{panic!("missing class success")};
    assert_eq!(p.new_info,expected.character.classes);
    let effects=crate::class_passives::synchronize(p.receiver,expected,Some(Class::Hunter as u8)).unwrap();
    for expected in effects {assert_eq!(receive(peer).await,expected);}
    let Packet::Unk042C(p)=receive(peer).await else{panic!("missing legacy follow-up")};
    assert_eq!((p.unk3,p.unk4),(0x20,1));quiet(peer).await;
}
#[tokio::test]
async fn local_class_save_own_receipt_precedes_success_and_preserves_other_character_fields() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    let before=user.lock().await.character.clone().unwrap();
    let old_stats=format!("{:?}",user.lock().await.get_stats());
    packet_handler(user.lock().await,request(Class::Ranger,Class::Hunter)).await.unwrap();
    quiet(&mut peer).await;
    assert!(!user.lock().await.accepts_client_packets());
    User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert_eq!(commit.expected_revision,0);
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,commit.commit_id);
    quiet(&mut peer).await;
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{
        commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;
    assert!(user.lock().await.accepts_client_packets());
    let saved=saved_character(&sql,1,1).await;
    let mut expected=before;
    expected.character.classes.main_class=Class::Ranger;
    expected.character.classes.sub_class=Class::Hunter;
    assert!(saved.play_time>=expected.play_time);expected.play_time=saved.play_time;
    assert_eq!(rmp_serde::to_vec(&saved).unwrap(),rmp_serde::to_vec(&expected).unwrap());
    // Deliberately leaves the old stats unchanged; recalculation still needs HP evidence.
    assert_eq!(format!("{:?}",user.lock().await.get_stats()),old_stats);
    success(&mut peer,&saved).await;close(&sql,&mut requests,&user,1).await;
}
#[tokio::test]
async fn local_class_save_missing_lease_rejects_before_mutation_or_reply() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    let session=user.lock().await.account_session.take();
    let before=rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap();
    let stats=format!("{:?}",user.lock().await.get_stats());
    assert!(packet_handler(user.lock().await,request(Class::Ranger,Class::Hunter)).await.is_err());
    {
        let mut u=user.lock().await;
        assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);
        assert_eq!(format!("{:?}",u.get_stats()),stats);
        assert!(u.pending_asset.is_none() && u.pending_equipment_broadcast.is_none());
        u.account_session=session;
    }
    quiet(&mut peer).await;assert!(requests.try_recv().is_err());close(&sql,&mut requests,&user,0).await;
}

#[tokio::test]
async fn local_class_save_older_checkpoint_cannot_release_new_class_reply() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    user.lock().await.checkpoint_due=Instant::now();User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
    packet_handler(user.lock().await,request(Class::Ranger,Class::Unknown)).await.unwrap();
    quiet(&mut peer).await;
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
        commit_id:commit.commit_id,revision:1,duplicate:false
    })).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {User::tick(user.lock().await).await.unwrap();if user.lock().await.checkpoint_for_asset {break;}tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await;ack(&mut requests,1,false).await;finish(&user).await;
    let saved=saved_character(&sql,1,1).await;
    assert_eq!(saved.character.classes.main_class,Class::Ranger);
    success(&mut peer,&saved).await;close(&sql,&mut requests,&user,2).await;
}

#[tokio::test]
async fn local_class_save_lost_receipt_never_reports_success_and_recovers_exact_snapshot() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    packet_handler(user.lock().await,request(Class::Ranger,Class::Hunter)).await.unwrap();
    User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit:original,..}=action else {panic!()};drop(send);
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {let _=User::tick(user.lock().await).await.unwrap();if user.lock().await.closing {break;}tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await;
    let serve=async {
        let retry=ack(&mut requests,0,true).await;
        assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&original).unwrap());
        ack(&mut requests,1,false).await;
    };
    let (r,())=tokio::time::timeout(Duration::from_secs(2),async {tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();r.unwrap();
    let saved=saved_character(&sql,1,1).await;
    assert_eq!((saved.character.classes.main_class,saved.character.classes.sub_class),(Class::Ranger,Class::Hunter));
    assert_eq!(saved.character.classes.ranger_info,ClassLevel {level1:2,level2:2,exp:123});
    quiet(&mut peer).await;
}
