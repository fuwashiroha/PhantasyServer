//! Handler/packet/SQLite checks for explicit Classic class-combination rules.
//! These do not accept class unlocks, HP transitions or complete class switching.
use super::*;
use pso2packetlib::protocol::models::character::Class;
use crate::user::local_equipment_save_tests::{fixture,auto_master,finish};
use crate::sql::local_checkpoint_tests::saved_character;
use std::time::Duration;

fn request(main:Class,sub:Class)->Packet {
    Packet::ChangeClassRequest(objects::ChangeClassRequestPacket {
        main_class:main,sub_class:sub,..Default::default()
    })
}
#[tokio::test]
async fn local_class_rules_invalid_selection_never_mutates_or_sends_success() {
    let (sql,requests,user,mut peer)=fixture().await;auto_master(requests);
    let original=user.lock().await.character.as_ref().unwrap().character.classes.clone();
    for (main,sub) in [
        (Class::Unknown,Class::Unknown),(Class::Unknown,Class::Ranger),
        (Class::Hero,Class::Hunter),(Class::Phantom,Class::Ranger),
        (Class::Etole,Class::Ranger),(Class::Luster,Class::Ranger),
        (Class::Hunter,Class::Hero),(Class::Phantom,Class::Hero),(Class::Hero,Class::Hero),
    ] {
        let before=rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap();
        let stats=format!("{:?}",user.lock().await.get_stats());
        assert!(crate::user::packet_handler(user.lock().await,request(main,sub)).await.is_err(),
            "invalid {main:?}/{sub:?} must be rejected");
        assert_eq!(rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap(),before);
        assert_eq!(format!("{:?}",user.lock().await.get_stats()),stats);
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
    assert_eq!(saved_character(&sql,1,1).await.character.classes,original);
}

#[tokio::test]
async fn local_class_rules_valid_ordinary_and_successor_choices_keep_legacy_response_and_levels() {
    let (sql,requests,user,mut peer)=fixture().await;auto_master(requests);
    let original=user.lock().await.character.as_ref().unwrap().character.classes.clone();
    for (main,sub) in [
        (Class::Ranger,Class::Hunter),(Class::Hunter,Class::Unknown),
        (Class::Hunter,Class::Phantom),(Class::Hunter,Class::Etole),(Class::Hunter,Class::Luster),
        (Class::Hero,Class::Unknown),(Class::Phantom,Class::Unknown),
        (Class::Etole,Class::Unknown),(Class::Luster,Class::Unknown),
    ] {
        let old_main=user.lock().await.character.as_ref().unwrap().character.classes.main_class;
        crate::user::packet_handler(user.lock().await,request(main,sub)).await.unwrap();
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
        finish(&user).await;
        let mut expected=original.clone();expected.main_class=main;expected.sub_class=sub;
        assert_eq!(user.lock().await.character.as_ref().unwrap().character.classes,expected);
        let packet=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap();
        let Packet::ChangeClass(p)=packet else {panic!("missing existing class reply")};
        assert_eq!(p.new_info,expected);
        if old_main==Class::Phantom || main==Class::Phantom {
            let packet=peer.read_packet_async().await.unwrap();
            assert!(matches!(packet,Packet::Unknown((h,_)) if (h.id,h.subid)==(4,0x28)));
            let c=user.lock().await.character.clone().unwrap();
            let expected_effects=crate::phantom_passives::synchronize(user.lock().await.create_object_header(),&c).unwrap();
            for expected in expected_effects {assert_eq!(peer.read_packet_async().await.unwrap(),expected);}
        }
        let c=user.lock().await.character.clone().unwrap();
        let header=user.lock().await.create_object_header();
        for expected in crate::class_passives::synchronize(header,&c,Some(old_main as u8)).unwrap() {
            assert_eq!(peer.read_packet_async().await.unwrap(),expected);
        }
        assert!(matches!(tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap(),Packet::Unk042C(_)));
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
    let saved=saved_character(&sql,1,1).await;
    let mut expected=original;expected.main_class=Class::Luster;expected.sub_class=Class::Unknown;
    assert_eq!(saved.character.classes,expected);
}
