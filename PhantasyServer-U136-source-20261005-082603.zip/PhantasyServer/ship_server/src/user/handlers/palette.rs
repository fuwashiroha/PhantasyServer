use super::HResult;
use crate::{Action, Error, User, sql::CharData, battle_stats::PlayerStats, mutex::MutexGuard};
use pso2packetlib::protocol::palette::{
    SetDefaultPAsPacket, SetPalettePacket, SetSubPalettePacket, UpdatePalettePacket,
    UpdateSubPalettePacket,
};

pub async fn send_full_palette(user: &mut User) -> HResult {
    let character = user.character.as_mut().unwrap();
    let packet = character.palette.send_full_palette();
    user.send_packet(&packet).await?;
    Ok(Action::Nothing)
}
pub async fn set_palette(mut user: MutexGuard<'_, User>, packet: SetPalettePacket) -> HResult {
    let mut character = user.character.as_ref().ok_or(Error::InvalidInput("palette_character"))?.clone();
    character.palette.set_palette(packet)?;
    // Classic 6.1253.3 consumes the active index at packet +8 in 21/01
    // (client RVA 2ace9cc -> 4e35b0). 0F/BC updates WeaponPosition;
    // it does not acknowledge a manual palette selection.
    let reply = character.palette.send_palette();
    commit_palette_candidate(&mut user, character, vec![reply])?;
    Ok(Action::Nothing)
}

pub async fn update_palette(
    mut user: MutexGuard<'_, User>,
    packet: UpdatePalettePacket,
) -> HResult {
    {
        let user: &mut User = &mut user;
        let mut character = user.character.as_ref().ok_or(Error::InvalidInput("palette_character"))?.clone();
        let out_packet = character
            .palette
            .update_palette(&mut character.inventory, packet)?;
        commit_palette_candidate(user, character, vec![out_packet])?;
    }
    Ok(Action::Nothing)
}

pub async fn update_subpalette(user: &mut User, packet: UpdateSubPalettePacket) -> HResult {
    let mut character = user.character.as_ref().ok_or(Error::InvalidInput("palette_character"))?.clone();
    let out_packet = character.palette.update_subpalette(packet)?;
    user.queue_equipment_change(character, None, vec![out_packet], vec![])?;
    Ok(Action::Nothing)
}

pub fn set_subpalette(user: &mut User, packet: SetSubPalettePacket) -> HResult {
    let mut character = user.character.as_ref().ok_or(Error::InvalidInput("palette_character"))?.clone();
    character.palette.set_subpalette(packet)?;
    user.queue_equipment_change(character, None, vec![], vec![])?;
    Ok(Action::Nothing)
}

pub async fn set_default_pa(user: &mut User, packet: SetDefaultPAsPacket) -> HResult {
    let mut character = user.character.as_ref().ok_or(Error::InvalidInput("palette_character"))?.clone();
    let packet = character.palette.set_default_pas(packet);
    user.queue_equipment_change(character, None, vec![packet], vec![])?;
    Ok(Action::Nothing)
}

fn commit_palette_candidate(user: &mut User, mut character: CharData, replies: Vec<pso2packetlib::protocol::Packet>) -> Result<(), Error> {
    // Keep palette selection, equipped instance and battle stats consistent.
    match character.palette.get_current_item(&character.inventory)? {
        Some(item) => character.inventory.equip_item(item.uuid, 9)?,
        None => character.inventory.clear_weapon_slot(),
    }
    let stats = PlayerStats::prepare_equipment_update(user, &character)?;
    let id = user.get_user_id();
    let broadcast = vec![character.palette.send_change_palette(id),
        character.palette.send_cur_weapon(id, &character.inventory)];
    user.queue_equipment_change(character, Some(stats), replies, broadcast)
}

#[cfg(test)]
mod local_palette_tests;
