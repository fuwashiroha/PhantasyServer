//! Real request dispatch and character state; not a PSO2 client test.
use super::*;
use crate::{Mutex, ServerData, user::{UserState, packet_handler}};
use pso2packetlib::protocol::{items::{Item, ItemId, ClothingItem},
    models::{character::HSVColor, item_attrs::HumanCostume}};
use std::sync::Arc;

async fn fixture() -> (Mutex<User>, tokio::net::TcpStream) {
    let (sql, requests, session, original, owner) = crate::sql::local_checkpoint_tests::fixture().await;
    let sql = Arc::new(sql);
    let (mut user, peer) = crate::sql::local_lifecycle_tests::connected_user(sql).await;
    user.account_session=Some(session);user.user_data=owner;
    crate::user::local_equipment_save_tests::auto_master(requests);
    let mut data = ServerData::default();
    // Deliberately synthetic isolated attributes, not original game parameters.
    data.item_params.attrs.human_costumes.push(HumanCostume {
        id: 10, subid: 20, model: 789, ..Default::default()});
    Arc::get_mut(&mut user.blockdata).unwrap().server_data = Arc::new(data);
    let mut character = original;
    character.character.look.costume_id = 99;
    character.character.look.costume_color = HSVColor {hue: 1, saturation: 2, value: 3};
    for uuid in [10, 30] {character.inventory.add_item(Item {uuid, ..Default::default()});}
    character.inventory.equip_item(10, 3).unwrap();
    character.inventory.equip_item(30, 0).unwrap();
    user.character = Some(character); user.state = UserState::InGame;
    (Mutex::new(user), peer)
}
fn clothing(uuid: u64, id: u16, subid: u16) -> Item {
    Item {uuid, id: ItemId {item_type: 2, id, subid, ..Default::default()},
        data: ItemType::Clothing(ClothingItem {color: HSVColor {hue: 100, saturation: 200, value: 300},
            ..Default::default()}), ..Default::default()}
}
async fn state(user: &Mutex<User>) -> Vec<u8> {
    rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap()
}
fn equip(uuid: u64) -> Packet {
    Packet::EquipItemRequest(EquipItemRequestPacket {uuid, equipment_pos: 3, ..Default::default()})
}
fn unequip(uuid: u64) -> Packet {
    Packet::UnequipItemRequest(UnequipItemRequestPacket {uuid, equipment_pos: 3, ..Default::default()})
}

#[tokio::test]
async fn local_equip_handler_missing_uuid_preserves_full_character() {
    let (user, _peer) = fixture().await;
    let before = state(&user).await;
    assert!(packet_handler(user.lock().await, equip(999)).await.is_err());
    assert_eq!(state(&user).await, before);
    assert!(user.lock().await.pending_asset.is_none());
    user.lock().await.character = None;
}

#[tokio::test]
async fn local_equip_handler_missing_exact_costume_attributes_preserves_full_character() {
    let (user, _peer) = fixture().await;
    for (id, subid) in [(10, 21), (11, 20), (11, 21)] {
        user.lock().await.character.as_mut().unwrap().inventory.add_item(clothing(20, id, subid));
        let before = state(&user).await;
        assert!(matches!(packet_handler(user.lock().await, equip(20)).await,
            Err(Error::NoItemInAttrs(..))));
        assert_eq!(state(&user).await, before);
        // Remove the fixture instance between cases without changing equipment.
        let mut guard = user.lock().await;
        let mut value = serde_json::to_value(&guard.character.as_ref().unwrap().inventory).unwrap();
        value["inventory"]["items"].as_array_mut().unwrap().retain(|i| i["uuid"] != 20);
        guard.character.as_mut().unwrap().inventory = serde_json::from_value(value).unwrap();
    }
    user.lock().await.character = None;
}

#[tokio::test]
async fn local_equip_handler_dangling_unequip_preserves_full_character() {
    let (user, _peer) = fixture().await;
    {
        let mut guard = user.lock().await;
        let mut value = serde_json::to_value(&guard.character.as_ref().unwrap().inventory).unwrap();
        value["inventory"]["equiped"] = serde_json::json!([[3,999],[0,30]]);
        guard.character.as_mut().unwrap().inventory = serde_json::from_value(value).unwrap();
    }
    let before = state(&user).await;
    assert!(packet_handler(user.lock().await, unequip(999)).await.is_err());
    assert_eq!(state(&user).await, before);
    user.lock().await.character = None;
}

#[tokio::test]
async fn local_equip_handler_valid_costume_repeat_and_unequip_keep_existing_behavior() {
    let (user, _peer) = fixture().await;
    user.lock().await.character.as_mut().unwrap().inventory.add_item(clothing(20, 10, 20));
    assert!(matches!(packet_handler(user.lock().await, equip(20)).await.unwrap(), Action::Nothing));
    crate::user::local_equipment_save_tests::finish(&user).await;
    {
        let guard = user.lock().await;
        let c = guard.character.as_ref().unwrap();
        assert_eq!(c.character.look.costume_id, 789);
        assert_eq!(c.character.look.costume_color, HSVColor {hue: 100, saturation: 200, value: 300});
        let Packet::LoadEquiped(p) = c.inventory.send_equiped(1) else {panic!()};
        assert_eq!(p.items.iter().map(|e| (e.unk, e.item.uuid)).collect::<Vec<_>>(), vec![(0,30),(3,20)]);
    }
    let before = state(&user).await;
    packet_handler(user.lock().await, equip(20)).await.unwrap();
    crate::user::local_equipment_save_tests::finish(&user).await;
    assert_eq!(state(&user).await, before);
    packet_handler(user.lock().await, unequip(20)).await.unwrap();
    crate::user::local_equipment_save_tests::finish(&user).await;
    {
        let mut guard = user.lock().await;
        let c = guard.character.as_ref().unwrap();
        let Packet::LoadEquiped(p) = c.inventory.send_equiped(1) else {panic!()};
        assert_eq!(p.items.iter().map(|e| e.item.uuid).collect::<Vec<_>>(), vec![30]);
        assert_eq!(c.inventory.get_inv_item(20).unwrap(), clothing(20,10,20));
        guard.character = None;
    }
}
