use super::HResult;
use crate::{Action, Error, User, mutex::MutexGuard};
use pso2packetlib::protocol::{Packet, models::character::Class, objects};

pub async fn movement(mut user: MutexGuard<'_, User>, packet: objects::MovementPacket) -> HResult {
    if let Some(n) = packet.rot_x {
        user.position.rot_x = n;
    }
    if let Some(n) = packet.rot_y {
        user.position.rot_y = n;
    }
    if let Some(n) = packet.rot_z {
        user.position.rot_z = n;
    }
    if let Some(n) = packet.rot_w {
        user.position.rot_w = n;
    }
    if let Some(n) = packet.cur_x {
        user.position.pos_x = n;
    }
    if let Some(n) = packet.cur_y {
        user.position.pos_y = n;
    }
    if let Some(n) = packet.cur_z {
        user.position.pos_z = n;
    }
    User::send_position(user, Packet::Movement(packet)).await
}

pub async fn action(user: MutexGuard<'_, User>, packet: objects::InteractPacket) -> HResult {
    let id = user.get_user_id();
    let map = user.get_current_map();
    let zone = user.zone_pos;
    drop(user);
    if let Some(map) = map {
        map.lock().await.interaction(zone, packet, id).await?;
    }
    Ok(Action::Nothing)
}

pub async fn change_class(
    mut user: MutexGuard<'_, User>,
    packet: objects::ChangeClassRequestPacket,
) -> HResult {
    // Classic successor mains have no subclass; Hero cannot be a subclass.
    // https://pso2.jp/players/manual/pso2/preparations/class/highclass/
    // Unknown is the no-subclass sentinel, never a valid main class.
    if packet.main_class == Class::Unknown
        || packet.sub_class == Class::Hero
        || (matches!(
            packet.main_class,
            Class::Hero | Class::Phantom | Class::Etole | Class::Luster
        ) && packet.sub_class != Class::Unknown)
    {
        return Err(Error::InvalidInput("class_change_selection"));
    }
    let mut character = user
        .character
        .clone()
        .ok_or(Error::InvalidInput("class_change_character"))?;
    character.character.classes.main_class = packet.main_class;
    character.character.classes.sub_class = packet.sub_class;

    let change = Packet::ChangeClass(objects::ChangeClassPacket {
        new_info: character.character.classes.clone(),
        receiver: user.create_object_header(),
        player: user.create_object_header(),
        unk3: Default::default(),
    });
    let follow_up = Packet::Unk042C(objects::Unk042CPacket {
        unk1: user.create_object_header(),
        unk2: user.create_object_header(),
        unk3: 0x20,
        unk4: 0x1,
        ..Default::default()
    });
    // Remove test Hero bonuses on class exit and restore them on entry. Keep
    // legacy class transitions unchanged when no Hero test ranks exist.
    let old=user.character.as_ref().unwrap();
    let stats=if (!character.hero_test_skills.is_empty() || character.native_hero_tree.is_some())
        && (old.character.classes.main_class==Class::Hero || packet.main_class==Class::Hero) {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(&user,&character)?)
    } else if old.character.classes.main_class==Class::Phantom || packet.main_class==Class::Phantom {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(&user,&character)?)
    } else if [old.character.classes.main_class,old.character.classes.sub_class,
        packet.main_class,packet.sub_class].contains(&Class::Etole)
        || [old.character.classes.main_class,old.character.classes.sub_class,
            packet.main_class,packet.sub_class].contains(&Class::Luster)
        || (character.native_class_trees.contains_key(&0)
            && [old.character.classes.main_class,old.character.classes.sub_class,
                packet.main_class,packet.sub_class].contains(&Class::Hunter))
        || (character.native_class_trees.contains_key(&1)
            && [old.character.classes.main_class,old.character.classes.sub_class,
                packet.main_class,packet.sub_class].contains(&Class::Ranger))
        || [old.character.classes.main_class,old.character.classes.sub_class,
                packet.main_class,packet.sub_class].contains(&Class::Force)
        || [old.character.classes.main_class,old.character.classes.sub_class,
                packet.main_class,packet.sub_class].contains(&Class::Techer)
        || [3u8,4,6,7,9].iter().any(|slot|character.native_class_trees.contains_key(slot)
            && [old.character.classes.main_class as u8,old.character.classes.sub_class as u8,
                packet.main_class as u8,packet.sub_class as u8].contains(slot))
            || !character.inventory.equipped_units()?.is_empty() {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(&user,&character)?)
    } else {None};
    let mut replies=vec![change];
    if character.native_hero_tree.is_some()
        && (old.character.classes.main_class==Class::Hero || packet.main_class==Class::Hero) {
        replies.push(super::native_hero::sheet_for_character(user.create_object_header(),&character)?);
        replies.extend(crate::hero_passives::synchronize(user.create_object_header(),&character)?);
    }
    if old.character.classes.main_class==Class::Phantom || packet.main_class==Class::Phantom {
        replies.push(super::native_hero::sheet_for_character(user.create_object_header(),&character)?);
        replies.extend(crate::phantom_passives::synchronize(user.create_object_header(),&character)?);
    }
    replies.extend(crate::class_passives::synchronize(user.create_object_header(),&character,Some(old.character.classes.main_class as u8))?);
    replies.push(follow_up);
    user.queue_equipment_change(character, stats, replies, vec![])?;

    Ok(Action::Nothing)
}

#[cfg(test)]
mod local_class_rules_tests;

#[cfg(test)]
mod local_class_save_tests;
