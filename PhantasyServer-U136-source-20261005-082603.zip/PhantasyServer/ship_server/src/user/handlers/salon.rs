//! H-SALON-ENTRY-01: opt-in experiment, not a complete salon implementation.
//! The packet shape is known. Zero unknowns/empty option lists are a hypothesis
//! to test UI entry only; they do not prove pricing, editing or salon exit rules.
use super::HResult;
use crate::{Action, Error, User};
use pso2packetlib::protocol::{Packet, login::SalonResponse};
use std::sync::{Arc, atomic::{AtomicU32,Ordering}};

static EXPERIMENT_ACCOUNT:AtomicU32=AtomicU32::new(0);

pub(crate) fn configure(account:Option<u32>)->Result<(),Error> {
    if account==Some(0) {return Err(Error::InvalidInput("salon_experiment_account"));}
    EXPERIMENT_ACCOUNT.store(account.unwrap_or(0),Ordering::Relaxed);
    if account.is_some() {log::warn!("H-SALON-ENTRY-01 enabled: entry-only hypothesis, editing/payment/exit unimplemented");}
    Ok(())
}
pub(crate) fn enabled_for(user:&User)->bool {
    let id=EXPERIMENT_ACCOUNT.load(Ordering::Relaxed);
    id!=0 && user.user_data.id==id
}
pub(crate) async fn entry(user:&mut User)->HResult {
    // Restriction of this experiment, not a claim about original access rules.
    if !enabled_for(user) || user.character.is_none()
        || !user.get_current_map().is_some_and(|map|Arc::ptr_eq(&map,&user.blockdata.lobby)) {
        return Err(Error::InvalidInput("salon_entry_experiment_scope"));
    }
    user.send_packet(&Packet::SalonEntryResponse(SalonResponse::default())).await?;
    log::info!("H-SALON-ENTRY-01 response sent; UI entry and cancel outcome unverified");
    Ok(Action::Nothing)
}

#[cfg(test)]
mod local_salon_tests;
