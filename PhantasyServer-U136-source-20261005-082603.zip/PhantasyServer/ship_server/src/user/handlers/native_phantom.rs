use crate::{Error,User,battle_stats::PlayerStats,native_phantom_tree::{PhantomTree,PHANTOM_SLOT}};
use pso2packetlib::protocol::models::character::Class;
pub(crate) fn prepare_operation(user:&mut User,body:&[u8])->Result<(),Error> {
    let request=crate::native_hero_tree::decode_request(body,user.get_user_id())?;
    let mut c=user.character.clone().ok_or(Error::InvalidInput("native_phantom_character"))?;
    if request.slot!=PHANTOM_SLOT || c.character.classes.main_class!=Class::Phantom {
        return Err(Error::InvalidInput("native_phantom_scope"));
    }
    let info=&c.character.classes.phantom_info;
    let tree=c.native_phantom_tree.clone().unwrap_or_default();
    let next=match request.operation {
        // Native confirmation sends the requested number of added ranks.
        2=>tree.learn(request.x,request.y,request.amount,info.level1,info.level2)?,
        6=>{
            if request.name.trim().is_empty() || request.name.chars().any(char::is_control)
                || request.name.encode_utf16().count()>15 {return Err(Error::InvalidInput("native_phantom_tree_name"));}
            PhantomTree{name:request.name,..tree.at_level(info.level1)}
        },
        _=>return Err(Error::InvalidInput("native_phantom_operation_not_implemented")),
    };
    next.validate(info.level1,info.level2)?;
    let header=user.create_object_header();
    c.native_phantom_tree=Some(next);
    let sheet=super::native_hero::sheet_for_character(header,&c)?;
    let stats=PlayerStats::prepare_hero_update(user,&c)?;
    let mut replies=vec![sheet];
    // Learning changes combat effects only after the same durable save boundary.
    if request.operation==2 {replies.extend(crate::phantom_passives::synchronize(header,&c)?);}
    replies.push(crate::native_hero_tree::response(header,request.operation,true));
    // Refresh list before notifying the original confirmation dialog. Neither
    // success nor new state reaches the client before durable save acknowledgement.
    user.queue_equipment_change(c,Some(stats),replies,vec![])
}
