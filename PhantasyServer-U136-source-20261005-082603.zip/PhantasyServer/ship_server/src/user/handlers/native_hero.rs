use crate::{Action,Error,User,battle_stats::PlayerStats,native_hero_tree::{self,HeroTree,HERO_SLOT}};
use pso2packetlib::protocol::{Packet,models::character::Class};

pub(crate) fn current_sheet(user:&User)->Result<Packet,Error> {
    let c=user.character.as_ref().ok_or(Error::InvalidInput("native_hero_character"))?;
    sheet_for_character(user.create_object_header(),c)
}
pub(crate) fn sheet_for_character(header:pso2packetlib::protocol::ObjectHeader,c:&crate::sql::CharData)->Result<Packet,Error> {
    let tree=c.native_hero_tree.clone().unwrap_or_default();
    tree.validate(c.character.classes.hero_info.level1,c.character.classes.hero_info.level2)?;
    let mut packet=native_hero_tree::sheet(header,&tree,c.character.classes.hero_info.level1);
    {
        let ph=c.native_phantom_tree.clone().unwrap_or_default();
        let info=&c.character.classes.phantom_info;ph.validate(info.level1,info.level2)?;
        let Packet::Unknown((_,body))=&mut packet else{unreachable!()};
        body.extend_from_slice(&ph.entry(info.level1));
        let mut count=2u32;
        // Retain Hr and Ph first so their accepted entry layouts do not move.
        for d in crate::native_class_tree::definitions().iter().filter(|d|!matches!(d.slot,11|12)) {
            let info=crate::native_class_tree::class_level(&c.character.classes,d.slot)?;
            let tree=c.native_class_trees.get(&d.slot).cloned().unwrap_or_default();
            tree.validate(d.slot,info.level1,info.level2)?;
            body.extend_from_slice(&tree.entry(d.slot,info.level1)?);count+=1;
        }
        body[28..32].copy_from_slice(&((count+0xa8)^0x49e3).to_le_bytes());
    }
    Ok(packet)
}
pub(crate) fn prepare_operation(user:&mut User,body:&[u8])->Result<(),Error> {
    let request=native_hero_tree::decode_request(body,user.get_user_id())?;
    if request.slot==crate::native_phantom_tree::PHANTOM_SLOT {return super::native_phantom::prepare_operation(user,body);}
    if request.slot!=HERO_SLOT {return super::native_class::prepare_operation(user,body);}
    let mut c=user.character.clone().ok_or(Error::InvalidInput("native_hero_character"))?;
    if request.slot!=HERO_SLOT || c.character.classes.main_class!=Class::Hero {
        return Err(Error::InvalidInput("native_hero_scope"));
    }
    let info=&c.character.classes.hero_info;
    let tree=c.native_hero_tree.clone().unwrap_or_default();
    let next=match request.operation {
        // Native confirmation sends the requested number of added ranks.
        2=>tree.learn(request.x,request.y,request.amount,info.level1,info.level2)?,
        6=>{
            if request.name.trim().is_empty() || request.name.chars().any(char::is_control)
                || request.name.encode_utf16().count()>15 {return Err(Error::InvalidInput("native_hero_tree_name"));}
            HeroTree{name:request.name,..tree.at_level(info.level1)}
        },
        _=>return Err(Error::InvalidInput("native_hero_operation_not_implemented")),
    };
    next.validate(info.level1,info.level2)?;
    let header=user.create_object_header();
    c.native_hero_tree=Some(next);
    let sheet=sheet_for_character(header,&c)?;
    let stats=PlayerStats::prepare_hero_update(user,&c)?;
    let mut replies=vec![sheet];
    // Learning changes combat effects only after the same durable save boundary.
    if request.operation==2 {replies.extend(crate::hero_passives::synchronize(header,&c)?);}
    replies.push(native_hero_tree::response(header,request.operation,true));
    // Refresh list before notifying the original confirmation dialog. Neither
    // success nor new state reaches the client before durable save acknowledgement.
    user.queue_equipment_change(c,Some(stats),replies,vec![])
}
pub(crate) async fn operation(user:&mut User,body:&[u8])->super::HResult {
    let op=body.get(24).copied().unwrap_or(0);
    if let Err(error)=prepare_operation(user,body) {
        log::warn!("native_hero_operation_rejected account={} op={} reason={error}",user.get_user_id(),op);
        user.send_packet(&native_hero_tree::response(user.create_object_header(),op,false)).await?;
    }
    Ok(Action::Nothing)
}
