use super::HResult;
use crate::{Action, Error, User, mutex::MutexGuard};
use pso2packetlib::protocol::playerstatus;

pub async fn deal_damage(
    mut user: MutexGuard<'_, User>,
    packet: playerstatus::DealDamagePacket,
) -> HResult {
    log::trace!("Got deal damage packet: {packet:?}");
    if crate::phantom_passives::is_marker_request(packet.attack_id) {
        let owner=user.create_object_header();
        let learned=user.character.as_ref().is_some_and(|c|
            c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom
            && c.native_phantom_tree.as_ref().is_some_and(|t|t.rank("VillainMarker")>0));
        if let Some(reply)=crate::phantom_passives::marker_request(owner,learned,&packet) {user.send_packet(&reply).await?;}
        return Ok(Action::Nothing);
    }
    if crate::phantom_counter::is_request(packet.attack_id) {
        let owner=user.create_object_header();
        let learned=user.character.as_ref().is_some_and(|c|
            c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom
            && c.native_phantom_tree.as_ref().is_some_and(|t|t.rank("VillainDodgeCounterShot")>0));
        if let Some(reply)=user.phantom_counter.handle(owner,learned,&packet) {user.send_packet(&reply).await?;}
        return Ok(Action::Nothing);
    }
    if crate::phantom_time::is_request(packet.attack_id) {
        let owner=user.create_object_header();
        let learned=user.character.as_ref().is_some_and(|c|
            c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom
            && c.native_phantom_tree.as_ref().is_some_and(|t|t.rank("PrimalTime")>0));
        for reply in user.phantom_time.handle(owner,learned,&packet,std::time::Instant::now()) {
            user.send_packet(&reply).await?;
        }
        return Ok(Action::Nothing);
    }
    // Self skill applications use 06/01 too. Do not pass the observed Hero
    // Time request through the map's enemy-only damage branches.
    if matches!(packet.attack_id,34111427|2535986814|1892987789) {
        let owner=pso2packetlib::protocol::ObjectHeader {id:user.get_user_id(),entity_type:pso2packetlib::protocol::ObjectType::Player,..Default::default()};
        let learned=user.character.as_ref().is_some_and(|c|
            c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Hero
            && c.native_hero_tree.as_ref().is_some_and(|t|t.rank("WpnmanTime")>0));
        if let Some(reply)=user.hero_time.handle(owner,learned,&packet,std::time::Instant::now()) {
            user.send_packet(&reply).await?;
        }
        return Ok(Action::Nothing);
    }
    let map = user.get_current_map();
    let zone = user.zone_pos;
    drop(user);
    if let Some(map) = map {
        let deadline = tokio::time::Instant::now() + std::time::Duration::from_secs(2);
        loop {
            // A busy attempt has committed nothing. Release the map before
            // retrying so an operation holding a player lock can finish.
            let result = map.lock().await.deal_damage(zone, packet.clone()).await;
            if matches!(result, Err(Error::CombatBusy)) && tokio::time::Instant::now() < deadline {
                tokio::time::sleep(std::time::Duration::from_millis(1)).await;
                continue;
            }
            result?;
            break;
        }
    }
    Ok(Action::Nothing)
}
