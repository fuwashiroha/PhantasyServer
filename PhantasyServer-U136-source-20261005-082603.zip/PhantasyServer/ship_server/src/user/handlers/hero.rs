use crate::{User,Error,battle_stats::PlayerStats};
use pso2packetlib::protocol::{Packet,models::character::Class,unk19::{SystemMessagePacket,MessageType}};

pub(crate) fn set_test_rank(user:&mut User,skill:&str,rank:u8)->Result<(),Error> {
    if !user.user_data.isgm {return Err(Error::InvalidInput("hero_test_gm_required"));}
    let mut character=user.character.clone().ok_or(Error::InvalidInput("hero_test_character"))?;
    if character.character.classes.main_class!=Class::Hero {return Err(Error::InvalidInput("hero_test_main_class"));}
    character.hero_test_skills=character.hero_test_skills.with_test_rank(skill,rank,character.character.get_level().level1)?;
    let stats=PlayerStats::prepare_hero_update(user,&character)?;
    let reply=Packet::SystemMessage(SystemMessagePacket {
        message:format!("[Hr server test] {skill}={rank} saved. Native skill tree/SP/UI unchanged; server effects only. Supported: weapon1 weapon2 normal high guard hp attack defense."),
        msg_type:MessageType::SystemMessage,..Default::default()
    });
    user.queue_equipment_change(character,Some(stats),vec![reply],vec![])
}
