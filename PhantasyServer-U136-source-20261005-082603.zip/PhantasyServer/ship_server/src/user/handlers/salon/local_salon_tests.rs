use super::*;
use crate::{mutex::Mutex,sql,user::{self,UserState}};
use pso2packetlib::{Connection,PrivateKey,PublicKey,protocol::PacketType};
use std::time::Duration;

#[test]
fn local_salon_default_configuration_is_disabled() {
    let settings:crate::settings::Settings=toml::from_str("").unwrap();
    assert_eq!(settings.salon_entry_experiment_account,None);
    assert!(!toml::to_string(&settings).unwrap().contains("salon_entry_experiment_account"));
    let explicit:crate::settings::Settings=toml::from_str("salon_entry_experiment_account = 123").unwrap();
    assert_eq!(explicit.salon_entry_experiment_account,Some(123));
}
#[test]
fn local_salon_zero_account_rejected_without_changing_config() {
    let before=EXPERIMENT_ACCOUNT.load(Ordering::Relaxed);
    assert!(matches!(configure(Some(0)),Err(Error::InvalidInput("salon_experiment_account"))));
    assert_eq!(EXPERIMENT_ACCOUNT.load(Ordering::Relaxed),before);
}

async fn receive(peer:&mut Connection<Packet>)->Packet {
    tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap()
}
async fn barrier(user:&Arc<Mutex<User>>,peer:&mut Connection<Packet>)->Vec<Packet> {
    user.lock().await.send_packet(&Packet::ServerPing).await.unwrap();
    let mut result=vec![];
    loop {let p=receive(peer).await;if p==Packet::ServerPing {break;}result.push(p);}
    result
}
#[tokio::test]
async fn local_salon_entry_dispatch_scoped_repeatable_without_asset_mutation() {
    struct Restore(u32);
    impl Drop for Restore {fn drop(&mut self){EXPERIMENT_ACCOUNT.store(self.0,Ordering::Relaxed);}}
    let _restore=Restore(EXPERIMENT_ACCOUNT.swap(0,Ordering::Relaxed));
    let db=Arc::new(sql::Sql::in_memory_for_test().await.unwrap());
    let (mut user,socket)=crate::sql::local_lifecycle_tests::connected_user(db).await;
    user.user_data.id=123;user.state=UserState::InGame;
    user.character=Some(sql::CharData::default());
    user.set_map(user.blockdata.lobby.clone());
    let original=rmp_serde::to_vec(&(user.character.as_ref().unwrap(),&user.user_data.accountflags,user.user_data.last_uuid)).unwrap();
    let user=Arc::new(Mutex::new(user));
    let mut peer=Connection::new_async(socket,PacketType::Classic,PrivateKey::None,PublicKey::None);
    let start=barrier(&user,&mut peer).await;
    assert!(start.iter().all(|p|matches!(p,Packet::ServerHello(_))));
    // Disabled and non-target users retain existing unsupported dispatch.
    user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.unwrap();
    assert!(barrier(&user,&mut peer).await.is_empty());
    configure(Some(124)).unwrap();
    user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.unwrap();
    assert!(barrier(&user,&mut peer).await.is_empty());
    configure(Some(123)).unwrap();
    user.lock().await.state=UserState::LoggingIn;
    user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.unwrap();
    assert!(barrier(&user,&mut peer).await.is_empty());
    user.lock().await.state=UserState::InGame;
    for _ in 0..2 {
        user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.unwrap();
        assert_eq!(barrier(&user,&mut peer).await,vec![Packet::SalonEntryResponse(SalonResponse::default())]);
    }
    {
        let u=user.lock().await;
        assert_eq!(rmp_serde::to_vec(&(u.character.as_ref().unwrap(),&u.user_data.accountflags,u.user_data.last_uuid)).unwrap(),original);
        assert!(u.pending_asset.is_none() && u.checkpoint_job.is_none());
        assert!(Arc::ptr_eq(&u.get_current_map().unwrap(),&u.blockdata.lobby));
        assert_eq!(u.state,UserState::InGame);
    }
    // Out-of-scope map or missing character must not receive a pretend entry.
    user.lock().await.map=None;
    assert!(user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.is_err());
    assert!(barrier(&user,&mut peer).await.is_empty());
    {let mut u=user.lock().await;u.map=Some(u.blockdata.lobby.clone());u.character=None;}
    assert!(user::packet_handler(user.lock().await,Packet::SalonEntryRequest).await.is_err());
    assert!(barrier(&user,&mut peer).await.is_empty());
}
