//! Request dispatch + encoded loopback responses. No game client or map peer.
use super::*;
use crate::{Mutex, user::{packet_handler, UserState}};
use pso2packetlib::{Connection, PrivateKey, PublicKey, protocol::{Packet, PacketType,
    items::{Item, ItemId, ItemType, WeaponItem},
    palette::WeaponPalette,
    models::{character::{Class, ClassLevel}, item_attrs::WeaponAttrs}}};
use std::{sync::Arc, time::Duration};

async fn fixture() -> (Mutex<User>, Connection<Packet>) {
    let (sql, requests, session, original, owner) = crate::sql::local_checkpoint_tests::fixture().await;
    let sql = Arc::new(sql);
    let (mut user, peer) = crate::sql::local_lifecycle_tests::connected_user(sql).await;
    user.account_session=Some(session);user.user_data=owner;
    crate::user::local_equipment_save_tests::auto_master(requests);
    let block = Arc::get_mut(&mut user.blockdata).unwrap();
    let data = Arc::make_mut(&mut block.server_data);
    // Synthetic weapon attributes isolate response/commit order from parity.
    data.item_params.attrs.weapons = vec![
        WeaponAttrs {id: 10, subid: 20, melee_dmg: 100, range_dmg: 110, ..Default::default()},
        WeaponAttrs {id: 10, subid: 30, melee_dmg: 200, range_dmg: 220, ..Default::default()},
    ].into();
    let mut c = original;
    c.character.classes.main_class = Class::Hunter;
    c.character.classes.sub_class = Class::Unknown;
    *c.character.get_level_mut() = ClassLevel {level1: 1, level2: 1, exp: 0};
    for (uuid, subid) in [(10,20),(20,30),(30,40),(40,50)] {
        c.inventory.add_item(Item {uuid, id: ItemId {item_type: 0, id: 10, subid, ..Default::default()},
            data: ItemType::Weapon(WeaponItem::default()), ..Default::default()});
    }
    c.inventory.equip_item(10,9).unwrap();c.inventory.equip_item(40,0).unwrap();
    for (slot, uuid) in [(0,10),(1,20),(2,30),(3,999)] {
        c.palette.set_palette_data(slot, WeaponPalette {uuid, ..Default::default()});
    }
    user.character=Some(c);user.state=UserState::InGame;
    user.battle_stats=PlayerStats::build(&user).unwrap();
    user.battle_stats.local_set_current_hp(7);
    tokio::time::timeout(Duration::from_secs(2),user.connection.flush_async()).await.unwrap().unwrap();
    let mut peer=Connection::new_async(peer,PacketType::Classic,PrivateKey::None,PublicKey::None);
    assert!(matches!(tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap(),Packet::ServerHello(_)));
    (Mutex::new(user),peer)
}
async fn snapshot(user:&Mutex<User>) -> (Vec<u8>,String) {
    let u=user.lock().await;
    (rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),format!("{:?}",u.get_stats()))
}
async fn quiet(peer:&mut Connection<Packet>) {
    assert!(tokio::time::timeout(Duration::from_millis(25),peer.read_packet_async()).await.is_err(),
        "palette response escaped before validation succeeded");
}
fn update(uuid:u64)->Packet {
    let mut packet=UpdatePalettePacket::default();packet.palettes[0].uuid=uuid;
    Packet::UpdatePalette(packet)
}
fn select(palette:u32)->Packet {Packet::SetPalette(SetPalettePacket {palette,..Default::default()})}

#[tokio::test]
async fn local_palette_update_uses_requested_slot_and_persists_correct_weapon() {
    let (user,mut peer)=fixture().await;
    let mut request=UpdatePalettePacket::default();
    request.cur_palette=1;
    // The old selected slot is now empty. The incoming selection is slot 1.
    request.palettes[1].uuid=20;
    packet_handler(user.lock().await,Packet::UpdatePalette(request)).await.unwrap();
    crate::user::local_equipment_save_tests::finish(&user).await;
    let Packet::LoadPalette(reply)=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap() else {panic!()};
    assert_eq!(reply.cur_palette,1);assert_eq!(reply.palettes[1].uuid,20);
    assert_eq!(equipped(&user).await,vec![(0,40),(9,20)]);
    assert_eq!(user.lock().await.get_stats().local_weapon_powers(),(200,220,0));
    let sql=user.lock().await.blockdata.sql.clone();
    let saved=crate::sql::local_checkpoint_tests::saved_character(&sql,1,1).await;
    assert_eq!(saved.palette.get_current_item(&saved.inventory).unwrap().unwrap().uuid,20);
    user.lock().await.character=None;
}

#[tokio::test]
async fn local_palette_update_rejects_missing_incoming_selection_atomically() {
    let (user,mut peer)=fixture().await;let before=snapshot(&user).await;
    let mut request=UpdatePalettePacket::default();request.cur_palette=1;
    request.palettes[0].uuid=10;request.palettes[1].uuid=999;
    assert!(packet_handler(user.lock().await,Packet::UpdatePalette(request)).await.is_err());
    assert_eq!(snapshot(&user).await,before);quiet(&mut peer).await;
    user.lock().await.character=None;
}
async fn equipped(user:&Mutex<User>)->Vec<(u32,u64)> {
    let u=user.lock().await;
    let Packet::LoadEquiped(p)=u.character.as_ref().unwrap().inventory.send_equiped(1) else {panic!()};
    p.items.iter().map(|e|(e.unk,e.item.uuid)).collect()
}

#[tokio::test]
async fn local_palette_atomic_missing_weapon_attributes_keeps_character_stats_and_socket() {
    for request in [update(30),select(2)] {
        let (user,mut peer)=fixture().await;let before=snapshot(&user).await;
        assert!(matches!(packet_handler(user.lock().await,request).await,Err(Error::NoItemInAttrs(10,40))));
        assert_eq!(snapshot(&user).await,before);quiet(&mut peer).await;
        user.lock().await.character=None;
    }
}

#[tokio::test]
async fn local_palette_atomic_invalid_level_keeps_character_stats_and_socket() {
    for request in [update(20),select(1)] {
        let (user,mut peer)=fixture().await;
        user.lock().await.character.as_mut().unwrap().character.get_level_mut().level1=0;
        let before=snapshot(&user).await;
        assert!(packet_handler(user.lock().await,request).await.is_err());
        assert_eq!(snapshot(&user).await,before);quiet(&mut peer).await;
        user.lock().await.character=None;
    }
}

#[tokio::test]
async fn local_palette_atomic_missing_instance_or_invalid_selection_has_no_reply() {
    for request in [update(999),select(3),select(6)] {
        let (user,mut peer)=fixture().await;let before=snapshot(&user).await;
        assert!(packet_handler(user.lock().await,request).await.is_err());
        assert_eq!(snapshot(&user).await,before);quiet(&mut peer).await;
        user.lock().await.character=None;
    }
}

#[tokio::test]
async fn local_palette_atomic_update_commits_before_reply_and_preserves_injured_or_zero_hp() {
    for hp in [7,0] {
        let (user,mut peer)=fixture().await;
        user.lock().await.battle_stats.local_set_current_hp(hp);
        let max_hp=user.lock().await.get_stats().get_hp().1;
        assert!(matches!(packet_handler(user.lock().await,update(20)).await.unwrap(),Action::Nothing));
        crate::user::local_equipment_save_tests::finish(&user).await;
        assert_eq!(equipped(&user).await,vec![(0,40),(9,20)]);
        {
            let u=user.lock().await;
            assert_eq!(u.get_stats().get_hp(),(hp,max_hp));
            assert_eq!(u.get_stats().local_weapon_powers(),(200,220,0));
        }
        let Packet::LoadPalette(reply)=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap() else {panic!()};
        assert_eq!(reply.palettes[0].uuid,20);quiet(&mut peer).await;
        user.lock().await.character=None;
    }
}

#[tokio::test]
async fn local_palette_atomic_selection_syncs_weapon_and_empty_slot_without_healing() {
    for hp in [7,0] {
        let (user,mut peer)=fixture().await;
        user.lock().await.battle_stats.local_set_current_hp(hp);
        packet_handler(user.lock().await,select(1)).await.unwrap();
        quiet(&mut peer).await; // No acknowledgement before durable save.
        crate::user::local_equipment_save_tests::finish(&user).await;
        assert_eq!(equipped(&user).await,vec![(0,40),(9,20)]);
        assert_eq!(user.lock().await.get_stats().local_weapon_powers(),(200,220,0));
        let before=snapshot(&user).await;
        packet_handler(user.lock().await,select(1)).await.unwrap();
        crate::user::local_equipment_save_tests::finish(&user).await;
        assert_eq!(snapshot(&user).await,before);
        packet_handler(user.lock().await,select(4)).await.unwrap();
        crate::user::local_equipment_save_tests::finish(&user).await;
        assert_eq!(equipped(&user).await,vec![(0,40)]);
        assert_eq!(user.lock().await.get_stats().local_weapon_powers(),(0,0,0));
        assert_eq!(user.lock().await.get_stats().get_hp().0,hp);
        // Every manual selection, including reselect/empty, confirms the
        // authoritative current index after its durable commit.
        for expected in [1,1,4] {
            let Packet::LoadPalette(reply)=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap() else {panic!("missing manual selection confirmation")};
            assert_eq!(reply.cur_palette,expected);
            // Independent of the Rust decoder: native client reads selection
            // at complete-packet +8, six 0x40-byte palettes begin at +0x14.
            use pso2packetlib::protocol::ProtocolRW;
            let wire=Packet::LoadPalette(reply.clone()).write(PacketType::Classic);
            assert_eq!(&wire[4..7], &[0x21,0x01,0x00]);
            assert_eq!(u32::from_le_bytes(wire[8..12].try_into().unwrap()),expected);
            assert_eq!(u64::from_le_bytes(wire[0x54..0x5c].try_into().unwrap()),20);
            assert_eq!(reply.palettes[0].uuid,10);
            assert_eq!(reply.palettes[1].uuid,20);
        }
        quiet(&mut peer).await; // Map broadcasts are out of this fixture's scope.
        user.lock().await.character=None;
    }
}

#[tokio::test]
async fn local_palette_atomic_candidate_build_never_publishes_prospective_state() {
    let (user,_peer)=fixture().await;let before=snapshot(&user).await;
    {
        let u=user.lock().await;let mut candidate=u.character.clone().unwrap();
        candidate.palette.set_palette(SetPalettePacket {palette:1,..Default::default()}).unwrap();
        let new=PlayerStats::prepare_equipment_update(&u,&candidate).unwrap();
        assert_eq!(new.local_weapon_powers(),(200,220,0));
        assert_eq!(new.get_hp().0,7);
    }
    assert_eq!(snapshot(&user).await,before);
    user.lock().await.character=None;
}
