use crate::{Error,User,native_class_tree::{self,ClassTree}};

pub(crate) fn prepare_operation(user:&mut User,body:&[u8])->Result<(),Error> {
    let request=crate::native_hero_tree::decode_request(body,user.get_user_id())?;
    native_class_tree::definition(request.slot)?;
    let mut c=user.character.clone().ok_or(Error::InvalidInput("native_class_character"))?;
    if c.character.classes.main_class as u8!=request.slot {
        return Err(Error::InvalidInput("native_class_scope"));
    }
    let info=native_class_tree::class_level(&c.character.classes,request.slot)?;
    let tree=c.native_class_trees.get(&request.slot).cloned().unwrap_or_default();
    let next=match request.operation {
        2=>tree.learn(request.slot,request.x,request.y,request.amount,info.level1,info.level2)?,
        6=>{
            if request.name.trim().is_empty() || request.name.chars().any(char::is_control)
                || request.name.encode_utf16().count()>15 {return Err(Error::InvalidInput("native_class_tree_name"));}
            ClassTree{name:request.name,..tree.at_level(request.slot,info.level1)?}
        },
        _=>return Err(Error::InvalidInput("native_class_operation_not_implemented")),
    };
    next.validate(request.slot,info.level1,info.level2)?;
    c.native_class_trees.insert(request.slot,next);
    let header=user.create_object_header();
    let sheet=super::native_hero::sheet_for_character(header,&c)?;
    let mut replies=vec![sheet];
    if request.operation==2 {replies.extend(crate::class_passives::synchronize(header,&c,None)?);}
    replies.push(crate::native_hero_tree::response(header,request.operation,true));
    let stats = if request.operation == 2 && matches!(request.slot,0|1|2|3|4|5|6|7|9|13|14) {
        Some(crate::battle_stats::PlayerStats::prepare_hero_update(user,&c)?)
    } else {None};
    user.queue_equipment_change(c,stats,replies,vec![])
}
