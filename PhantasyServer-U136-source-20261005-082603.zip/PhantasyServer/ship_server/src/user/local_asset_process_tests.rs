//! Opt-in isolated process interruption matrix. Never runs in ordinary tests.
use super::*;
use super::local_asset_save_tests::{stack, request, expected};
use crate::master_conn::MasterConnection;
use data_structs::{inventory::{AccountStorages, StorageInventory}, master_ship::{AccountCommit, AccountCommitResult, MasterShipAction, AccountState}};
use pso2packetlib::PrivateKey;
use sha2::Digest;
use std::{path::Path, io::Write, time::Duration, sync::atomic::{AtomicBool, Ordering}};

type Peer = tokio::sync::Mutex<Option<Connection<Packet>>>;
fn write_json(path: &Path, value: &impl serde::Serialize) {
    let mut file = std::fs::File::create(path).unwrap();
    file.write_all(&serde_json::to_vec_pretty(value).unwrap()).unwrap(); file.sync_all().unwrap();
}
fn commit_hash(commit: &AccountCommit) -> String {
    sha2::Sha256::digest(rmp_serde::to_vec(commit).unwrap()).iter().map(|b|format!("{b:02x}")).collect()
}
async fn quiet(peer: &Peer) {
    let mut guard = peer.lock().await;
    let peer = guard.as_mut().expect("peer initialized before asset operation");
    assert!(tokio::time::timeout(Duration::from_millis(20), peer.read_packet_async()).await.is_err(), "unexpected response before interruption");
}
fn abrupt_exit(root: &Path, point: &str, kind: usize, commit: Option<&AccountCommit>, replies: usize) -> ! {
    write_json(&root.join("crash-marker.json"), &serde_json::json!({"point":point,"kind":kind,"exit_code":77,
        "commit_id":commit.map(|c|c.commit_id),"payload_sha256":commit.map(commit_hash),"asset_replies_observed":replies}));
    println!("U027_ABRUPT_EXIT: {point} kind {kind}; helper only, without Rust cleanup");
    std::io::stdout().flush().unwrap(); std::process::exit(77)
}
// Independent arithmetic for the seeded operation. No mutator builds the oracle.
fn assert_assets(character: &CharData, owner: &sql::User, kind: usize, applied: bool) {
    let mut items = vec![stack(10, 1, if applied && [0,3].contains(&kind) {3} else {5})];
    if applied && kind == 1 {items.push(stack(101, 3, 2));}
    let mut account = AccountStorages::default(); account.storage_meseta = if applied && kind == 5 {75} else {100};
    account.default.items = vec![stack(20, 3, if applied && [1,2,4].contains(&kind) {4} else {6})];
    if applied && kind == 0 {account.default.items.push(stack(101, 1, 2));}
    let mut personal = StorageInventory::default(); personal.storage_id = 14;
    if applied && kind == 2 {personal.items.push(stack(101, 3, 2));}
    let inventory = serde_json::to_value(&character.inventory.inventory).unwrap();
    assert_eq!(inventory["items"], serde_json::to_value(items).unwrap());
    assert_eq!(inventory["meseta"], if applied && kind == 5 {25} else {0});
    assert_eq!(inventory["max_capacity"], 50); assert_eq!(inventory["equiped"], serde_json::json!([]));
    assert_eq!(serde_json::to_value(&character.inventory.storages).unwrap(), serde_json::to_value(account).unwrap());
    assert_eq!(serde_json::to_value(&character.inventory.character).unwrap(), serde_json::to_value(personal).unwrap());
    assert_eq!(owner.last_uuid, if applied && kind <= 2 {101} else {100});
}

#[tokio::test]
#[ignore = "requires marked isolated U027 runtime; prepare deliberately exits helper process77"]
async fn local_asset_process_crash_probe() {
    let root = std::path::PathBuf::from(std::env::var("PSO2_U027_PROBE_ROOT").expect("isolated root")).canonicalize().unwrap();
    let normal = root.to_string_lossy().replace("\\\\?\\", "").to_ascii_lowercase();
    assert!(normal.starts_with("f:\\pso2classic\\setup\\m0-u027-crash-drill\\"));
    assert_eq!(std::env::current_dir().unwrap().canonicalize().unwrap(), root);
    assert_eq!(std::fs::read_to_string(root.join(".isolated-u027")).unwrap(), "isolated U027 asset process recovery only\n");
    let phase = std::env::var("PSO2_U027_PROBE_PHASE").unwrap(); assert!(matches!(phase.as_str(), "prepare"|"recover"));
    let scenario: serde_json::Value = serde_json::from_slice(&std::fs::read(root.join("scenario.json")).unwrap()).unwrap();
    let point = scenario["point"].as_str().unwrap();
    assert!(matches!(point, "before_asset_stage"|"asset_staged"|"asset_master_committed"|"asset_before_reply"|"asset_after_reply"));
    let kind = scenario["kind"].as_u64().unwrap() as usize; assert!(kind < 6);
    let iteration = scenario["iteration"].as_u64().unwrap(); assert!(iteration < 10);
    let username = scenario["username"].as_str().unwrap();
    assert!(username.starts_with("u027_") && username.chars().all(|c| c.is_ascii_alphanumeric() || c=='_'));
    let address: std::net::SocketAddr = std::fs::read_to_string(root.join("probe-address.txt")).unwrap().trim().parse().unwrap();
    assert!(address.ip().is_loopback() && address.port() > 20000);
    let db = root.join("probe-ship.db"); assert_eq!(db.exists(), phase=="recover");
    let wire = MasterConnection::new(address, b"isolated-u027-probe", root.join("hostkeys.toml").to_str().unwrap()).await.unwrap();
    let (proxy, mut requests) = MasterConnection::channel_for_test();
    let url = format!("sqlite://{}", db.to_string_lossy().replace("\\\\?\\", "").replace('\\', "/"));
    let sql = Arc::new(sql::Sql::new(&url, proxy).await.unwrap());
    let peer = Peer::new(None); let armed = AtomicBool::new(false);
    let last_commit = std::sync::Mutex::new(None::<AccountCommit>);
    let (stop, mut stopped) = tokio::sync::watch::channel(false);
    let route = async {
        loop {
            let next = tokio::select! {biased; _=stopped.changed()=>return, next=requests.recv()=>next};
            let Some((action, reply)) = next else {return;};
            let asset = match &action {
                MasterShipAction::CommitAccountSnapshot {commit, ..} if armed.load(Ordering::SeqCst) => {
                    assert_eq!(commit.expected_revision, 2);
                    *last_commit.lock().unwrap() = Some(commit.clone());
                    write_json(&root.join("asset-commit.json"), commit);
                    Some(commit.clone())
                }, _ => None,
            };
            if point=="asset_staged" && asset.is_some() {
                quiet(&peer).await; abrupt_exit(&root, point, kind, asset.as_ref(), 0);
            }
            let result = wire.run_action(action).await.unwrap();
            if point=="asset_master_committed" && asset.is_some() {
                assert!(matches!(&result, MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id,revision:3,duplicate:false}) if *commit_id==asset.as_ref().unwrap().commit_id));
                quiet(&peer).await; abrupt_exit(&root, point, kind, asset.as_ref(), 0);
            }
            reply.send(result).await.unwrap();
        }
    };
    let workflow = async {
        let mut owner = sql.get_sega_user(username, "isolated_u027_password", Ipv4Addr::LOCALHOST).await.unwrap();
        if phase=="prepare" {
            let mut session = sql.open_account_session(&mut owner).await.unwrap(); assert_eq!(session.revision, 0);
            let id = sql.create_session_character(&mut session, &mut owner, CharData::default(), 100).await.unwrap();
            let mut character = sql.session_character(&session, id).await.unwrap();
            character.character.name = format!("U027 {kind} {iteration}");
            character.inventory.add_item(stack(10, 1, 5));
            character.inventory.storages.default.items = vec![stack(20, 3, 6)];
            character.inventory.storages.storage_meseta = 100; character.inventory.character.storage_id = 14;
            sql.checkpoint_session(&mut session, &character, &owner).await.unwrap(); assert_eq!(session.revision, 2);
            assert_assets(&sql.session_character(&session, id).await.unwrap(), &owner, kind, false);
            write_json(&root.join("expected.json"), &serde_json::json!({"kind":kind,"point":point,"iteration":iteration,
                "user_id":owner.id,"character_id":id,"applied":point!="before_asset_stage","revision":if point=="before_asset_stage" {2}else{3}}));
            let (mut user, raw_peer) = crate::sql::local_lifecycle_tests::connected_user(sql.clone()).await;
            user.user_data=owner; user.character=Some(character); user.account_session=Some(session);
            user.state=UserState::InGame; user.session_start=Instant::now(); user.checkpoint_due=Instant::now()+Duration::from_secs(60);
            user.connection.flush_async().await.unwrap();
            let mut connection = Connection::new_async(raw_peer, PacketType::Classic, PrivateKey::None, PublicKey::None);
            assert!(matches!(connection.read_packet_async().await.unwrap(), Packet::ServerHello(_)));
            *peer.lock().await=Some(connection);
            let user=Mutex::new(user);
            armed.store(true, Ordering::SeqCst);
            assert!(matches!(packet_handler(user.lock().await, request(kind)).await.unwrap(), Action::Nothing));
            assert!(!user.lock().await.accepts_client_packets());
            if point=="before_asset_stage" {quiet(&peer).await; abrupt_exit(&root,point,kind,None,0);}
            loop {
                if point=="asset_before_reply" {
                    let replies = user.lock().await.service_checkpoints(Instant::now());
                    assert!(!user.lock().await.closing);
                    if !replies.is_empty() {
                        assert_eq!(replies, expected(kind)); quiet(&peer).await;
                        abrupt_exit(&root,point,kind,last_commit.lock().unwrap().as_ref(),0);
                    }
                } else {
                    assert!(matches!(User::tick(user.lock().await).await.unwrap(), Action::Nothing));
                    if user.lock().await.pending_asset.is_none() {
                        assert_eq!(point,"asset_after_reply");
                        let packets=expected(kind);
                        {let mut guard=peer.lock().await;
                        for packet in &packets {assert_eq!(&guard.as_mut().unwrap().read_packet_async().await.unwrap(),packet);}}
                        quiet(&peer).await;
                        abrupt_exit(&root,point,kind,last_commit.lock().unwrap().as_ref(),packets.len());
                    }
                }
                tokio::time::sleep(Duration::from_millis(1)).await;
            }
        } else {
            let exp: serde_json::Value = serde_json::from_slice(&std::fs::read(root.join("expected.json")).unwrap()).unwrap();
            let marker: serde_json::Value = serde_json::from_slice(&std::fs::read(root.join("crash-marker.json")).unwrap()).unwrap();
            assert_eq!(exp["point"],point); assert_eq!(exp["kind"],kind); assert_eq!(marker["exit_code"],77);
            assert_eq!(marker["asset_replies_observed"],if point=="asset_after_reply" {expected(kind).len()} else {0});
            assert_eq!(owner.id,exp["user_id"].as_u64().unwrap() as u32);
            let pending = sql.pending_account_save(owner.id).await.unwrap();
            let journal_expected=matches!(point,"asset_staged"|"asset_master_committed");
            assert_eq!(pending.is_some(),journal_expected);
            let commit = if point=="before_asset_stage" {None} else {
                let commit: AccountCommit=serde_json::from_slice(&std::fs::read(root.join("asset-commit.json")).unwrap()).unwrap();
                assert_eq!(marker["payload_sha256"],commit_hash(&commit));
                if let Some(pending)=&pending {assert_eq!(commit_hash(&pending.commit),commit_hash(&commit));}
                Some(commit)
            };
            let session=sql.open_account_session(&mut owner).await.unwrap();
            assert_eq!(session.revision,exp["revision"].as_u64().unwrap());
            let character=sql.session_character(&session,exp["character_id"].as_u64().unwrap() as u32).await.unwrap();
            assert_assets(&character,&owner,kind,point!="before_asset_stage");
            assert!(sql.pending_account_save(owner.id).await.unwrap().is_none());
            if let Some(commit)=commit {
                assert!(matches!(sql.run_action(MasterShipAction::CommitAccountSnapshot {id:owner.id,commit}).await.unwrap(),
                    MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision:3,duplicate:true,..})));
            }
            let MasterShipAction::AccountState(AccountState {revision,snapshot})=sql.run_action(MasterShipAction::GetAccountState(owner.id)).await.unwrap() else {panic!()};
            assert_eq!(revision,session.revision); assert_eq!(snapshot.last_uuid,owner.last_uuid);
            assert_eq!(serde_json::to_value(snapshot.storage).unwrap(),serde_json::to_value(&character.inventory.storages).unwrap());
            let check=sqlx::SqlitePool::connect(&format!("{url}?mode=ro")).await.unwrap();
            let integrity: Vec<String>=sqlx::query_scalar("PRAGMA integrity_check").fetch_all(&check).await.unwrap();assert_eq!(integrity,vec!["ok"]);
            let deferred: i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves").fetch_one(&check).await.unwrap();assert_eq!(deferred,0);check.close().await;
            write_json(&root.join("recovered.json"),&serde_json::json!({"point":point,"kind":kind,"iteration":iteration,
                "revision":revision,"last_uuid":owner.last_uuid,"inventory":character.inventory.inventory,
                "personal":character.inventory.character,"account":character.inventory.storages,"integrity":"ok","journals_empty":true,"duplicate_verified":point!="before_asset_stage"}));
            session.release();
            println!("U027_PROCESS_RECOVERY_OK: {point} kind {kind} iteration {iteration}; exact asset state verified");
            stop.send(true).unwrap();
        }
    };
    tokio::time::timeout(Duration::from_secs(20),async {tokio::join!(workflow,route)}).await.unwrap();
}
