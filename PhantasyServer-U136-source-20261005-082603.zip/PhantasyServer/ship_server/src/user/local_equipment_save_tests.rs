//! Real SQLite, controlled account acknowledgments and encoded packet sockets.
//! Synthetic items verify persistence order, never original equipment rules.
use super::*;
use crate::sql::local_checkpoint_tests::{Requests, ack, saved_character};
use data_structs::master_ship::{AccountCommitResult, MasterShipAction};
use pso2packetlib::protocol::{items::*, palette::*, models::character::{Class,ClassLevel}, models::item_attrs::WeaponAttrs};
use std::time::Duration;

pub(crate) fn auto_master(mut requests: Requests) {
    tokio::spawn(async move {
        while let Some((action,send))=requests.recv().await {
            let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
            let _=send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
                commit_id:commit.commit_id,revision:commit.expected_revision+1,duplicate:false})).await;
        }
    });
}
pub(crate) async fn finish(user:&Mutex<User>) {
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {
            assert!(matches!(User::tick(user.lock().await).await.unwrap(),Action::Nothing));
            if user.lock().await.pending_asset.is_none() {break;}
            tokio::task::yield_now().await;
        }
    }).await.unwrap();
}
pub(crate) async fn fixture()->(Arc<sql::Sql>,Requests,Mutex<User>,Connection<Packet>) {
    let (sql,requests,user,peer)=super::local_asset_save_tests::fixture().await;
    {
        let mut u=user.lock().await;
        let block=Arc::get_mut(&mut u.blockdata).unwrap();
        Arc::make_mut(&mut block.server_data).item_params.attrs.weapons=vec![
            WeaponAttrs {id:10,subid:20,melee_dmg:100,..Default::default()},
            WeaponAttrs {id:10,subid:30,melee_dmg:200,..Default::default()},
        ].into();
        let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
        *c.character.get_level_mut()=ClassLevel{level1:1,level2:1,exp:0};
        for (uuid,subid) in [(110,20),(120,30)] {
            c.inventory.add_item(Item{uuid,id:ItemId{item_type:0,id:10,subid,..Default::default()},
                data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
        }
        c.inventory.equip_item(110,9).unwrap();
        c.palette.set_palette_data(0,WeaponPalette{uuid:110,..Default::default()});
        c.palette.set_palette_data(1,WeaponPalette{uuid:120,..Default::default()});
        u.battle_stats=PlayerStats::build(&u).unwrap();
        u.battle_stats.local_set_current_hp(7);
    }
    (sql,requests,user,peer)
}
pub(crate) fn request(kind:usize)->Packet {
    match kind {
        0=>Packet::EquipItemRequest(EquipItemRequestPacket{uuid:120,equipment_pos:9,..Default::default()}),
        1=>Packet::UnequipItemRequest(UnequipItemRequestPacket{uuid:110,equipment_pos:9,..Default::default()}),
        2=>Packet::SetPalette(SetPalettePacket{palette:1,..Default::default()}),
        3=>{let mut p=UpdatePalettePacket::default();p.palettes[0].uuid=120;Packet::UpdatePalette(p)},
        4=>Packet::SetSubPalette(SetSubPalettePacket{subpalette:2,..Default::default()}),
        5=>{let mut p=UpdateSubPalettePacket::default();p.subpalettes[2].items[3]=PalettePA{id:42,category:1,level:2,unk:0};Packet::UpdateSubPalette(p)},
        6=>Packet::SetDefaultPAs(SetDefaultPAsPacket{default:default_pas().into()}),
        _=>unreachable!(),
    }
}
fn default_pas()->Vec<u32> {let mut p=vec![0;0x1A0];p[0]=100;p[1]=200;p}
async fn quiet(peer:&mut Connection<Packet>) {
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
}
async fn receive(peer:&mut Connection<Packet>)->Packet {
    tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap()
}
async fn close(sql:&sql::Sql,requests:&mut Requests,user:&Mutex<User>,revision:u64) {
    user.lock().await.queue_disconnect();
    let (r,_)=tokio::time::timeout(Duration::from_secs(2),async{tokio::join!(sql.drain_session_saves(),ack(requests,revision,false))}).await.unwrap();r.unwrap();
}
fn assert_state(c:&CharData,kind:usize) {
    let Packet::FullPaletteInfo(p)=c.palette.send_full_palette() else{panic!()};
    let Packet::LoadEquiped(e)=c.inventory.send_equiped(1) else{panic!()};
    let ids:Vec<_>=e.items.iter().map(|i|i.item.uuid).collect();
    match kind {
        0|2|3=>assert_eq!(ids,vec![120]),
        1=>assert!(ids.is_empty()),
        _=>assert_eq!(ids,vec![110]),
    }
    if kind==2 {assert_eq!(p.cur_palette,1);}
    if kind==3 {assert_eq!(p.palettes[0].uuid,120);}
    if kind==4 {assert_eq!(p.cur_subpalette,2);}
    if kind==5 {assert_eq!(p.subpalettes[2].items[3],PalettePA{id:42,category:1,level:2,unk:0});}
    if kind==6 {assert_eq!(&*p.default_pa,default_pas().as_slice());}
}

#[tokio::test]
async fn local_equipment_save_all_seven_requests_wait_for_receipt_and_read_back() {
    for kind in 0..7 {
        let (sql,mut requests,user,mut peer)=fixture().await;
        packet_handler(user.lock().await,request(kind)).await.unwrap();
        assert!(!user.lock().await.accepts_client_packets());quiet(&mut peer).await;
        User::tick(user.lock().await).await.unwrap();
        let (action,send)=requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
        assert_eq!(commit.expected_revision,0);
        let pending=sql.pending_account_save(1).await.unwrap().unwrap();
        assert_eq!(pending.commit.commit_id,commit.commit_id);
        quiet(&mut peer).await;
        assert!(user.lock().await.pending_equipment_broadcast.is_some());
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{
            commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
        finish(&user).await;
        let saved=saved_character(&sql,1,1).await;assert_state(&saved,kind);
        assert!(sql.pending_account_save(1).await.unwrap().is_none());
        assert!(user.lock().await.pending_equipment_broadcast.is_none());
        assert_eq!(user.lock().await.get_stats().get_hp().0,7);
        if matches!(kind,2|3|5) {let Packet::LoadPalette(p)=receive(&mut peer).await else{panic!()};assert_eq!(p.cur_palette,if kind==2{1}else{0});}
        if kind==6 {let Packet::NewDefaultPAs(p)=receive(&mut peer).await else{panic!()};assert_eq!(&*p.default,default_pas().as_slice());}
        quiet(&mut peer).await;
        close(&sql,&mut requests,&user,1).await;
    }
}

#[tokio::test]
async fn local_equipment_save_older_checkpoint_cannot_release_palette_reply() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    user.lock().await.checkpoint_due=Instant::now();User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    packet_handler(user.lock().await,request(3)).await.unwrap();
    quiet(&mut peer).await;
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        loop{User::tick(user.lock().await).await.unwrap();if user.lock().await.checkpoint_for_asset {break;}tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await;ack(&mut requests,1,false).await;finish(&user).await;
    assert!(matches!(receive(&mut peer).await,Packet::LoadPalette(_)));
    assert_state(&saved_character(&sql,1,1).await,3);
    close(&sql,&mut requests,&user,2).await;
}

#[tokio::test]
async fn local_equipment_save_lost_receipt_clears_broadcast_and_recovers_exact_commit() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    packet_handler(user.lock().await,request(3)).await.unwrap();User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit:original,..}=action else{panic!()};drop(send);
    tokio::time::timeout(Duration::from_secs(2),async{
        loop{let _=User::tick(user.lock().await).await.unwrap();if user.lock().await.closing {break;}tokio::task::yield_now().await;}
    }).await.unwrap();
    assert!(user.lock().await.pending_equipment_broadcast.is_none());quiet(&mut peer).await;
    let serve=async{let retry=ack(&mut requests,0,true).await;assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&original).unwrap());ack(&mut requests,1,false).await;};
    let (r,())=tokio::time::timeout(Duration::from_secs(2),async{tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();r.unwrap();
    assert_state(&saved_character(&sql,1,1).await,3);quiet(&mut peer).await;
}

#[tokio::test]
async fn local_equipment_save_missing_lease_rejects_without_character_or_stats_mutation() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    for kind in 0..7 {
        let mut u=user.lock().await;let session=u.account_session.take();
        let before=rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap();let stats=format!("{:?}",u.get_stats());
        drop(u);assert!(packet_handler(user.lock().await,request(kind)).await.is_err());
        let mut u=user.lock().await;
        assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);assert_eq!(format!("{:?}",u.get_stats()),stats);
        assert!(u.pending_asset.is_none()&&u.pending_equipment_broadcast.is_none());u.account_session=session;
    }
    quiet(&mut peer).await;close(&sql,&mut requests,&user,0).await;
}

#[tokio::test]
async fn local_equipment_save_local_sql_failure_never_releases_reply_and_final_save_recovers() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql,true).await;
    packet_handler(user.lock().await,request(6)).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2),async {
        loop{let _=User::tick(user.lock().await).await.unwrap();if user.lock().await.closing {break;}tokio::task::yield_now().await;}
    }).await.unwrap();
    assert!(user.lock().await.pending_equipment_broadcast.is_none());quiet(&mut peer).await;
    assert!(requests.try_recv().is_err());
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql,false).await;
    let serve=async{ack(&mut requests,0,false).await;ack(&mut requests,1,false).await;};
    let (r,())=tokio::time::timeout(Duration::from_secs(4),async{tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();r.unwrap();
    assert_state(&saved_character(&sql,1,1).await,6);quiet(&mut peer).await;
}

#[tokio::test]
async fn local_equipment_save_disconnect_before_worker_saves_without_success() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    packet_handler(user.lock().await,request(5)).await.unwrap();
    close(&sql,&mut requests,&user,0).await;
    assert_state(&saved_character(&sql,1,1).await,5);
    assert!(user.lock().await.pending_equipment_broadcast.is_none());quiet(&mut peer).await;
}

#[tokio::test]
async fn local_equipment_save_map_broadcast_waits_for_commit_without_player_map_deadlock() {
    for kind in 0..4 {
        let (sql,mut requests,user,mut peer)=fixture().await;
        let user=Arc::new(user);
        let captured=Arc::new(tokio::sync::Mutex::new(Vec::new()));let output=captured.clone();
        let reader=tokio::spawn(async move {
            while let Ok(p)=peer.read_packet_async().await {
                if matches!(p,Packet::EquipItem(_)|Packet::UnequipItem(_)|Packet::ChangeWeaponPalette(_)|Packet::EquipedWeapon(_)|Packet::LoadPalette(_)) {
                    output.lock().await.push(p);
                }
            }
        });
        party::Party::init_player(user.clone(),1).await.unwrap();
        let map=user.lock().await.blockdata.lobby.clone();
        user.lock().await.map=Some(map.clone());
        tokio::time::timeout(Duration::from_secs(2),map.lock().await.init_add_player(user.clone())).await.unwrap().unwrap();
        tokio::time::sleep(Duration::from_millis(20)).await;captured.lock().await.clear();
        packet_handler(user.lock().await,request(kind)).await.unwrap();
        User::tick(user.lock().await).await.unwrap();
        let (action,send)=requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
        tokio::time::sleep(Duration::from_millis(20)).await;
        assert!(captured.lock().await.is_empty(),"map observed success before durable receipt");
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
        finish(&user).await;
        let expected=if kind>=2{3}else{1};
        tokio::time::timeout(Duration::from_secs(2),async {
            loop{User::tick(user.lock().await).await.unwrap();if captured.lock().await.len()>=expected {break;}tokio::task::yield_now().await;}
        }).await.unwrap();
        let packets=captured.lock().await;assert_eq!(packets.len(),expected);
        match kind {
            0=>{let Packet::EquipItem(p)=&packets[0] else{panic!()};assert_eq!(p.equiped_item.uuid,120);},
            1=>{let Packet::UnequipItem(p)=&packets[0] else{panic!()};assert_eq!(p.unequiped_item.uuid,110);},
            _=>{
                let Packet::LoadPalette(p)=&packets[0] else{panic!("owner must receive current palette")};
                assert_eq!(p.cur_palette,if kind==2 {1}else{0});
                let offset=1;
                assert!(matches!(packets[offset],Packet::ChangeWeaponPalette(_)));
                let Packet::EquipedWeapon(p)=&packets[offset+1] else{panic!()};assert_eq!(p.item.uuid,120);
            }
        }
        drop(packets);assert_state(&saved_character(&sql,1,1).await,kind);
        close(&sql,&mut requests,&user,1).await;reader.abort();
    }
}

// Test fixture extension only; never modifies the live BlockData or user saves.
pub(crate) fn extend_fixture_weapon_attrs(user:&mut User,attrs:impl IntoIterator<Item=WeaponAttrs>) {
    let block=Arc::get_mut(&mut user.blockdata).unwrap();
    Arc::make_mut(&mut block.server_data).item_params.attrs.weapons.extend(attrs);
}
