use crate::Error;
use data_structs::ServerData;
use pso2packetlib::protocol::models::character::{Class, ClassLevel};
use pso2packetlib::protocol::playerstatus::EXPReceiver;
use crate::{battle_stats::PlayerStats, sql::CharData};

// Exclusive borrows keep the validated character and stats unchanged until
// commit. Dropping a prepared award performs no mutation. A batch can validate
// every recipient before making any infallible commits, without clone rollback.
pub(crate) struct PreparedExp<'a> {
    pub(super) character: &'a mut CharData,
    pub(super) stats: &'a mut PlayerStats,
    pub(super) main: ClassLevel,
    pub(super) sub: Option<ClassLevel>,
    pub(super) new_stats: Option<PlayerStats>,
    pub(super) packet: EXPReceiver,
}

impl PreparedExp<'_> {
    pub(crate) fn commit(self) -> EXPReceiver {
        *self.character.character.get_level_mut() = self.main;
        if let Some(sub) = self.sub {
            *self.character.character.get_sublevel_mut() = sub;
        }
        if let Some(stats) = self.new_stats { *self.stats = stats; }
        self.packet
    }
}

// Existing server ceilings, not a new claim about original subclass rules.
pub(super) const MAIN_CAP: u16 = 100;
pub(super) const SUB_EXP_CAP: u16 = 70;

// Callers must identify the source: Summoner's initial Subclass Grow Up
// applies to quest-earned EXP, not client orders or EXP tickets.
#[derive(Clone, Copy, Debug)]
pub(crate) enum ExpSource {
    EnemyDefeat { in_quest: bool },
    // These sources have no production reward handlers yet. Explicit variants
    // prevent future callers from inheriting the quest-only skill by default.
    #[allow(dead_code)]
    EmergencyTrial,
    #[allow(dead_code)]
    ClientOrder,
    #[allow(dead_code)]
    ExperienceTicket,
    #[allow(dead_code)]
    Administrative,
}

pub(super) fn subclass_gain(main: Class, sub: Class, sub_level: u16, gain: u32, source: ExpSource) -> u32 {
    if sub == Class::Unknown || sub_level >= SUB_EXP_CAP { return 0; }
    let quest_earned = matches!(source, ExpSource::EnemyDefeat { in_quest: true } | ExpSource::EmergencyTrial);
    // Exact integer ratios floor the final share, without multiplication overflow.
    // Other EXP boosts and cap-crossing clipping remain separate validation gaps.
    gain / if main == Class::Summoner && quest_earned { 2 } else { 4 }
}

pub(super) fn advance(data: &ServerData, class: Class, old: ClassLevel, gain: u32, ceiling: u16) -> Result<ClassLevel, Error> {
    if class == Class::Unknown || old.level1 == 0 || old.level1 > MAIN_CAP || ceiling == 0 || ceiling > MAIN_CAP {
        return Err(Error::InvalidInput("experience_level"));
    }
    let rows = data.player_stats.stats.get(class as usize)
        .ok_or(Error::InvalidInput("experience_class"))?;
    if rows.get(old.level1 as usize - 1).is_none() {
        return Err(Error::InvalidInput("experience_level_data"));
    }
    let mut next = old;
    next.exp = old.exp.checked_add(gain).ok_or(Error::InvalidInput("experience_overflow"))?;
    while next.level1 < ceiling {
        let index = next.level1 as usize - 1;
        let threshold = rows.get(index).ok_or(Error::InvalidInput("experience_level_data"))?.exp_to_next;
        let previous = if index == 0 { 0 } else { rows[index - 1].exp_to_next };
        if threshold <= previous {
            return Err(Error::InvalidInput("experience_curve"));
        }
        if u64::from(next.exp) < threshold { break; }
        // The destination level must exist before accepting the award.
        if rows.get(index + 1).is_none() {
            return Err(Error::InvalidInput("experience_level_data"));
        }
        next.level1 += 1;
        next.level2 = next.level1;
    }
    Ok(next)
}
