//! Durable meseta component for a server-confirmed quest completion.
//! Not a client packet handler: authoritative objective/rank validation and
//! QuestResult emission must be connected before a quest becomes playable.
use super::*;

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub(crate) struct QuestMesetaReceipt {
    pub run_id: [u8; 16],
    pub character_id: u32,
    pub quest_name_id: u32,
    pub difficulty: u16,
    pub meseta: u32,
}

#[derive(Debug, PartialEq, Eq)]
pub(crate) enum RewardQueueResult { Queued, AlreadyAwarded }

// This internal entry will be called by the server-owned objective/settlement
// path, never by trusting a client amount. Keep it disconnected until that
// producer is implemented. Zero reward is still a completed reward component.
impl User {
    #[allow(dead_code)]
    pub(crate) fn queue_quest_meseta_reward(
        &mut self, reward: QuestMesetaReceipt,
    ) -> Result<RewardQueueResult, Error> {
        self.queue_quest_reward_with_result(reward,None)
    }
    pub(crate) fn queue_quest_settlement(&mut self,reward:QuestMesetaReceipt,result:pso2packetlib::protocol::questlist::QuestResultPacket)->Result<RewardQueueResult,Error> {
        crate::quest_completion::validate_result(&result)?;
        if result.meseta_earned!=reward.meseta {return Err(Error::InvalidInput("quest_result_reward_mismatch"));}
        self.queue_quest_reward_with_result(reward,Some(result))
    }
    fn queue_quest_reward_with_result(&mut self,reward:QuestMesetaReceipt,result:Option<pso2packetlib::protocol::questlist::QuestResultPacket>)->Result<RewardQueueResult,Error> {
        if !self.accepts_client_packets() || !matches!(self.state, UserState::InGame)
            || self.account_session.is_some() == self.checkpoint_job.is_some()
            || self.account_session.as_ref().is_some_and(|s| s.id != self.user_data.id) {
            return Err(Error::InvalidInput("quest_reward_session_unavailable"));
        }
        let character = self.character.as_ref().ok_or(Error::InvalidInput("quest_reward_character_missing"))?;
        if reward.run_id == [0;16] || reward.quest_name_id == 0
            || reward.character_id != character.character.character_id {
            return Err(Error::InvalidInput("quest_reward_identity"));
        }
        if let Some(previous) = character.quest_meseta_receipts.iter().find(|r| r.run_id == reward.run_id) {
            return if previous == &reward { Ok(RewardQueueResult::AlreadyAwarded) }
                else { Err(Error::InvalidInput("quest_reward_conflict")) };
        }
        let mut next = character.clone();
        let reply = next.inventory.credit_quest_meseta(reward.meseta)?;
        next.quest_meseta_receipts.push(reward);
        // No await/fallible operation separates asset, receipt and pending ACK.
        self.character = Some(next);
        let mut replies=vec![reply];
        if let Some(result)=result {replies.push(Packet::QuestResult(result));}
        self.pending_asset = Some(replies);
        self.checkpoint_wakeup.notify_one();
        Ok(RewardQueueResult::Queued)
    }
}

#[cfg(test)]
mod local_quest_reward_tests {
    use super::*;
    use crate::sql::local_checkpoint_tests::{fixture, ack};
    use crate::sql::local_lifecycle_tests::connected_user;
    use pso2packetlib::protocol::items::InventoryMesetaPacket;

    fn receipt(character: u32, run: u8, amount: u32) -> QuestMesetaReceipt {
        QuestMesetaReceipt {run_id:[run;16],character_id:character,quest_name_id:30010,difficulty:0,meseta:amount}
    }
    fn bytes(character: &CharData) -> Vec<u8> { rmp_serde::to_vec(character).unwrap() }

    #[tokio::test]
    async fn local_quest_reward_replay_conflict_identity_and_unavailable_session() {
        let (sql,_requests,session,character,owner)=fixture().await;
        let sql=Arc::new(sql);let (mut user,_peer)=connected_user(sql.clone()).await;
        let id=character.character.character_id;
        user.character=Some(character);user.user_data=owner;user.account_session=Some(session);user.state=UserState::InGame;
        let before=bytes(user.character.as_ref().unwrap());
        for r in [receipt(id+1,1,50),receipt(id,0,50)] {
            assert!(user.queue_quest_meseta_reward(r).is_err());
            assert_eq!(bytes(user.character.as_ref().unwrap()),before);assert!(user.pending_asset.is_none());
        }
        user.state=UserState::PreInGame;
        assert!(user.queue_quest_meseta_reward(receipt(id,1,50)).is_err());
        assert_eq!(bytes(user.character.as_ref().unwrap()),before);
        user.state=UserState::InGame;
        assert_eq!(user.queue_quest_meseta_reward(receipt(id,1,50)).unwrap(),RewardQueueResult::Queued);
        assert!(user.queue_quest_meseta_reward(receipt(id,1,50)).is_err()); // pending durable barrier
        let after=bytes(user.character.as_ref().unwrap());
        assert_eq!(user.pending_asset.take().unwrap(),vec![Packet::InventoryMeseta(InventoryMesetaPacket{meseta:50})]);
        assert_eq!(user.queue_quest_meseta_reward(receipt(id,1,50)).unwrap(),RewardQueueResult::AlreadyAwarded);
        let mut difficulty_conflict=receipt(id,1,50); difficulty_conflict.difficulty=1;
        let mut quest_conflict=receipt(id,1,50); quest_conflict.quest_name_id=30020;
        for changed in [receipt(id,1,51),difficulty_conflict,quest_conflict] {
            assert!(user.queue_quest_meseta_reward(changed).is_err());
            assert_eq!(bytes(user.character.as_ref().unwrap()),after);assert!(user.pending_asset.is_none());
        }
        assert_eq!(user.queue_quest_meseta_reward(receipt(id,2,0)).unwrap(),RewardQueueResult::Queued);
        assert_eq!(user.character.as_ref().unwrap().quest_meseta_receipts.len(),2);
        user.character=None;user.account_session.take().unwrap().release();
    }

    #[tokio::test]
    async fn local_quest_reward_overflow_does_not_record_receipt_or_ack() {
        let (sql,_requests,session,mut character,owner)=fixture().await;
        let mut value=serde_json::to_value(&character.inventory).unwrap();
        value["inventory"]["meseta"]=serde_json::json!(u64::MAX);
        character.inventory=serde_json::from_value(value).unwrap();
        let id=character.character.character_id;let before=bytes(&character);
        let sql=Arc::new(sql);let (mut user,_peer)=connected_user(sql).await;
        user.character=Some(character);user.user_data=owner;user.account_session=Some(session);user.state=UserState::InGame;
        assert!(user.queue_quest_meseta_reward(receipt(id,1,1)).is_err());
        assert_eq!(bytes(user.character.as_ref().unwrap()),before);assert!(user.pending_asset.is_none());
        user.character=None;user.account_session.take().unwrap().release();
    }

    #[test]
    fn local_quest_reward_legacy_character_snapshot_loads_without_receipts() {
        // Exact prior sequence layout; do not generate a new-format snapshot
        // and merely remove an arbitrary byte to simulate old storage.
        let c=CharData::default();
        let old=rmp_serde::to_vec(&(c.character,c.inventory,c.palette,c.flags,
            c.unlocked_quests,c.unlocked_quests_notif,c.play_time)).unwrap();
        let decoded:CharData=rmp_serde::from_slice(&old).unwrap();
        assert!(decoded.quest_meseta_receipts.is_empty());
    }

    #[tokio::test]
    async fn local_quest_reward_receipt_and_balance_restore_together_after_checkpoint() {
        let (sql,mut requests,session,character,owner)=fixture().await;
        let id=character.character.character_id;let sql=Arc::new(sql);
        let (mut user,_peer)=connected_user(sql.clone()).await;
        user.character=Some(character);user.user_data=owner;user.account_session=Some(session);user.state=UserState::InGame;
        user.queue_quest_meseta_reward(receipt(id,1,50)).unwrap();
        let character=user.character.clone().unwrap();let mut session=user.account_session.take().unwrap();
        let (result,_)=tokio::join!(sql.checkpoint_session(&mut session,&character,&user.user_data),ack(&mut requests,0,false));
        result.unwrap();
        let saved=sql.session_character(&session,id).await.unwrap();
        assert_eq!(saved.quest_meseta_receipts,vec![receipt(id,1,50)]);
        let inventory=serde_json::to_value(&saved.inventory).unwrap();assert_eq!(inventory["inventory"]["meseta"],50);
        user.character=Some(saved);user.account_session=Some(session);user.pending_asset=None;
        assert_eq!(user.queue_quest_meseta_reward(receipt(id,1,50)).unwrap(),RewardQueueResult::AlreadyAwarded);
        assert!(user.pending_asset.is_none());assert!(requests.try_recv().is_err());
        user.character=None;user.account_session.take().unwrap().release();
    }
}
