use super::*;
use super::local_equipment_save_tests::{fixture,finish};
use crate::sql::local_checkpoint_tests::{saved_character,ack};
use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
use std::time::Duration;
fn request(x:u8,y:u8,amount:u8)->Vec<u8> {
    let mut b=vec![0;68];b[12..16].copy_from_slice(&1u32.to_le_bytes());
    b[24..28].copy_from_slice(&[2,11,x,y]);b[32]=amount;b[33]=1;b
}
#[tokio::test]
async fn local_native_hero_learn_waits_for_durable_ack_then_refreshes_and_reloads() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;
        let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Hero;
        c.character.classes.hero_info.level1=1;c.character.classes.hero_info.level2=5;
        u.battle_stats=PlayerStats::build(&u).unwrap();
        handlers::native_hero::prepare_operation(&mut u,&request(1,2,5)).unwrap();
    }
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    User::tick(user.lock().await).await.unwrap();
    let (a,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot{commit,..}=a else{panic!()};
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;
    let Packet::Unknown((h,b))=peer.read_packet_async().await.unwrap() else{panic!("tree refresh missing")};
    assert_eq!((h.id,h.subid),(4,0x28));assert_eq!(&b[38..40],&5u16.to_le_bytes());
    let Packet::Unk0425(p)=peer.read_packet_async().await.unwrap() else{panic!("old counter removal missing")};
    assert_eq!(p.unk3,111004);
    let Packet::Unk0424(p)=peer.read_packet_async().await.unwrap() else{panic!("learned counter effect missing")};
    assert_eq!(p.unk4,111004);assert_eq!(&p.unk6[4..8],&5u32.to_le_bytes());
    let Packet::Unk0425(p)=peer.read_packet_async().await.unwrap() else{panic!("unlearned aura removal missing")};
    assert_eq!(p.unk3,111009);
    for id in [111005,111006,111032] {
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0425(p) if p.unk3==id));
        if id==111032 {
            assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0424(p) if p.unk4==111032 && p.unk6[4..8]==1u32.to_le_bytes()));
        }
    }
    let Packet::Unk042C(p)=peer.read_packet_async().await.unwrap() else{panic!("native confirmation missing")};
    assert_eq!((p.unk3,p.unk4),(0x27,1));assert_eq!(p.unk6[0],2);
    let c=saved_character(&sql,1,1).await;
    assert_eq!(c.native_hero_tree.as_ref().unwrap().rank("WpnmanCounter"),5);
    assert_eq!(c.native_hero_tree.as_ref().unwrap().spent(),5);
    assert_eq!(c.character.classes.hero_info.level2,5); // total SP is not remaining SP
    user.lock().await.queue_disconnect();let (r,_)=tokio::join!(sql.drain_session_saves(),ack(&mut requests,1,false));r.unwrap();
}
#[tokio::test]
async fn local_native_hero_rejections_preserve_tree_inventory_and_pending_save() {
    let (sql,requests,user,_peer)=fixture().await;super::local_equipment_save_tests::auto_master(requests);
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Hero;c.character.classes.hero_info.level1=1;c.character.classes.hero_info.level2=1;
        let before=rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap();
        for b in [request(0,3,1),request(0,0,2),request(5,41,1),vec![0;3]] {
            assert!(handlers::native_hero::prepare_operation(&mut u,&b).is_err());
            assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);assert!(u.pending_asset.is_none());
        }
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
#[tokio::test]
async fn local_native_hero_class_exit_clears_effects_and_return_restores_learned_rank() {
    let (sql,requests,user,mut peer)=fixture().await;
    super::local_equipment_save_tests::auto_master(requests);
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Hero;
        c.character.classes.hero_info.level1=85;c.character.classes.hero_info.level2=85;
        c.native_hero_tree=Some(crate::native_hero_tree::HeroTree::default().learn(1,2,3,85,85).unwrap());
        u.battle_stats=PlayerStats::build(&u).unwrap();
    }
    for main in [Class::Hunter,Class::Hero] {
        handlers::object::change_class(user.lock().await,pso2packetlib::protocol::objects::ChangeClassRequestPacket{
            main_class:main,sub_class:Class::Unknown,..Default::default()
        }).await.unwrap();
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
        finish(&user).await;
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::ChangeClass(_)));
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unknown((h,_)) if (h.id,h.subid)==(4,0x28)));
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0425(p) if p.unk3==111004));
        if main==Class::Hero {
            assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0424(p) if p.unk4==111004 && p.unk6[4..8]==3u32.to_le_bytes()));
        }
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0425(p) if p.unk3==111009));
        for id in [111005,111006,111032] {
            assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0425(p) if p.unk3==id));
            if id==111032 && main==Class::Hero {
                assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0424(p) if p.unk4==111032 && p.unk6[4..8]==1u32.to_le_bytes()));
            }
        }
        if main!=Class::Hero {
            assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk0425(p) if p.unk3==111046));
        }
        let c=user.lock().await.character.clone().unwrap();
        let header=user.lock().await.create_object_header();
        let old=if main==Class::Hero {Class::Hunter} else {Class::Hero};
        for expected in crate::class_passives::synchronize(header,&c,Some(old as u8)).unwrap() {
            assert_eq!(peer.read_packet_async().await.unwrap(),expected);
        }
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk042C(_)));
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
        let c=saved_character(&sql,1,1).await;
        assert_eq!(c.character.classes.main_class,main);
        assert_eq!(c.native_hero_tree.unwrap().rank("WpnmanCounter"),3);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
#[test]
fn local_native_hero_legacy_snapshot_and_native_roundtrip_do_not_import_gm_overrides() {
    let c=crate::sql::CharData::default();
    let bytes=rmp_serde::to_vec(&(&c.character,&c.inventory,&c.palette,&c.flags,&c.unlocked_quests,
        &c.unlocked_quests_notif,&c.play_time,&c.quest_meseta_receipts,&c.hero_test_skills)).unwrap();
    let mut old:crate::sql::CharData=rmp_serde::from_slice(&bytes).unwrap();assert!(old.native_hero_tree.is_none());
    old.native_hero_tree=Some(crate::native_hero_tree::HeroTree::default().learn(0,0,5,85,85).unwrap());
    let restored:crate::sql::CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&old).unwrap()).unwrap();
    assert_eq!(old.native_hero_tree,restored.native_hero_tree);assert!(restored.hero_test_skills.is_empty());
}
