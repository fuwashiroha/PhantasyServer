use super::*;
use super::local_equipment_save_tests::{fixture,finish};
use crate::sql::local_checkpoint_tests::{saved_character,ack};
use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
use std::time::Duration;

#[tokio::test]
async fn local_hero_skill_test_override_waits_for_durable_ack_and_isolated_save() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;u.user_data.isgm=true;
        u.character.as_mut().unwrap().character.classes.main_class=Class::Hero;
        u.character.as_mut().unwrap().character.classes.hero_info.level1=1;
        u.battle_stats=PlayerStats::build(&u).unwrap();
        handlers::hero::set_test_rank(&mut u,"weapon1",3).unwrap();
    }
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    User::tick(user.lock().await).await.unwrap();
    let (a,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot{commit,..}=a else {panic!()};
    assert_eq!(commit.expected_revision,0);
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;
    let Packet::SystemMessage(reply)=peer.read_packet_async().await.unwrap() else {panic!()};assert!(reply.message.contains("weapon1=3 saved"));
    assert_eq!(saved_character(&sql,1,1).await.hero_test_skills.rank("weapon1"),3);
    user.lock().await.queue_disconnect();
    let (r,_)=tokio::join!(sql.drain_session_saves(),ack(&mut requests,1,false));r.unwrap();
}

#[tokio::test]
async fn local_hero_skill_test_override_rejects_non_gm_non_hero_and_unsupported_without_save() {
    let (sql,requests,user,_peer)=fixture().await;super::local_equipment_save_tests::auto_master(requests);
    {
        let mut u=user.lock().await;u.user_data.isgm=false;
        let before=rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap();
        assert!(handlers::hero::set_test_rank(&mut u,"weapon1",3).is_err());
        u.user_data.isgm=true;assert!(handlers::hero::set_test_rank(&mut u,"weapon1",3).is_err());
        assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);
        u.character.as_mut().unwrap().character.classes.main_class=Class::Hero;
        let before=rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap();
        assert!(handlers::hero::set_test_rank(&mut u,"hb",10).is_err());
        assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);assert!(u.pending_asset.is_none());
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
