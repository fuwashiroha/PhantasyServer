use super::*;
use data_structs::master_ship::{AccountCommit,AccountCommitResult,AccountState,MasterShipAction};
use crate::sql::local_checkpoint_tests::{Requests,ack};
use std::time::Duration;

async fn fixture() -> (Arc<sql::Sql>,Requests,User,tokio::net::TcpStream) {
    let (sql,requests,session,character,owner)=crate::sql::local_checkpoint_tests::fixture().await;
    let sql=Arc::new(sql);
    let (mut user,peer)=crate::sql::local_lifecycle_tests::connected_user(sql.clone()).await;
    user.user_data=owner;user.account_session=Some(session);user.character=Some(character);
    user.state=UserState::InGame;user.session_start=Instant::now();user.checkpoint_due=Instant::now();
    (sql,requests,user,peer)
}

async fn return_state(requests: &mut Requests,revision: u64,commit: AccountCommit) {
    let (action,send)=requests.recv().await.unwrap();assert!(matches!(action,MasterShipAction::GetAccountState(1)));
    send.send(MasterShipAction::AccountState(AccountState {revision,snapshot:commit.snapshot})).await.unwrap();
}

async fn poll_finished(user: &mut User) {
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {
            user.service_checkpoints(Instant::now());
            if user.checkpoint_job.is_none() {break;}
            tokio::task::yield_now().await;
        }
    }).await.unwrap();
}

#[tokio::test]
async fn local_online_checkpoint_tick_is_nonblocking_and_disconnect_orders_latest_snapshot() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    user.character.as_mut().unwrap().character.name="online older".into();
    let id=user.character.as_ref().unwrap().character.character_id;
    let wrapper=Mutex::new(user);
    assert!(matches!(tokio::time::timeout(Duration::from_millis(200),User::tick(wrapper.lock().await)).await.unwrap().unwrap(),Action::Nothing));
    let (action,reply)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit:older,..}=action else {panic!()};assert_eq!(older.expected_revision,0);
    for _ in 0..4 {User::tick(wrapper.lock().await).await.unwrap();}
    assert!(requests.try_recv().is_err());
    {
        let mut user=wrapper.lock().await;
        assert!(user.account_session.is_none());assert!(user.checkpoint_job.is_some());
        user.character.as_mut().unwrap().character.name="latest at disconnect".into();
        user.character.as_mut().unwrap().inventory.storages.storage_meseta=345;
        user.user_data.last_uuid=42;user.queue_disconnect();user.queue_disconnect();
    }
    let mut waiting_owner=sql::User {id:1,..Default::default()};
    assert!(tokio::time::timeout(Duration::from_millis(20),sql.open_account_session(&mut waiting_owner)).await.is_err());
    let serve=async {
        reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
            commit_id:older.commit_id,revision:1,duplicate:false})).await.unwrap();
        ack(&mut requests,1,false).await
    };
    let (drained,latest)=tokio::time::timeout(Duration::from_secs(3),async {tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();
    drained.unwrap();assert_eq!(latest.snapshot.last_uuid,42);assert_eq!(latest.snapshot.storage.storage_meseta,345);
    let mut owner=sql::User {id:1,..Default::default()};
    let (session,())=tokio::join!(sql.open_account_session(&mut owner),return_state(&mut requests,2,latest));let session=session.unwrap();
    assert_eq!(sql.session_character(&session,id).await.unwrap().character.name,"latest at disconnect");
    assert_eq!(owner.last_uuid,42);session.release();assert!(requests.try_recv().is_err());
}

#[tokio::test]
async fn local_online_checkpoint_returns_lease_and_advances_multiple_online_saves() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    for revision in 0..2 {
        user.checkpoint_due=Instant::now();user.user_data.last_uuid=20+revision;
        user.service_checkpoints(Instant::now());
        assert!(user.account_session.is_none());assert!(user.checkpoint_job.is_some());
        let commit=ack(&mut requests,revision,false).await;assert_eq!(commit.snapshot.last_uuid,20+revision);
        poll_finished(&mut user).await;
        assert_eq!(user.account_session.as_ref().unwrap().revision,revision+1);
        assert!(user.checkpoint_job.is_none());assert!(sql.pending_account_save(1).await.unwrap().is_none());
    }
    user.queue_disconnect();
    let (result,_)=tokio::join!(sql.drain_session_saves(),ack(&mut requests,2,false));result.unwrap();
    assert!(requests.try_recv().is_err());
}

#[tokio::test]
async fn local_online_checkpoint_remote_loss_persists_newest_final_and_shutdown_finishes() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    let id=user.character.as_ref().unwrap().character.character_id;
    user.service_checkpoints(Instant::now());
    let (action,reply)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit:head,..}=action else {panic!()};
    user.character.as_mut().unwrap().character.name="newer while remote unavailable".into();
    user.character.as_mut().unwrap().inventory.storages.storage_meseta=5432;user.user_data.last_uuid=90;
    user.user_data.accountflags.set(17,1);user.queue_disconnect();drop(reply);
    let lose_retry=async {let (action,reply)=requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};assert_eq!(commit.commit_id,head.commit_id);drop(reply);};
    let (result,())=tokio::time::timeout(Duration::from_secs(3),async {tokio::join!(sql.drain_session_saves(),lose_retry)}).await.unwrap();
    result.unwrap();assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,head.commit_id);
    let mut owner=sql::User {id:1,..Default::default()};
    let recover=async {
        let retry=ack(&mut requests,0,true).await;assert_eq!(retry.commit_id,head.commit_id);
        let latest=ack(&mut requests,1,false).await;return_state(&mut requests,2,latest).await;
    };
    let (session,())=tokio::join!(sql.open_account_session(&mut owner),recover);let session=session.unwrap();
    let character=sql.session_character(&session,id).await.unwrap();
    assert_eq!(character.character.name,"newer while remote unavailable");assert_eq!(character.inventory.storages.storage_meseta,5432);
    assert_eq!(owner.last_uuid,90);assert_eq!(owner.accountflags.get(17),1);session.release();
}

#[tokio::test]
async fn local_online_checkpoint_snapshots_and_logout_do_not_double_count_playtime() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    user.character.as_mut().unwrap().play_time=Duration::from_secs(40);
    let start=Instant::now();user.session_start=start;
    assert_eq!(user.persistence_character_at(start+Duration::from_secs(10)).unwrap().play_time,Duration::from_secs(50));
    assert_eq!(user.persistence_character_at(start+Duration::from_secs(20)).unwrap().play_time,Duration::from_secs(60));
    assert_eq!(user.character.as_ref().unwrap().play_time,Duration::from_secs(40));
    let id=user.character.as_ref().unwrap().character.character_id;
    let earliest=Duration::from_secs(40)+start.elapsed();user.queue_disconnect();let latest=Duration::from_secs(40)+start.elapsed();
    let (result,commit)=tokio::join!(sql.drain_session_saves(),ack(&mut requests,0,false));result.unwrap();
    let mut owner=sql::User {id:1,..Default::default()};
    let (session,())=tokio::join!(sql.open_account_session(&mut owner),return_state(&mut requests,1,commit));let session=session.unwrap();
    let saved=sql.session_character(&session,id).await.unwrap().play_time;
    assert!(saved>=earliest && saved<=latest);session.release();
}

#[tokio::test]
async fn local_online_checkpoint_characterless_and_closing_sessions_schedule_no_worker() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    user.character=None;user.state=UserState::CharacterSelect;
    user.service_checkpoints(Instant::now());assert!(user.checkpoint_job.is_none());assert!(user.account_session.is_some());
    user.queue_disconnect();let wrapper=Mutex::new(user);
    assert!(matches!(User::tick(wrapper.lock().await).await.unwrap(),Action::Disconnect));
    sql.drain_session_saves().await.unwrap();assert!(requests.try_recv().is_err());
}

#[tokio::test]
async fn local_online_checkpoint_worker_panic_fences_account_and_fails_shutdown() {
    let (sql,mut requests,mut user,_peer)=fixture().await;
    let lease=user.account_session.take().unwrap();
    let (send,receive)=tokio::sync::oneshot::channel::<saving::CheckpointReply>();user.checkpoint_job=Some(receive);
    sql.track_save(async move {let _lease=lease;let _reply=send;panic!("injected online checkpoint worker failure");});
    poll_finished(&mut user).await;assert!(user.closing);
    assert!(sql.drain_session_saves().await.is_err());
    let mut owner=sql::User {id:1,..Default::default()};
    assert!(matches!(sql.open_account_session(&mut owner).await,Err(Error::InvalidInput("account_session_fenced"))));
    assert!(requests.try_recv().is_err());
}
