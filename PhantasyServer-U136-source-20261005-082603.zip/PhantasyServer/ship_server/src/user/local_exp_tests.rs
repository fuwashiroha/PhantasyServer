use super::*;
use pso2packetlib::protocol::models::character::ClassLevel;
const QUEST_KILL: ExpSource = ExpSource::EnemyDefeat { in_quest: true };
use crate::{Quests, ServerData, SerDeFile, PrivateKey};
use std::sync::atomic::AtomicU32;
use tokio::net::{TcpListener, TcpStream};

async fn fixture(main_level: u16, sub_level: Option<u16>) -> (User, TcpStream) {
    let data=Arc::new(ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../data/com_data.mp")).unwrap());
    let ids=AtomicU32::new(1);
    let lobby=Map::new_from_data(data.maps["lobby"].clone(),&ids).unwrap();
    let block=Arc::new(BlockData {
        sql:Arc::new(sql::Sql::in_memory_for_test().await.unwrap()),block_id:1,block_name:"exp-regression".into(),
        blocks:Arc::new(RwLock::new(vec![])),lobby:Arc::new(Mutex::new(lobby)),key:PrivateKey::None,
        latest_mapid:ids,latest_partyid:AtomicU32::new(1),server_data:data.clone(),
        quests:Arc::new(Quests::load(data.quests.clone())),clients:Mutex::new(vec![]),
    });
    let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();
    let client=TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
    let (stream,_)=listener.accept().await.unwrap();
    let (mut user,_read_half)=User::new(stream,block,1).unwrap();
    user.user_data.id=1;
    user.state=UserState::InGame;
    let mut character=CharData::default();
    character.character.classes.main_class=Class::Hunter;
    character.character.classes.sub_class=if sub_level.is_some() {Class::Ranger} else {Class::Unknown};
    *character.character.get_level_mut()=ClassLevel {level1:main_level,level2:main_level,exp:0};
    if let Some(level)=sub_level {
        *character.character.get_sublevel_mut()=ClassLevel {level1:level,level2:level,exp:0};
    }
    user.character=Some(character);
    user.battle_stats=PlayerStats::build(&user).unwrap();
    (user,client)
}

#[tokio::test]
async fn local_exp_without_level_change_preserves_injured_and_zero_hp() {
    for sub in [None,Some(1)] {
        for hp in [7,0] {
            let (mut user,_peer)=fixture(1,sub).await;
            let max_hp=user.get_stats().get_hp().1;
            user.battle_stats.local_set_current_hp(hp);
            // Reproduce the previous assignment's reset using the same builder:
            // it creates full HP even when levels and equipment have not changed.
            assert_eq!(PlayerStats::build(&user).unwrap().get_hp(),(max_hp,max_hp));
            for (gain,total,sub_total) in [(0,0,0),(1,1,0),(1,2,0),(4,6,1),(5,11,2)] {
                let packet=user.add_exp(gain, QUEST_KILL).unwrap();
                assert_eq!(packet.gained,u64::from(gain));
                assert_eq!(packet.total,total);
                assert_eq!(packet.level,1);
                assert_eq!(user.get_stats().get_hp(),(hp,max_hp));
                if sub.is_some() {
                    assert_eq!(packet.gained_sub,u64::from(gain/4));
                    assert_eq!(packet.total_sub,sub_total);
                    assert_eq!(packet.level_sub,1);
                }
            }
            user.character=None;
        }
    }
}

#[tokio::test]
async fn local_exp_existing_main_and_sub_level_changes_still_rebuild_stats() {
    // This checks preservation of the prior level-change path, NOT original
    // level-up healing parity. That policy remains an explicit research gap.
    for only_subclass_levels in [false,true] {
        let (mut user,_peer)=fixture(if only_subclass_levels {10} else {1},
            if only_subclass_levels {Some(1)} else {None}).await;
        let class=if only_subclass_levels {Class::Ranger} else {Class::Hunter};
        let threshold=user.blockdata.server_data.player_stats.stats[class as usize][0].exp_to_next as u32;
        let character=&mut user.character.as_mut().unwrap().character;
        if only_subclass_levels { character.get_sublevel_mut().exp=threshold-1; }
        else { character.get_level_mut().exp=threshold-1; }
        user.battle_stats.local_set_current_hp(7);
        let old_max=user.get_stats().get_hp().1;
        let packet=user.add_exp(if only_subclass_levels {4} else {1}, QUEST_KILL).unwrap();
        let expected=PlayerStats::build(&user).unwrap().get_hp();
        assert_eq!(user.get_stats().get_hp(),expected);
        assert_ne!(expected.1,old_max);
        if only_subclass_levels {
            assert_eq!(packet.level,10); assert_eq!(packet.level_sub,2);
        } else { assert_eq!(packet.level,2); }
        user.character=None;
    }
}

#[tokio::test]
async fn local_exp_existing_level_caps_do_not_reset_hp() {
    let (mut user,_peer)=fixture(100,Some(70)).await;
    let max_hp=user.get_stats().get_hp().1;
    user.battle_stats.local_set_current_hp(0);
    let packet=user.add_exp(1, QUEST_KILL).unwrap();
    assert_eq!(packet.level,100);
    assert_eq!(packet.level_sub,70);
    assert_eq!(packet.total,1);
    assert_eq!(packet.gained_sub,0);
    assert_eq!(packet.total_sub,0);
    assert_eq!(user.get_stats().get_hp(),(0,max_hp));
    user.character=None;
}

#[test]
fn local_exp_compiled_curves_match_source_and_ordinary_wiki_fixture() {
    let root=std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data");
    let data=ServerData::load_from_mp_comp(root.join("com_data.mp")).unwrap();
    let fixture:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-exp-thresholds.json")).unwrap();
    let mut checked=0;
    let mut ordinary=0;
    for entry in std::fs::read_dir(root.join("class_stats")).unwrap() {
        let path=entry.unwrap().path();
        if path.extension().and_then(|x|x.to_str())!=Some("json") {continue;}
        let json:serde_json::Value=serde_json::from_slice(&std::fs::read(&path).unwrap()).unwrap();
        if json.get("stats").is_none() {continue;}
        let stored:data_structs::stats::ClassStatsStored=serde_json::from_value(json.clone()).unwrap();
        let compiled=&data.player_stats.stats[stored.class as usize];
        assert_eq!(compiled.len(),stored.stats.len());
        for (a,b) in compiled.iter().zip(&stored.stats) {assert_eq!(a.exp_to_next,b.exp_to_next);}
        checked+=1;
        if fixture["matched_classes"].as_array().unwrap().contains(&json["class"]) {
            for (level,expected) in fixture["cumulative_thresholds"].as_array().unwrap().iter().enumerate() {
                assert_eq!(compiled[level].exp_to_next,expected.as_u64().unwrap());
            }
            ordinary+=1;
        }
    }
    assert_eq!((checked,ordinary),(15,13));
}

#[test]
fn local_exp_all_ordinary_threshold_boundaries_and_split_awards() {
    let data=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../data/com_data.mp")).unwrap();
    let fixture:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-exp-thresholds.json")).unwrap();
    let start=ClassLevel {level1:1,level2:1,exp:0};
    for class in fixture["matched_classes"].as_array().unwrap() {
        let class:Class=serde_json::from_value(class.clone()).unwrap();
        for (index,value) in fixture["cumulative_thresholds"].as_array().unwrap().iter().enumerate() {
            let threshold=u32::try_from(value.as_u64().unwrap()).unwrap();
            for (grant,expected) in [(threshold-1,index+1),(threshold,index+2),(threshold+1,index+2)] {
                let result=experience::advance(&data,class,start,grant,100).unwrap();
                assert_eq!(result.level1 as usize,expected,"{class:?}, grant={grant}");
                assert_eq!(result.level2,result.level1);
                assert_eq!(result.exp,grant);
            }
        }
        let whole=experience::advance(&data,class,start,50_000,100).unwrap();
        let first=experience::advance(&data,class,start,20_000,100).unwrap();
        let split=experience::advance(&data,class,first,30_000,100).unwrap();
        assert_eq!(whole,split);
    }
}

#[tokio::test]
async fn local_exp_multi_level_packet_and_existing_sub_ceiling() {
    let (mut user,_peer)=fixture(1,Some(1)).await;
    let packet=user.add_exp(5_320, QUEST_KILL).unwrap();
    assert_eq!((packet.level,packet.level_sub),(7,4));
    assert_eq!((packet.total,packet.total_sub),(5_320,1_330));
    let packet=user.add_exp(400_000_000, QUEST_KILL).unwrap();
    assert_eq!(packet.level_sub,70);
    let before=user.character.as_ref().unwrap().character.get_sublevel().exp;
    let packet=user.add_exp(1, QUEST_KILL).unwrap();
    assert_eq!(packet.gained_sub,0);
    assert_eq!(packet.total_sub,u64::from(before));
    assert!(packet.level<=100);
    user.character=None;
    // A class already above the passive EXP ceiling must not be downgraded.
    let (mut user,_peer)=fixture(100,Some(95)).await;
    let packet=user.add_exp(1, QUEST_KILL).unwrap();
    assert_eq!(packet.level_sub,95);
    assert_eq!(packet.gained_sub,0);
    user.character=None;
}

#[tokio::test]
async fn local_exp_errors_leave_both_classes_and_stats_unchanged() {
    for case in ["main_zero","main_too_high","sub_zero","main_overflow","sub_overflow","unknown_main","same_class","modifier_missing"] {
        let (mut user,_peer)=fixture(1,Some(1)).await;
        user.battle_stats.local_set_current_hp(7);
        let c=&mut user.character.as_mut().unwrap().character;
        c.get_level_mut().exp=119; // Main would advance if it were committed first.
        match case {
            "main_zero"=>c.get_level_mut().level1=0,
            "main_too_high"=>c.get_level_mut().level1=u16::MAX,
            "sub_zero"=>c.get_sublevel_mut().level1=0,
            "main_overflow"=>c.get_level_mut().exp=u32::MAX,
            "sub_overflow"=>c.get_sublevel_mut().exp=u32::MAX,
            "unknown_main"=>c.classes.main_class=Class::Unknown,
            "same_class"=>c.classes.sub_class=Class::Hunter,
            "modifier_missing"=>{
                let block=Arc::get_mut(&mut user.blockdata).unwrap();
                Arc::get_mut(&mut block.server_data).unwrap().player_stats.modifiers.clear();
            },
            _=>unreachable!(),
        }
        let before=user.character.as_ref().unwrap().character.classes.clone();
        let stats_before=format!("{:?}",user.get_stats());
        assert!(user.add_exp(4, QUEST_KILL).is_err(),"{case}");
        assert_eq!(user.character.as_ref().unwrap().character.classes,before,"{case}");
        assert_eq!(format!("{:?}",user.get_stats()),stats_before,"{case}");
        user.character=None;
        assert!(user.add_exp(4, QUEST_KILL).is_err());
    }
}

#[test]
fn local_exp_rejects_missing_or_invalid_curve_without_indexing() {
    let mut data=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../data/com_data.mp")).unwrap();
    let start=ClassLevel {level1:1,level2:1,exp:0};
    let index=Class::Hunter as usize;
    let rows=data.player_stats.stats[index].clone();
    data.player_stats.stats[index].truncate(1);
    assert!(experience::advance(&data,Class::Hunter,start,120,100).is_err());
    data.player_stats.stats[index]=rows;
    data.player_stats.stats[index][1].exp_to_next=119;
    assert!(experience::advance(&data,Class::Hunter,start,480,100).is_err());
    data.player_stats.stats.clear();
    assert!(experience::advance(&data,Class::Hunter,start,0,100).is_err());
}

#[test]
fn local_exp_subclass_shares_round_down_without_overflow() {
    for main in [Class::Hunter,Class::Summoner] {
        for (source,quest_earned) in [(QUEST_KILL,true),(ExpSource::EmergencyTrial,true),
            (ExpSource::EnemyDefeat { in_quest: false },false),(ExpSource::ClientOrder,false),
            (ExpSource::ExperienceTicket,false),(ExpSource::Administrative,false)] {
            let divisor=if main==Class::Summoner && quest_earned {2} else {4};
            for gain in [0,1,2,3,4,5,7,119,120,121,u32::MAX-1,u32::MAX] {
                let result=experience::subclass_gain(main,Class::Ranger,1,gain,source);
                assert_eq!(u64::from(result),u64::from(gain)/divisor);
                for level in [70,95,100] {
                    assert_eq!(experience::subclass_gain(main,Class::Ranger,level,gain,source),0);
                }
                assert_eq!(experience::subclass_gain(main,Class::Unknown,1,gain,source),0);
            }
        }
    }
}

#[tokio::test]
async fn local_exp_summoner_source_changes_actual_subclass_state_and_response() {
    for main in [Class::Hunter,Class::Summoner] {
        for sub in [None,Some(1),Some(70)] {
            for (source,quest_earned) in [(QUEST_KILL,true),(ExpSource::EmergencyTrial,true),
                (ExpSource::EnemyDefeat { in_quest: false },false),(ExpSource::ClientOrder,false),
                (ExpSource::ExperienceTicket,false),(ExpSource::Administrative,false)] {
                let (mut user,_peer)=fixture(1,sub).await;
                let c=&mut user.character.as_mut().unwrap().character;
                c.classes.main_class=main;
                *c.get_level_mut()=ClassLevel {level1:1,level2:1,exp:0};
                user.battle_stats=PlayerStats::build(&user).unwrap();
                user.battle_stats.local_set_current_hp(0);
                let hp=user.get_stats().get_hp();
                let expected=if sub!=Some(1) {0} else if main==Class::Summoner && quest_earned {3} else {1};
                let packet=user.add_exp(7,source).unwrap();
                assert_eq!((packet.gained,packet.total),(7,7));
                assert_eq!((packet.gained_sub,packet.total_sub),(expected,expected));
                assert_eq!(packet.class,main);
                assert_eq!(user.get_stats().get_hp(),hp);
                if sub.is_some() {
                    assert_eq!(u64::from(user.character.as_ref().unwrap().character.get_sublevel().exp),expected);
                }
                user.character=None;
            }
        }
    }
}
