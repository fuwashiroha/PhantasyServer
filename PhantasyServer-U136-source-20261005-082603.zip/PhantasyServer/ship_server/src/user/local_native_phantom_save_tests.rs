use super::*;
use super::local_equipment_save_tests::{fixture,finish,auto_master};
use crate::sql::local_checkpoint_tests::saved_character;
use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
use std::time::Duration;
fn request(x:u8,y:u8,n:u8)->Vec<u8> {
    let mut b=vec![0;68];b[12..16].copy_from_slice(&1u32.to_le_bytes());
    b[24..28].copy_from_slice(&[2,12,x,y]);b[32]=n;b
}
#[tokio::test]
async fn local_native_phantom_learning_waits_for_commit_and_preserves_hero_tree() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    let hero=crate::native_hero_tree::HeroTree::default().learn(1,2,3,85,85).unwrap();
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Phantom;
        c.character.classes.phantom_info.level1=85;c.character.classes.phantom_info.level2=85;
        c.character.classes.hero_info.level1=85;c.character.classes.hero_info.level2=85;
        c.native_hero_tree=Some(hero.clone());
        c.native_phantom_tree=Some(crate::native_phantom_tree::PhantomTree::default().learn(0,0,1,85,85).unwrap());
        u.battle_stats=PlayerStats::build(&u).unwrap();
        handlers::native_hero::prepare_operation(&mut u,&request(1,3,3)).unwrap();
    }
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    User::tick(user.lock().await).await.unwrap();
    let (a,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot{commit,..}=a else{panic!()};
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;
    let Packet::Unknown((h,b))=peer.read_packet_async().await.unwrap() else{panic!("no tree list")};
    assert_eq!((h.id,h.subid),(4,0x28));assert_eq!(b.len(),32+13*204);
    assert_eq!(u32::from_le_bytes(b[28..32].try_into().unwrap())^0x49e3,0xb5);
    assert_eq!(&b[32..32+204],&hero.entry(85));assert_eq!(b[32+204],12);
    let mut counter=false;
    for _ in 0..90 {
        match tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap() {
            Packet::Unk0424(p)=>{if p.unk4==112064 {assert_eq!(p.unk6[4..8],3u32.to_le_bytes());counter=true;}},
            Packet::Unk0425(_)=>{},
            Packet::Unk042C(p)=>{assert_eq!(p.unk4,1);break;},
            _=>panic!("unexpected learning reply"),
        }
    }
    assert!(counter);
    let c=saved_character(&sql,1,1).await;
    assert_eq!(c.native_hero_tree,Some(hero));
    assert_eq!(c.native_phantom_tree.as_ref().unwrap().rank("VillainDodgeCounterShot"),3);
    assert_eq!(c.native_phantom_tree.as_ref().unwrap().spent(),4);
    assert_eq!(c.character.classes.phantom_info.level2,85);
    auto_master(requests);user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
#[tokio::test]
async fn local_native_phantom_bad_skill_or_cross_class_never_commits() {
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    let mut u=user.lock().await;
    assert!(handlers::native_hero::prepare_operation(&mut u,&request(0,0,1)).is_err());
    let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Phantom;
    c.character.classes.phantom_info.level1=85;c.character.classes.phantom_info.level2=1;
    let before=rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap();
    for b in [request(1,3,1),request(0,0,2),request(4,42,1),vec![0;3]] {
        assert!(handlers::native_hero::prepare_operation(&mut u,&b).is_err());
        assert!(u.pending_asset.is_none());
        assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);
    }
    u.queue_disconnect();drop(u);sql.drain_session_saves().await.unwrap();
}
