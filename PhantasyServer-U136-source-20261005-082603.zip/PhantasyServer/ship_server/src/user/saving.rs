//! One tracked background snapshot per live account; no player mutex spans IO.
use super::*;
use std::time::Duration;
use tokio::sync::oneshot;

// Service scheduling choices, not original game parameters.
pub(super) const CHECKPOINT_INTERVAL: Duration = Duration::from_secs(30);
const CHECKPOINT_RETRY: Duration = Duration::from_secs(2);
const CHECKPOINT_TIMEOUT: Duration = Duration::from_secs(15);
pub(super) type CheckpointReply = (sql::AccountSession, Result<(), Error>);

// Wakes even when the worker unwinds/cancels and closes its lease channel.
// Notify holds one permit if the client loop has not begun waiting yet.
struct CheckpointWake {
    notify: Arc<tokio::sync::Notify>,
    reply: Option<oneshot::Sender<CheckpointReply>>,
}

#[cfg(test)]
mod local_wake_tests {
    use super::*;

    #[tokio::test]
    async fn local_checkpoint_wake_cancel_before_poll_closes_reply_before_notification() {
        let notify=Arc::new(tokio::sync::Notify::new());
        let (send,mut receive)=oneshot::channel::<CheckpointReply>();
        let wake=CheckpointWake{notify:notify.clone(),reply:Some(send)};
        let worker=async move{let _wake=wake;std::future::pending::<()>().await;};
        drop(worker); // Captured guard must work even if the future was never polled.
        tokio::time::timeout(Duration::from_secs(2),notify.notified()).await.unwrap();
        assert!(matches!(receive.try_recv(),Err(oneshot::error::TryRecvError::Closed)));
    }

    #[tokio::test]
    async fn local_checkpoint_wake_panicking_worker_closes_reply_before_notification() {
        let notify=Arc::new(tokio::sync::Notify::new());
        let (send,mut receive)=oneshot::channel::<CheckpointReply>();
        let wake=CheckpointWake{notify:notify.clone(),reply:Some(send)};
        let worker=tokio::spawn(async move{let _wake=wake;panic!("injected checkpoint wake panic");});
        tokio::time::timeout(Duration::from_secs(2),notify.notified()).await.unwrap();
        assert!(matches!(receive.try_recv(),Err(oneshot::error::TryRecvError::Closed)));
        assert!(worker.await.unwrap_err().is_panic());
    }
}
impl Drop for CheckpointWake {
    fn drop(&mut self) {
        // A failed worker must close the reply channel before waking the reader;
        // otherwise another runtime thread could observe Empty and lose the wake.
        drop(self.reply.take());
        self.notify.notify_one();
    }
}

impl User {
    pub(crate) fn checkpoint_wakeup(&self) -> Arc<tokio::sync::Notify> {
        self.checkpoint_wakeup.clone()
    }

    pub(super) fn queue_equipment_change(
        &mut self, character: CharData, stats: Option<PlayerStats>,
        replies: Vec<Packet>, broadcast: Vec<Packet>,
    ) -> Result<(), Error> {
        if !self.accepts_client_packets() || !matches!(self.state, UserState::InGame)
            || self.pending_equipment_broadcast.is_some()
            || self.account_session.is_some() == self.checkpoint_job.is_some()
            || self.account_session.as_ref().is_some_and(|s| s.id != self.user_data.id)
            || self.character.as_ref().is_none_or(|c| c.character.character_id != character.character.character_id) {
            return Err(Error::InvalidInput("equipment_session_unavailable"));
        }
        // Prospective validation has finished. Publish the full character and
        // defer replies/broadcast until the existing durable snapshot completes.
        self.character = Some(character);
        if let Some(stats) = stats { self.battle_stats = stats; }
        self.pending_asset = Some(replies);
        self.pending_equipment_broadcast = Some(broadcast);
        self.checkpoint_wakeup.notify_one();
        Ok(())
    }

    pub(crate) fn accepts_client_packets(&self) -> bool {
        !self.closing && self.pending_asset.is_none()
    }

    pub(super) fn queue_asset_change(
        &mut self,
        operation: impl FnOnce(&mut crate::inventory::Inventory, &mut u64) -> Result<Vec<Packet>, Error>,
    ) -> Result<(), Error> {
        // The existing worker may temporarily own the lease. Exactly one owner
        // must exist before any inventory/UUID mutation is allowed.
        if !self.accepts_client_packets() || !matches!(self.state, UserState::InGame)
            || self.account_session.is_some() == self.checkpoint_job.is_some()
            || self.account_session.as_ref().is_some_and(|s| s.id != self.user_data.id) {
            return Err(Error::InvalidInput("asset_session_unavailable"));
        }
        let current = self.character.as_ref().ok_or(Error::InvalidInput("asset_character_missing"))?;
        if !current.inventory.equipped_units()?.is_empty() {
            // A transfer/discard may remove an equipped instance. Validate the
            // prospective inventory before publishing any currency/UUID change;
            // missing equipped units must never leave ghost defense/HP bonuses.
            // Automatic unequip-on-transfer is not established; explicit
            // unequip followed by transfer remains supported.
            let mut character = current.clone();
            let mut uuid = self.user_data.last_uuid;
            let replies = operation(&mut character.inventory, &mut uuid)?;
            let stats = PlayerStats::prepare_hero_update(self, &character)?;
            self.character = Some(character);
            self.user_data.last_uuid = uuid;
            self.battle_stats = stats;
            self.pending_asset = Some(replies);
            self.checkpoint_wakeup.notify_one();
            return Ok(());
        }
        let character = self.character.as_mut().ok_or(Error::InvalidInput("asset_character_missing"))?;
        let replies = operation(&mut character.inventory, &mut self.user_data.last_uuid)?;
        self.pending_asset = Some(replies);
        self.checkpoint_wakeup.notify_one();
        Ok(())
    }

    pub(super) fn persistence_character_at(&self, now: Instant) -> Option<CharData> {
        let mut character = self.character.clone()?;
        // Keep the in-memory base unchanged: every snapshot covers the same
        // session origin, rather than repeatedly adding overlapping intervals.
        character.play_time += now.duration_since(self.session_start);
        Some(character)
    }

    pub(super) fn reset_checkpoint_clock(&mut self) {
        self.checkpoint_due = self.session_start + CHECKPOINT_INTERVAL;
    }

    pub(super) fn service_checkpoints(&mut self, now: Instant) -> Vec<Packet> {
        if self.closing {return vec![];}
        let completed = self.checkpoint_job.as_mut().and_then(|receiver| {
            match receiver.try_recv() {
                Ok(value) => Some(Ok(value)),
                Err(oneshot::error::TryRecvError::Empty) => None,
                Err(oneshot::error::TryRecvError::Closed) => Some(Err(())),
            }
        });
        if let Some(completed) = completed {
            self.checkpoint_job = None;
            let for_asset = std::mem::replace(&mut self.checkpoint_for_asset, false);
            match completed {
                Ok((session, result)) => {
                    if self.account_session.is_some() || session.id != self.user_data.id {
                        self.blockdata.sql.record_session_save_failure("checkpoint lease ownership mismatch");
                        drop(session);
                        self.queue_disconnect();
                        return vec![];
                    }
                    self.account_session = Some(session);
                    if for_asset {
                        match (result, self.pending_asset.take()) {
                            (Ok(()), Some(replies)) => return replies,
                            (Err(error), _) => log::warn!("Asset save for account {} failed; closing before acknowledgment: {error}", self.user_data.id),
                            (Ok(()), None) => self.blockdata.sql.record_session_save_failure("asset checkpoint lost its pending reply"),
                        }
                        self.queue_disconnect();
                        return vec![];
                    }
                    if let Err(e) = result {
                        log::warn!("Online checkpoint for account {} retained for retry: {e}", self.user_data.id);
                        self.checkpoint_due = now + CHECKPOINT_RETRY;
                    }
                },
                Err(()) => {
                    self.blockdata.sql.record_session_save_failure("online checkpoint worker lost its account lease");
                    self.queue_disconnect();
                    return vec![];
                },
            }
        }
        if self.checkpoint_job.is_some() || (self.pending_asset.is_none() && now < self.checkpoint_due)
            || !matches!(self.state, UserState::PreInGame | UserState::InGame) {
            return vec![];
        }
        let Some(character) = self.persistence_character_at(now) else {return vec![];};
        let Some(mut session) = self.account_session.take() else {return vec![];};
        self.checkpoint_due = now + CHECKPOINT_INTERVAL;
        let data = self.user_data.clone();
        let worker = self.blockdata.sql.clone();
        let (send, receive) = oneshot::channel();
        self.checkpoint_job = Some(receive);
        self.checkpoint_for_asset = self.pending_asset.is_some();
        let wake = CheckpointWake { notify: self.checkpoint_wakeup.clone(), reply: Some(send) };
        self.blockdata.sql.track_save(async move {
            let mut wake = wake;
            let result = match tokio::time::timeout(CHECKPOINT_TIMEOUT,
                worker.checkpoint_session(&mut session, &character, &data)).await {
                Ok(result) => result,
                Err(_) => Err(Error::MSNoResponse),
            };
            if wake.reply.take().unwrap().send((session, result)).is_err() {
                // Dropping the unreturned lease deliberately leaves it fenced.
                worker.record_session_save_failure("online checkpoint receiver disappeared before lease handoff");
            }
        });
        vec![]
    }
}
