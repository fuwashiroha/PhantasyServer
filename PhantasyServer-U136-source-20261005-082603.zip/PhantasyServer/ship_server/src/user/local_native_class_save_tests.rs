use super::*;
use super::local_equipment_save_tests::{fixture,finish,auto_master};
use crate::{native_class_tree::{self,ClassTree},sql::local_checkpoint_tests::{saved_character,ack}};
use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
use std::time::Duration;

fn request(slot:u8,x:u8,y:u8,n:u8)->Vec<u8> {
    let mut b=vec![0;68];b[12..16].copy_from_slice(&1u32.to_le_bytes());
    b[24..28].copy_from_slice(&[2,slot,x,y]);b[32]=n;b
}
fn root(slot:u8)-> &'static crate::native_hero_tree::Node {
    let tree=ClassTree::default().at_level(slot,85).unwrap();
    native_class_tree::definition(slot).unwrap().nodes.iter()
        .find(|n|n.cost>0 && n.minimum_level<=85 && n.parent.as_ref().is_none_or(|p|tree.rank(p)>=n.parent_rank)).unwrap()
}
async fn quiet(peer:&mut Connection<Packet>) {
    assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
}
#[tokio::test]
async fn local_class_tree_eleven_classes_commit_then_reply_and_keep_other_trees() {
    for class in [Class::Hunter,Class::Ranger,Class::Force,Class::Fighter,Class::Gunner,Class::Techer,
        Class::Braver,Class::Bouncer,Class::Summoner,Class::Etole,Class::Luster] {
        let slot=class as u8;let node=root(slot);
        let (sql,mut requests,user,mut peer)=fixture().await;
        let hero=crate::native_hero_tree::HeroTree::default().learn(1,2,3,85,85).unwrap();
        {
            let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
            c.character.classes.main_class=class;
            c.character.get_level_mut().level1=85;c.character.get_level_mut().level2=10;
            c.character.classes.hero_info.level1=85;c.character.classes.hero_info.level2=85;
            c.native_hero_tree=Some(hero.clone());
            handlers::native_hero::prepare_operation(&mut u,&request(slot,node.x,node.y,1)).unwrap();
            assert!(!u.accepts_client_packets());
        }
        quiet(&mut peer).await;User::tick(user.lock().await).await.unwrap();
        let (action,send)=requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
        quiet(&mut peer).await;
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{
            commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
        finish(&user).await;
        let Packet::Unknown((h,b))=peer.read_packet_async().await.unwrap() else{panic!("tree list missing")};
        assert_eq!((h.id,h.subid),(4,0x28));assert_eq!(b.len(),32+13*204);
        assert_eq!(u32::from_le_bytes(b[28..32].try_into().unwrap())^0x49e3,0xb5);
        let entries:Vec<_>=b[32..].chunks_exact(204).collect();
        assert_eq!(entries.iter().map(|e|e[0]).collect::<std::collections::BTreeSet<_>>().len(),13);
        let entry=entries.iter().find(|e|e[0]==slot).unwrap();
        assert_eq!((entry[4+node.rank_byte]>>node.rank_shift)&15,1);
        let c=user.lock().await.character.clone().unwrap();
        let header=user.lock().await.create_object_header();
        let effects=crate::class_passives::synchronize(header,&c,None).unwrap();
        assert!(effects.iter().any(|p|matches!(p,Packet::Unk0424(_))),"initial class actions must be enabled");
        for expected in effects {assert_eq!(peer.read_packet_async().await.unwrap(),expected);}
        assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk042C(p) if p.unk4==1));
        quiet(&mut peer).await;
        let c=saved_character(&sql,1,1).await;
        assert_eq!(c.native_class_trees.len(),1);assert_eq!(c.native_class_trees[&slot].rank(&node.name),1);
        assert_eq!(c.native_class_trees[&slot].spent(slot).unwrap(),u16::from(node.cost));
        assert_eq!(c.native_hero_tree,Some(hero));assert_eq!(c.character.get_level().level2,10);
        auto_master(requests);user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
    }
}
#[tokio::test]
async fn local_class_tree_invalid_sp_or_class_and_rename_keep_allocations_separate() {
    let (sql,requests,user,mut peer)=fixture().await;auto_master(requests);
    let n=root(0);
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.get_level_mut().level1=85;c.character.get_level_mut().level2=0;
        let before=rmp_serde::to_vec(c).unwrap();
        for b in [request(0,n.x,n.y,1),request(1,0,0,1),request(8,0,0,1),request(0,255,255,1)] {
            assert!(handlers::native_hero::prepare_operation(&mut u,&b).is_err());
            assert!(u.pending_asset.is_none());assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);
        }
        let c=u.character.as_mut().unwrap();c.character.get_level_mut().level2=10;
        c.native_class_trees.insert(0,ClassTree::default().learn(0,n.x,n.y,1,85,10).unwrap());
        let other=root(1);c.character.classes.ranger_info.level1=85;c.character.classes.ranger_info.level2=10;
        c.native_class_trees.insert(1,ClassTree::default().learn(1,other.x,other.y,1,85,10).unwrap());
        let mut b=request(0,0,0,0);b[24]=6;
        for (i,c) in "Test Hu".encode_utf16().enumerate(){b[36+i*2..38+i*2].copy_from_slice(&c.to_le_bytes());}
        handlers::native_hero::prepare_operation(&mut u,&b).unwrap();
    }
    finish(&user).await;
    assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unknown(_)));
    assert!(matches!(peer.read_packet_async().await.unwrap(),Packet::Unk042C(p) if p.unk4==1 && p.unk6[0]==6));
    let c=saved_character(&sql,1,1).await;assert_eq!(c.native_class_trees[&0].name,"Test Hu");
    assert_eq!(c.native_class_trees[&0].rank(&n.name),1);
    assert_eq!(c.native_class_trees[&1].rank(&root(1).name),1);
    assert_eq!(c.character.classes.ranger_info.level2,10);
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
#[tokio::test]
async fn local_class_tree_lost_receipt_never_sends_success_and_recovers_same_commit() {
    let (sql,mut requests,user,mut peer)=fixture().await;let n=root(0);
    {
        let mut u=user.lock().await;u.character.as_mut().unwrap().character.get_level_mut().level1=85;
        handlers::native_hero::prepare_operation(&mut u,&request(0,n.x,n.y,1)).unwrap();
    }
    User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit:original,..}=action else{panic!()};drop(send);
    tokio::time::timeout(Duration::from_secs(2),async {
        loop {let _=User::tick(user.lock().await).await.unwrap();if user.lock().await.closing {break;}tokio::task::yield_now().await;}
    }).await.unwrap();quiet(&mut peer).await;
    let serve=async {
        let retry=ack(&mut requests,0,true).await;
        assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&original).unwrap());
        ack(&mut requests,1,false).await;
    };
    let (r,())=tokio::time::timeout(Duration::from_secs(2),async {tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();
    r.unwrap();quiet(&mut peer).await;
    assert_eq!(saved_character(&sql,1,1).await.native_class_trees[&0].rank(&n.name),1);
}
