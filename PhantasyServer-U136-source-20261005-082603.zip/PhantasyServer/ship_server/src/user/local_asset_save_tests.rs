//! Isolated real packet sockets + real SQLite, with a controlled master peer.
//! These are backend integration tests, not a PSO2 client acceptance test.
use super::*;
use crate::sql::local_checkpoint_tests::{Requests, ack, saved_character};
use data_structs::master_ship::{AccountCommit, AccountCommitResult, MasterShipAction};
use pso2packetlib::{PrivateKey, protocol::items::*};
use std::time::Duration;

pub(super) fn stack(uuid: u64, subid: u16, amount: u16) -> Item {
    Item {uuid, id: ItemId {item_type: 3, subid, ..Default::default()},
        data: ItemType::Consumable(ConsumableItem {amount, ..Default::default()}), ..Default::default()}
}
fn amount(item: &Item) -> u16 {
    let ItemType::Consumable(data) = &item.data else {panic!("expected consumable")}; data.amount
}
fn storage(uuid: u64) -> MoveStorageItemRequest {
    MoveStorageItemRequest {uuid, amount: 2, storage_id: 0, ..Default::default()}
}
fn quantity(uuid: u64) -> UUIDAmount {UUIDAmount {uuid, amount: 2, ..Default::default()}}
pub(super) fn request(kind: usize) -> Packet {
    match kind {
        0 => Packet::MoveToStorageRequest(MoveToStorageRequestPacket {uuids: vec![storage(10)]}),
        1 => Packet::MoveToInventoryRequest(MoveToInventoryRequestPacket {uuids: vec![storage(20)]}),
        2 => Packet::MoveStoragesRequest(MoveStoragesRequestPacket {old_id: 0, new_id: 14, items: vec![quantity(20)]}),
        3 => Packet::DiscardItemRequest(DiscardItemRequestPacket {items: vec![quantity(10)]}),
        4 => Packet::DiscardStorageItemRequest(DiscardStorageItemRequestPacket {items: vec![storage(20)]}),
        5 => Packet::MoveMeseta(MoveMesetaPacket {meseta: 25, direction: MesetaDirection::ToInventory}),
        _ => unreachable!(),
    }
}
// Independent expectations, not computed by calling the implementation again.
pub(super) fn expected(kind: usize) -> Vec<Packet> {
    let inv = UpdatedInventoryItem {uuid: 10, new_amount: 3, moved: 2};
    let old = UpdatedStorageItem {uuid: 20, new_amount: 4, moved: 2, storage_id: 0};
    match kind {
        0 => vec![Packet::MoveToStorage(MoveToStoragePacket {updated_inventory: vec![inv],
            new_items: vec![NewStorageItem {item: stack(101, 1, 2), storage_id: 0}], updated: vec![]})],
        1 => vec![Packet::MoveToInventory(MoveToInventoryPacket {updated: vec![old],
            new_items: vec![NewInventoryItem {item: stack(101, 3, 2), amount: 2, is_new: 1}]})],
        2 => vec![Packet::MoveStorages(MoveStoragesPacket {updated_old: vec![old], updated_new: vec![],
            new_items: vec![NewStorageItem {item: stack(101, 3, 2), storage_id: 14}]})],
        3 => vec![Packet::UpdateInventory(UpdateInventoryPacket {updated: vec![inv], unk2: 1, ..Default::default()})],
        4 => vec![Packet::UpdateStorage(UpdateStoragePacket {updated: vec![old], unk2: 1, ..Default::default()})],
        5 => vec![Packet::InventoryMeseta(InventoryMesetaPacket {meseta: 25}), Packet::StorageMeseta(StorageMesetaPacket {meseta: 75})],
        _ => unreachable!(),
    }
}
pub(super) async fn fixture() -> (Arc<sql::Sql>, Requests, Mutex<User>, Connection<Packet>) {
    fixture_with_peer_linger(false).await
}
async fn fixture_with_peer_linger(reset_on_close: bool) -> (Arc<sql::Sql>, Requests, Mutex<User>, Connection<Packet>) {
    let (sql, requests, session, mut character, mut owner) = crate::sql::local_checkpoint_tests::fixture().await;
    let sql = Arc::new(sql);
    let (mut user, peer) = crate::sql::local_lifecycle_tests::connected_user(sql.clone()).await;
    if reset_on_close {
        #[allow(deprecated)]
        peer.set_linger(Some(Duration::ZERO)).unwrap();
    }
    character.inventory.add_item(stack(10, 1, 5));
    character.inventory.storages.default.items = vec![stack(20, 3, 6)];
    character.inventory.storages.storage_meseta = 100;
    character.inventory.character.storage_id = 14;
    owner.last_uuid = 100;
    user.character = Some(character); user.user_data = owner; user.account_session = Some(session);
    user.state = UserState::InGame; user.session_start = Instant::now();
    user.checkpoint_due = Instant::now() + Duration::from_secs(60);
    tokio::time::timeout(Duration::from_secs(2), user.connection.flush_async()).await.unwrap().unwrap();
    let mut peer = Connection::new_async(peer, PacketType::Classic, PrivateKey::None, PublicKey::None);
    assert!(matches!(tokio::time::timeout(Duration::from_secs(2), peer.read_packet_async()).await.unwrap().unwrap(), Packet::ServerHello(_)));
    (sql, requests, Mutex::new(user), peer)
}
async fn quiet(peer: &mut Connection<Packet>) {
    assert!(tokio::time::timeout(Duration::from_millis(20), peer.read_packet_async()).await.is_err(), "asset response arrived before durable receipt");
}
async fn tick(user: &Mutex<User>) {
    assert!(matches!(tokio::time::timeout(Duration::from_millis(200), User::tick(user.lock().await)).await.unwrap().unwrap(), Action::Nothing));
}
async fn finish(user: &Mutex<User>) {
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {tick(user).await; if user.lock().await.pending_asset.is_none() {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
}
async fn receive(peer: &mut Connection<Packet>, kind: usize) {
    for packet in expected(kind) {
        assert_eq!(tokio::time::timeout(Duration::from_secs(2), peer.read_packet_async()).await.unwrap().unwrap(), packet);
    }
    quiet(peer).await;
}
async fn close(sql: &sql::Sql, requests: &mut Requests, user: &Mutex<User>, revision: u64) -> AccountCommit {
    user.lock().await.queue_disconnect();
    let (result, commit) = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(sql.drain_session_saves(), ack(requests, revision, false))
    }).await.unwrap(); result.unwrap(); commit
}
async fn assert_saved(sql: &sql::Sql, user: &Mutex<User>, kind: usize) {
    let guard = user.lock().await;
    let session = guard.account_session.as_ref().unwrap();
    let saved = sql.session_character(session, guard.character.as_ref().unwrap().character.character_id).await.unwrap();
    assert_eq!(session.revision, 1);
    assert_eq!(guard.user_data.last_uuid, if kind <= 2 {101} else {100});
    assert_eq!(amount(&saved.inventory.get_inv_item(10).unwrap()), if kind == 0 || kind == 3 {3} else {5});
    assert_eq!(amount(&saved.inventory.storages.default.items[0]), if [1,2,4].contains(&kind) {4} else {6});
    assert_eq!(saved.inventory.storages.storage_meseta, if kind == 5 {75} else {100});
    assert_eq!(serde_json::to_value(&saved.inventory.inventory).unwrap()["meseta"], if kind == 5 {25} else {0});
    match kind {
        0 => assert_eq!(saved.inventory.storages.default.items[1], stack(101, 1, 2)),
        1 => assert_eq!(saved.inventory.get_inv_item(101).unwrap(), stack(101, 3, 2)),
        2 => assert_eq!(saved.inventory.character.items, vec![stack(101, 3, 2)]),
        _ => {},
    }
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
}
async fn succeeds(kind: usize) {
    let (sql, mut requests, user, mut peer) = fixture().await;
    assert!(matches!(packet_handler(user.lock().await, request(kind)).await.unwrap(), Action::Nothing));
    assert!(!user.lock().await.accepts_client_packets()); quiet(&mut peer).await;
    tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit, ..} = action else {panic!()};
    assert_eq!(commit.expected_revision, 0);
    assert_eq!(commit.snapshot.last_uuid, if kind <= 2 {101} else {100});
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id, commit.commit_id);
    // Map-driven state can change while the snapshot is held; completion must
    // not replace the live character with the older snapshot.
    user.lock().await.character.as_mut().unwrap().character.name = "newer map state".into();
    for _ in 0..3 {tick(&user).await;}
    quiet(&mut peer).await;
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id: commit.commit_id, revision: 1, duplicate: false})).await.unwrap();
    finish(&user).await; receive(&mut peer, kind).await; assert_saved(&sql, &user, kind).await;
    assert!(user.lock().await.accepts_client_packets());
    assert_eq!(user.lock().await.character.as_ref().unwrap().character.name, "newer map state");
    close(&sql, &mut requests, &user, 1).await;
}
#[tokio::test] async fn local_asset_durable_to_storage_reply() {succeeds(0).await;}
#[tokio::test] async fn local_asset_durable_to_inventory_reply() {succeeds(1).await;}
#[tokio::test] async fn local_asset_durable_between_storages_reply() {succeeds(2).await;}
#[tokio::test] async fn local_asset_durable_discard_inventory_reply() {succeeds(3).await;}
#[tokio::test] async fn local_asset_durable_discard_storage_reply() {succeeds(4).await;}
#[tokio::test] async fn local_asset_durable_meseta_both_replies() {succeeds(5).await;}

#[tokio::test]
async fn local_capacity_rejection_is_silent_and_freeing_slot_allows_durable_withdrawal() {
    let (sql,mut requests,user,mut peer)=fixture().await;
    // The ordinary fixture owns one stack; fill its saved 50-slot bag.
    {
        let mut guard=user.lock().await;
        let inv=&mut guard.character.as_mut().unwrap().inventory;
        for i in 0..49 {inv.add_item(stack(1000+i,100+i as u16,1));}
    }
    let before=format!("{:?}",user.lock().await.character.as_ref().unwrap().inventory);
    let saved_before=serde_json::to_value(saved_character(&sql,1,1).await).unwrap();
    assert!(matches!(handlers::item::move_to_inventory(&mut *user.lock().await,MoveToInventoryRequestPacket {uuids:vec![storage(20)]}).await,
        Err(Error::InvalidInput("asset_destination_capacity"))));
    assert_eq!(format!("{:?}",user.lock().await.character.as_ref().unwrap().inventory),before);
    assert_eq!(serde_json::to_value(saved_character(&sql,1,1).await).unwrap(),saved_before);
    assert_eq!(user.lock().await.user_data.last_uuid,100);
    assert!(user.lock().await.pending_asset.is_none());tick(&user).await;
    assert!(sql.pending_account_save(1).await.unwrap().is_none());assert!(requests.try_recv().is_err());quiet(&mut peer).await;
    // Remove a complete stack via the actual durable discard handler.
    packet_handler(user.lock().await,Packet::DiscardItemRequest(DiscardItemRequestPacket {
        items:vec![UUIDAmount {uuid:1000,amount:1,..Default::default()}]})).await.unwrap();
    tick(&user).await;quiet(&mut peer).await;ack(&mut requests,0,false).await;finish(&user).await;
    let reply=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap();
    assert!(matches!(reply,Packet::UpdateInventory(p) if p.updated.len()==1 && p.updated[0].uuid==1000 && p.updated[0].new_amount==0));
    // Withdrawal into the freed slot must wait for the next durable receipt.
    packet_handler(user.lock().await,request(1)).await.unwrap();tick(&user).await;quiet(&mut peer).await;
    let commit=ack(&mut requests,1,false).await;assert_eq!(commit.snapshot.last_uuid,101);
    finish(&user).await;receive(&mut peer,1).await;
    {
        let guard=user.lock().await;
        let saved=sql.session_character(guard.account_session.as_ref().unwrap(),guard.character.as_ref().unwrap().character.character_id).await.unwrap();
        assert_eq!(serde_json::to_value(&saved.inventory.inventory).unwrap()["items"].as_array().unwrap().len(),50);
        assert!(saved.inventory.get_inv_item(1000).is_err());
        assert_eq!(saved.inventory.get_inv_item(101).unwrap(),stack(101,3,2));
        assert_eq!(saved.inventory.storages.default.items,vec![stack(20,3,4)]);
        assert!(guard.accepts_client_packets());
    }
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    close(&sql,&mut requests,&user,2).await;
}

#[tokio::test]
async fn local_asset_waits_for_older_periodic_checkpoint_then_commits_next_revision() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    user.lock().await.checkpoint_due = Instant::now(); tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit: old, ..} = action else {panic!()};
    assert!(user.lock().await.accepts_client_packets());
    packet_handler(user.lock().await, request(0)).await.unwrap();
    tick(&user).await; quiet(&mut peer).await; assert!(requests.try_recv().is_err());
    assert_eq!(old.snapshot.last_uuid, 100);
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id: old.commit_id, revision: 1, duplicate: false})).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {tick(&user).await; if user.lock().await.checkpoint_for_asset {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await;
    let next = ack(&mut requests, 1, false).await;
    assert_ne!(next.commit_id, old.commit_id); assert_eq!(next.snapshot.last_uuid, 101);
    assert_eq!(next.snapshot.storage.default.items[1], stack(101, 1, 2));
    finish(&user).await; receive(&mut peer, 0).await;
    close(&sql, &mut requests, &user, 2).await;
}

#[tokio::test]
async fn local_asset_rejection_has_no_reply_no_journal_and_no_partial_mutation() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    let before = format!("{:?}", user.lock().await.character.as_ref().unwrap().inventory);
    assert!(handlers::item::move_to_storage(&mut *user.lock().await, MoveToStorageRequestPacket {uuids: vec![storage(10), storage(999)]}).await.is_err());
    assert_eq!(format!("{:?}", user.lock().await.character.as_ref().unwrap().inventory), before);
    assert_eq!(user.lock().await.user_data.last_uuid, 100);
    assert!(user.lock().await.pending_asset.is_none()); tick(&user).await;
    assert!(sql.pending_account_save(1).await.unwrap().is_none()); assert!(requests.try_recv().is_err()); quiet(&mut peer).await;
    close(&sql, &mut requests, &user, 0).await;
}

#[tokio::test]
async fn local_asset_preconditions_reject_before_calling_mutator() {
    let (sql, mut requests, user, _peer) = fixture().await;
    {
        let mut guard = user.lock().await;
        let reject = |u: &mut User| assert!(u.queue_asset_change(|_, _| panic!("invalid session reached mutation")).is_err());
        let lease = guard.account_session.take(); reject(&mut guard); guard.account_session = lease;
        guard.closing = true; reject(&mut guard); guard.closing = false;
        guard.pending_asset = Some(vec![]); reject(&mut guard); guard.pending_asset = None;
        guard.state = UserState::CharacterSelect; reject(&mut guard); guard.state = UserState::InGame;
        let character = guard.character.take(); reject(&mut guard); guard.character = character;
        let (send, receive) = tokio::sync::oneshot::channel();
        guard.checkpoint_job = Some(receive); reject(&mut guard); guard.checkpoint_job = None; drop(send);
        guard.account_session.as_mut().unwrap().id = 2; reject(&mut guard); guard.account_session.as_mut().unwrap().id = 1;
    }
    close(&sql, &mut requests, &user, 0).await;
}

#[tokio::test]
async fn local_asset_lost_receipt_closes_without_reply_and_retries_exact_commit() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    packet_handler(user.lock().await, request(0)).await.unwrap(); tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit: original, ..} = action else {panic!()}; drop(reply);
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {let _ = User::tick(user.lock().await).await.unwrap(); if user.lock().await.closing {break;} tokio::task::yield_now().await;}
    }).await.unwrap(); quiet(&mut peer).await;
    let serve = async {
        let retry = ack(&mut requests, 0, true).await;
        assert_eq!(rmp_serde::to_vec(&retry).unwrap(), rmp_serde::to_vec(&original).unwrap());
        let latest = ack(&mut requests, 1, false).await;
        assert_eq!(latest.snapshot.last_uuid, 101); assert_eq!(latest.snapshot.storage.default.items[1], stack(101, 1, 2));
    };
    let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {tokio::join!(sql.drain_session_saves(), serve)}).await.unwrap(); result.unwrap();
    quiet(&mut peer).await;
}

#[tokio::test]
async fn local_asset_shutdown_before_worker_or_receipt_saves_complete_operation_without_reply() {
    for started in [false, true] {
        let (sql, mut requests, user, mut peer) = fixture().await;
        packet_handler(user.lock().await, request(5)).await.unwrap();
        if started {tick(&user).await;}
        user.lock().await.queue_disconnect();
        assert!(!user.lock().await.accepts_client_packets()); quiet(&mut peer).await;
        let serve = async {
            let first = ack(&mut requests, 0, false).await;
            assert_eq!(first.snapshot.storage.storage_meseta, 75);
            if started {assert_eq!(ack(&mut requests, 1, false).await.snapshot.storage.storage_meseta, 75);}
        };
        let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {tokio::join!(sql.drain_session_saves(), serve)}).await.unwrap(); result.unwrap();
        quiet(&mut peer).await;
    }
}

#[tokio::test]
async fn local_asset_worker_panic_fences_account_without_success() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    packet_handler(user.lock().await, request(0)).await.unwrap();
    {
        let mut guard = user.lock().await;
        let lease = guard.account_session.take().unwrap();
        let (send, receive) = tokio::sync::oneshot::channel::<saving::CheckpointReply>();
        guard.checkpoint_job = Some(receive); guard.checkpoint_for_asset = true;
        sql.track_save(async move {let _lease = lease; let _send = send; panic!("injected asset worker panic");});
    }
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {let _ = User::tick(user.lock().await).await; if user.lock().await.closing {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
    assert!(sql.drain_session_saves().await.is_err()); quiet(&mut peer).await;
    assert!(matches!(sql.open_account_session(&mut sql::User {id: 1, ..Default::default()}).await, Err(Error::InvalidInput("account_session_fenced"))));
    assert!(requests.try_recv().is_err());
}

#[tokio::test]
async fn local_asset_local_write_fault_never_acknowledges_and_final_save_recovers() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql, true).await;
    packet_handler(user.lock().await, request(0)).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {let _ = User::tick(user.lock().await).await.unwrap(); if user.lock().await.closing {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await; assert!(requests.try_recv().is_err());
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql, false).await;
    let serve = async {
        let head = ack(&mut requests, 0, false).await;
        assert_eq!(head.snapshot.last_uuid, 101); assert_eq!(head.snapshot.storage.default.items[1], stack(101, 1, 2));
        let latest = ack(&mut requests, 1, false).await;
        assert_eq!(latest.snapshot.last_uuid, 101); assert_eq!(latest.snapshot.storage.default.items[1], stack(101, 1, 2));
    };
    let (result, ()) = tokio::time::timeout(Duration::from_secs(5), async {tokio::join!(sql.drain_session_saves(), serve)}).await.unwrap(); result.unwrap();
    quiet(&mut peer).await;
}

#[tokio::test]
async fn local_quest_reward_socket_ack_waits_for_durable_receipt_and_replay_is_silent() {
    use super::quest_rewards::{QuestMesetaReceipt, RewardQueueResult};
    let (sql, mut requests, user, mut peer) = fixture().await;
    let id = user.lock().await.character.as_ref().unwrap().character.character_id;
    let reward = QuestMesetaReceipt {run_id: [1;16], character_id: id,
        quest_name_id: 30010, difficulty: 0, meseta: 50};
    assert_eq!(user.lock().await.queue_quest_meseta_reward(reward.clone()).unwrap(), RewardQueueResult::Queued);
    quiet(&mut peer).await; tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit, ..} = action else {panic!()};
    let saved = saved_character(&sql, 1, id).await;
    assert_eq!(saved.quest_meseta_receipts, vec![reward.clone()]);
    assert_eq!(serde_json::to_value(&saved.inventory.inventory).unwrap()["meseta"], 50);
    assert!(sql.pending_account_save(1).await.unwrap().is_some());
    for _ in 0..3 {tick(&user).await;}
    quiet(&mut peer).await;
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
        commit_id: commit.commit_id, revision: 1, duplicate: false})).await.unwrap();
    finish(&user).await;
    assert_eq!(tokio::time::timeout(Duration::from_secs(2), peer.read_packet_async()).await.unwrap().unwrap(),
        Packet::InventoryMeseta(InventoryMesetaPacket {meseta: 50}));
    // Reload persisted state instead of relying on the original in-memory receipt.
    user.lock().await.character = Some(saved_character(&sql, 1, id).await);
    assert_eq!(user.lock().await.queue_quest_meseta_reward(reward).unwrap(), RewardQueueResult::AlreadyAwarded);
    tick(&user).await; quiet(&mut peer).await; assert!(requests.try_recv().is_err());
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    close(&sql, &mut requests, &user, 1).await;
}

#[tokio::test]
async fn local_quest_reward_local_fault_rolls_back_receipt_and_balance_then_recovers_once() {
    use super::quest_rewards::QuestMesetaReceipt;
    let (sql, mut requests, user, mut peer) = fixture().await;
    let id = user.lock().await.character.as_ref().unwrap().character.character_id;
    let before = saved_character(&sql, 1, id).await;
    let reward = QuestMesetaReceipt {run_id: [2;16], character_id: id,
        quest_name_id: 30010, difficulty: 0, meseta: 50};
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql, true).await;
    user.lock().await.queue_quest_meseta_reward(reward.clone()).unwrap();
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {let _ = User::tick(user.lock().await).await.unwrap(); if user.lock().await.closing {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await; assert!(requests.try_recv().is_err());
    let failed = saved_character(&sql, 1, id).await;
    assert_eq!(rmp_serde::to_vec(&failed).unwrap(), rmp_serde::to_vec(&before).unwrap());
    assert!(failed.quest_meseta_receipts.is_empty());
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    crate::sql::local_checkpoint_tests::inject_asset_local_write_fault(&sql, false).await;
    let serve = async {ack(&mut requests, 0, false).await; ack(&mut requests, 1, false).await;};
    let (result, ()) = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(sql.drain_session_saves(), serve)
    }).await.unwrap(); result.unwrap();
    let recovered = saved_character(&sql, 1, id).await;
    assert_eq!(recovered.quest_meseta_receipts, vec![reward]);
    assert_eq!(serde_json::to_value(&recovered.inventory.inventory).unwrap()["meseta"], 50);
    quiet(&mut peer).await;
}

#[tokio::test]
async fn local_asset_wrong_master_receipt_cannot_release_success_reply() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    packet_handler(user.lock().await, request(5)).await.unwrap(); tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit: original, ..} = action else {panic!()};
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
        commit_id: original.commit_id.clone(), revision: 99, duplicate: false})).await.unwrap();
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {let _ = User::tick(user.lock().await).await.unwrap(); if user.lock().await.closing {break;} tokio::task::yield_now().await;}
    }).await.unwrap(); quiet(&mut peer).await;
    let serve = async {
        let retry = ack(&mut requests, 0, true).await; assert_eq!(retry.commit_id, original.commit_id);
        assert_eq!(ack(&mut requests, 1, false).await.snapshot.storage.storage_meseta, 75);
    };
    let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {tokio::join!(sql.drain_session_saves(), serve)}).await.unwrap(); result.unwrap();
    quiet(&mut peer).await;
}

#[tokio::test]
async fn local_asset_periodic_lost_receipt_is_resolved_before_new_asset_success() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    user.lock().await.checkpoint_due = Instant::now(); tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit: old, ..} = action else {panic!()};
    packet_handler(user.lock().await, request(0)).await.unwrap(); drop(reply);
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {tick(&user).await; if user.lock().await.checkpoint_for_asset {break;} tokio::task::yield_now().await;}
    }).await.unwrap();
    quiet(&mut peer).await;
    let retry = ack(&mut requests, 0, true).await;
    assert_eq!(rmp_serde::to_vec(&retry).unwrap(), rmp_serde::to_vec(&old).unwrap());
    quiet(&mut peer).await;
    let next = ack(&mut requests, 1, false).await;
    assert_eq!(next.snapshot.last_uuid, 101); assert_eq!(next.snapshot.storage.default.items[1], stack(101, 1, 2));
    finish(&user).await; receive(&mut peer, 0).await;
    close(&sql, &mut requests, &user, 2).await;
}

#[tokio::test]
async fn local_asset_identical_later_client_request_is_a_new_operation() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    for revision in 0..2 {
        packet_handler(user.lock().await, request(5)).await.unwrap(); tick(&user).await; quiet(&mut peer).await;
        let commit = ack(&mut requests, revision, false).await;
        assert_eq!(commit.snapshot.storage.storage_meseta, 100 - 25 * (revision + 1));
        finish(&user).await;
        assert_eq!(peer.read_packet_async().await.unwrap(), Packet::InventoryMeseta(InventoryMesetaPacket {meseta: 25 * (revision + 1)}));
        assert_eq!(peer.read_packet_async().await.unwrap(), Packet::StorageMeseta(StorageMesetaPacket {meseta: 100 - 25 * (revision + 1)}));
        assert!(user.lock().await.accepts_client_packets());
    }
    close(&sql, &mut requests, &user, 2).await;
}

#[tokio::test]
async fn local_asset_elapsed_checkpoint_timeout_closes_without_success_and_retries_identity() {
    let (sql, mut requests, user, mut peer) = fixture().await;
    packet_handler(user.lock().await, request(5)).await.unwrap();
    let start = Instant::now(); tick(&user).await;
    let (action, held_reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit: original, ..} = action else {panic!()};
    tokio::time::timeout(Duration::from_secs(18), async {
        loop {
            let result = User::tick(user.lock().await).await.unwrap();
            if matches!(result, Action::Disconnect) {break;}
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    }).await.unwrap();
    assert!(start.elapsed() >= Duration::from_secs(15));
    assert!(user.lock().await.closing); drop(held_reply);
    // Keepalive packets are permitted during the wait; an asset result is not.
    while let Ok(packet) = tokio::time::timeout(Duration::from_millis(20), peer.read_packet_async()).await {
        assert_eq!(packet.unwrap(), Packet::ServerPing);
    }
    let serve = async {
        let retry = ack(&mut requests, 0, true).await;
        assert_eq!(rmp_serde::to_vec(&retry).unwrap(), rmp_serde::to_vec(&original).unwrap());
        assert_eq!(ack(&mut requests, 1, false).await.snapshot.storage.storage_meseta, 75);
    };
    let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {tokio::join!(sql.drain_session_saves(), serve)}).await.unwrap(); result.unwrap();
    quiet(&mut peer).await;
}

#[tokio::test]
async fn local_asset_peer_write_failure_closes_after_durable_save_without_reapplying() {
    let (sql, mut requests, user, peer) = fixture_with_peer_linger(true).await;
    packet_handler(user.lock().await, request(5)).await.unwrap(); tick(&user).await;
    drop(peer);
    // Establish the actual reset before releasing the asset receipt. A fixed
    // delay alone would not prove the server has observed the closed peer.
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            if user.lock().await.send_packet(&Packet::ServerPing).await.is_err() {break;}
            tokio::time::sleep(Duration::from_millis(1)).await;
        }
    }).await.unwrap();
    ack(&mut requests, 0, false).await;
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            let result = User::tick(user.lock().await).await;
            if user.lock().await.closing {assert!(result.is_err()); break;}
            result.unwrap(); tokio::time::sleep(Duration::from_millis(1)).await;
        }
    }).await.unwrap();
    let final_commit = close(&sql, &mut requests, &user, 1).await;
    assert_eq!(final_commit.snapshot.storage.storage_meseta, 75);
    assert_eq!(final_commit.snapshot.last_uuid, 100);
    assert!(requests.try_recv().is_err());
}

fn durable_equipment_instance(kind:u16,uuid:u64,variant:u8)->Item {
    use pso2packetlib::protocol::items::{WeaponItem,UnitItem,ClothingItem,CamoItem};
    let data=match kind {
        1=>ItemType::Weapon(WeaponItem {element:variant,grind:variant,affixes:[variant as u16;8],unk7:17+variant as u32,..Default::default()}),
        2=>{let mut data=ClothingItem::default();data.color.hue=100*variant as u16;data.unk1=17+variant as u16;ItemType::Clothing(data)},
        5=>ItemType::Unit(UnitItem {enh_level:variant,affixes:[variant as u16;8],unk5:17+variant as u16,..Default::default()}),
        10=>ItemType::Camo(CamoItem {unk1:variant,unk4:17+variant,..Default::default()}),
        // Original named pet-egg identity; opaque sentinel bytes only test
        // preservation, not an interpretation of valid pet growth attributes.
        12=>ItemType::Unknown((0..40).map(|i|i^variant).collect::<Vec<u8>>().into()),
        _=>panic!("unsupported fixture kind"),
    };
    Item {uuid,id:ItemId {item_type:kind,id:if kind==12 {1}else{0},subid:if kind==12 {2}else{1},..Default::default()},data,..Default::default()}
}


fn equipment_request(direction:usize)->Packet {
    let storage=MoveStorageItemRequest {uuid:20,amount:1,storage_id:0,..Default::default()};
    match direction {
        0=>Packet::MoveToStorageRequest(MoveToStorageRequestPacket {uuids:vec![storage]}),
        1=>Packet::MoveToInventoryRequest(MoveToInventoryRequestPacket {uuids:vec![storage]}),
        _=>Packet::MoveStoragesRequest(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![UUIDAmount {uuid:20,amount:1,..Default::default()}]}),
    }
}
async fn equipment_setup(user:&Mutex<User>,kind:u16,variant:u8,direction:usize)->(Item,Item) {
    let existing=durable_equipment_instance(kind,10,1);let moved=durable_equipment_instance(kind,20,variant);
    let mut guard=user.lock().await;
    let inv=&mut guard.character.as_mut().unwrap().inventory;
    *inv=crate::inventory::Inventory::default();inv.character.storage_id=14;
    match direction {
        0=>{inv.add_item(moved.clone());inv.storages.default.items=vec![existing.clone()];},
        1=>{inv.add_item(existing.clone());inv.storages.default.items=vec![moved.clone()];},
        _=>{inv.storages.default.items=vec![moved.clone()];inv.character.items=vec![existing.clone()];},
    }
    (existing,moved)
}
fn equipment_expected_storage(direction:usize,existing:&Item,moved:&Item)->Vec<Item> {
    if direction==0 {vec![existing.clone(),moved.clone()]} else {vec![]}
}
async fn equipment_durable(direction:usize) {
    equipment_durable_kinds(direction,&[1,2,5,10]).await;
}
async fn equipment_durable_kinds(direction:usize,kinds:&[u16]) {
    for &kind in kinds {
        for variant in [1,2] {
            let (sql,mut requests,user,mut peer)=fixture().await;
            let (existing,moved)=equipment_setup(&user,kind,variant,direction).await;
            packet_handler(user.lock().await,equipment_request(direction)).await.unwrap();
            quiet(&mut peer).await;tick(&user).await;
            let (action,reply)=tokio::time::timeout(Duration::from_secs(2),requests.recv()).await.unwrap().unwrap();
            let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
            assert_eq!(commit.snapshot.last_uuid,100);
            assert_eq!(commit.snapshot.storage.default.items,equipment_expected_storage(direction,&existing,&moved));
            assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,commit.commit_id);
            quiet(&mut peer).await;
            reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
            finish(&user).await;
            let packet=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap();
            let old=UpdatedStorageItem {uuid:20,new_amount:0,moved:1,storage_id:0};
            let expected=match direction {
                0=>Packet::MoveToStorage(MoveToStoragePacket {updated_inventory:vec![UpdatedInventoryItem {uuid:20,new_amount:0,moved:1}],updated:vec![],new_items:vec![NewStorageItem {item:moved.clone(),storage_id:0}]}),
                1=>Packet::MoveToInventory(MoveToInventoryPacket {updated:vec![old],new_items:vec![NewInventoryItem {item:moved.clone(),amount:1,is_new:1}]}),
                _=>Packet::MoveStorages(MoveStoragesPacket {updated_old:vec![old],updated_new:vec![],new_items:vec![NewStorageItem {item:moved.clone(),storage_id:14}]}),
            };
            assert_eq!(packet,expected);quiet(&mut peer).await;
            {
                let guard=user.lock().await;assert_eq!(guard.user_data.last_uuid,100);
                let saved=sql.session_character(guard.account_session.as_ref().unwrap(),guard.character.as_ref().unwrap().character.character_id).await.unwrap();
                let pack=if direction==1 {vec![existing.clone(),moved.clone()]} else {vec![]};
                let character_storage=if direction==2 {vec![existing.clone(),moved.clone()]} else {vec![]};
                assert_eq!(serde_json::to_value(&saved.inventory.inventory).unwrap()["items"],serde_json::to_value(pack).unwrap());
                assert_eq!(saved.inventory.character.items,character_storage);
                assert_eq!(saved.inventory.storages.default.items,equipment_expected_storage(direction,&existing,&moved));
                assert!(guard.accepts_client_packets());
            }
            assert!(sql.pending_account_save(1).await.unwrap().is_none());
            let final_commit=close(&sql,&mut requests,&user,1).await;
            assert_eq!(final_commit.snapshot.last_uuid,100);
            assert_eq!(final_commit.snapshot.storage.default.items,equipment_expected_storage(direction,&existing,&moved));
        }
    }
}
#[tokio::test] async fn local_equipment_durable_to_storage() {equipment_durable(0).await;}
#[tokio::test] async fn local_equipment_durable_to_inventory() {equipment_durable(1).await;}
#[tokio::test] async fn local_equipment_durable_between_storages() {equipment_durable(2).await;}
#[tokio::test]
async fn local_pet_egg_durable_three_routes_preserve_opaque_payload_and_uuid() {
    for direction in 0..3 {equipment_durable_kinds(direction,&[12]).await;}
}

#[tokio::test]
async fn local_equipment_lost_receipt_retries_exact_instances_without_success_reply() {
    for kind in [1,2,5,10] {
        for direction in 0..3 {
            let (sql,mut requests,user,mut peer)=fixture().await;
            let (existing,moved)=equipment_setup(&user,kind,2,direction).await;
            packet_handler(user.lock().await,equipment_request(direction)).await.unwrap();tick(&user).await;
            let (action,reply)=tokio::time::timeout(Duration::from_secs(2),requests.recv()).await.unwrap().unwrap();
            let MasterShipAction::CommitAccountSnapshot {commit:original,..}=action else {panic!()};drop(reply);
            tokio::time::timeout(Duration::from_secs(2),async {
                loop {let _=User::tick(user.lock().await).await.unwrap();if user.lock().await.closing {break;}tokio::task::yield_now().await;}
            }).await.unwrap();quiet(&mut peer).await;
            let serve=async {
                let retry=ack(&mut requests,0,true).await;
                assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&original).unwrap());
                let latest=ack(&mut requests,1,false).await;
                assert_eq!(latest.snapshot.last_uuid,100);
                assert_eq!(latest.snapshot.storage.default.items,equipment_expected_storage(direction,&existing,&moved));
            };
            let (result,())=tokio::time::timeout(Duration::from_secs(3),async {tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();result.unwrap();
            quiet(&mut peer).await;
        }
    }
}

#[tokio::test]
async fn local_quest_completion_durable_result_waits_for_ack_and_reload_replay_is_silent() {
    use pso2packetlib::protocol::ProtocolRW;
    use super::quest_rewards::{QuestMesetaReceipt, RewardQueueResult};
    let (sql, mut requests, user, mut peer) = fixture().await;
    let id = user.lock().await.character.as_ref().unwrap().character.character_id;
    let reward = QuestMesetaReceipt {run_id: [1;16], character_id: id,
        quest_name_id: 30010, difficulty: 0, meseta: 50};
    let result=pso2packetlib::protocol::questlist::QuestResultPacket {meseta_earned:50,..Default::default()};
    // Exercise a real decoded result template, including fixed-array padding.
    let mut packets=Packet::read(&Packet::QuestResult(result).write(PacketType::Classic),PacketType::Classic).unwrap();
    let Packet::QuestResult(result)=packets.remove(0) else {panic!()};
    let before=serde_json::to_value(user.lock().await.character.as_ref().unwrap()).unwrap();
    let mut wrong=result.clone();wrong.exp_earned=1;
    assert!(user.lock().await.queue_quest_settlement(reward.clone(),wrong).is_err());
    let mut wrong=result.clone();wrong.meseta_earned=49;
    assert!(user.lock().await.queue_quest_settlement(reward.clone(),wrong).is_err());
    assert_eq!(serde_json::to_value(user.lock().await.character.as_ref().unwrap()).unwrap(),before);
    assert_eq!(user.lock().await.queue_quest_settlement(reward.clone(),result.clone()).unwrap(), RewardQueueResult::Queued);
    quiet(&mut peer).await; tick(&user).await;
    let (action, reply) = requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {commit, ..} = action else {panic!()};
    let saved = saved_character(&sql, 1, id).await;
    assert_eq!(saved.quest_meseta_receipts, vec![reward.clone()]);
    assert_eq!(serde_json::to_value(&saved.inventory.inventory).unwrap()["meseta"], 50);
    assert!(sql.pending_account_save(1).await.unwrap().is_some());
    for _ in 0..3 {tick(&user).await;}
    quiet(&mut peer).await;
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
        commit_id: commit.commit_id, revision: 1, duplicate: false})).await.unwrap();
    finish(&user).await;
    assert_eq!(tokio::time::timeout(Duration::from_secs(2), peer.read_packet_async()).await.unwrap().unwrap(),
        Packet::InventoryMeseta(InventoryMesetaPacket {meseta: 50}));
    let received=tokio::time::timeout(Duration::from_secs(2), peer.read_packet_async()).await.unwrap().unwrap();
    let Packet::QuestResult(decoded)=&received else {panic!("expected quest result after durable meseta reply");};
    assert_eq!(decoded.meseta_earned,50);assert_eq!(decoded.exp_earned,0);
    // FixedVec defaults are empty in memory, but the codec pads the actual wire.
    // Compare complete wire contents instead of unequal padded/unpadded vectors.
    assert_eq!(received.write(PacketType::Classic),Packet::QuestResult(result.clone()).write(PacketType::Classic));
    // Reload persisted state instead of relying on the original in-memory receipt.
    user.lock().await.character = Some(saved_character(&sql, 1, id).await);
    assert_eq!(user.lock().await.queue_quest_settlement(reward,result).unwrap(), RewardQueueResult::AlreadyAwarded);
    tick(&user).await; quiet(&mut peer).await; assert!(requests.try_recv().is_err());
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    close(&sql, &mut requests, &user, 1).await;
}
