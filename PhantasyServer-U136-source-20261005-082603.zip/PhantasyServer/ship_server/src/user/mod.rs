pub(crate) mod handlers;
mod diagnostics;
mod packet_identity;
mod experience;
mod saving;
mod quest_rewards;
pub(crate) use quest_rewards::QuestMesetaReceipt;
#[cfg(test)]
mod local_save_tests;
#[cfg(test)]
mod local_asset_save_tests;
#[cfg(test)]
pub(crate) mod local_equipment_save_tests;
#[cfg(test)]
mod local_equipment_process_tests;
#[cfg(test)]
mod local_asset_process_tests;
pub(crate) use experience::ExpSource;
#[cfg(test)]
mod local_exp_tests;
#[cfg(test)]
mod local_hero_save_tests;
#[cfg(test)]
mod local_native_hero_save_tests;
#[cfg(test)]
mod local_native_phantom_save_tests;
#[cfg(test)]
mod local_native_class_save_tests;
use crate::{
    Action, BlockData, Error,
    battle_stats::PlayerStats,
    invites::PartyInvite,
    map::Map,
    mutex::{Mutex, MutexGuard, RwLock},
    party::{self, Party},
    sql::{self, CharData},
};
use data_structs::flags::Flags;
use pso2packetlib::{
    Connection, PublicKey,
    connection::{ConnectionError, ConnectionRead, ConnectionWrite},
    protocol::{
        self as Pr, ObjectHeader, Packet, PacketType,
        login::Language,
        models::{
            Position,
            character::Class,
        },
        party::BusyState,
        playerstatus::EXPReceiver,
        spawn::CharacterSpawnPacket,
    },
};
use std::{fmt::Display, net::Ipv4Addr, sync::Arc, time::Instant};

pub struct User {
    // ideally all of these should be private
    connection: ConnectionWrite,
    blockdata: Arc<BlockData>,
    pub position: Position,
    map: Option<Arc<Mutex<Map>>>,
    pub party: Option<Arc<RwLock<Party>>>,
    pub character: Option<CharData>,
    last_ping: Instant,
    failed_pings: u32,
    ready_to_shutdown: bool,
    pub party_invites: Vec<PartyInvite>,
    pub party_ignore: Pr::party::RejectStatus,
    pub map_id: u32,
    // offset of the zone in map zones list
    pub zone_pos: usize,
    firstload: bool,
    pub state: UserState,
    battle_stats: PlayerStats,
    conn_id: usize,
    pub user_data: sql::User,
    account_session: Option<sql::AccountSession>,
    checkpoint_job: Option<tokio::sync::oneshot::Receiver<saving::CheckpointReply>>,
    checkpoint_due: Instant,
    checkpoint_wakeup: Arc<tokio::sync::Notify>,
    pending_asset: Option<Vec<Packet>>,
    pending_equipment_broadcast: Option<Vec<Packet>>,
    checkpoint_for_asset: bool,
    closing: bool,

    session_start: Instant,
    unhandled_packets: diagnostics::UnhandledPackets,
    native_skill_trace: crate::native_skill_trace::NativeSkillTrace,
    hero_combat_trace: crate::hero_combat_trace::HeroCombatTrace,
    hero_time: crate::hero_time::HeroTime,
    phantom_time: crate::phantom_time::PhantomTime,
    phantom_counter: crate::phantom_counter::PhantomCounter,
}

impl User {
    pub(crate) fn phantom_time_invulnerable(&self, now:Instant)->bool {
        self.character.as_ref().is_some_and(|c|c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom)
            && self.phantom_time.invulnerable(now)
    }

    pub(crate) fn new(
        stream: tokio::net::TcpStream,
        blockdata: Arc<BlockData>,
        conn_id: usize,
    ) -> Result<(User, ConnectionRead<Packet>), Error> {
        stream.set_nodelay(true)?;
        let mut con = Connection::new_async(
            stream,
            PacketType::Classic,
            blockdata.key.clone(),
            PublicKey::None,
        );
        match con.write_packet(&Packet::ServerHello(Pr::server::ServerHelloPacket {
            unk1: 3,
            blockid: blockdata.block_id as u16,
            unk2: 68833280,
        })) {
            Ok(_) => {}
            Err(ConnectionError::Io(x)) if x.kind() == std::io::ErrorKind::WouldBlock => {}
            Err(x) => return Err(x.into()),
        }
        let (read, write) = con.into_split()?;
        Ok((
            User {
                connection: write,
                blockdata,
                character: None,
                map: None,
                party: None,
                position: Default::default(),
                last_ping: Instant::now(),
                failed_pings: 0,
                ready_to_shutdown: false,
                party_invites: vec![],
                party_ignore: Default::default(),
                map_id: 0,
                zone_pos: 0,
                firstload: true,
                state: UserState::LoggingIn,
                battle_stats: Default::default(),
                conn_id,
                user_data: sql::User {
                    packet_type: PacketType::Classic,
                    lang: Language::Japanese,
                    isgm: false,
                    last_uuid: 1,
                    ..Default::default()
                },
                session_start: Instant::now(),
                account_session: None,
                checkpoint_job: None,
                pending_asset: None,
                pending_equipment_broadcast: None,
                checkpoint_for_asset: false,
                checkpoint_due: Instant::now() + saving::CHECKPOINT_INTERVAL,
                checkpoint_wakeup: Arc::new(tokio::sync::Notify::new()),
                closing: false,
                unhandled_packets: Default::default(),
                native_skill_trace: Default::default(),
                hero_combat_trace: Default::default(),
                hero_time: Default::default(),
                phantom_time: Default::default(),
                phantom_counter: Default::default(),
            },
            read,
        ))
    }
    // I hope async guard won't cause me troubles in the future
    pub async fn tick(mut s: MutexGuard<'_, Self>) -> Result<Action, Error> {
        if s.closing { return Ok(Action::Disconnect); }
        let replies = s.service_checkpoints(Instant::now());
        if s.closing { return Ok(Action::Disconnect); }
        for reply in replies {
            if let Err(error) = s.send_packet(&reply).await {
                s.queue_disconnect();
                return Err(error);
            }
        }
        let owner=s.create_object_header();
        if let Some(reply)=s.hero_time.expire(owner,Instant::now()) {
            s.send_packet(&reply).await?;
        }
        let ph_reply=if s.character.as_ref().is_some_and(|c|c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom) {
            s.phantom_time.expire(owner,Instant::now())
        } else {s.phantom_time.cancel(owner)};
        for reply in ph_reply {
            s.send_packet(&reply).await?;
        }
        if !s.character.as_ref().is_some_and(|c|c.character.classes.main_class==pso2packetlib::protocol::models::character::Class::Phantom) {
            if let Some(reply)=s.phantom_counter.clear(owner) {s.send_packet(&reply).await?;}
        }
        let _ = s.connection.flush();
        if s.ready_to_shutdown && s.last_ping.elapsed().as_millis() >= 500 {
            return Ok(Action::Disconnect);
        }
        if s.failed_pings >= 5 {
            return Ok(Action::Disconnect);
        }
        if s.last_ping.elapsed().as_secs() >= 10 {
            s.last_ping = Instant::now();
            s.failed_pings += 1;
            let _ = s.send_packet(&Packet::ServerPing).await;
        }
        // Only a successful checkpoint can clear pending_asset without closing.
        // Drop the player lock before taking the map lock (map sends lock users).
        if s.pending_asset.is_none() {
            if let Some(packets) = s.pending_equipment_broadcast.take() {
                let map = s.map.clone();
                let zone = s.zone_pos;
                drop(s);
                if let Some(map) = map {
                    let map = map.lock().await;
                    for packet in packets { map.send_to_all(zone, &packet).await; }
                }
            }
        }
        Ok(Action::Nothing)
    }
    // Helper functions
    pub fn get_ip(&self) -> Result<Ipv4Addr, Error> {
        Ok(self.connection.get_ip()?)
    }
    pub async fn send_packet(&mut self, packet: &Packet) -> Result<(), Error> {
        self.connection.write_packet_async(packet).await?;
        Ok(())
    }
    pub fn try_send_packet(&mut self, packet: &Packet) -> Result<(), Error> {
        match self.connection.write_packet(packet) {
            Ok(_) => {}
            Err(ConnectionError::Io(ref e)) if e.kind() == std::io::ErrorKind::WouldBlock => {}
            Err(e) => return Err(e.into()),
        };
        Ok(())
    }
    pub fn send_packet_block(&mut self, packet: &Packet) -> Result<(), Error> {
        match self.connection.write_packet(packet) {
            Ok(_) => return Ok(()),
            Err(ConnectionError::Io(ref e)) if e.kind() == std::io::ErrorKind::WouldBlock => {}
            Err(e) => return Err(e.into()),
        };
        loop {
            match self.connection.flush() {
                Ok(_) => return Ok(()),
                Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => {}
                Err(e) => return Err(e.into()),
            }
        }
    }
    pub async fn spawn_character(&mut self, packet: CharacterSpawnPacket) -> Result<(), Error> {
        self.send_packet(&Packet::CharacterSpawn(packet)).await?;
        Ok(())
    }
    pub fn try_spawn_character(&mut self, packet: CharacterSpawnPacket) -> Result<(), Error> {
        self.try_send_packet(&Packet::CharacterSpawn(packet))?;
        Ok(())
    }
    pub fn get_current_map(&self) -> Option<Arc<Mutex<Map>>> {
        self.map.clone()
    }
    pub fn get_current_party(&self) -> Option<Arc<RwLock<Party>>> {
        self.party.clone()
    }
    pub fn set_map(&mut self, map: Arc<Mutex<Map>>) {
        self.map = Some(map)
    }
    pub const fn get_user_id(&self) -> u32 {
        self.user_data.id
    }
    pub const fn get_map_id(&self) -> u32 {
        self.map_id
    }
    pub const fn get_stats(&self) -> &PlayerStats {
        &self.battle_stats
    }
    pub const fn get_stats_mut(&mut self) -> &mut PlayerStats {
        &mut self.battle_stats
    }
    pub const fn create_object_header(&self) -> ObjectHeader {
        ObjectHeader {
            id: self.get_user_id(),
            unk: 0,
            entity_type: Pr::ObjectType::Player,
            map_id: 0,
        }
    }
    pub fn get_blockdata(&self) -> &BlockData {
        &self.blockdata
    }
    pub async fn send_item_attrs(&mut self) -> Result<(), Error> {
        let blockdata = self.blockdata.clone();
        let item_attrs = &blockdata.server_data.item_params;
        let data = match self.user_data.packet_type {
            PacketType::Vita => &item_attrs.vita_attrs,
            _ => &item_attrs.pc_attrs,
        };
        let size = data.len();
        for (id, chunk) in data.chunks(0x32000).enumerate() {
            let packet = Pr::items::ItemAttributesPacket {
                id: 0,
                segment: id as u16,
                total_size: size as u32,
                data: chunk.to_vec().into(),
            };
            self.send_packet(&Packet::LoadItemAttributes(packet))
                .await?;
        }
        Ok(())
    }
    pub async fn send_system_msg(
        &mut self,
        msg: &(impl std::fmt::Display + ?Sized + Sync),
    ) -> Result<(), Error> {
        self.send_packet(&Packet::SystemMessage(Pr::unk19::SystemMessagePacket {
            message: msg.to_string(),
            msg_type: Pr::unk19::MessageType::SystemMessage,
            ..Default::default()
        }))
        .await?;
        Ok(())
    }
    pub async fn send_error(
        &mut self,
        msg: &(impl std::fmt::Display + ?Sized + Sync),
    ) -> Result<(), Error> {
        self.send_packet(&Packet::SystemMessage(Pr::unk19::SystemMessagePacket {
            message: msg.to_string(),
            msg_type: Pr::unk19::MessageType::AdminMessageInstant,
            ..Default::default()
        }))
        .await?;
        Ok(())
    }
    pub async fn send_position(
        user: MutexGuard<'_, User>,
        packet: Packet,
    ) -> Result<Action, Error> {
        let id = user.get_user_id();
        let map = user.get_current_map();
        let zone = user.zone_pos;
        drop(user);
        if let Some(map) = map {
            map.lock().await.send_movement(zone, packet, id).await;
        }
        Ok(Action::Nothing)
    }
    #[cfg(test)]
    pub fn add_exp(&mut self, exp: u32, source: ExpSource) -> Result<EXPReceiver, Error> {
        Ok(self.prepare_exp(exp, source)?.commit())
    }

    pub(crate) fn prepare_exp(&mut self, exp: u32, source: ExpSource) -> Result<experience::PreparedExp<'_>, Error> {
        let char = self.character.as_ref().ok_or(Error::InvalidInput("add_exp_character"))?;
        let classes = &char.character.classes;
        if classes.main_class == classes.sub_class {
            return Err(Error::InvalidInput("experience_same_class"));
        }
        let old_main = *char.character.get_level();
        let old_sub = *char.character.get_sublevel();
        let main = experience::advance(&self.blockdata.server_data, classes.main_class,
            old_main, exp, experience::MAIN_CAP)?;
        let sub_gain = experience::subclass_gain(classes.main_class, classes.sub_class, old_sub.level1, exp, source);
        let sub = if classes.sub_class == Class::Unknown { None } else {
            Some(experience::advance(&self.blockdata.server_data, classes.sub_class,
                old_sub, sub_gain, experience::SUB_EXP_CAP)?)
        };
        let levels_changed = main.level1 != old_main.level1
            || sub.is_some_and(|level| level.level1 != old_sub.level1);
        // All fallible work precedes mutation, including the prospective stats.
        // Keep U014's non-level HP preservation and the existing level-change
        // recovery behavior; the latter still needs original-version evidence.
        let new_stats = if levels_changed {
            Some(PlayerStats::build_for_levels(self, main.level1 as usize,
                sub.map(|level| level.level1 as usize))?)
        } else { None };
        let mut packet = EXPReceiver {
            object: self.create_object_header(),
            unk1: 1,
            unk2: 1,
            gained: exp as _,
            total: main.exp as _,
            level: main.level1,
            level2: main.level2,
            class: classes.main_class,
            subclass: classes.sub_class,
            ..Default::default()
        };
        if let Some(sub) = sub {
            packet.gained_sub = sub_gain as _;
            packet.total_sub = sub.exp as _;
            packet.level2_sub = sub.level2;
            packet.level_sub = sub.level1;
        }
        let character = self.character.as_mut().ok_or(Error::InvalidInput("add_exp_character"))?;
        Ok(experience::PreparedExp { character, stats: &mut self.battle_stats,
            main, sub, new_stats, packet })
    }
    pub async fn set_account_flag(&mut self, flag: u32, value: bool) -> Result<(), Error> {
        self.user_data.accountflags.set(flag as _, value as _);
        self.send_packet(&Packet::ServerSetFlag(Pr::flag::ServerSetFlagPacket {
            flag_type: Pr::flag::FlagType::Account,
            id: flag,
            value: value as u32,
            ..Default::default()
        }))
        .await?;
        Ok(())
    }
    pub fn set_account_flag_block(&mut self, flag: u32, value: bool) -> Result<(), Error> {
        self.user_data.accountflags.set(flag as _, value as _);
        self.send_packet_block(&Packet::ServerSetFlag(Pr::flag::ServerSetFlagPacket {
            flag_type: Pr::flag::FlagType::Account,
            id: flag,
            value: value as u32,
            ..Default::default()
        }))?;
        Ok(())
    }
    pub fn get_account_flags(&self) -> Flags {
        self.user_data.accountflags.clone()
    }
    pub async fn set_char_flag(&mut self, flag: u32, value: bool) -> Result<(), Error> {
        if let Some(c) = self.character.as_mut() {
            c.flags.set(flag as _, value as _);
        }
        self.send_packet(&Packet::ServerSetFlag(Pr::flag::ServerSetFlagPacket {
            flag_type: Pr::flag::FlagType::Character,
            id: flag,
            value: value as u32,
            ..Default::default()
        }))
        .await?;
        Ok(())
    }
    pub fn set_char_flag_block(&mut self, flag: u32, value: bool) -> Result<(), Error> {
        if let Some(c) = self.character.as_mut() {
            c.flags.set(flag as _, value as _);
        }
        self.send_packet_block(&Packet::ServerSetFlag(Pr::flag::ServerSetFlagPacket {
            flag_type: Pr::flag::FlagType::Character,
            id: flag,
            value: value as u32,
            ..Default::default()
        }))?;
        Ok(())
    }
    pub fn get_char_flags(&self) -> Option<Flags> {
        self.character.as_ref().map(|c| c.flags.clone())
    }

    pub(crate) async fn begin_account_session(&mut self) -> Result<(), Error> {
        if self.account_session.is_some() || self.checkpoint_job.is_some() || self.closing {
            return Err(Error::InvalidInput("account_session_already_started"));
        }
        self.account_session = Some(self.blockdata.sql.open_account_session(&mut self.user_data).await?);
        Ok(())
    }

    pub(crate) fn queue_disconnect(&mut self) {
        if self.closing { return; }
        self.closing = true;
        // The durable state is saved below even when its acknowledgment was
        // never sent. Never manufacture success while disconnecting.
        self.pending_asset = None;
        self.pending_equipment_broadcast = None;
        self.checkpoint_for_asset = false;
        let mut session = self.account_session.take();
        let checkpoint_job = self.checkpoint_job.take();
        // Existing map readers may still hold a weak reference until cleanup.
        // Leave their identity/character readable, but stop packet mutation.
        let character = self.persistence_character_at(Instant::now());
        let party = self.party.take();
        let map = self.map.take();
        if session.is_none() && checkpoint_job.is_none() && character.is_none() && party.is_none() && map.is_none() { return; }
        let sql = self.blockdata.sql.clone();
        let data = self.user_data.clone();
        self.blockdata.sql.track_save(async move {
            if let Some(receiver) = checkpoint_job {
                match receiver.await {
                    Ok((held, _result)) => {
                        if session.is_some() || held.id != data.id {
                            sql.record_session_save_failure("disconnect checkpoint lease mismatch");
                            drop(held);
                        } else {session = Some(held);}
                    },
                    Err(_) => sql.record_session_save_failure("disconnect checkpoint worker lost its lease"),
                }
            }
            if let (Some(session), Some(character)) = (session.as_mut(), &character) {
                sql.persist_session(session, character, &data).await;
            }
            // Complete old map/party removal before allowing the same account
            // to enter again; their indexes use player IDs, not session IDs.
            if let Some(party) = party {
                if let Err(e) = party.write().await.remove_player(data.id).await {
                    log::warn!("Party cleanup for account {}: {e}", data.id);
                }
            }
            if let Some(map) = map { map.lock().await.remove_player(data.id).await; }
            if let Some(session) = session {
                session.release();
            } else if character.is_some() {
                sql.record_session_save_failure("character without account lease; refusing unfenced final save");
            }
        });
    }
}

pub async fn packet_handler(
    mut user_guard: MutexGuard<'_, User>,
    packet: Packet,
) -> Result<Action, Error> {
    let user: &mut User = &mut user_guard;
    if user.closing { return Ok(Action::Disconnect); }
    let state = user.state;
    if state == UserState::InGame { user.native_skill_trace.observe(&packet); }
    if state == UserState::InGame && user.character.as_ref().is_some_and(|c|c.character.classes.main_class==Class::Hero) {
        user.hero_combat_trace.observe(&packet);
    }
    // sidestep borrow checker
    let match_unit = (state, packet);
    use {Packet as P, UserState as US, handlers as H};

    match match_unit {
        // Server packets
        (US::PreInGame, P::InitialLoad) => H::server::initial_load(user_guard).await,
        (_, P::ServerPong) => {
            user.failed_pings = 0;
            Ok(Action::Nothing)
        }
        (US::InGame, P::MapLoaded(data)) => H::server::map_loaded(user_guard, data).await,
        (US::InGame, P::ToCampship(data)) => H::server::to_campship(user_guard, data).await,
        (US::InGame, P::CampshipDown(data)) => H::server::campship_down(user_guard, data).await,
        (US::InGame, P::ReturnToCampship(data)) => H::server::return_to_campship(user_guard, data).await,
        (US::InGame, P::ReturnToCampshipFinal(_)) => H::server::return_completed_quest(user_guard).await,
        (US::InGame, P::DeathToCampship(_)) if H::server::death_experiment_enabled_for(user) => H::server::death_to_campship_experiment(user_guard).await,
        (US::InGame, P::CasinoToLobby(data)) => H::server::move_from_casino(user_guard, data).await,
        (US::InGame, P::CasinoTransport(data)) => H::server::move_to_casino(user_guard, data).await,
        (US::InGame, P::BridgeToLobby(data)) => H::server::move_from_bridge(user_guard, data).await,
        (US::InGame, P::BridgeTransport(data)) => H::server::move_to_bridge(user_guard, data).await,
        (US::InGame, P::CafeToLobby(data)) => H::server::move_from_cafe(user_guard, data).await,
        (US::InGame, P::CafeTransport(data)) => H::server::move_to_cafe(user_guard, data).await,
        (US::InGame, P::StoryToLobby(data)) => H::server::move_from_story(user_guard, data).await,

        // Object packets
        (US::InGame, P::Unknown((h,body))) if h.id==4 && h.subid==0x27 => H::native_hero::operation(user,&body).await,
        (US::InGame, P::Movement(data)) => H::object::movement(user_guard, data).await,
        (US::InGame, P::MovementAction(..)) => User::send_position(user_guard, match_unit.1).await,
        (US::InGame, P::Interact(data)) => H::object::action(user_guard, data).await,
        (US::InGame, P::ChangeClassRequest(data)) => {
            H::object::change_class(user_guard, data).await
        }
        (US::InGame, P::ActionUpdate(..)) => User::send_position(user_guard, match_unit.1).await,
        (US::InGame, P::MovementEnd(ref data)) => {
            user.position = data.cur_pos;
            User::send_position(user_guard, match_unit.1).await
        }
        (US::InGame, P::ActionEnd(..)) => User::send_position(user_guard, match_unit.1).await,

        // Player status packets
        (US::InGame, P::DealDamage(data)) => H::player_status::deal_damage(user_guard, data).await,

        // Chat packets
        (US::InGame, P::ChatMessage(..)) => H::chat::send_chat(user_guard, match_unit.1).await,

        // Quest List packets
        (US::InGame, P::MinimapRevealRequest(data)) => {
            H::quest::minimap_reveal(user_guard, data).await
        }
        (US::InGame, P::AvailableQuestsRequest(data)) => {
            H::quest::avaliable_quests(user, data).await
        }
        (US::InGame, P::QuestCategoryRequest(data)) => H::quest::quest_category(user, data).await,
        (US::InGame, P::QuestDifficultyRequest(data)) => {
            H::quest::quest_difficulty(user, data).await
        }
        (US::InGame, P::AcceptQuest(data)) => H::quest::set_quest(user_guard, data).await,
        (US::InGame, P::QuestCounterRequest) => H::quest::counter_request(user).await,
        (US::InGame, P::AcceptStoryQuest(data)) => {
            H::quest::set_story_quest(user_guard, data).await
        }

        // Party packets
        (US::InGame, P::PartyInviteRequest(data)) => {
            H::party::send_invite(user_guard, data.invitee.id).await
        }
        (US::InGame, P::AcceptInvite(data)) => H::party::accept_invite(user_guard, data).await,
        (US::InGame, P::LeaveParty) => H::party::leave_party(user_guard).await,
        (US::InGame, P::NewPartySettings(data)) => {
            H::party::set_party_settings(user_guard, data).await
        }
        (US::InGame, P::TransferLeader(data)) => H::party::transfer_leader(user_guard, data).await,
        (US::InGame, P::KickMember(data)) => H::party::kick_player(user_guard, data).await,
        (US::InGame, P::DisbandParty(..)) => H::party::disband_party(user_guard).await,
        (US::InGame, P::ChatStatus(data)) => H::party::set_chat_state(user_guard, data).await,
        (US::InGame, P::GetPartyDetails(data)) => {
            party::Party::get_details(user_guard, data).await?;
            Ok(Action::Nothing)
        }
        (US::InGame, P::SetBusy) => H::party::set_busy_state(user_guard, BusyState::Busy).await,
        (US::InGame, P::SetNotBusy) => {
            H::party::set_busy_state(user_guard, BusyState::NotBusy).await
        }
        (US::InGame, P::SetInviteDecline(data)) => {
            user.party_ignore = data.decline_status;
            Ok(Action::Nothing)
        }
        (US::InGame, P::GetPartyInfo(data)) => {
            party::Party::get_info(user_guard, data).await?;
            Ok(Action::Nothing)
        }

        // Item packets
        (US::InGame, P::EquipItemRequest(data)) => H::item::equip_item(user_guard, data).await,
        (US::InGame, P::UnequipItemRequest(data)) => H::item::unequip_item(user_guard, data).await,
        (US::InGame, P::MoveToStorageRequest(data)) => H::item::move_to_storage(user, data).await,
        (US::InGame, P::MoveToInventoryRequest(data)) => {
            H::item::move_to_inventory(user, data).await
        }
        (US::InGame, P::MoveMeseta(data)) => H::item::move_meseta(user, data).await,
        (US::InGame, P::DiscardItemRequest(data)) => H::item::discard_inventory(user, data).await,
        (US::InGame, P::MoveStoragesRequest(data)) => H::item::move_storages(user, data).await,
        (US::InGame, P::GetItemDescription(data)) => H::item::get_description(user, data).await,
        (US::InGame, P::DiscardStorageItemRequest(data)) => {
            H::item::discard_storage(user, data).await
        }

        // Login packets
        (US::LoggingIn, P::SegaIDLogin(..)) => H::login::login_request(user, match_unit.1).await,
        (US::CharacterSelect, P::CharacterListRequest) => H::login::character_list(user).await,
        (US::CharacterSelect, P::StartGame(data)) => H::login::start_game(user, data).await,
        (US::CharacterSelect, P::CharacterCreate(data)) => {
            H::login::new_character(user, data).await
        }
        (US::CharacterSelect, P::CharacterDeletionRequest(data)) => {
            H::login::delete_request(user, data).await
        }
        (_, P::EncryptionRequest(data)) => H::login::encryption_request(user, data).await,
        (_, P::ClientPing(data)) => H::login::client_ping(user, data).await,
        (_, P::BlockListRequest) => H::login::block_list(user).await,
        (US::InGame, P::BlockSwitchRequest(data)) => H::login::switch_block(user, data).await,
        (US::LoggingIn, P::BlockLogin(data)) => H::login::challenge_login(user, data).await,
        (US::NewUsername, P::NicknameResponse(data)) => H::login::set_username(user, data).await,
        (_, P::ClientGoodbye) => {
            user.ready_to_shutdown = true;
            user.last_ping = Instant::now();
            Ok(Action::Nothing)
        }
        (_, P::SystemInformation(..)) => Ok(Action::Nothing),
        (US::CharacterSelect, P::CreateCharacter1) => H::login::character_create1(user).await,
        (US::CharacterSelect, P::CreateCharacter2) => H::login::character_create2(user).await,
        (US::LoggingIn, P::VitaLogin(..)) => H::login::login_request(user, match_unit.1).await,
        (_, P::AllBlocksListRequest) => H::login::all_block_list(user).await,
        (_, P::ChallengeResponse(..)) => {
            user.user_data.packet_type = PacketType::NA;
            user.connection.change_packet_type(PacketType::NA);
            Ok(Action::Nothing)
        }
        (US::CharacterSelect, P::LoginHistoryRequest) => H::login::login_history(user).await,
        (US::CharacterSelect, P::CharacterUndeletionRequest(data)) => {
            H::login::undelete_request(user, data).await
        }
        (US::CharacterSelect, P::CharacterRenameRequest(data)) => {
            H::login::rename_request(user, data).await
        }
        (US::CharacterSelect, P::CharacterNewNameRequest(data)) => {
            H::login::newname_request(user, data).await
        }
        (US::CharacterSelect, P::CharacterMoveRequest(data)) => {
            H::login::move_request(user, data).await
        }

        // Friends packets
        (US::InGame, P::FriendListRequest(data)) => H::friends::get_friends(user, data).await,

        // Palette packets
        (_, P::FullPaletteInfoRequest) if state >= US::PreInGame => {
            H::palette::send_full_palette(user).await
        }
        (US::InGame, P::SetPalette(data)) => H::palette::set_palette(user_guard, data).await,
        (US::InGame, P::UpdateSubPalette(data)) => H::palette::update_subpalette(user, data).await,
        (US::InGame, P::UpdatePalette(data)) => H::palette::update_palette(user_guard, data).await,
        (US::InGame, P::SetSubPalette(data)) => H::palette::set_subpalette(user, data),
        (US::InGame, P::SetDefaultPAs(data)) => H::palette::set_default_pa(user, data).await,

        // Flag packets
        (US::InGame, P::SetFlag(data)) => H::server::set_flag(user, data).await,
        (US::InGame, P::SkitItemAddRequest(data)) => H::quest::questwork(user_guard, data).await,
        (US::InGame, P::CutsceneEnd(data)) => H::quest::cutscene_end(user_guard, data).await,

        // Settings packets
        (_, P::SettingsRequest) if state >= US::NewUsername => {
            H::settings::settings_request(user).await
        }
        (_, P::SaveSettings(data)) if state >= US::NewUsername => {
            H::settings::save_settings(user, data).await
        }

        // SA packets
        (US::InGame, P::SymbolArtClientDataRequest(data)) => {
            H::symbolart::data_request(user, data).await
        }
        (US::InGame, P::SymbolArtData(data)) => H::symbolart::add_sa(user, data).await,
        (US::InGame, P::ChangeSymbolArt(data)) => H::symbolart::change_sa(user, data).await,
        (US::InGame, P::SymbolArtListRequest) => H::symbolart::list_sa(user).await,
        (US::InGame, P::SendSymbolArt(data)) => H::symbolart::send_sa(user_guard, data).await,

        // ARKS Missions packets
        (US::InGame, P::MissionListRequest) => H::arksmission::mission_list(user).await,

        // Mission Pass packets
        (US::InGame, P::MissionPassInfoRequest) => H::missionpass::mission_pass_info(user).await,
        (US::InGame, P::MissionPassRequest) => H::missionpass::mission_pass(user).await,

        (US::InGame, P::AbandonQuestRequest) => H::party::abandon_quest(user_guard).await,

        (US::InGame, P::SalonEntryRequest) if H::salon::enabled_for(user) => H::salon::entry(user).await,

        (state, data) => {
            crate::request_trace::observe(user.user_data.id, user.conn_id, state == US::InGame, &data);
            let identity = packet_identity::identify(&data);
            if let Some(observation) = user.unhandled_packets.observe(state, identity) {
                log::warn!(
                    "unsupported_request client={} state={state:?} packet={} header={:?} occurrence={observation:?}",
                    user.user_data.id, identity.name, identity.header
                );
            }
            Ok(Action::Nothing)
        }
    }
    // Packet::SalonEntryRequest => {
    //     user.send_packet(&Packet::SalonEntryResponse(login::SalonResponse {
    //         ..Default::default()
    //     }))?;
    // }
    // Packet::SegaIDInfoRequest => {
    //     let mut dataout = vec![];
    //     for _ in 0..0x30 {
    //         dataout.push(0x42);
    //         dataout.push(0x41);
    //     }
    //     for _ in 0..0x12 {
    //         dataout.write_u32::<LittleEndian>(1)?;
    //     }
    //     user.send_packet(&Packet::Unknown((
    //         PacketHeader {
    //             id: 0x11,
    //             subid: 108,
    //             ..Default::default()
    //         },
    //         dataout,
    //     )))?;
    // }
}

impl Drop for User {
    fn drop(&mut self) {
        self.queue_disconnect();
    }
}

#[derive(PartialEq, Clone, Copy, PartialOrd, Debug)]
pub enum UserState {
    /// User is logging in, nothing is set up.
    LoggingIn,
    /// User is logged in, but no username was set, only user id is set.
    NewUsername,
    /// User is logged in, account stuff is set up, but no character info.
    CharacterSelect,
    /// User has selected the character, but map and party aren't set up yet.
    PreInGame,
    /// User is in the game, character, map, party are set up.
    InGame,
}

impl Display for UserState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let str = match self {
            UserState::LoggingIn => "Logging in",
            UserState::NewUsername => "Inputting username",
            UserState::CharacterSelect => "Selecting a character",
            UserState::PreInGame => "Waiting for client to load",
            UserState::InGame => "Playing",
        };
        f.write_str(str)
    }
}

#[cfg(test)]
mod test {
    use std::cmp::Ordering;

    use crate::user::UserState;

    #[test]
    fn test_userstate() {
        assert_eq!(
            UserState::InGame
                .partial_cmp(&UserState::CharacterSelect)
                .unwrap(),
            Ordering::Greater
        );
        assert_eq!(
            UserState::CharacterSelect
                .partial_cmp(&UserState::InGame)
                .unwrap(),
            Ordering::Less
        );
        assert!(UserState::InGame > UserState::LoggingIn);
    }
}
