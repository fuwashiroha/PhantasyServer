//! Explicit local test-account/GM evidence window; no invented replies.
use pso2packetlib::protocol::Packet;
use std::{collections::BTreeMap,time::{Duration,Instant}};

#[derive(Default)]
pub(crate) struct NativeSkillTrace {
    started:Option<Instant>,
    remaining:u8,
    counts:BTreeMap<(u8,u16),u8>,
}
impl NativeSkillTrace {
    // Account 1 is the existing local test account verified for this candidate.
    // This permits a bounded trace of that account's own incoming requests only.
    pub(crate) fn authorized(account:u32,is_gm:bool)->bool {account==1 || is_gm}
    pub(crate) fn arm(&mut self,authorized:bool,now:Instant)->Result<(),crate::Error> {
        if !authorized {return Err(crate::Error::InvalidInput("skill_trace_account_not_authorized"));}
        self.started=Some(now);self.remaining=24;self.counts.clear();Ok(())
    }
    pub(crate) fn sample(&mut self,packet:&Packet,now:Instant)->Option<serde_json::Value> {
        let elapsed=now.checked_duration_since(self.started?)?;
        if elapsed>=Duration::from_secs(60) || self.remaining==0 {return None;}
        let (key,mut value)=match packet {
            Packet::Interact(p) if p.object1.id==715 => ((4,0x14),serde_json::json!({
                "kind":"class_counter_interaction","object":715,"action":p.action.to_string()})),
            // These object requests have decoded fields but no verified purpose.
            // Preserve them as candidates, never manufacture a skill-tree reply.
            Packet::Unk0423(p) => ((4,0x23),serde_json::json!({"kind":"candidate_decoded","fields":p})),
            Packet::Unk042B(p) => ((4,0x2b),serde_json::json!({"kind":"candidate_decoded","fields":p})),
            // Candidate unknown protocol categories only; these are not claimed
            // to be skill-tree packet IDs. No login/chat/mail/friend payloads.
            Packet::Unknown((h,b)) if matches!(h.id,0x04|0x0a|0x0c|0x20|0x22|0x24) => {
                let prefix=&b[..b.len().min(2048)];
                let hex:String=prefix.iter().map(|x|format!("{x:02x}")).collect();
                ((h.id,h.subid),serde_json::json!({"kind":"candidate_unknown","flags":h.flag.bits(),
                    "original_len":b.len(),"truncated":b.len()>prefix.len(),"payload_hex":hex}))
            },
            Packet::Unknown((h,b)) if !matches!(h.id,0x07|0x11|0x18|0x1a|0x1c|0x2f) => {
                ((h.id,h.subid),serde_json::json!({"kind":"metadata_only","original_len":b.len()}))
            },
            _=>return None,
        };
        let limit=if key==(4,0x14) {12} else {3};
        let count=self.counts.entry(key).or_default();if *count>=limit {return None;}
        *count+=1;self.remaining-=1;
        value["header"]=serde_json::json!([key.0,key.1]);value["elapsed_ms"]=serde_json::json!(elapsed.as_millis());
        Some(value)
    }
    pub(crate) fn observe(&mut self,packet:&Packet) {
        if let Some(sample)=self.sample(packet,Instant::now()) {log::warn!("native_skill_trace {sample}");}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pso2packetlib::protocol::{PacketHeader,objects::InteractPacket};
    fn unknown(id:u8,sub:u16)->Packet {Packet::Unknown((PacketHeader::new(id,sub,Default::default()),vec![0xab;2100]))}
    #[test]
    fn local_native_skill_trace_is_opt_in_authorized_bounded_and_excludes_sensitive_categories() {
        assert!(NativeSkillTrace::authorized(1,false));assert!(NativeSkillTrace::authorized(2,true));assert!(!NativeSkillTrace::authorized(2,false));
        let now=Instant::now();let mut t=NativeSkillTrace::default();assert!(t.sample(&unknown(0x20,0),now).is_none());
        assert!(t.arm(false,now).is_err());t.arm(true,now).unwrap();
        for id in [0x07,0x11,0x18,0x1a,0x1c,0x2f] {assert!(t.sample(&unknown(id,0),now).is_none());}
        let sample=t.sample(&unknown(0x20,0),now).unwrap();assert_eq!(sample["payload_hex"].as_str().unwrap().len(),4096);assert_eq!(sample["truncated"],true);
        assert!(t.sample(&unknown(0x20,0),now).is_some());assert!(t.sample(&unknown(0x20,0),now).is_some());assert!(t.sample(&unknown(0x20,0),now).is_none());
        let meta=t.sample(&unknown(0x0f,0),now).unwrap();assert!(meta.get("payload_hex").is_none());
        for sub in 1..50 {t.sample(&unknown(0x20,sub),now);}
        assert_eq!(t.remaining,0);assert!(t.sample(&unknown(0x20,90),now).is_none());
        t.arm(true,now).unwrap();assert!(t.sample(&unknown(0x20,0),now+Duration::from_secs(60)).is_none());
    }
    #[test]
    fn local_native_skill_trace_records_only_class_counter_interactions() {
        let now=Instant::now();let mut t=NativeSkillTrace::default();t.arm(true,now).unwrap();
        let mut p=InteractPacket{action:"GetList".into(),..Default::default()};p.object1.id=713;
        assert!(t.sample(&Packet::Interact(p.clone()),now).is_none());p.object1.id=715;
        let s=t.sample(&Packet::Interact(p),now).unwrap();assert_eq!(s["action"],"GetList");
    }
    #[test]
    fn local_native_skill_trace_keeps_candidate_object_fields_without_claiming_semantics() {
        let now=Instant::now();let mut t=NativeSkillTrace::default();t.arm(true,now).unwrap();
        let p=Packet::Unk0423(pso2packetlib::protocol::objects::Unk0423Packet{unk4:123,..Default::default()});
        let s=t.sample(&p,now).unwrap();assert_eq!(s["header"],serde_json::json!([4,0x23]));assert_eq!(s["fields"]["unk4"],123);
        let s=t.sample(&Packet::Unk042B(Default::default()),now).unwrap();assert_eq!(s["kind"],"candidate_decoded");
        assert!(t.sample(&unknown(4,0xff),now).unwrap().get("payload_hex").is_some());
    }
}
