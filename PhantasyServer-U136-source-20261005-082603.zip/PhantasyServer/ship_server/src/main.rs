#[tokio::main]
async fn main() -> std::process::ExitCode {
    match pso2ship_server::run().await {
        Ok(_) => std::process::ExitCode::SUCCESS,
        Err(e) => { eprintln!("Server error: {e}"); std::process::ExitCode::FAILURE },
    }
}
