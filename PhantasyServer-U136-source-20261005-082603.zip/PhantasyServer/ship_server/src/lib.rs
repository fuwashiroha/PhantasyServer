#![deny(clippy::undocumented_unsafe_blocks)]
#![warn(clippy::future_not_send)]
#![warn(clippy::missing_const_for_fn)]
#![allow(clippy::await_holding_lock)]
#![allow(dead_code)]

mod battle_stats;
mod block;
mod inventory;
mod invites;
mod map;
mod master_conn;
mod mutex;
mod palette;
mod pa_powers;
mod hero_skills;
mod hero_passives;
mod hero_time;
mod native_skill_trace;
mod native_hero_tree;
mod native_phantom_tree;
mod native_class_tree;
mod class_passives;
mod phantom_passives;
mod phantom_combat;
mod etoile_combat;
mod luster_combat;
mod hunter_combat;
mod ranger_combat;
mod other_class_combat;
mod techniques;
mod phantom_time;
mod phantom_counter;
mod hero_survival;
mod hero_combat_trace;
mod party;
mod quests;
mod quest_completion;
mod damage_measurement;
mod custom_rockbear;
mod request_trace;
mod settings;
mod sql;
mod user;

use data_structs::{
    SerDeFile, ServerData,
    master_ship::{self, ShipInfo},
};
use master_conn::MasterConnection;
use mutex::{Mutex, RwLock};
use pso2packetlib::{
    Connection, PrivateKey, PublicKey,
    protocol::{Packet, PacketType, login},
};
use quests::Quests;
use rand::distr::{Distribution, Uniform};
use rsa::traits::{PrivateKeyParts, PublicKeyParts};
use settings::Settings;
use std::{
    io,
    net::Ipv4Addr,
    sync::{Arc, atomic::AtomicU32},
};
use thiserror::Error;
use user::*;

#[derive(Debug, Error)]
pub enum Error {
    #[error("Invalid input in fn {0}")]
    InvalidInput(&'static str),
    #[error("Combat state is busy; reward was not committed")]
    CombatBusy,
    #[error("Invalid password")]
    InvalidPassword,
    #[error("No user found")]
    NoUser,
    #[error("No user {0} found in mapset {1}")]
    NoUserInMap(u32, String),
    #[error("Mapid {0} not found in mapset {1}")]
    NoMapInMapSet(u32, String),
    #[error("Master ship returned error: {0}")]
    MSError(String),
    #[error("Master ship sent unexpected data")]
    MSUnexpected,
    #[error("Invalid master ship PSK")]
    MSInvalidPSK,
    #[error("Master server didn't respond")]
    MSNoResponse,
    #[error("User sent unexpected packet while being in state: {0}")]
    UserInvalidState(UserState),
    #[error("Map with name {0} doesn't exist")]
    NoMapFound(String),
    #[error("Item ({0}, {1}) not found in item attributes")]
    NoItemInAttrs(u16, u16),
    #[error("No clothes with model {0} found in item attributes")]
    NoClothes(u16),
    #[error("No enemy data for {0} found")]
    NoEnemyData(String),
    #[error("No {2} level data for enemy {0} at level {1}")]
    NoEnemyLevelData(String, u32, &'static str),
    #[error("Invalid map data: {0}")]
    InvalidMapData(String),
    #[error("No damage ID {0} found")]
    NoDamageInfo(u32),
    #[error("No PA potency for ID {0} at level {1}")]
    NoPhotonArtInfo(u32, u8),
    #[error("Unknown enemy hitbox {0}:{1}")]
    NoHitboxInfo(String, u32),
    #[error("No ship data available")]
    NoShipData,

    // passthrough errors
    #[error("SQL error: {0}")]
    SqlError(#[from] sqlx::Error),
    #[error("IO error: {0}")]
    IOError(#[from] std::io::Error),
    #[error("JSON error: {0}")]
    SerdeError(#[from] serde_json::Error),
    #[error(transparent)]
    DataError(#[from] data_structs::Error),
    #[error("Lua error: {0}")]
    LuaError(#[from] mlua::Error),
    #[error("MP Serialization error: {0}")]
    RMPEncodeError(#[from] rmp_serde::encode::Error),
    #[error("MP Deserialization error: {0}")]
    RMPDecodeError(#[from] rmp_serde::decode::Error),
    #[error("TOML Serialization error: {0}")]
    TomlSerError(#[from] toml::ser::Error),
    #[error("TOML Deserialization error: {0}")]
    TomlDeError(#[from] toml::de::Error),
    #[error("RSA error: {0}")]
    RSAError(#[from] rsa::Error),
    #[error("PKCS8 error: {0}")]
    PKCS8Error(#[from] rsa::pkcs8::Error),
    #[error("Client connection error: {0}")]
    ConnError(#[from] pso2packetlib::connection::ConnectionError),
    #[error("Packet error: {0}")]
    PacketError(#[from] pso2packetlib::protocol::PacketError),
    #[error("Task join error: {0}")]
    JoinError(#[from] tokio::task::JoinError),
}

#[derive(Clone)]
struct BlockInfo {
    id: u32,
    name: String,
    ip: Ipv4Addr,
    port: u16,
    max_players: u32,
    players: u32,
    lobby_map: String,
    server_data: Arc<ServerData>,
    quests: Arc<Quests>,
}

struct BlockData {
    sql: Arc<sql::Sql>,
    block_id: u32,
    block_name: String,
    blocks: Arc<RwLock<Vec<BlockInfo>>>,
    lobby: Arc<Mutex<map::Map>>,
    key: PrivateKey,
    latest_mapid: AtomicU32,
    latest_partyid: AtomicU32,
    server_data: Arc<ServerData>,
    quests: Arc<Quests>,
    clients: Mutex<Vec<(usize, Arc<Mutex<User>>)>>,
}

#[derive(Default, Clone)]
enum Action {
    #[default]
    Nothing,
    Disconnect,
}

// feel free to suggest log level changes
pub async fn run() -> Result<(), Error> {
    let settings = Settings::load("ship.toml").await?;
    // setup logging
    {
        let _ = std::fs::create_dir_all(&settings.log_dir);
        let mut path = std::path::PathBuf::from(&settings.log_dir);
        path.push(format!(
            "ship_{}.log",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_secs()
        ));
        let log_file = std::fs::File::create(path)?;

        use simplelog::*;
        CombinedLogger::init(vec![
            TermLogger::new(
                settings.console_log_level,
                Config::default(),
                TerminalMode::Mixed,
                ColorChoice::Auto,
            ),
            WriteLogger::new(settings.file_log_level, Config::default(), log_file),
        ])
        .unwrap();
    }

    request_trace::configure(settings.request_trace.as_ref())?;
    user::handlers::salon::configure(settings.salon_entry_experiment_account)?;
    user::handlers::server::configure_death_experiment(settings.death_campship_experiment_account)?;
    log::info!("Starting server...");
    let key = settings.load_key()?;
    let server_statuses = Arc::new(RwLock::new(Vec::<BlockInfo>::new()));

    let master_ip = if let Some(ip) = settings.master_ship.as_ref() {
        tokio::net::lookup_host(ip)
            .await?
            .next()
            .expect("No IPs found for master ship")
    } else {
        log::warn!("No master ship IP provided, discovering...");
        data_structs::master_ship::try_discover().await?
    };
    log::info!("Connecting to master ship...");
    let mut master_conn = MasterConnection::new(
        master_ip,
        settings.master_ship_psk.as_bytes(),
        &settings.hostkeys_file,
    )
    .await?;
    log::info!("Connected to master ship");
    let total_max_players = settings.blocks.iter().map(|b| b.max_players).sum();
    log::info!("Registering ship");
    for id in settings.min_ship_id..=settings.max_ship_id {
        log::debug!("Requested ship id: {id}");
        let resp = MasterConnection::register_ship(
            &master_conn,
            ShipInfo {
                ip: Ipv4Addr::UNSPECIFIED,
                id,
                port: settings.balance_port,
                max_players: total_max_players,
                name: settings.server_name.clone(),
                status: pso2packetlib::protocol::login::ShipStatus::Online,
                key: master_ship::KeyInfo {
                    n: key.n().to_le_bytes().to_vec(),
                    e: key.e().to_le_bytes().to_vec(),
                },
            },
        )
        .await?;
        match resp {
            master_ship::RegisterShipResult::Success => break,
            master_ship::RegisterShipResult::AlreadyTaken => {
                if id < settings.max_ship_id {
                    continue;
                }
                log::error!("No stots left");
                return Ok(());
            }
        }
    }
    log::info!("Registed ship");
    let mut notif_channel = master_conn.take_notif_ch().unwrap();

    let mut server_data = Arc::new(if let Some(data_path) = settings.data_file {
        log::info!("Loading server data...");
        ServerData::load_from_mp_comp(data_path)?
    } else {
        log::warn!("No server data file provided, receiving from master ship...");
        match master_conn
            .run_action(master_ship::MasterShipAction::ServerDataRequest)
            .await?
        {
            master_ship::MasterShipAction::ServerDataResponse(server_data_result) => {
                match server_data_result {
                    master_ship::ServerDataResult::Ok(server_data) => *server_data,
                    master_ship::ServerDataResult::NotAvailable => {
                        log::error!("No data available from master ship!");
                        return Err(Error::NoShipData);
                    }
                }
            }
            master_ship::MasterShipAction::Error(e) => return Err(Error::MSError(e)),
            _ => return Err(Error::MSUnexpected),
        }
    });
    log::info!("Loaded server data");
    let quests = Arc::new(Quests::load(std::mem::take(
        &mut Arc::get_mut(&mut server_data).unwrap().quests,
    )));

    let sql = Arc::new(sql::Sql::new(&settings.db_name, master_conn).await?);
    let balance = make_block_balance(server_statuses.clone(), settings.balance_port).await?;
    let (shutdown, shutdown_rx) = tokio::sync::watch::channel(false);
    let mut blocks = vec![];
    let mut ports = 13001;
    let mut blockstatus_lock = server_statuses.write().await;
    log::info!("Starting blocks...");
    for (i, block) in settings.blocks.into_iter().enumerate() {
        let port = block.port.unwrap_or(ports);
        ports += 1;
        let new_block = BlockInfo {
            id: i as u32 + 1,
            name: block.name.clone(),
            ip: Ipv4Addr::UNSPECIFIED,
            port,
            max_players: block.max_players,
            players: 0,
            lobby_map: block.lobby_map,
            server_data: server_data.clone(),
            quests: quests.clone(),
        };
        blockstatus_lock.push(new_block.clone());
        let server_statuses = server_statuses.clone();
        let sql = sql.clone();
        let primes = key.primes();
        let key = PrivateKey::Params {
            n: key.n().to_le_bytes().to_vec(),
            e: key.e().to_le_bytes().to_vec(),
            d: key.d().to_le_bytes().to_vec(),
            p: primes[0].to_le_bytes().to_vec(),
            q: primes[1].to_le_bytes().to_vec(),
        };
        log::debug!("Started block {}", block.name);
        let stop = shutdown_rx.clone();
        blocks.push(tokio::spawn(async move {
            match block::init_block(server_statuses, new_block, sql, key, stop).await {
                Ok(_) => {}
                Err(e) => log::error!("Block \"{}\" failed: {e}", block.name),
            }
        }))
    }
    drop(blockstatus_lock);

    log::info!("Server started.");
    let control = data_structs::local_control::LocalControl::create(&std::env::current_dir()?, "ship")?;
    let result = loop {
        tokio::select! {
            biased;
            _ = tokio::signal::ctrl_c() => { break Ok(()); }
            request = control.wait() => { break request.map_err(Error::from); }
            action = notif_channel.recv() => {
                match action {
                    Some(master_ship::MasterShipAction::Ping) => {
                        if let Err(e) = sql.run_action(master_ship::MasterShipAction::Pong).await { break Err(e); }
                    }
                    Some(_) => {},
                    None => { break Err(Error::MSNoResponse); }
                }
            }
        }
    };
    log::info!("Stopping connections and waiting for durable session saves...");
    let _ = shutdown.send(true);
    balance.abort();
    let _ = balance.await;
    for block in blocks {
        if let Err(e) = block.await { log::error!("Block shutdown failed: {e}"); }
    }
    sql.drain_session_saves().await?;
    result?;

    Ok(())
}

async fn make_block_balance(
    server_statuses: Arc<RwLock<Vec<BlockInfo>>>,
    port: u16,
) -> io::Result<tokio::task::JoinHandle<()>> {
    use tokio::net::TcpListener;
    let listener = TcpListener::bind(("127.0.0.1", port)).await?;
    let task = tokio::spawn(async move {
        loop {
            match listener.accept().await {
                Ok((s, _)) => {
                    let _ = send_block_balance(s, server_statuses.clone()).await;
                }
                Err(e) => {
                    log::warn!("Failed to accept block balance connection: {}", e);
                    return;
                }
            }
        }
    });
    Ok(task)
}

async fn send_block_balance(
    stream: tokio::net::TcpStream,
    blocks: Arc<RwLock<Vec<BlockInfo>>>,
) -> Result<(), Error> {
    stream.set_nodelay(true)?;
    let local_addr = stream.local_addr()?.ip();
    log::debug!("Block balancing {local_addr}...");
    let mut con = Connection::<Packet>::new_async(
        stream,
        PacketType::Classic,
        PrivateKey::None,
        PublicKey::None,
    );
    let mut blocks = blocks.write().await;
    let server_count = blocks.len() as u32;
    for block in blocks.iter_mut() {
        if block.ip == Ipv4Addr::UNSPECIFIED {
            if let std::net::IpAddr::V4(addr) = local_addr {
                block.ip = addr
            }
        }
    }
    let block = Uniform::new(0, server_count)
        .unwrap()
        .sample(&mut rand::rng());
    let block = &mut blocks[block as usize];
    let packet = login::BlockBalancePacket {
        ip: block.ip,
        port: block.port,
        blockname: block.name.clone().into(),
        ..Default::default()
    };
    con.write_packet_async(&Packet::BlockBalance(packet))
        .await?;
    Ok(())
}

#[cfg(test)]
mod local_gameplay_tests;

mod rare_mastery;

mod weapon_enhancement;

mod weapon_element;
mod element_weak;
