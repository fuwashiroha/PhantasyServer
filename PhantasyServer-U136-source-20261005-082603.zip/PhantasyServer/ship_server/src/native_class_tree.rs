//! Native Classic trees for the eleven classes outside the existing Hr/Ph saves.
//! SKT coordinates, prerequisites and nibble positions are pinned client data.
use crate::{Error, native_hero_tree::Node};
use pso2packetlib::protocol::models::character::{ClassInfo, ClassLevel};
use std::{collections::BTreeMap, sync::OnceLock};

#[derive(serde::Deserialize)]
pub(crate) struct Definition { pub slot:u8, pub title:String, pub nodes:Vec<Node> }
#[derive(serde::Deserialize)]
struct Catalogue { classes:Vec<Definition> }
pub(crate) fn definitions()-> &'static [Definition] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-class-native-trees.json"))
        .expect("pinned Classic SKT catalogue")).classes
}
pub(crate) fn definition(slot:u8)->Result<&'static Definition,Error> {
    definitions().iter().find(|d|d.slot==slot && !matches!(slot,11|12))
        .ok_or(Error::InvalidInput("native_class_tree_slot"))
}
pub(crate) fn class_level(c:&ClassInfo,slot:u8)->Result<&ClassLevel,Error> {
    Ok(match slot {
        0=>&c.hunter_info,1=>&c.ranger_info,2=>&c.force_info,3=>&c.fighter_info,
        4=>&c.gunner_info,5=>&c.techer_info,6=>&c.braver_info,7=>&c.bouncer_info,
        9=>&c.summoner_info,11=>&c.hero_info,12=>&c.phantom_info,
        13=>&c.etole_info,14=>&c.luster_info,
        _=>return Err(Error::InvalidInput("native_class_tree_class")),
    })
}
#[derive(Debug,Clone,Default,PartialEq,serde::Serialize,serde::Deserialize)]
#[serde(default)]
pub(crate) struct ClassTree { pub name:String, pub ranks:BTreeMap<String,u8> }
impl ClassTree {
    pub(crate) fn rank(&self,name:&str)->u8 {self.ranks.get(name).copied().unwrap_or(0)}
    fn parent_met(&self,node:&Node)->bool {
        node.parent.as_ref().is_none_or(|n|self.rank(n)>=node.parent_rank)
    }
    pub(crate) fn at_level(&self,slot:u8,level:u16)->Result<Self,Error> {
        let d=definition(slot)?;let mut tree=self.clone();
        if tree.name.is_empty(){tree.name=format!("{} 1",d.title);}
        for node in &d.nodes {
            if node.initial && level>=node.minimum_level && tree.parent_met(node) {
                tree.ranks.insert(node.name.clone(),1);
            }
        }
        Ok(tree)
    }
    pub(crate) fn spent(&self,slot:u8)->Result<u16,Error> {
        Ok(definition(slot)?.nodes.iter().map(|n|u16::from(self.rank(&n.name))*u16::from(n.cost)).sum())
    }
    pub(crate) fn validate(&self,slot:u8,level:u16,total_sp:u16)->Result<(),Error> {
        let d=definition(slot)?;
        for (name,rank) in &self.ranks {
            let node=d.nodes.iter().find(|n|&n.name==name).ok_or(Error::InvalidInput("native_class_unknown_node"))?;
            if *rank>node.max_rank || (*rank>0 && (level<node.minimum_level || !self.parent_met(node))) {
                return Err(Error::InvalidInput("native_class_rank_gate"));
            }
        }
        let spent=self.spent(slot)?;
        if spent>total_sp || spent>i16::MAX as u16 {return Err(Error::InvalidInput("native_class_sp"));}
        Ok(())
    }
    pub(crate) fn learn(&self,slot:u8,x:u8,y:u8,amount:u8,level:u16,total_sp:u16)->Result<Self,Error> {
        let mut tree=self.at_level(slot,level)?;tree.validate(slot,level,total_sp)?;
        let node=definition(slot)?.nodes.iter().find(|n|n.x==x && n.y==y)
            .ok_or(Error::InvalidInput("native_class_coordinate"))?;
        if node.initial || amount==0 {return Err(Error::InvalidInput("native_class_not_allocatable"));}
        let rank=tree.rank(&node.name).checked_add(amount).ok_or(Error::InvalidInput("native_class_rank_overflow"))?;
        tree.ranks.insert(node.name.clone(),rank);tree.validate(slot,level,total_sp)?;
        tree.at_level(slot,level)
    }
    pub(crate) fn entry(&self,slot:u8,level:u16)->Result<[u8;204],Error> {
        let tree=self.at_level(slot,level)?;let mut data=[0;204];
        data[0]=slot;data[4]=slot;data[5]=3;
        data[6..8].copy_from_slice(&tree.spent(slot)?.to_le_bytes());
        for (i,c) in tree.name.encode_utf16().take(31).enumerate(){data[8+i*2..10+i*2].copy_from_slice(&c.to_le_bytes());}
        for n in &definition(slot)?.nodes {data[4+n.rank_byte]|=(tree.rank(&n.name)&15)<<n.rank_shift;}
        Ok(data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_class_tree_catalogue_has_distinct_class_coordinates_and_wire_nibbles() {
        assert_eq!(definitions().len(),13);assert_eq!(definitions().iter().map(|d|d.nodes.len()).sum::<usize>(),619);
        for d in definitions() {
            let mut coords=std::collections::BTreeSet::new();let mut nibbles=coords.clone();
            for n in &d.nodes {
                assert!(coords.insert((n.x as usize,n.y)));assert!(nibbles.insert((n.rank_byte,n.rank_shift)));
                assert!(n.max_rank<=15 && n.rank_byte>=0x44 && n.rank_byte+4<204);
                assert!(matches!(n.rank_shift,0|4));
                if let Some(parent)=&n.parent {assert!(d.nodes.iter().any(|p|&p.name==parent && p.max_rank>=n.parent_rank));}
            }
        }
        for slot in [8,10,11,12,255] {assert!(definition(slot).is_err());}
    }
    #[test]
    fn local_class_tree_all_eleven_classes_enforce_sp_rank_and_free_skill_gates() {
        for d in definitions().iter().filter(|d|!matches!(d.slot,11|12)) {
            let t=ClassTree::default().at_level(d.slot,100).unwrap();
            assert_eq!(t.spent(d.slot).unwrap(),0);
            let n=d.nodes.iter().find(|n|!n.initial && n.cost>0 && t.parent_met(n)).unwrap();
            assert!(t.learn(d.slot,n.x,n.y,1,100,0).is_err());
            let paid=t.learn(d.slot,n.x,n.y,n.max_rank,100,1000).unwrap();
            assert!(paid.learn(d.slot,n.x,n.y,1,100,1000).is_err());
            assert!(paid.validate(d.slot,100,0).is_err());
            assert!(t.learn(d.slot,255,255,1,100,1000).is_err());
            for n in d.nodes.iter().filter(|n|!n.initial && n.cost==0 && t.parent_met(n)) {
                assert_eq!(t.rank(&n.name),0);
                let free=t.learn(d.slot,n.x,n.y,1,100,0).unwrap();assert_eq!(free.rank(&n.name),1);
                assert_eq!(free.spent(d.slot).unwrap(),0);
                if n.minimum_level>0 {assert!(t.learn(d.slot,n.x,n.y,1,n.minimum_level-1,1000).is_err());}
            }
            let b=paid.entry(d.slot,100).unwrap();assert_eq!(b[0],d.slot);assert_eq!(b[4],d.slot);
            for n in &d.nodes {assert_eq!((b[4+n.rank_byte]>>n.rank_shift)&15,paid.rank(&n.name));}
        }
    }
    #[test]
    fn local_class_tree_missing_parent_and_unknown_skills_are_rejected_atomically() {
        for d in definitions().iter().filter(|d|!matches!(d.slot,11|12)) {
            let t=ClassTree::default().at_level(d.slot,100).unwrap();
            for n in d.nodes.iter().filter(|n|!n.initial && !t.parent_met(n)) {
                assert!(t.learn(d.slot,n.x,n.y,1,100,1000).is_err());assert_eq!(t.rank(&n.name),0);
            }
            let mut bad=t.clone();bad.ranks.insert("not_a_native_skill".into(),1);
            assert!(bad.validate(d.slot,100,1000).is_err());
        }
    }
    #[test]
    fn local_class_tree_old_eleven_field_snapshot_and_new_map_roundtrip() {
        let mut c=crate::sql::CharData::default();
        c.native_hero_tree=Some(crate::native_hero_tree::HeroTree::default().learn(1,2,3,85,85).unwrap());
        c.native_phantom_tree=Some(crate::native_phantom_tree::PhantomTree::default().learn(0,0,1,85,85).unwrap());
        let old=rmp_serde::to_vec(&(&c.character,&c.inventory,&c.palette,&c.flags,&c.unlocked_quests,
            &c.unlocked_quests_notif,&c.play_time,&c.quest_meseta_receipts,&c.hero_test_skills,&c.native_hero_tree,&c.native_phantom_tree)).unwrap();
        let mut next:crate::sql::CharData=rmp_serde::from_slice(&old).unwrap();assert!(next.native_class_trees.is_empty());
        for d in definitions().iter().filter(|d|!matches!(d.slot,11|12)) {
            next.native_class_trees.insert(d.slot,ClassTree::default().at_level(d.slot,85).unwrap());
        }
        let saved:crate::sql::CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&next).unwrap()).unwrap();
        assert_eq!(saved.native_class_trees,next.native_class_trees);
        assert_eq!(saved.native_hero_tree,c.native_hero_tree);assert_eq!(saved.native_phantom_tree,c.native_phantom_tree);
    }
}
