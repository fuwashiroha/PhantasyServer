//! U098: observed owner self-effect request, not an enemy damage request.
//! 34111427 = WpnmanTimeBuff; original native descriptor 111046, kind 62.
//! Duration/recast are pinned by classic-hero-skill-catalogue.json (30/120 s).
//! Gear validation and hit-based attack growth remain incomplete.
use std::time::{Duration,Instant};
use pso2packetlib::protocol::{Packet,ObjectHeader,ObjectType,objects::{Unk0424Packet,Unk0425Packet},playerstatus::DealDamagePacket};

#[derive(Default)]
pub(crate) struct HeroTime { started:Option<Instant>, removed:bool }
impl HeroTime {
    // Explicitly remove the active effect when time is exhausted. Client gear
    // countdown alone does not acknowledge/remove the server-applied buff.
    pub(crate) fn expire(&mut self,owner:ObjectHeader,now:Instant)->Option<Packet> {
        if self.removed || !self.started.is_some_and(|t|now.saturating_duration_since(t)>=Duration::from_secs(30)) {return None;}
        self.removed=true;
        Some(Packet::Unk0425(Unk0425Packet{unk1:owner,unk2:owner,unk3:111046,..Default::default()}))
    }
    pub(crate) fn handle(&mut self,owner:ObjectHeader,learned:bool,p:&DealDamagePacket,now:Instant)->Option<Packet> {
        if !learned || owner.entity_type!=ObjectType::Player || p.inflicter!=owner || p.target!=owner {return None;}
        match p.attack_id {
            34111427 if p.hitbox_id==u32::MAX => {
                if self.started.is_some_and(|t|now.saturating_duration_since(t)<Duration::from_secs(120)) {return None;}
                self.started=Some(now);self.removed=false;
                let mut tail=[0;12];tail[..4].copy_from_slice(&30f32.to_le_bytes());
                tail[4..8].copy_from_slice(&1u32.to_le_bytes());tail[8..].copy_from_slice(&4u32.to_le_bytes());
                Some(Packet::Unk0424(Unk0424Packet{unk1:owner,unk2:owner,unk3:owner,unk4:111046,unk5:u32::MAX,unk6:tail,unk7:[0;12]}))
            },
            // Original SKI: RemoveOrder (kind 7) includes Remove (kind 17),
            // which names WpnmanTimeBuff. U099 client trace reports hitbox 0,
            // unlike activation (u32::MAX). Do not reject this real removal.
            2535986814 | 1892987789 if matches!(p.hitbox_id,0|u32::MAX) && self.started.is_some() && !self.removed => {
                self.removed=true;
                Some(Packet::Unk0425(Unk0425Packet{unk1:owner,unk2:owner,unk3:111046,..Default::default()}))
            },
            _=>None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn sample()->(ObjectHeader,DealDamagePacket) {
        let h=ObjectHeader{id:1,entity_type:ObjectType::Player,..Default::default()};
        (h,DealDamagePacket{inflicter:h,target:h,attack_id:34111427,hitbox_id:u32::MAX,..Default::default()})
    }
    #[test]
    fn local_hero_time_owner_learned_request_has_bounded_duration_and_recast() {
        let (h,p)=sample();let now=Instant::now();let mut s=HeroTime::default();
        assert!(s.handle(h,false,&p,now).is_none());
        let Packet::Unk0424(a)=s.handle(h,true,&p,now).unwrap() else{panic!()};
        assert_eq!(a.unk4,111046);assert_eq!(f32::from_le_bytes(a.unk6[..4].try_into().unwrap()),30.0);
        for sec in [0,29,30,119] {assert!(s.handle(h,true,&p,now+Duration::from_secs(sec)).is_none());}
        assert!(s.handle(h,true,&p,now+Duration::from_secs(120)).is_some());
    }
    #[test]
    fn local_hero_time_rejects_foreign_targets_and_unknown_effects_without_consuming_cooldown() {
        let (h,p)=sample();let now=Instant::now();let mut s=HeroTime::default();
        for field in 0..4 {
            let mut bad=p.clone();match field {0=>bad.inflicter.id=2,1=>bad.target.id=2,2=>bad.attack_id=999,_=>bad.hitbox_id=0};
            assert!(s.handle(h,true,&bad,now).is_none());assert!(s.started.is_none());
        }
        assert!(s.handle(h,true,&p,now).is_some());
        let mut remove=p.clone();remove.attack_id=2535986814;remove.hitbox_id=0;
        assert!(matches!(s.handle(h,true,&remove,now),Some(Packet::Unk0425(p)) if p.unk3==111046));
        assert!(s.handle(h,true,&remove,now).is_none());
        assert!(s.handle(h,true,&p,now).is_none());
    }
}

#[cfg(test)]
mod expiry_tests {
    use super::*;
    #[test]
    fn local_hero_time_expiry_clears_once_without_resetting_recast() {
        let h=ObjectHeader{id:7,entity_type:ObjectType::Player,..Default::default()};
        let p=DealDamagePacket{inflicter:h,target:h,attack_id:34111427,hitbox_id:u32::MAX,..Default::default()};
        let now=Instant::now();let mut s=HeroTime::default();
        assert!(s.expire(h,now).is_none());s.handle(h,true,&p,now).unwrap();
        assert!(s.expire(h,now+Duration::from_millis(29999)).is_none());
        assert!(matches!(s.expire(h,now+Duration::from_secs(30)),Some(Packet::Unk0425(p)) if p.unk3==111046 && p.unk1==h && p.unk2==h));
        assert!(s.expire(h,now+Duration::from_secs(31)).is_none());
        assert!(s.handle(h,true,&p,now+Duration::from_secs(119)).is_none());
        assert!(s.handle(h,true,&p,now+Duration::from_secs(120)).is_some());
        let mut end=p.clone();end.attack_id=1892987789;
        assert!(matches!(s.handle(h,true,&end,now+Duration::from_secs(125)),Some(Packet::Unk0425(_))));
        assert!(s.expire(h,now+Duration::from_secs(150)).is_none());
    }
}
