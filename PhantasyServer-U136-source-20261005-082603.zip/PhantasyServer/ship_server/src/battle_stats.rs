use crate::{Error, User, sql::CharData};
use data_structs::{ServerData, stats::EnemyHitbox};
use pso2packetlib::protocol::{
    models::{Position, character::Class},
    objects::{DamageReceivePacket, EnemyKilledPacket},
    playerstatus::DealDamagePacket,
    spawn::EnemySpawnPacket,
};
use rand::distr::{Distribution, Uniform};

#[cfg(test)]
mod local_hero_tests;
#[cfg(test)]
mod local_phantom_tests;
#[cfg(test)]
mod local_et_dualblade_tests;
#[cfg(test)]
mod local_et_skill_tests;
#[cfg(test)]
mod local_et_doublesaber_tests;
#[cfg(test)]
mod local_luster_tests;
#[cfg(test)]
mod local_luster_bonus_tests;
#[cfg(test)]
mod local_unit_tests;
#[cfg(test)]
mod local_hunter_tests;
#[cfg(test)]
mod local_ranger_tests;
#[cfg(test)]
mod local_technique_tests;
#[cfg(test)]
mod local_mastery_tests;
#[cfg(test)]
mod local_compound_tests;
#[cfg(test)]
mod local_caster_tests;
#[cfg(test)]
mod local_other_class_tests;
#[cfg(test)]
mod local_hp_skill_tests;
#[cfg(test)]
mod local_summoner_bonus_tests;
#[cfg(test)]
mod local_braver_normal_tests;
#[cfg(test)]
mod local_braver_charge_tests;
#[cfg(test)]
mod local_dagger_ground_tests;
#[cfg(test)]
mod local_rare_mastery_tests;
#[cfg(test)]
mod local_weapon_enhancement_tests;
#[cfg(test)]
mod local_weapon_element_tests;
#[cfg(test)]
mod local_ranger_weak_tests;
#[cfg(test)]
mod local_techer_element_weak_tests;
#[cfg(test)]
mod local_force_conversion_tests;
#[cfg(test)]
mod local_sub_luster_gunslash_tests;

#[derive(Debug, Clone, Default)]
pub struct PlayerStats {
    max_hp: u32,
    hp: u32,
    dex: u32,

    base_mel_pwr: u32,
    weapon_mel_pwr: u32,
    base_rng_pwr: u32,
    weapon_rng_pwr: u32,
    base_tec_pwr: u32,
    weapon_tec_pwr: u32,

    base_mel_def: u32,
    base_rng_def: u32,
    base_tec_def: u32,
    hero_skills: crate::hero_skills::HeroSkills,
    hero_weapon: bool,
    rare_mastery: bool,
    weapon_element: crate::weapon_element::WeaponElement,
    phantom_combat: crate::phantom_combat::PhantomCombat,
    etoile_combat: crate::etoile_combat::EtoileCombat,
    luster_combat: crate::luster_combat::LusterCombat,
    hunter_combat: crate::hunter_combat::HunterCombat,
    ranger_combat: crate::ranger_combat::RangerCombat,
    technique_combat: crate::techniques::TechniqueCombat,
    other_class_combat: crate::other_class_combat::OtherClassCombat,
    hero_survival: crate::hero_survival::HeroSurvival,
}

#[derive(Debug, Clone, Default)]
pub struct EnemyStats {
    name: String,
    level: u32,
    exp: u32,
    pos: Position,

    max_hp: u32,
    hp: u32,
    dex: u32,

    max_mel_pwr: u32,
    min_mel_pwr: u32,
    max_rng_pwr: u32,
    min_rng_pwr: u32,
    max_tec_pwr: u32,
    min_tec_pwr: u32,

    mel_def: u32,
    rng_def: u32,
    tec_def: u32,

    hitboxes: Vec<EnemyHitbox>,
    // Authored training only: equalize all regions, never a fallback for ordinary enemies.
    custom_uniform_target: bool,
}

pub enum BattleResult {
    Damaged {
        dmg_packet: DamageReceivePacket,
    },
    Killed {
        dmg_packet: DamageReceivePacket,
        kill_packet: EnemyKilledPacket,
        exp_amount: u32,
    },
}

impl PlayerStats {
    pub fn build(user: &User) -> Result<Self, Error> {
        let char = user.character.as_ref().ok_or(Error::InvalidInput("player_stats_character"))?;
        Self::build_for_levels(user, char.character.get_level().level1 as usize,
            if char.character.classes.sub_class == Class::Unknown { None }
            else { Some(char.character.get_sublevel().level1 as usize) })
    }

    // Compute prospective level stats without changing the character first.
    pub(crate) fn build_for_levels(user: &User, level: usize, sub_level: Option<usize>) -> Result<Self, Error> {
        let char = user.character.as_ref().ok_or(Error::InvalidInput("player_stats_character"))?;
        let server_data = &user.get_blockdata().server_data;
        let mut stats=Self::build_character_levels(server_data, char, level, sub_level)?;
        stats.hero_survival=user.get_stats().hero_survival.clone();
        Ok(stats)
    }

    // Validate prospective equipment without temporarily publishing a new
    // character. Preserve the existing equipment-update HP policy.
    pub(crate) fn prepare_equipment_update(user: &User, char: &CharData) -> Result<Self, Error> {
        let mut stats = Self::build_character_levels(&user.get_blockdata().server_data, char,
            char.character.get_level().level1 as usize,
            if char.character.classes.sub_class == Class::Unknown {None}
            else {Some(char.character.get_sublevel().level1 as usize)})?;
        stats.hp = user.get_stats().hp;
        stats.hero_survival=user.get_stats().hero_survival.clone();
        Ok(stats)
    }

    pub(crate) fn prepare_hero_update(user:&User,char:&CharData)->Result<Self,Error> {
        let mut stats=Self::prepare_equipment_update(user,char)?;
        // Test override/class transition preserves current HP, never revives;
        // lowering a test HP bonus cannot leave current HP above maximum.
        stats.hp=stats.hp.min(stats.max_hp);
        Ok(stats)
    }

    fn build_character_levels(server_data: &ServerData, char: &CharData,
        level: usize, sub_level: Option<usize>) -> Result<Self, Error> {

        let char_data = &char.character;
        let class = char_data.classes.main_class as usize;
        if char_data.classes.main_class == Class::Unknown {
            return Err(Error::InvalidInput("player_stats_class"));
        }
        let mut resulting_stats = Self::calculate_class_stats(server_data, char, class, level)?;

        if char_data.classes.sub_class != Class::Unknown {
            // Classic manual: 20% of subclass parameters, capped to main level.
            // https://pso2.jp/players/manual/pso2/preparations/class/sub/
            let class = char_data.classes.sub_class as usize;
            let level = sub_level.ok_or(Error::InvalidInput("player_stats_sublevel"))?.min(level);
            let subclass_stats = Self::calculate_class_stats(server_data, char, class, level)?;
            resulting_stats.hp += subclass_stats.hp / 5;
            resulting_stats.max_hp = resulting_stats.hp;
            resulting_stats.dex += subclass_stats.dex / 5;
            resulting_stats.base_mel_pwr += subclass_stats.base_mel_pwr / 5;
            resulting_stats.base_rng_pwr += subclass_stats.base_rng_pwr / 5;
            resulting_stats.base_tec_pwr += subclass_stats.base_tec_pwr / 5;
            resulting_stats.base_mel_def += subclass_stats.base_mel_def / 5;
            resulting_stats.base_rng_def += subclass_stats.base_rng_def / 5;
            resulting_stats.base_tec_def += subclass_stats.base_tec_def / 5;
        }

        let mut weapon_category = None;
        if let Some(equiped_item) = char.palette.get_current_item(&char.inventory)? {
            let ids = equiped_item.id;
            weapon_category = Some(ids.id as u16);
            let weapon_stats = server_data
                .item_params
                .attrs
                .weapons
                .iter()
                .find(|a| a.id == ids.id && a.subid == ids.subid)
                .cloned()
                .ok_or(Error::NoItemInAttrs(ids.id, ids.subid))?;
            resulting_stats.weapon_element=crate::weapon_element::WeaponElement::build(char,&weapon_stats)?;
            resulting_stats.rare_mastery = crate::rare_mastery::active(char, &weapon_stats)?;
            let powers=crate::weapon_enhancement::powers(&equiped_item,&weapon_stats)?;
            resulting_stats.weapon_mel_pwr=powers[0];
            resulting_stats.weapon_rng_pwr=powers[1];
            resulting_stats.weapon_tec_pwr=powers[2];
            if char_data.classes.main_class==Class::Phantom {resulting_stats.phantom_combat.weapon=ids.id as u8;}
            resulting_stats.hero_weapon = char_data.classes.main_class == Class::Hero
                && matches!(ids.id,1|10|12);
        }
        if char_data.classes.main_class == Class::Hero {
            resulting_stats.hero_skills=if let Some(tree)=&char.native_hero_tree {
                tree.validate(level as u16,char_data.classes.hero_info.level2)?;
                tree.effects(level as u16)?
            } else {
                char.hero_test_skills.validate(level as u16)?;
                char.hero_test_skills.clone()
            };
            let hp=resulting_stats.hero_skills.hp();
            let atk=resulting_stats.hero_skills.attack();
            let def=resulting_stats.hero_skills.defense();
            resulting_stats.hp+=hp;resulting_stats.max_hp+=hp;
            resulting_stats.base_mel_pwr+=atk;resulting_stats.base_rng_pwr+=atk;resulting_stats.base_tec_pwr+=atk;
            resulting_stats.base_mel_def+=def;resulting_stats.base_rng_def+=def;resulting_stats.base_tec_def+=def;
            resulting_stats.dex+=def;
        }
        if char_data.classes.main_class==Class::Phantom {
            let tree=char.native_phantom_tree.clone().unwrap_or_default().at_level(level as u16);
            tree.validate(level as u16,char_data.classes.phantom_info.level2)?;
            resulting_stats.phantom_combat.tree=Some(tree);
        }
        resulting_stats.etoile_combat = crate::etoile_combat::EtoileCombat::build(char, weapon_category)?;
        resulting_stats.luster_combat = crate::luster_combat::LusterCombat::build(char, weapon_category)?;
        resulting_stats.hunter_combat = crate::hunter_combat::HunterCombat::build(char)?;
        resulting_stats.hp += resulting_stats.hunter_combat.hp();
        resulting_stats.max_hp += resulting_stats.hunter_combat.hp();
        resulting_stats.base_mel_pwr += resulting_stats.hunter_combat.melee();
        resulting_stats.dex += resulting_stats.hunter_combat.dex();
        resulting_stats.base_mel_def += resulting_stats.hunter_combat.defense();
        resulting_stats.ranger_combat = crate::ranger_combat::RangerCombat::build(char)?;
        resulting_stats.base_rng_pwr += resulting_stats.ranger_combat.ranged();
        resulting_stats.dex += resulting_stats.ranger_combat.dex();
        resulting_stats.base_rng_def += resulting_stats.ranger_combat.defense();
        resulting_stats.technique_combat = crate::techniques::TechniqueCombat::build(char)?;
        resulting_stats.hp += resulting_stats.technique_combat.hp();
        resulting_stats.max_hp += resulting_stats.technique_combat.hp();
        resulting_stats.base_mel_pwr += resulting_stats.technique_combat.melee();
        resulting_stats.base_tec_pwr += resulting_stats.technique_combat.tech_power();
        resulting_stats.dex += resulting_stats.technique_combat.dex();
        resulting_stats.base_tec_def += resulting_stats.technique_combat.tech_defense();
        resulting_stats.other_class_combat=crate::other_class_combat::OtherClassCombat::build(char)?;
        let bonus=&resulting_stats.other_class_combat;
        resulting_stats.hp+=bonus.hp;resulting_stats.max_hp+=bonus.hp;
        resulting_stats.base_mel_pwr+=bonus.mel;resulting_stats.base_rng_pwr+=bonus.rng;resulting_stats.base_tec_pwr+=bonus.tec;
        resulting_stats.dex+=bonus.dex;resulting_stats.base_mel_def+=bonus.mel_def;resulting_stats.base_rng_def+=bonus.rng_def;resulting_stats.base_tec_def+=bonus.tec_def;
        // Equipment adds after class/subclass and learned base-stat bonuses.
        // Unit enhancement affects defenses only, with each unit rounded down.
        for item in char.inventory.equipped_units()? {
            let pso2packetlib::protocol::items::ItemType::Unit(unit) = &item.data else { unreachable!() };
            if item.id.item_type != 5 || unit.enh_level > 10 {
                return Err(Error::InvalidInput("unit_stat_identity_or_enhancement"));
            }
            let attrs = server_data.item_params.attrs.data6.iter()
                .find(|a| a.id == item.id.id && a.subid == item.id.subid)
                .ok_or(Error::NoItemInAttrs(item.id.id, item.id.subid))?;
            let percent = 100 + u32::from(unit.enh_level) * 4;
            resulting_stats.base_mel_def += u32::from(attrs.stats.mel_def) * percent / 100;
            resulting_stats.base_rng_def += u32::from(attrs.stats.rng_def) * percent / 100;
            resulting_stats.base_tec_def += u32::from(attrs.stats.tec_def) * percent / 100;
            resulting_stats.base_mel_pwr += u32::from(attrs.atk.mel_atk);
            resulting_stats.base_rng_pwr += u32::from(attrs.atk.rng_atk);
            resulting_stats.base_tec_pwr += u32::from(attrs.atk.tec_atk);
            resulting_stats.dex += u32::from(attrs.atk.dex);
            resulting_stats.max_hp += u32::from(attrs.stats.hp);
            resulting_stats.hp += u32::from(attrs.stats.hp);
        }
        Ok(resulting_stats)
    }
    fn calculate_class_stats(server_data: &ServerData, char: &CharData, class: usize, level: usize) -> Result<Self, Error> {
        let mut resulting_stats = Self::default();
        let player_stats = &server_data.player_stats;

        let stats = level.checked_sub(1)
            .and_then(|index| player_stats.stats.get(class).and_then(|rows| rows.get(index)))
            .ok_or(Error::InvalidInput("player_stats_level"))?;

        let char_data = &char.character;
        let modifier_offset = char_data.look.race as usize * 2 + char_data.look.gender as usize;
        let modifiers = player_stats.modifiers.get(modifier_offset)
            .ok_or(Error::InvalidInput("player_stats_modifier"))?;

        resulting_stats.hp = (stats.hp + (stats.hp * 0.01 * modifiers.hp as f32).floor()) as _;
        resulting_stats.max_hp = resulting_stats.hp;
        resulting_stats.dex = (stats.dex + (stats.dex * 0.01 * modifiers.dex as f32).floor()) as _;
        resulting_stats.base_mel_pwr =
            (stats.mel_pow + (stats.mel_pow * 0.01 * modifiers.mel_pow as f32).floor()) as _;
        resulting_stats.base_rng_pwr =
            (stats.rng_pow + (stats.rng_pow * 0.01 * modifiers.rng_pow as f32).floor()) as _;
        resulting_stats.base_tec_pwr =
            (stats.tec_pow + (stats.tec_pow * 0.01 * modifiers.tec_pow as f32).floor()) as _;
        resulting_stats.base_mel_def =
            (stats.mel_def + (stats.mel_def * 0.01 * modifiers.mel_def as f32).floor()) as _;
        resulting_stats.base_rng_def =
            (stats.rng_def + (stats.rng_def * 0.01 * modifiers.rng_def as f32).floor()) as _;
        resulting_stats.base_tec_def =
            (stats.tec_def + (stats.tec_def * 0.01 * modifiers.tec_def as f32).floor()) as _;

        Ok(resulting_stats)
    }
    pub fn update(player: &mut User) -> Result<(), Error> {
        let old_hp = player.get_stats().hp;
        let mut new_stats = Self::build(player)?;
        new_stats.hp = old_hp;
        *player.get_stats_mut() = new_stats;

        Ok(())
    }
    // Only H-DEATH-CAMPSHIP-01 calls this after a completed campship transfer.
    // Exact original revival HP is still unverified. Never heal a living player.
    pub(crate) fn experimental_revive_at_max_hp(&mut self) -> Result<(),Error> {
        if self.hp!=0 || self.max_hp==0 {return Err(Error::InvalidInput("experimental_revive_hp"));}
        self.hp=self.max_hp;
        Ok(())
    }
    pub const fn get_hp(&self) -> (u32, u32) {
        (self.hp, self.max_hp)
    }
    pub(crate) fn begin_hero_quest(&mut self){self.hero_survival.begin_quest();}
    pub(crate) fn end_hero_quest(&mut self){self.hero_survival.end_quest();}
    #[cfg(test)]
    pub(crate) fn local_set_current_hp(&mut self, hp: u32) {
        assert!(hp <= self.max_hp);
        self.hp = hp;
    }
    #[cfg(test)]
    pub(crate) fn local_weapon_powers(&self) -> (u32, u32, u32) {
        (self.weapon_mel_pwr, self.weapon_rng_pwr, self.weapon_tec_pwr)
    }
    pub fn damage_enemy(
        &mut self,
        enemy: &mut EnemyStats,
        srv_data: &ServerData,
        attack: DealDamagePacket,
    ) -> Result<BattleResult, Error> {
        // SKI conditional SwordShotCharge2 refers to this native skill. Do not
        // authorize the missing branch solely from a client-supplied attack ID.
        if attack.attack_id==4293352205 && (!self.hero_weapon || self.hero_skills.rank("aura")==0) {
            return Err(Error::InvalidInput("hero_aura_charge_skill_required"));
        }
        let Some(damage) = srv_data
            .attack_stats
            .iter()
            .find(|a| a.attack_id == attack.attack_id)
            .cloned()
        else {
            return Err(Error::NoDamageInfo(attack.attack_id));
        };
        let Some(hitbox) = enemy
            .hitboxes
            .iter()
            .find(|h| h.hitbox_id == attack.hitbox_id)
            .cloned()
            .or_else(|| enemy.custom_uniform_target.then(|| EnemyHitbox {
                name:"Authored uniform region".into(),hitbox_id:attack.hitbox_id,damage_mul:1.0,
                mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,
                fire_mul:1.2,ice_mul:1.2,thunder_mul:1.2,wind_mul:1.2,light_mul:1.2,dark_mul:1.2,
            }))
        else {
            return Err(Error::NoHitboxInfo(
                enemy.name.to_string(),
                attack.hitbox_id,
            ));
        };
        let (base_pwr, weapon_pwr, part_mul) = match damage.attack_type {
            data_structs::stats::AttackType::Mel => {
                (self.base_mel_pwr, self.weapon_mel_pwr, hitbox.mel_mul)
            }
            data_structs::stats::AttackType::Rng => {
                (self.base_rng_pwr, self.weapon_rng_pwr, hitbox.rng_mul)
            }
            data_structs::stats::AttackType::Tec => {
                (self.base_tec_pwr, self.weapon_tec_pwr, hitbox.tec_mul)
            }
        };
        // HP slayers add to the selected player attack stat, before target defense.
        let base_pwr=base_pwr.saturating_add(self.other_class_combat.hp_attack(self.hp,self.max_hp));
        let part_mul=if self.phantom_combat.rod_melee_region(attack.attack_id)
            || self.luster_combat.melee_region(attack.attack_id) {hitbox.mel_mul} else {part_mul};
        // Techniques use TEC attack/defense but their own elemental region,
        // not TEC region multiplied again and not the equipped weapon element.
        let tech_region=crate::techniques::region(attack.attack_id,&hitbox);
        let part_mul=tech_region.unwrap_or(part_mul);
        let def = match damage.defense_type {
            data_structs::stats::AttackType::Mel => enemy.mel_def,
            data_structs::stats::AttackType::Rng => enemy.rng_def,
            data_structs::stats::AttackType::Tec => enemy.tec_def,
        };
        self.etoile_combat.validate_attack(attack.attack_id)?;
        self.luster_combat.validate_attack(attack.attack_id)?;
        self.technique_combat.validate_attack(attack.attack_id)?;
        let total_mul = self.hero_skills.outgoing(self.hero_weapon,
            crate::hero_skills::is_normal_attack(attack.attack_id)) * hitbox.damage_mul
            * if self.hero_weapon {self.hero_skills.conditional_power(attack.attack_id)} else {1.0}
            * self.phantom_combat.multiplier(attack.attack_id)?
            * self.phantom_combat.attribute_factor(attack.attack_id,damage.attack_type.clone())
            * self.etoile_combat.multiplier(damage.attack_type.clone())
            * self.luster_combat.multiplier(damage.attack_type)
            * self.hunter_combat.outgoing()
            * self.ranger_combat.outgoing(enemy.hp,enemy.max_hp)
            * self.ranger_combat.weak_hit(attack.attack_id,hitbox.damage_mul,hitbox.rng_mul)
            * self.technique_combat.multiplier(attack.attack_id)
            * self.technique_combat.outgoing()
            * self.technique_combat.element_weak(attack.attack_id,&enemy.name,self.weapon_element)
            * self.technique_combat.element_conversion(attack.attack_id,self.weapon_element)
            * self.other_class_combat.outgoing
            * self.other_class_combat.hp_multiplier(self.hp,self.max_hp)
            * self.other_class_combat.summoner_multiplier(attack.attack_id)
            * self.other_class_combat.normal_multiplier(attack.attack_id)
            * self.other_class_combat.charged_shot_multiplier(attack.attack_id)
            * if self.rare_mastery {1.10} else {1.0};
        let min_pure_attack =
            (base_pwr as f32 + weapon_pwr as f32 * 0.9 - def as f32).clamp(1.0, f32::MAX);
        let pure_attack = (base_pwr + weapon_pwr)
            .saturating_sub(def)
            .clamp(1, u32::MAX) as f32;
        let damage_mul = match damage.damage {
            data_structs::stats::DamageType::Generic(m) => m,
            data_structs::stats::DamageType::PA((pa_id, hit_multiplier)) => {
                // The client reports individual hits. Multiply once by that
                // hit's SKI factor; do not apply the PA's full multi-hit total.
                let level = crate::pa_powers::PLAYER_PA_LEVEL;
                crate::pa_powers::power(pa_id, level)
                    .ok_or(Error::NoPhotonArtInfo(pa_id, level))? * hit_multiplier
            },
        };
        let min_weapon_attack = min_pure_attack / 5.0 * 1.05 * part_mul * damage_mul * total_mul;
        let max_weapon_attack = pure_attack / 5.0 * 1.05 * part_mul * damage_mul * total_mul;

        // Weapon element is a fixed component: no physical-region multiplier,
        // no defense subtraction and no weapon-variance sampling of this part.
        let element_damage=self.weapon_element.power(attack.attack_id,weapon_pwr,&hitbox)
            /5.0*1.05*damage_mul*total_mul;
        let min_weapon_attack=min_weapon_attack+element_damage;
        let max_weapon_attack=max_weapon_attack+element_damage;

        let mut rng = rand::rng();
        let crit_chance = Uniform::new(0, 100).unwrap().sample(&mut rng);
        // Limit the new weakness interpretation to imported Hero weapon hits.
        // Technique elemental weakness and critical UI flags remain separate.
        let hero_hit=include_str!("../testdata/classic-hero-attack-ids.json");
        static HERO_IDS:std::sync::OnceLock<Vec<u32>>=std::sync::OnceLock::new();
        let physical_weak=self.hero_weapon && HERO_IDS.get_or_init(||serde_json::from_str(hero_hit).expect("Hero attack IDs")).contains(&attack.attack_id)
            && matches!(damage.defense_type,data_structs::stats::AttackType::Mel|data_structs::stats::AttackType::Rng)
            && part_mul*hitbox.damage_mul>1.0;
        let critical=5+if physical_weak {self.hero_skills.physical_weak_critical_bonus()} else {0};
        let dmg = if crit_chance < critical || min_weapon_attack == max_weapon_attack {
            max_weapon_attack
        } else {
            Uniform::new(min_weapon_attack, max_weapon_attack)
                .unwrap()
                .sample(&mut rng)
        }
        .round() as u32;
        enemy.hp = enemy.hp.saturating_sub(dmg);
        let dmg_packet = DamageReceivePacket {
            dmg_target: attack.target,
            dmg_inflicter: attack.inflicter,
            damage_id: damage.damage_id,
            dmg_amount: dmg as _,
            new_hp: enemy.hp,
            hitbox_id: attack.hitbox_id,
            x_pos: attack.x_pos,
            y_pos: attack.y_pos,
            z_pos: attack.z_pos,
            ..Default::default()
        };
        Ok(if enemy.hp == 0 {
            let kill_packet = EnemyKilledPacket {
                receiver: dmg_packet.receiver,
                dmg_target: dmg_packet.dmg_target,
                dmg_inflicter: dmg_packet.dmg_inflicter,
                damage_id: dmg_packet.damage_id,
                dmg_amount: dmg_packet.dmg_amount,
                new_hp: dmg_packet.new_hp,
                hitbox_id: dmg_packet.hitbox_id,
                x_pos: dmg_packet.x_pos,
                y_pos: dmg_packet.y_pos,
                z_pos: dmg_packet.z_pos,
                unk1: dmg_packet.unk1,
                unk2: dmg_packet.unk3,
                unk3: dmg_packet.unk4,
                unk4: dmg_packet.unk4,
                unk5: dmg_packet.unk5,
                unk6: dmg_packet.unk6,
                unk7: dmg_packet.unk7,
            };
            BattleResult::Killed {
                dmg_packet,
                kill_packet,
                exp_amount: enemy.exp,
            }
        } else {
            BattleResult::Damaged { dmg_packet }
        })
    }
}

#[cfg(test)]
mod local_level_tests {
    use super::*;
    use data_structs::SerDeFile;

    fn data() -> ServerData {
        ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../data/com_data.mp")).unwrap()
    }

    #[test]
    fn local_level_missing_and_misaligned_records_are_errors() {
        let mut data = data();
        for level in [0, 101, u32::MAX] {
            assert!(matches!(EnemyStats::build("SoldierAnt", level, Position::default(), &data),
                Err(Error::NoEnemyLevelData(_, n, "base")) if n == level));
        }
        data.enemy_stats.enemies.get_mut("SoldierAnt").unwrap().levels.clear();
        assert!(matches!(EnemyStats::build("SoldierAnt", 1, Position::default(), &data),
            Err(Error::NoEnemyLevelData(_, 1, "enemy"))));
        data.enemy_stats.base.levels[0].level = 2;
        assert!(matches!(EnemyStats::build("SoldierAnt", 1, Position::default(), &data),
            Err(Error::NoEnemyLevelData(_, 1, "base"))));
    }

    #[test]
    fn local_level_current_corpus_all_levels_preserve_stats() {
        let data = data();
        for level in 1..=100 {
            let enemy = EnemyStats::build("SoldierAnt", level, Position::default(), &data).unwrap();
            let base = &data.enemy_stats.base.levels[level as usize - 1];
            let factor = &data.enemy_stats.enemies["SoldierAnt"].levels[level as usize - 1];
            assert_eq!(enemy.level, level);
            assert_eq!(enemy.hp, (base.hp * factor.hp).floor() as u32);
            assert_eq!(enemy.exp, (base.exp * factor.exp).floor() as u32);
        }
        assert!(matches!(EnemyStats::build("M0MissingEnemy", 1, Position::default(), &data),
            Err(Error::NoEnemyData(_))));
    }
}

impl EnemyStats {
    pub(crate) fn custom_rockbear(pos:Position)->Self {
        // HP/level/defense/DEX from saved swiki. Equal regions and no attacks
        // are explicit custom rules. Elemental damage is separate from the
        // ordinary model's listed weaknesses (fire/wind), as used by Te EWH.
        Self {name:"BigBeastA".into(),level:20,hp:400_000_000,max_hp:400_000_000,
            mel_def:100,rng_def:100,tec_def:100,dex:146,pos,custom_uniform_target:true,..Default::default()}
    }
    pub(crate) fn name(&self)->&str {&self.name}
    pub(crate) fn current_hp(&self)->u32 {self.hp}
    #[cfg(test)]
    pub(crate) fn local_current_hp(&self) -> u32 { self.hp }

    pub fn build(name: &str, level: u32, pos: Position, data: &ServerData) -> Result<Self, Error> {
        let mut resulting_stats = Self {
            name: name.to_string(),
            pos,
            ..Default::default()
        };
        let base_stats = &data.enemy_stats.base;
        let enemy_stats = &data
            .enemy_stats
            .enemies
            .get(name)
            .ok_or(Error::NoEnemyData(name.to_string()))?;
        resulting_stats.hitboxes.clone_from(&enemy_stats.hitboxes);
        // Compiled data can predate compiler validation. Never index an absent
        // level or substitute another level's unverified parameters.
        let index = level.checked_sub(1).map(|v| v as usize);
        let base_level_stats = index
            .and_then(|i| base_stats.levels.get(i))
            .filter(|stats| stats.level == level)
            .ok_or_else(|| Error::NoEnemyLevelData(name.to_string(), level, "base"))?;
        let level_stats = index
            .and_then(|i| enemy_stats.levels.get(i))
            .filter(|stats| stats.level == level)
            .ok_or_else(|| Error::NoEnemyLevelData(name.to_string(), level, "enemy"))?;

        resulting_stats.level = level_stats.level;
        resulting_stats.exp = (base_level_stats.exp * level_stats.exp).floor() as _;
        resulting_stats.max_hp = (base_level_stats.hp * level_stats.hp).floor() as _;
        resulting_stats.hp = resulting_stats.max_hp;
        resulting_stats.dex = (base_level_stats.dex * level_stats.dex).floor() as _;
        resulting_stats.max_mel_pwr =
            (base_level_stats.max_mel_dmg * level_stats.max_mel_dmg).floor() as _;
        resulting_stats.min_mel_pwr =
            (base_level_stats.min_mel_dmg * level_stats.min_mel_dmg).floor() as _;
        resulting_stats.max_rng_pwr =
            (base_level_stats.max_rng_dmg * level_stats.max_rng_dmg).floor() as _;
        resulting_stats.min_rng_pwr =
            (base_level_stats.min_rng_dmg * level_stats.min_rng_dmg).floor() as _;
        resulting_stats.max_tec_pwr =
            (base_level_stats.max_tec_dmg * level_stats.max_tec_dmg).floor() as _;
        resulting_stats.min_tec_pwr =
            (base_level_stats.min_tec_dmg * level_stats.min_tec_dmg).floor() as _;
        resulting_stats.mel_def = (base_level_stats.mel_def * level_stats.mel_def).floor() as _;
        resulting_stats.rng_def = (base_level_stats.rng_def * level_stats.rng_def).floor() as _;
        resulting_stats.tec_def = (base_level_stats.tec_def * level_stats.tec_def).floor() as _;

        Ok(resulting_stats)
    }
    pub fn create_spawn_packet(&self, id: u32) -> EnemySpawnPacket {
        EnemySpawnPacket {
            object: pso2packetlib::protocol::ObjectHeader {
                id,
                entity_type: pso2packetlib::protocol::ObjectType::Object,
                ..Default::default()
            },
            position: self.pos,
            name: self.name.to_string().into(),
            hp: self.hp,
            level: self.level,
            unk2: 2,
            unk4: 2,
            // unk5: 269877691,

            // contains emergency marker color
            // 0x505 - blue
            // 0x605 - purple
            // 0x705 - green
            // unk6: 0x405,
            // 0x1 - ??
            // 0x2 - ??
            // 0x4 - ??
            // 0x8 - ??
            // 0x10 - ??
            // 0x20 - ??
            // 0x40 - big enemy marker
            // 0x80 - hide enemy from minimap
            // 0x300 - emergency color
            // 0x400 - ??
            unk6: 0x405,
            unk7: 255,
            unk8: 65535,
            // last nonzero value - model id
            unk9: [
                0, 0, 0, 0, 0, 0, 0, 0, 0, 1062804813, 3212836864, 0,
                // H-SPAWN-NAME-01: U088 rendered Dagan despite BigBeastA.
                // The inherited fixed model slot is suspect. Clear it only
                // for the authored range; name-based fallback is unverified.
                if self.custom_uniform_target { 0 } else { 1570802465 }, 0, 0, 0,
            ],
            unk11: 1,
            unk12: 255,
            ..Default::default()
        }
    }
    pub fn damage_player(
        &mut self,
        player: &mut PlayerStats,
        srv_data: &ServerData,
        attack: DealDamagePacket,
    ) -> Result<BattleResult, Error> {
        self.damage_player_with_phantom_guard(player,srv_data,attack,false)
    }

    pub(crate) fn damage_player_with_phantom_guard(
        &mut self, player:&mut PlayerStats, srv_data:&ServerData,
        attack:DealDamagePacket, phantom_guard:bool,
    )->Result<BattleResult,Error> {
        let Some(damage) = srv_data
            .attack_stats
            .iter()
            .find(|a| a.attack_id == attack.attack_id)
            .cloned()
        else {
            return Err(Error::NoDamageInfo(attack.attack_id));
        };
        let (min_pwr, max_pwr) = match damage.attack_type {
            data_structs::stats::AttackType::Mel => (self.min_mel_pwr, self.max_mel_pwr),
            data_structs::stats::AttackType::Rng => (self.min_rng_pwr, self.max_rng_pwr),
            data_structs::stats::AttackType::Tec => (self.min_tec_pwr, self.max_tec_pwr),
        };
        let def = match damage.defense_type {
            data_structs::stats::AttackType::Mel => player.base_mel_def,
            data_structs::stats::AttackType::Rng => player.base_rng_def,
            data_structs::stats::AttackType::Tec => player.base_tec_def,
        };
        let total_mul = player.hero_skills.incoming()
            * player.hunter_combat.incoming(damage.defense_type);
        let min_pure_attack = min_pwr.saturating_sub(def).clamp(1, u32::MAX) as f32;
        let pure_attack = max_pwr.saturating_sub(def).clamp(1, u32::MAX) as f32;
        let damage_mul = match damage.damage {
            data_structs::stats::DamageType::Generic(m) => m,
            data_structs::stats::DamageType::PA(_) => {
                return Err(Error::InvalidInput("enemy_pa_damage"));
            },
        };
        let min_weapon_attack = min_pure_attack / 5.0 * 1.05 * damage_mul * total_mul;
        let max_weapon_attack = pure_attack / 5.0 * 1.05 * damage_mul * total_mul;

        //TODO: elemental res

        let mut rng = rand::rng();
        let crit_chance = Uniform::new(0, 100).unwrap().sample(&mut rng);
        let dmg = if crit_chance < 5 || min_weapon_attack == max_weapon_attack {
            max_weapon_attack
        } else {
            Uniform::new(min_weapon_attack, max_weapon_attack)
                .unwrap()
                .sample(&mut rng)
        }
        .round() as u32;
        // The server checks the accepted Time activation and its deadline;
        // client animation alone does not authorize damage immunity.
        let dmg=if phantom_guard {0} else {player.hero_survival.receive(player.hero_skills.rank("will"),player.hp,dmg,
            Uniform::new(0,100).unwrap().sample(&mut rng),std::time::Instant::now())};
        player.hp = player.hp.saturating_sub(dmg);
        let dmg_packet = DamageReceivePacket {
            dmg_target: attack.target,
            dmg_inflicter: attack.inflicter,
            damage_id: damage.damage_id,
            dmg_amount: dmg as _,
            new_hp: player.hp,
            hitbox_id: attack.hitbox_id,
            x_pos: attack.x_pos,
            y_pos: attack.y_pos,
            z_pos: attack.z_pos,
            ..Default::default()
        };
        Ok(if player.hp == 0 {
            let kill_packet = EnemyKilledPacket {
                receiver: dmg_packet.receiver,
                dmg_target: dmg_packet.dmg_target,
                dmg_inflicter: dmg_packet.dmg_inflicter,
                damage_id: dmg_packet.damage_id,
                dmg_amount: dmg_packet.dmg_amount,
                new_hp: dmg_packet.new_hp,
                hitbox_id: dmg_packet.hitbox_id,
                x_pos: dmg_packet.x_pos,
                y_pos: dmg_packet.y_pos,
                z_pos: dmg_packet.z_pos,
                unk1: dmg_packet.unk1,
                unk2: dmg_packet.unk3,
                unk3: dmg_packet.unk4,
                unk4: dmg_packet.unk4,
                unk5: dmg_packet.unk5,
                unk6: dmg_packet.unk6,
                unk7: dmg_packet.unk7,
            };
            BattleResult::Killed {
                dmg_packet,
                kill_packet,
                exp_amount: 0,
            }
        } else {
            BattleResult::Damaged { dmg_packet }
        })
    }
}

// Synthetic regression fixture only; never supplies live character parameters.
#[cfg(test)]
pub(crate) fn local_training_player()->PlayerStats {PlayerStats{base_rng_pwr:1000,..Default::default()}}
#[cfg(test)]
pub(crate) fn local_player_with_hp(hp: u32) -> PlayerStats {
    PlayerStats { hp, max_hp: hp, ..Default::default() }
}

#[cfg(test)]
mod local_player_damage_tests {
    use super::*;
    use data_structs::SerDeFile;
    use pso2packetlib::protocol::{ObjectHeader, ObjectType};

    #[test]
    fn local_player_lethal_exact_overkill_and_repeat_preserve_zero_hp() {
        let data = ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../data/com_data.mp")).unwrap();
        let attack = DealDamagePacket {
            attack_id: data_structs::name_to_id("StrikeAdd"),
            inflicter: ObjectHeader { id: 400, entity_type: ObjectType::Object, ..Default::default() },
            target: ObjectHeader { id: 1, entity_type: ObjectType::Player, ..Default::default() },
            ..Default::default()
        };
        // Fixed fixture power produces 21 damage through the existing formula.
        let mut enemy = EnemyStats { min_mel_pwr: 100, max_mel_pwr: 100, ..Default::default() };
        for start_hp in [22, 21, 1] {
            let mut player = local_player_with_hp(start_hp);
            let result = enemy.damage_player(&mut player, &data, attack.clone()).unwrap();
            let packet = match result {
                BattleResult::Damaged { dmg_packet } => { assert_eq!(start_hp,22); dmg_packet },
                BattleResult::Killed { dmg_packet, exp_amount, .. } => {
                    assert!(start_hp <= 21); assert_eq!(exp_amount,0); dmg_packet
                },
            };
            assert_eq!(packet.dmg_amount,21);
            assert_eq!(packet.new_hp,start_hp.saturating_sub(21));
            assert_eq!(packet.dmg_target,attack.target);
            assert_eq!(packet.dmg_inflicter,attack.inflicter);
            assert_eq!(player.get_hp(),(start_hp.saturating_sub(21),start_hp));
            if start_hp <= 21 {
                let repeated=enemy.damage_player(&mut player,&data,attack.clone()).unwrap();
                let BattleResult::Killed { dmg_packet, exp_amount, .. }=repeated else { panic!("HP must stay zero"); };
                assert_eq!(dmg_packet.new_hp,0);
                assert_eq!(exp_amount,0);
            }
        }
    }
}

#[cfg(test)]
mod local_pa_tests {
    use super::*;
    use data_structs::{SerDeFile, name_to_id};
    fn data() -> ServerData {
        ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("../data/com_data.mp")).unwrap()
    }
    fn player() -> PlayerStats {
        PlayerStats { base_rng_pwr: 1000, base_mel_pwr: 100, ..Default::default() }
    }
    fn enemy(hp: u32) -> EnemyStats {
        EnemyStats { hp, max_hp: hp, exp: 10, hitboxes: vec![EnemyHitbox {
            damage_mul: 1.0, rng_mul: 1.0, mel_mul: 1.0, tec_mul: 1.0,
            ..Default::default()
        }], ..Default::default() }
    }
    fn hit(name: &str) -> DealDamagePacket {
        DealDamagePacket { attack_id: name_to_id(name), ..Default::default() }
    }
    #[test]
    fn local_pa_original_values_and_damage() {
        let data = data();
        // 1000 ranged attack / 5 * existing 1.05 factor; zero weapon
        // variance makes the result deterministic even on a critical roll.
        for (name, expected) in [("Rifle:A1",273), ("Rifle:PA3",344),
                                 ("Rifle:PA6",1225), ("Rifle:PA6Kick",98),
                                 ("Rifle:PA10_0",562), ("Rifle:PA10_1",3370),
                                 ("Rifle:PA10_2",2247), ("Rifle:PA11_0",1793),
                                 ("Rifle:PA11_1",2933), ("Rifle:PA11_2",3259)] {
            let mut target = enemy(100000);
            let result = player().damage_enemy(&mut target, &data, hit(name)).unwrap();
            let BattleResult::Damaged { dmg_packet } = result else { panic!("Unexpected kill"); };
            assert_eq!(dmg_packet.dmg_amount, expected, "{name}");
            assert_eq!(target.hp, 100000 - expected as u32, "{name}");
            assert_eq!(dmg_packet.new_hp, target.hp);
            let record = data.attack_stats.iter().find(|a| a.attack_id == name_to_id(name)).unwrap();
            assert_eq!(dmg_packet.damage_id, record.damage_id);
        }
        assert!((crate::pa_powers::power(name_to_id("RiflePA03"),17).unwrap()-21.77).abs()<1e-5);
        assert!(crate::pa_powers::power(0,1).is_none());
        assert!(crate::pa_powers::power(name_to_id("RiflePA03"),0).is_none());
        assert!(crate::pa_powers::power(name_to_id("RiflePA03"),18).is_none());
    }
    #[test]
    fn local_pa_all_standard_rifle_hits_kill_and_unknown_pa_is_an_error() {
        let mut data = data();
        let names = ["Rifle:PA1", "Rifle:PA2", "Rifle:PA3", "Rifle:PA4", "Rifle:PA5",
            "Rifle:PA6", "Rifle:PA6Kick", "Rifle:PA7", "Rifle:PA8", "Rifle:PA8Upper",
            "Rifle:PA9", "Rifle:PA10_0", "Rifle:PA10_1", "Rifle:PA10_2",
            "Rifle:PA11_0", "Rifle:PA11_1", "Rifle:PA11_2"];
        for name in names {
            let mut target = enemy(1);
            let result = player().damage_enemy(&mut target, &data, hit(name)).unwrap();
            let BattleResult::Killed { dmg_packet, kill_packet, exp_amount } = result
                else { panic!("{name} should kill low-HP target"); };
            assert!(dmg_packet.dmg_amount > 0);
            assert_eq!(target.hp,0);
            assert_eq!(kill_packet.new_hp,0);
            assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);
            assert_eq!(exp_amount,10);
        }
        let row=data.attack_stats.iter_mut().find(|a| a.attack_id==name_to_id("Rifle:PA3")).unwrap();
        row.damage=data_structs::stats::DamageType::PA((0,1.0));
        let mut target=enemy(100);
        assert!(matches!(player().damage_enemy(&mut target,&data,hit("Rifle:PA3")),Err(Error::NoPhotonArtInfo(0,1))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_launcher_compiled_records_and_original_potency_bits() {
        let current=data();
        let root=std::path::Path::new(env!("CARGO_MANIFEST_DIR"));
        let before=ServerData::load_from_mp_comp(root.join("testdata/pre-launcher-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        for (key,value) in old_json.as_object().unwrap() {
            assert!(value==&new_json[key],"Unrelated compiled section changed: {key}");
        }

        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-launcher-parameters.json")).unwrap();
        let launcher_ids: std::collections::HashSet<_> = fixture["attacks"].as_array().unwrap().iter()
            .map(|row| name_to_id(row["attack_name"].as_str().unwrap())).collect();
        assert_eq!(launcher_ids.len(),21);
        assert_eq!(current.attack_stats.iter().filter(|r|launcher_ids.contains(&r.attack_id)).count(),21);
        for row in fixture["attacks"].as_array().unwrap() {
            let record=current.attack_stats.iter().find(|r|r.attack_id==name_to_id(row["attack_name"].as_str().unwrap())).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>assert_eq!(mul.to_bits(),bits),
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        for (name,table) in fixture["pa_tables"].as_object().unwrap() {
            let id=name_to_id(name);
            for (index,bits) in table["standard_bits"].as_array().unwrap().iter().enumerate() {
                assert_eq!(crate::pa_powers::power(id,(index+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(bits.as_str().unwrap(),16).unwrap());
            }
            assert!(crate::pa_powers::power(id,0).is_none());
            assert!(crate::pa_powers::power(id,18).is_none());
        }
    }

    #[test]
    fn local_launcher_all_standard_hits_damage_and_kill() {
        let data=data();
        // Fixed expected hits at 1000 ranged power, no weapon variance, zero
        // defense and unit hitbox. Values derive from the pinned client's
        // potency and individual-hit factor, not from the function under test.
        for (name,expected) in [("Launcher:A1",823),("Launcher:A2",882),("Launcher:A3",1176),
            ("Launcher:A1US",275),("Launcher:A2US",294),("Launcher:A3US",393),
            ("Launcher:SA1",1176),("Launcher:SA1US",393),("Launcher:PA1",2577),
            ("Launcher:PA2",1487),("Launcher:PA3",2520),("Launcher:PA4",2508),
            ("Launcher:PA4P",68),("Launcher:PA5",2768),("Launcher:PA6B",1044),
            ("Launcher:PA6F",1044),("Launcher:PA7",2318),("Launcher:PA8Explosion",2346),
            ("Launcher:PA9",843),("Launcher:PA10",390),("Launcher:PA11",1359)] {
            let mut target=enemy(100000);
            let BattleResult::Damaged {dmg_packet}=player().damage_enemy(&mut target,&data,hit(name)).unwrap()
                else {panic!("Unexpected kill: {name}");};
            assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
            assert_eq!(target.hp,100000-expected as u32);
            let mut target=enemy(1);
            let BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=player().damage_enemy(&mut target,&data,hit(name)).unwrap()
                else {panic!("Expected kill: {name}");};
            assert_eq!(target.hp,0);
            assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
            assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);
            assert_eq!(exp_amount,10);
        }
    }

    #[test]
    fn local_launcher_mixed_defense_and_unimplemented_variants() {
        let data=data();
        let mut target=enemy(100000);
        target.mel_def=500;target.rng_def=100;
        let BattleResult::Damaged {dmg_packet}=player().damage_enemy(&mut target,&data,hit("Launcher:PA7")).unwrap()
            else {panic!("Unexpected kill");};
        // Original SKI: ranged power with melee defense, not ranged defense.
        assert_eq!(dmg_packet.dmg_amount,1159);
        for name in ["Launcher:PA1C0","Launcher:PA1C1","Launcher:PA6CRush",
            "Launcher:PA6CExplosionC0","Launcher:PA6CExplosionC1","LauncherGPA1","LauncherGPA2","LauncherGPA3"] {
            let mut target=enemy(100);
            assert!(matches!(player().damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
    }

    #[test]
    fn local_sword_compiled_delta_preserves_existing_data_and_exact_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-sword-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled sections changed");
        assert_eq!(before.attack_stats.len(),53);
        // This historical fixture owns its 48 sword IDs; later weapons are checked separately.
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-sword-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),48);
        let ids:std::collections::HashSet<_>=rows.iter().map(|r|name_to_id(r["attack_name"].as_str().unwrap())).collect();
        assert_eq!(ids.len(),48);
        assert!(before.attack_stats.iter().all(|r|!ids.contains(&r.attack_id)));
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let matches:Vec<_>=current.attack_stats.iter().filter(|r|r.attack_id==id).collect();
            assert_eq!(matches.len(),1);let record=matches[0];
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        for (name,table) in fixture["pa_tables"].as_object().unwrap() {
            let id=name_to_id(name);let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (index,bits) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(id,(index+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(bits.as_str().unwrap(),16).unwrap());
            }
            assert!(crate::pa_powers::power(id,0).is_none());
            assert!(crate::pa_powers::power(id,18).is_none());
            assert!(crate::pa_powers::power(id,34).is_none());
        }
    }

    #[test]
    fn local_sword_all_base_hits_damage_and_kill_with_melee_power() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:100,base_tec_pwr:10,..Default::default()};
        // Fixed integers calculated from the pinned SKI/PHA bits and current
        // server formula before integration. This does not prove original
        // charge/gear/PP, valid hit sequences or the formula's complete parity.
        for (name,expected) in [("Sword:GA1",1331),
            ("Sword:GA2",1109),
            ("Sword:GA3",1890),
            ("Sword:AA1",1054),
            ("Sword:AA2",1050),
            ("Sword:AA3",1417),
            ("Sword:SA1",1134),
            ("Sword:PA1Up",1835),
            ("Sword:PA1",688),
            ("Sword:PA2",416),
            ("Sword:PA2L",853),
            ("Sword:PA2M",569),
            ("Sword:PA2H",591),
            ("Sword:PA3FinishG0",1872),
            ("Sword:PA3FinishG1",1040),
            ("Sword:PA3FinishG2",1040),
            ("Sword:PA3M",936),
            ("Sword:PA3H",1040),
            ("Sword:PA4",1186),
            ("Sword:PA5L",631),
            ("Sword:PA5M",947),
            ("Sword:PA5H",1263),
            ("Sword:PA5Finish",3789),
            ("Sword:PA6",1004),
            ("Sword:PA7L",974),
            ("Sword:PA7M",682),
            ("Sword:PA7H",487),
            ("Sword:PA7Tail",487),
            ("Sword:PA8Damage",4126),
            ("Sword:PA8TriggerDamage",1032),
            ("Sword:PA9L",767),
            ("Sword:PA9LBO",767),
            ("Sword:PA9M",982),
            ("Sword:PA9MBO",982),
            ("Sword:PA9H",1198),
            ("Sword:PA9HBO",1198),
            ("Sword:PA10TriggerDamage",649),
            ("Sword:PA10HoldDamage",337),
            ("Sword:PA10FinishDamage",934),
            ("Sword:PA10MissDamage",934),
            ("Sword:PA11",414),
            ("Sword:PA11FinishL",1241),
            ("Sword:PA11FinishM",1448),
            ("Sword:PA11FinishH",1655),
            ("Sword:PA11Counter",1241),
            ("Sword:PA11CounterFinishL",2896),
            ("Sword:PA11CounterFinishM",3310),
            ("Sword:PA11CounterFinishH",3723)] {
            let mut target=enemy(100000);
            let BattleResult::Damaged {dmg_packet}=player.damage_enemy(&mut target,&data,hit(name)).unwrap()
                else {panic!("Unexpected kill: {name}");};
            assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
            assert_eq!(target.hp,100000-expected as u32);
            assert_eq!(dmg_packet.new_hp,target.hp);
            let record=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
            assert_eq!(dmg_packet.damage_id,record.damage_id);
            let mut target=enemy(1);
            let BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=player.damage_enemy(&mut target,&data,hit(name)).unwrap()
                else {panic!("Expected kill: {name}");};
            assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
            assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
            assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
        }
    }

    #[test]
    fn local_sword_melee_defense_and_deferred_variants() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,..Default::default()};
        let mut target=enemy(100000);target.mel_def=500;target.rng_def=900;target.tec_def=999;
        let BattleResult::Damaged {dmg_packet}=player.damage_enemy(&mut target,&data,hit("Sword:GA1")).unwrap()
            else {panic!("Unexpected kill");};
        assert_eq!(dmg_packet.dmg_amount,666);
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-sword-parameters.json")).unwrap();
        for row in fixture["deferred_attacks"].as_array().unwrap() {
            let name=row["attack_name"].as_str().unwrap();let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        for name in ["Sword:GA1b","Sword:PA1B","Sword:PA10TriggerDamageC"] {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
    }


    #[test]
    fn local_gunslash_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-gunslash-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),101);
        // This historical fixture owns its 42 gunslash IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-gunslash-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),42);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            assert!(before.attack_stats.iter().all(|r|r.attack_id!=id));
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),11);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_gunslash_every_standard_hit_uses_original_melee_or_ranged_damage() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:10,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("GunSlash:GA1Damage",524),
            ("GunSlash:GA2Damage",462),
            ("GunSlash:GA3Damage",454),
            ("GunSlash:AA1Damage",524),
            ("GunSlash:AA2Damage",462),
            ("GunSlash:AA3Damage",454),
            ("GunSlash:GR1Damage",88),
            ("GunSlash:GR2Damage",88),
            ("GunSlash:GR3Damage",88),
            ("GunSlash:AR1Damage",88),
            ("GunSlash:AR2Damage",88),
            ("GunSlash:AR3Damage",88),
            ("GunSlash:SA1Damage",571),
            ("GunSlash:SB1Damage",571),
            ("GunSlash:PA1Damage",391),
            ("GunSlash:PA1Lurch",781),
            ("GunSlash:PA2Damage",306),
            ("GunSlash:PA2DamageR",361),
            ("GunSlash:PA3Damage",1294),
            ("GunSlash:PA3DamageR",566),
            ("GunSlash:PA4Damage",274),
            ("GunSlash:PA4BlowUp",342),
            ("GunSlash:PA5Damage0",194),
            ("GunSlash:PA5Damage1",648),
            ("GunSlash:PA5Damage2",2590),
            ("GunSlash:PA6Damage",164),
            ("GunSlash:PA7DamageS",364),
            ("GunSlash:PA7DamageR",159),
            ("GunSlash:PA7DamageRR",1860),
            ("GunSlash:PA7BlowOutB",1860),
            ("GunSlash:PA8BlowOut",593),
            ("GunSlash:PA8Damage",259),
            ("GunSlash:PA9Damage",629),
            ("GunSlash:PA9BlowOut",447),
            ("GunSlash:PA10DamageH",317),
            ("GunSlash:PA10DamageT",666),
            ("GunSlash:PA10DamageS",319),
            ("GunSlash:PA11DamageSD",396),
            ("GunSlash:PA11DamageS1",528),
            ("GunSlash:PA11DamageS3",660),
            ("GunSlash:PA11DamageR1",346),
            ("GunSlash:PA11DamageR3",346)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=9;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_gunslash_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-gunslash-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),6);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("GunSlash:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("GunSlash:PA2DamageR");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }


    #[test]
    fn local_knuckle_katana_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-knuckle_katana-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),143);
        // This historical fixture owns its 70 knuckle/katana IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-knuckle_katana-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),70);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            assert!(before.attack_stats.iter().all(|r|r.attack_id!=id));
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),22);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_knuckle_katana_every_standard_hit_uses_original_melee_or_ranged_damage() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:10,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("Knuckle:GA1Damage",638),
            ("Knuckle:GA2Damage",806),
            ("Knuckle:GA3Damage",1092),
            ("Knuckle:GA1Damage2",638),
            ("Knuckle:GA2Damage2",806),
            ("Knuckle:GA3Damage2",1092),
            ("Knuckle:AA1Damage",638),
            ("Knuckle:AA2Damage",806),
            ("Knuckle:AA3Damage",1092),
            ("Knuckle:AA1Damage2",638),
            ("Knuckle:AA2Damage2",806),
            ("Knuckle:AA3Damage2",1092),
            ("Knuckle:SA1Damage",1008),
            ("Knuckle:PA1Damage",1720),
            ("Knuckle:PA2Damage",462),
            ("Knuckle:PA3Damage",832),
            ("Knuckle:PA4Damage",1588),
            ("Knuckle:PA5C1Damage",278),
            ("Knuckle:PA5C1BlowOut",380),
            ("Knuckle:PA5C2Damage",734),
            ("Knuckle:PA5C2BlowOut",1063),
            ("Knuckle:PA6Damage",1220),
            ("Knuckle:PA7Damage",888),
            ("Knuckle:PA8Damage",514),
            ("Knuckle:PA8BlowUp",1027),
            ("Knuckle:PA9BlowOut1",2202),
            ("Knuckle:PA9BlowOut2",2489),
            ("Knuckle:PA9BlowOut3",2753),
            ("Knuckle:PA10A1Damage",334),
            ("Knuckle:PA10A2Damage",334),
            ("Knuckle:PA10B1Damage",227),
            ("Knuckle:PA10B2Damage",227),
            ("Knuckle:PA10C1Damage",5556),
            ("Knuckle:PA10C2Damage",5556),
            ("Knuckle:PA11Hit",934),
            ("Katana:GA1",470),
            ("Katana:GA2",504),
            ("Katana:GA3",538),
            ("Katana:AA1",470),
            ("Katana:AA2",504),
            ("Katana:AA3",538),
            ("Katana:SA1",655),
            ("Katana:PA1",1005),
            ("Katana:PA2FallSlash",267),
            ("Katana:PA2UpperSlash",893),
            ("Katana:PA3C",604),
            ("Katana:PA3",411),
            ("Katana:PA4C",1019),
            ("Katana:PA4",774),
            ("Katana:PA5",309),
            ("Katana:PA6",425),
            ("Katana:PA6Saya",544),
            ("Katana:PA6End",851),
            ("Katana:PA7Slash",185),
            ("Katana:PA7SlashC",123),
            ("Katana:PA7NC",308),
            ("Katana:PA7_1",62),
            ("Katana:PA7_2",154),
            ("Katana:PA7_3",370),
            ("Katana:PA7_4",616),
            ("Katana:PA8Slash",741),
            ("Katana:PA8SlashC",570),
            ("Katana:PA8AddSlash",741),
            ("Katana:PA8AddSideSlash",684),
            ("Katana:PA8Finish2",1937),
            ("Katana:PA8Finish",1709),
            ("Katana:PA9",2890),
            ("Katana:PA10",277),
            ("Katana:PA11Slash",416),
            ("Katana:PA11SlashF",1664)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=9;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_knuckle_katana_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-knuckle_katana-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),15);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("Knuckle:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("Katana:PA1");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_wired_partisan_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-wired_partisan-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),213);
        // This historical fixture owns its 70 wired-lance/partisan IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-wired_partisan-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),70);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            assert!(before.attack_stats.iter().all(|r|r.attack_id!=id));
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),21);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_wired_partisan_every_standard_hit_uses_original_melee_or_ranged_damage() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:10,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("WLance:GA1",638),
            ("WLance:GA2",529),
            ("WLance:GA3",1525),
            ("WLance:AA1",638),
            ("WLance:AA2",529),
            ("WLance:AA3",1525),
            ("WLance:SA1",586),
            ("WLance:PA1Damage",2189),
            ("WLance:PA1TriggerDamage",243),
            ("WLance:PA2",1761),
            ("WLance:PA2Miss",1761),
            ("WLance:PA2TriggerDamage",196),
            ("WLance:PA3Damage",2236),
            ("WLance:PA3TriggerDamage",248),
            ("WLance:PA4Damage",613),
            ("WLance:PA4TriggerDamage",613),
            ("WLance:PA4Spin",613),
            ("WLance:PA5",236),
            ("WLance:PA5TriggerDamage",212),
            ("WLance:PA5Spin",636),
            ("WLance:PA6",350),
            ("WLance:PA6D",630),
            ("WLance:PA6TriggerDamage",350),
            ("WLance:PA6Wire",350),
            ("WLance:PA7",1509),
            ("WLance:PA8",509),
            ("WLance:PA8Finish",1357),
            ("WLance:PA9",539),
            ("WLance:PA10",269),
            ("WLance:PA11",393),
            ("Partisan:GA1Damage",454),
            ("Partisan:GA2Damage",449),
            ("Partisan:GA3Damage",564),
            ("Partisan:AA1Damage",454),
            ("Partisan:AA2Damage",449),
            ("Partisan:AA3Damage",564),
            ("Partisan:SA1Damage",504),
            ("Partisan:SB1Damage",504),
            ("Partisan:PA1SDamage",318),
            ("Partisan:PA1SBlowOut",1588),
            ("Partisan:PA1LDamage",349),
            ("Partisan:PA1LBlowOut",1747),
            ("Partisan:PA2SDamage",586),
            ("Partisan:PA2LDamage",645),
            ("Partisan:PA3SBlowUp",1097),
            ("Partisan:PA3LBlowUp",1206),
            ("Partisan:PA4SDamage",566),
            ("Partisan:PA4SBlowUpB",2076),
            ("Partisan:PA4LDamage",623),
            ("Partisan:PA4LBlowUpB",2284),
            ("Partisan:PA5SDamage",639),
            ("Partisan:PA5SBlowUp",639),
            ("Partisan:PA5LDamage",703),
            ("Partisan:PA5LBlowUp",703),
            ("Partisan:PA6SDamage",849),
            ("Partisan:PA6SBlowOut",2070),
            ("Partisan:PA6LDamage",933),
            ("Partisan:PA6LBlowOut",2277),
            ("Partisan:PA7SDamage",636),
            ("Partisan:PA7SBlowUp",1927),
            ("Partisan:PA7LDamage",699),
            ("Partisan:PA7LBlowUp",2120),
            ("Partisan:PA8SDamage",656),
            ("Partisan:PA8LDamage",721),
            ("Partisan:PA9SDamage",303),
            ("Partisan:PA9LDamage",356),
            ("Partisan:PA11SDamage",441),
            ("Partisan:PA11LDamage",441),
            ("Partisan:PA11SFinish",4707),
            ("Partisan:PA11LFinish",5443)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=9;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_wired_partisan_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-wired_partisan-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),16);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("WLance:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("WLance:PA1Damage");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_doublesaber_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-doublesaber-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),283);
        // This historical fixture owns its 31 double-saber IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-doublesaber-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),31);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            assert!(before.attack_stats.iter().all(|r|r.attack_id!=id));
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),11);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_doublesaber_every_standard_hit_uses_original_melee_or_ranged_damage() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:10,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("DSaber:GA1Damage",487),
            ("DSaber:GA2Damage",437),
            ("DSaber:GA3Damage",504),
            ("DSaber:AA1Damage",454),
            ("DSaber:AA2Damage",412),
            ("DSaber:AA3Damage",487),
            ("DSaber:SA1Damage",386),
            ("DSaber:PA1Damage",285),
            ("DSaber:PA2Damage",153),
            ("DSaber:PA2BlowUp",1089),
            ("DSaber:PA3Damage",195),
            ("DSaber:PA3BlowOut",1168),
            ("DSaber:PA4Damage",229),
            ("DSaber:PA4Slash",229),
            ("DSaber:PA4BlowOut",1605),
            ("DSaber:PA5Damage",623),
            ("DSaber:PA5BlowUpC",1246),
            ("DSaber:PA6Damage",279),
            ("DSaber:PA6BlowUp",1157),
            ("DSaber:PA7Damage",207),
            ("DSaber:PA8Damage",462),
            ("DSaber:PA9Damage",266),
            ("DSaber:BigTornado1",1062),
            ("DSaber:BigTornado2",1603),
            ("DSaber:BigTornado3",2124),
            ("DSaber:PA11Damage1",434),
            ("DSaber:PA11Damage2",434),
            ("DSaber:PA11Damage3",434),
            ("DSaber:PA11BlowOut1",1013),
            ("DSaber:PA11BlowOut2",1302),
            ("DSaber:PA11BlowOut3",1591)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=9;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_doublesaber_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-doublesaber-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),3);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("DSaber:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("DSaber:PA1Damage");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_bow_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-bow-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),314);
        // This historical fixture owns its 25 bow IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-bow-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),25);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),11);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_bow_every_standard_hit_uses_original_melee_or_ranged_damage() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:10,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("CompoundBow:A1c0",79),
            ("CompoundBow:A1c1",397),
            ("CompoundBow:SA1",105),
            ("CompoundBow:PA1c0",143),
            ("CompoundBow:PA1c1",178),
            ("CompoundBow:PA2c0",335),
            ("CompoundBow:PA2c1",459),
            ("CompoundBow:PA3c0",101),
            ("CompoundBow:PA3c1",101),
            ("CompoundBow:PA4Sc0",38),
            ("CompoundBow:PA4Sc1",44),
            ("CompoundBow:PA4Bc0",110),
            ("CompoundBow:PA4Bc1",126),
            ("CompoundBow:PA5Zc0",373),
            ("CompoundBow:PA5Zc1",839),
            ("CompoundBow:PA5Kc0",138),
            ("CompoundBow:PA5Kc1",320),
            ("CompoundBow:PA6B",534),
            ("CompoundBow:PA6K",488),
            ("CompoundBow:PA7",2411),
            ("CompoundBow:PA8K",155),
            ("CompoundBow:PA8TK",108),
            ("CompoundBow:PA8S",379),
            ("CompoundBow:PA10",146),
            ("CompoundBow:PA11",415)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=9;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_bow_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-bow-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),9);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("CompoundBow:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("CompoundBow:PA3c0");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_normal_tech_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-normal_tech-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),332);
        // This historical fixture owns its ten normal-tech IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-normal_tech-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),10);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),0);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_normal_tech_every_hit_uses_original_power_and_defense_routes() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("Rod:GA1",176),
            ("Rod:GA2",175),
            ("Rod:GA3",181),
            ("Talis:GA1",73),
            ("Talis:GA2",73),
            ("Talis:GA3",73),
            ("Wand:GA1",564),
            ("Wand:GA2",504),
            ("Wand:GA3",622),
            ("Wand:SA1",588)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=100;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_normal_tech_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-normal_tech-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),3);
        let old_names:std::collections::HashSet<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        assert_eq!(old_names,["Wand:PA1","Wand:PA1Charge","Wand:PA1Charge2"].into_iter().collect());
        // These exact three roots now have damage/kill and bit tests in local_direct_particle_.
        for name in old_names {assert!(data.attack_stats.iter().any(|r|r.attack_id==name_to_id(name)));}
        let names=["Rod:DoesNotExist"];
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("Talis:GA1");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_dualblade_normal_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-dualblade_normal-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),342);
        // This historical fixture owns its seven dual-blade normal IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-dualblade_normal-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),7);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),0);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_dualblade_normal_every_hit_uses_original_power_and_defense_routes() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("DBlade:GA1",454),
            ("DBlade:GA2",487),
            ("DBlade:GA3",622),
            ("DBlade:AA1",454),
            ("DBlade:AA2",487),
            ("DBlade:AA3",622),
            ("DBlade:SA1",420)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=100;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_dualblade_normal_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-dualblade_normal-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),17);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("DBlade:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("DBlade:GA1");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_successor_batch_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-successor_batch-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),349);
        // This historical fixture owns its 52 successor batch IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-successor_batch-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),52);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),8);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_successor_batch_every_hit_uses_original_power_and_defense_routes() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("VlnKatana:GA1c",504),
            ("VlnKatana:GA2c",538),
            ("VlnKatana:GA3c",1008),
            ("VlnKatana:AA1c",504),
            ("VlnKatana:AA2c",538),
            ("VlnKatana:AA3c",1008),
            ("VlnKatana:SA1c",974),
            ("VlnRifle:A1P",404),
            ("VlnRifle:A2P",412),
            ("VlnRifle:A3P",809),
            ("VlnRifle:SA1P",500),
            ("VlnRifle:PA1nutMP",79),
            ("VlnRifle:PA1nutLP",138),
            ("VlnRifle:PA1stpP",109),
            ("VlnRifle:PA1stpFP",613),
            ("VlnRifle:PA2nutLP",640),
            ("VlnRifle:PA2stpP",512),
            ("VlnRifle:PA3nutMP",586),
            ("VlnRifle:PA3nutLP",703),
            ("VlnRifle:PA3stpExpP",64),
            ("VlnRifle:PA4nutP",41),
            ("VlnRifle:PA4stpP",293),
            ("VlnRod:GA1b",294),
            ("VlnRod:GA2b",305),
            ("VlnRod:GA3b",651),
            ("VlnRod:SA1B",640),
            ("MstDSaber:GA1Damage",504),
            ("MstDSaber:GA2Damage",722),
            ("MstDSaber:GA3Damage",622),
            ("MstDSaber:AA1Damage",504),
            ("MstDSaber:AA2Damage",722),
            ("MstDSaber:AA3Damage",622),
            ("MstDSaber:PA1Damage1",1094),
            ("MstDSaber:PA1Damage2",355),
            ("MstDSaber:PA1Damage3",650),
            ("MstDSaber:PA2Damage1",603),
            ("MstDSaber:PA2Damage2",567),
            ("MstDSaber:PA2Damage3",603),
            ("MstDSaber:PA3Damage1",633),
            ("MstDSaber:PA3Damage4",656),
            ("MstDSaber:PA4Damage1",1809),
            ("MstDSaber:PA4Damage2",6057),
            ("MstDBlade:GA1b",874),
            ("MstDBlade:GA2_1b",672),
            ("MstDBlade:GA2_2b",706),
            ("MstDBlade:GA3b",1126),
            ("MstDBlade:AA1b",874),
            ("MstDBlade:AA2_1b",672),
            ("MstDBlade:AA2_2b",706),
            ("MstDBlade:AA3b",1126),
            ("MstDBlade:SA1_1b",554),
            ("MstDBlade:SA1_2b",605)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=100;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_successor_batch_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-successor_batch-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),119);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("VlnRifle:DoesNotExist");
        for name in names {
            // U100's pinned Phantom catalogue now covers part of this historical
            // deferred set. It is checked positively in phantom_combat tests.
            if crate::phantom_combat::attacks().contains_key(&data_structs::name_to_id(name)) {continue;}
            if crate::etoile_combat::new_doublesaber_attacks().contains(&data_structs::name_to_id(name)) {continue;}
            if crate::luster_combat::attacks().contains_key(&data_structs::name_to_id(name)) {continue;}
            let et:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-et-dualblade-pa.json")).unwrap();
            if et["attacks"].as_array().unwrap().iter().any(|a|a["name"]==name) {continue;}
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("VlnRifle:A1P");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_direct_particle_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-direct_particle-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),401);
        // This historical fixture owns its five direct-particle PA IDs; later weapons are checked separately.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-direct_particle-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),5);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),2);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),1);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in (0..=255u8).filter(|level| *level!=1) {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_direct_particle_every_hit_uses_original_power_and_defense_routes() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("Wand:PA1",750),
            ("Wand:PA1Charge",6189),
            ("Wand:PA1Charge2",9378),
            ("TMachineGun:GPAN",564),
            ("TMachineGun:GPAP",7619)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=100;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_direct_particle_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-direct_particle-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),0);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("TMachineGun:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("TMachineGun:GPAN");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

    #[test]
    fn local_etwand_batch_exact_compiled_delta_and_original_bits() {
        let current=data();
        let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("testdata/pre-etwand_batch-com-data.mp")).unwrap();
        let mut old_json=serde_json::to_value(&before).unwrap();
        let mut new_json=serde_json::to_value(&current).unwrap();
        old_json.as_object_mut().unwrap().remove("attack_stats");
        new_json.as_object_mut().unwrap().remove("attack_stats");
        // Later curated item updates are owned by local_weapon_catalogue_exact_delta_.
        old_json.as_object_mut().unwrap().remove("item_params");
        new_json.as_object_mut().unwrap().remove("item_params");
        assert!(old_json==new_json,"Unrelated compiled data changed");
        assert_eq!(before.attack_stats.len(),406);
        assert!(current.attack_stats.len() >= 422); // Hero additions checked by local_hero tests.
        let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();
        assert_eq!(ids.len(),current.attack_stats.len(),"Duplicate attack hash");
        for old in &before.attack_stats {
            let new=current.attack_stats.iter().find(|r|r.attack_id==old.attack_id).unwrap();
            assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
        }
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-etwand_batch-parameters.json")).unwrap();
        let rows=fixture["attacks"].as_array().unwrap();assert_eq!(rows.len(),16);
        for row in rows {
            let id=name_to_id(row["attack_name"].as_str().unwrap());
            let record=current.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
            assert_eq!(record.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
            assert_eq!(serde_json::to_value(&record.attack_type).unwrap(),row["attack_type"]);
            assert_eq!(serde_json::to_value(&record.defense_type).unwrap(),row["defense_type"]);
            let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
            match record.damage {
                data_structs::stats::DamageType::Generic(mul)=>{
                    assert!(row["damage"].get("Generic").is_some());assert_eq!(mul.to_bits(),bits);
                },
                data_structs::stats::DamageType::PA((id,mul))=>{
                    assert_eq!(mul.to_bits(),bits);
                    assert_eq!(id,name_to_id(row["damage"]["PA"]["name"].as_str().unwrap()));
                }
            }
        }
        let tables=fixture["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),4);
        for (name,table) in tables {
            let bits=table["standard_bits"].as_array().unwrap();assert_eq!(bits.len(),17);
            for (i,value) in bits.iter().enumerate() {
                assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),
                    u32::from_str_radix(value.as_str().unwrap(),16).unwrap());
            }
            for level in [0,18,34] {assert!(crate::pa_powers::power(name_to_id(name),level).is_none());}
        }
    }

    #[test]
    fn local_etwand_batch_every_hit_uses_original_power_and_defense_routes() {
        let data=data();
        let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()};
        // Fixed expected hits from pinned original floats and the pre-existing
        // formula: different melee/ranged powers AND defenses catch swapped
        // routing. No weapon variance. This does not establish full game parity.
        for (name,expected) in [("MstWand:GA1",773),
            ("MstWand:GA2",655),
            ("MstWand:GA3",554),
            ("MstWand:PA1Rush",678),
            ("MstWand:PA1Slash1",339),
            ("MstWand:PA1Slash2",2714),
            ("MstWand:PA1SlashBox",2374),
            ("MstWand:PA2",260),
            ("MstWand:PA2S",3646),
            ("MstWand:PA2L",781),
            ("MstWand:PA3Dmg",836),
            ("MstWand:PA3Box",213),
            ("MstWand:PA3ExpS",1026),
            ("MstWand:PA3ExpL",425),
            ("MstWand:PA4Laser",3484),
            ("MstWand:PA4LaserChange",1106)] {
            for hp in [100000,1] {
                let mut target=enemy(hp);target.mel_def=200;target.rng_def=50;target.tec_def=100;
                match player.damage_enemy(&mut target,&data,hit(name)).unwrap() {
                    BattleResult::Damaged {dmg_packet}=>{
                        assert_eq!(hp,100000);assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(target.hp,hp-expected as u32);assert_eq!(dmg_packet.new_hp,target.hp);
                        let row=data.attack_stats.iter().find(|r|r.attack_id==name_to_id(name)).unwrap();
                        assert_eq!(dmg_packet.damage_id,row.damage_id);
                    },
                    BattleResult::Killed {dmg_packet,kill_packet,exp_amount}=>{
                        assert_eq!(hp,1);assert_eq!(target.hp,0);assert_eq!(kill_packet.new_hp,0);
                        assert_eq!(dmg_packet.dmg_amount,expected,"{name}");
                        assert_eq!(kill_packet.damage_id,dmg_packet.damage_id);assert_eq!(exp_amount,10);
                    }
                }
            }
        }
    }

    #[test]
    fn local_etwand_batch_deferred_or_unknown_hits_do_not_mutate_enemy() {
        let data=data();let mut player=PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,..Default::default()};
        let fixture:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-etwand_batch-parameters.json")).unwrap();
        let deferred=fixture["deferred_attacks"].as_array().unwrap();assert_eq!(deferred.len(),4);
        let mut names:Vec<_>=deferred.iter().map(|r|r["attack_name"].as_str().unwrap()).collect();
        names.push("MstWand:DoesNotExist");
        for name in names {
            let mut target=enemy(100);
            assert!(matches!(player.damage_enemy(&mut target,&data,hit(name)),Err(Error::NoDamageInfo(_))));
            assert_eq!(target.hp,100);
        }
        let mut target=enemy(100);let mut request=hit("MstWand:GA1");request.hitbox_id=u32::MAX;
        assert!(matches!(player.damage_enemy(&mut target,&data,request),Err(Error::NoHitboxInfo(_, _))));
        assert_eq!(target.hp,100);
    }

}

#[cfg(test)]
mod local_subclass_stats_tests;

#[cfg(test)]
mod local_weapon_catalogue_tests;

#[cfg(test)]
mod local_custom_spawn_tests {
    use super::*;
    #[test]
    fn local_custom_spawn_model_experiment_changes_only_the_authored_model_slot() {
        let range=EnemyStats::custom_rockbear(Position::default());
        let packet=range.create_spawn_packet(900);
        assert_eq!(packet.name.as_str(),"BigBeastA");
        assert_eq!(packet.unk9[12],0);
        let mut ordinary=range.clone();ordinary.custom_uniform_target=false;
        let legacy=ordinary.create_spawn_packet(900);
        assert_eq!(legacy.unk9[12],1570802465);
        let mut normalized=packet;normalized.unk9[12]=1570802465;
        assert_eq!(normalized,legacy);
        ordinary.name="SoldierAnt".into();
        let dagan=ordinary.create_spawn_packet(901);
        assert_eq!(dagan.name.as_str(),"SoldierAnt");
        assert_eq!(dagan.unk9[12],1570802465);
    }
}
