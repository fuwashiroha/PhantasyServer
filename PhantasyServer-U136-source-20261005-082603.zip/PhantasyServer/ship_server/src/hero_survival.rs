//! Hero Will: pinned Classic skill table; runtime state belongs to one quest.
use std::time::{Duration,Instant};
#[derive(Debug,Clone,Default,PartialEq)]
pub(crate) struct HeroSurvival {active:bool,used:bool,invulnerable_until:Option<Instant>}
impl HeroSurvival {
    pub(crate) fn begin_quest(&mut self){*self=Self{active:true,..Default::default()};}
    pub(crate) fn end_quest(&mut self){*self=Self::default();}
    pub(crate) fn receive(&mut self,rank:u8,hp:u32,damage:u32,roll:u8,now:Instant)->u32 {
        if hp==0 || !self.active || rank==0 {return damage;}
        if self.invulnerable_until.is_some_and(|until|now<until){return 0;}
        let chance=[0,50,60,70,80,100].get(rank as usize).copied().unwrap_or(0);
        if !self.used && damage>=hp && roll<chance {
            self.used=true;
            self.invulnerable_until=Some(now+Duration::from_secs(u64::from(rank)));
            return hp-1;
        }
        damage
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_hero_will_every_rank_probability_duration_and_single_use(){
        let now=Instant::now();
        for (rank,chance) in [(1,50),(2,60),(3,70),(4,80),(5,100)] {
            let mut success=0;
            for roll in 0..100 {
                let mut s=HeroSurvival::default();s.begin_quest();
                let damage=s.receive(rank,100,120,roll,now);
                if roll<chance {success+=1;assert_eq!(damage,99);assert_eq!(s.receive(rank,1,120,0,now+Duration::from_millis(1)),0);
                    assert_eq!(s.receive(rank,100,120,0,now+Duration::from_secs(rank as u64)),120);
                } else {assert_eq!(damage,120);assert!(!s.used);}
            }
            assert_eq!(success,chance);
        }
    }
    #[test]
    fn local_hero_will_lifecycle_and_nonlethal_do_not_rearm(){
        let now=Instant::now();let mut s=HeroSurvival::default();
        assert_eq!(s.receive(5,100,200,0,now),200);s.begin_quest();
        assert_eq!(s.receive(5,100,10,0,now),10);assert!(!s.used);
        assert_eq!(s.receive(0,100,200,0,now),200);assert!(!s.used);
        assert_eq!(s.receive(5,1,200,0,now),0);assert!(s.used);
        let mut rebuilt=s.clone();assert_eq!(rebuilt.receive(5,100,200,0,now+Duration::from_secs(6)),200);
        rebuilt.begin_quest();assert_eq!(rebuilt.receive(5,100,200,0,now),99);
        rebuilt.end_quest();assert_eq!(rebuilt.receive(5,100,200,0,now),200);
        assert_eq!(rebuilt.receive(5,0,200,0,now),200);
    }
}
