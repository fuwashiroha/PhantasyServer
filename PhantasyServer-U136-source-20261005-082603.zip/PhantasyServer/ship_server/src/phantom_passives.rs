//! U100: Phantom native learned effects, IDs read from the isolated Classic client.
//! A 04/28 tree sheet stores ranks; it does not install the actor's buff objects.
//! IDs/kind 16 were read from the original private client's skill descriptors.
//! Wire layout is from native 0xF8D5A0; defaults from 0x291110/0x2DD7230.
//! This narrow candidate still requires client acceptance of each newly synchronized action.
use crate::{Error, native_phantom_tree::PhantomTree, sql::CharData};
use pso2packetlib::protocol::{
    Packet, ObjectHeader, models::character::Class,
    objects::{Unk0424Packet, Unk0425Packet},
};

const EFFECTS: [(&str, u32); 41] = [
    ("VillainMarker", 112044),
    ("VillainDushJump", 112026),
    ("VillainFirstBlood", 112056),
    ("VillainAirReversal", 112025),
    ("VillainJustReversalJACombo", 112028),
    ("VillainNextJump", 112011),
    ("VillainGespenst", 112066),
    ("VillainHighLevelBonus", 112070),
    ("VillainStepJACombo", 112027),
    ("VillainSprintTecCharge", 112065),
    ("VillainDodge", 112069),
    ("VillainTalisShortCharge", 112073),
    ("VillainMag", 112034),
    ("VillainDodgeCounterShot", 112064),
    ("PrimalTime", 112014),
    ("VillainAttackJellen", 112061),
    ("VillainWeaponBonus1", 112041),
    ("VillainDodgePPRegain", 112030),
    ("VillainTimeFinish", 112017),
    ("VillainJellenRedress", 112062),
    ("VillainWeaponBonus2", 112042),
    ("PrimalTimePlus2", 112052),
    ("PrimalTimePlus", 112051),
    ("VillainJustReversal", 112024),
    ("VillainZeroRangeBoost", 112048),
    ("VillainLongRangeBoost", 112049),
    ("VillainChaseMarkBoost", 112050),
    ("VillainLoadOfThorn", 112059),
    ("VillainChargeTechJA", 112057),
    ("VillainMarkPpDrain", 112046),
    ("VillainMarkHeal", 112045),
    ("VillainQuickCut", 112063),
    ("VillainBullsEye", 112060),
    ("VillainAmbivalence", 112067),
    ("VillainAllAttackBonus", 112071),
    ("VillainPhotonStream1", 112035),
    ("VillainPPRestraint", 112058),
    ("VillainTecShortCharge", 112033),
    ("VillainFullDrive", 112031),
    ("VillainPhotonStream2", 112072),
    ("VillainPPHighUp", 112029),
];

pub(crate) fn synchronize(header: ObjectHeader, character: &CharData) -> Result<Vec<Packet>, Error> {
    let classes = &character.character.classes;
    let tree = character.native_phantom_tree.clone().unwrap_or_default().at_level(classes.phantom_info.level1);
    tree.validate(classes.phantom_info.level1, classes.phantom_info.level2)?;
    Ok(effect_packets(header, &tree, classes.main_class == Class::Phantom))
}

pub(crate) fn clear_marker(header:ObjectHeader)->Packet {
    Packet::Unk0425(Unk0425Packet{unk1:header,unk2:header,unk3:112010,..Default::default()})
}
fn enable_marker(header:ObjectHeader)->Packet {
    let mut tail=[0;12];tail[..4].copy_from_slice(&(-1f32).to_le_bytes());
    tail[4..8].copy_from_slice(&1u32.to_le_bytes());tail[8..].copy_from_slice(&4u32.to_le_bytes());
    Packet::Unk0424(Unk0424Packet{unk1:header,unk2:header,unk3:header,unk4:112010,unk5:u32::MAX,unk6:tail,unk7:[0;12]})
}
pub(crate) fn is_marker_request(id:u32)->bool {
    id==data_structs::name_to_id("VlnMarker") || id==data_structs::name_to_id("VlnMarkerRemove")
}
pub(crate) fn marker_request(header:ObjectHeader,learned:bool,p:&pso2packetlib::protocol::playerstatus::DealDamagePacket)->Option<Packet> {
    if !learned || header.entity_type!=pso2packetlib::protocol::ObjectType::Player || p.target!=header || p.inflicter!=header || !matches!(p.hitbox_id,0|u32::MAX) {return None;}
    if p.attack_id==data_structs::name_to_id("VlnMarker") {Some(enable_marker(header))}
    else if p.attack_id==data_structs::name_to_id("VlnMarkerRemove") {Some(clear_marker(header))}
    else {None}
}

fn effect_packets(header: ObjectHeader, tree: &PhantomTree, phantom: bool) -> Vec<Packet> {
    let mut packets = Vec::new();
    for (name, id) in EFFECTS {
        // The native installer returns an existing effect unchanged. Remove it
        // first so rank changes do not retain the previous rank or duplicate it.
        // 04/25's ID at offset 0x20 is passed to native 0x2ADAA0.
        packets.push(Packet::Unk0425(Unk0425Packet {
            unk1: header, unk2: header, unk3: id, ..Default::default()
        }));
        let rank = tree.rank(name);
        if !phantom || rank == 0 { continue; }
        // At absolute wire offsets: 0x2C descriptor ID, 0x30 native -1
        // sentinel, 0x34 default duration, 0x38 learned rank, 0x3C flags=4.
        // The last 16 bytes are the original passive context, not PA damage.
        let mut tail = [0u8; 12];
        tail[4..8].copy_from_slice(&u32::from(rank).to_le_bytes());
        tail[8..12].copy_from_slice(&4u32.to_le_bytes());
        packets.push(Packet::Unk0424(Unk0424Packet {
            unk1: header, unk2: header, unk3: header,
            unk4: id, unk5: u32::MAX, unk6: tail, unk7: [0; 12],
        }));
    }
    if !phantom {
        packets.push(Packet::Unk0425(Unk0425Packet {unk1:header,unk2:header,unk3:112018,..Default::default()}));
    }
    // Learned rank 112044 and runtime marker container 112010 are distinct.
    // The kind-165 installer at 0x5031a0 keeps the existing container when it
    // exists: do not remove it on allocation refresh or weapon switches.
    // Original definition has 20/100 thresholds; native hit callbacks perform
    // accumulation. This does not claim server-authoritative mark accounting.
    packets.push(if phantom && tree.rank("VillainMarker")>0 {enable_marker(header)} else {clear_marker(header)});
    packets
}


#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_phantom_effects_require_ranks_and_remove_on_class_exit() {
        let t=PhantomTree::default().learn(0,0,1,85,85).unwrap().learn(1,3,2,85,85).unwrap();
        let active=effect_packets(Default::default(),&t,true);
        assert!(active.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==112064 && p.unk6[4..8]==2u32.to_le_bytes())));
        assert!(!active.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==112063))); // Quick Cut unlearned
        let exit=effect_packets(Default::default(),&t,false);
        assert!(exit.iter().all(|p|matches!(p,Packet::Unk0425(_))));
        assert!(exit.iter().any(|p|matches!(p,Packet::Unk0425(p) if p.unk3==112018)));
        let pinned:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-phantom-effects.json")).unwrap();
        assert_eq!(pinned["effects"].as_array().unwrap().len(),EFFECTS.len());
        for (name,id) in EFFECTS {assert!(pinned["effects"].as_array().unwrap().iter().any(|x|x["name"]==name&&x["id"]==id));}
    }
    #[test]
    fn local_phantom_marker_runtime_is_separate_learned_and_preserved_on_refresh() {
        let h=ObjectHeader{id:7,entity_type:pso2packetlib::protocol::ObjectType::Player,..Default::default()};
        let empty=PhantomTree::default();
        let learned=empty.learn(0,0,1,85,85).unwrap();
        for (tree,ph,enabled) in [(&empty,true,false),(&learned,true,true),(&learned,false,false)] {
            let packets=effect_packets(h,tree,ph);
            assert_eq!(packets.iter().filter(|p|matches!(p,Packet::Unk0424(p) if p.unk4==112010)).count(),usize::from(enabled));
            assert_eq!(packets.iter().filter(|p|matches!(p,Packet::Unk0425(p) if p.unk3==112010)).count(),usize::from(!enabled));
        }
        let mut p=pso2packetlib::protocol::playerstatus::DealDamagePacket{target:h,inflicter:h,hitbox_id:u32::MAX,attack_id:data_structs::name_to_id("VlnMarker"),..Default::default()};
        assert!(marker_request(h,false,&p).is_none());
        let Packet::Unk0424(effect)=marker_request(h,true,&p).unwrap() else {panic!()};
        assert_eq!(effect.unk4,112010);assert_eq!(f32::from_le_bytes(effect.unk6[..4].try_into().unwrap()),-1.0);
        p.target.id=99;assert!(marker_request(h,true,&p).is_none());p.target=h;
        p.attack_id=data_structs::name_to_id("VlnMarkerRemove");p.hitbox_id=0;
        assert!(matches!(marker_request(h,true,&p),Some(Packet::Unk0425(p)) if p.unk3==112010));
    }
}
