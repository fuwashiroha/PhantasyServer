//! Unconditional Hu learned effects. Stance/JA/gear state is not inferred.
use crate::{Error, native_class_tree::ClassTree, sql::CharData};
use data_structs::stats::AttackType;
use pso2packetlib::protocol::models::character::Class;

#[derive(Debug, Clone, Default)]
pub(crate) struct HunterCombat { tree: Option<ClassTree> }
const FLAT: [[u32; 11]; 3] = [
    [0,3,6,10,14,18,23,28,34,40,50],
    [0,4,9,14,19,25,31,39,50,62,75],
    [0,5,11,18,26,35,45,56,68,81,100],
];
impl HunterCombat {
    pub(crate) fn build(c: &CharData) -> Result<Self, Error> {
        if c.character.classes.main_class != Class::Hunter && c.character.classes.sub_class != Class::Hunter {
            return Ok(Self::default());
        }
        let info = &c.character.classes.hunter_info;
        let tree = c.native_class_trees.get(&0).cloned().unwrap_or_default().at_level(0, info.level1)?;
        tree.validate(0, info.level1, info.level2)?;
        Ok(Self { tree: Some(tree) })
    }
    fn rank(&self, name: &str) -> usize { self.tree.as_ref().map_or(0, |t| t.rank(name) as usize) }
    // Learned stat bonuses apply in full after the subclass base-stat 20% contribution.
    pub(crate) fn hp(&self) -> u32 { (0..3).map(|i| FLAT[i][self.rank(&format!("HunterHPUp{}", i+1))]).sum() }
    pub(crate) fn melee(&self) -> u32 { (0..3).map(|i| FLAT[i][self.rank(&format!("HunterAtpStrikeUp{}", i+1))]).sum() }
    pub(crate) fn dex(&self) -> u32 { FLAT[0][self.rank("HunterDexUp1")] }
    pub(crate) fn defense(&self) -> u32 { FLAT[0][self.rank("HunterDfpStrikeUp1")] }
    pub(crate) fn outgoing(&self) -> f32 { [1.0,1.01,1.02,1.03,1.04,1.05][self.rank("HunterHighLevelBonus")] }
    pub(crate) fn incoming(&self, defense_type: AttackType) -> f32 {
        // Flash Guards use the defense category, not power source or elemental resistance.
        // Activation is unconditional at every learned rank since 2014-08-27.
        match defense_type {
            AttackType::Mel | AttackType::Rng =>
                (1.0 - self.rank("MaterialDefence1") as f32 * 0.02)
                * (1.0 - self.rank("MaterialDefence2") as f32 * 0.02),
            AttackType::Tec => 1.0 - self.rank("TechDefence") as f32 * 0.03,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_hunter_all_twelve_rank_tables_match_pinned_swiki() {
        let f: serde_json::Value = serde_json::from_str(include_str!("../testdata/classic-hunter-passive-effects.json")).unwrap();
        for (name, title, label, kind) in [
            ("HunterHPUp1", "HPアップ1", "HPアップ1 HP最大値", 0),
            ("HunterHPUp2", "HPアップ1", "HPアップ2 HP最大値", 0),
            ("HunterHPUp3", "HPアップ1", "HPアップ3 HP最大値", 0),
            ("HunterAtpStrikeUp1", "打撃アップ1", "打撃アップ1 打撃力", 1),
            ("HunterAtpStrikeUp2", "打撃アップ1", "打撃アップ2 打撃力", 1),
            ("HunterAtpStrikeUp3", "打撃アップ1", "打撃アップ3 打撃力", 1),
            ("HunterDexUp1", "技量アップ", "技量", 2),
            ("HunterDfpStrikeUp1", "打撃防御アップ", "打撃防御", 3),
            ("MaterialDefence1", "フラッシュガード1", "軽減率", 4),
            ("MaterialDefence2", "フラッシュガード1", "軽減率", 4),
            ("TechDefence", "フラッシュテックガード", "軽減率", 5),
            ("HunterHighLevelBonus", "ハイレベルボーナスHu", "威力", 6),
        ] {
            let section=f["sections"].as_array().unwrap().iter().find(|s| s["title"].as_str().unwrap().starts_with(title)).unwrap();
            let row=section["tables"][0].as_array().unwrap().iter().find(|r|r.as_array().unwrap().iter().any(|c|c==label)).unwrap();
            let values: Vec<f32> = row.as_array().unwrap().iter().filter_map(|v|v.as_str().unwrap().trim_matches(['+','%']).parse().ok()).collect();
            let node=f["original_nodes"].as_array().unwrap().iter().find(|n|n["name"]==name).unwrap();
            assert_eq!(values.len(),node["max_rank"].as_u64().unwrap() as usize);
            for (i,value) in values.iter().enumerate() {
                // Isolated arithmetic; complete native prerequisite validation is tested separately.
                let mut t=ClassTree::default();t.ranks.insert(name.into(),i as u8+1);
                let c=HunterCombat{tree:Some(t)};
                let actual=match kind {0=>c.hp() as f32,1=>c.melee() as f32,2=>c.dex() as f32,3=>c.defense() as f32,
                    4=>(1.0-c.incoming(AttackType::Rng))*100.0,5=>(1.0-c.incoming(AttackType::Tec))*100.0,_=>c.outgoing()*100.0};
                assert!((actual-value).abs()<0.0001,"{name} rank {}: {actual} != {value}",i+1);
            }
        }
    }
}
