use super::*;
use data_structs::{SerDeFile,name_to_id,stats::{AttackType,DamageType}};
const NAMES:[&str;4]=["TDagger:GA1Damage","TDagger:GA2Damage","TDagger:GA3Damage","TDagger:SA1Damage"];
pub(super) fn contains(id:u32)->bool {NAMES.iter().any(|name|name_to_id(name)==id)}
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-dagger-ground-attacks.json")).unwrap()}
fn enemy(hp:u32)->EnemyStats {EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:2500,tec_def:7000,
    hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:0.1,tec_mul:0.2,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn player()->PlayerStats {PlayerStats{base_mel_pwr:1020,base_rng_pwr:4000,base_tec_pwr:8000,hp:1000,max_hp:1000,..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_dagger_ground_exact_four_record_delta_and_original_damage_bits() {
    let d=data();assert_eq!(d.attack_stats.len(),2057);
    let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-dagger-ground-com-data.mp")).unwrap();assert_eq!(old.attack_stats.len(),2053);
    assert!(old.attack_stats.iter().all(|a|!contains(a.attack_id)));
    let mut filtered=d.clone();filtered.attack_stats.retain(|a|!contains(a.attack_id));filtered.attack_stats.sort_by_key(|a|a.attack_id);old.attack_stats.sort_by_key(|a|a.attack_id);
    local_rare_mastery_tests::extend_previous_items(&mut old);old.item_params.pc_attrs=filtered.item_params.pc_attrs.clone();old.item_params.vita_attrs=filtered.item_params.vita_attrs.clone();
    assert!(serde_json::to_value(filtered).unwrap()==serde_json::to_value(old).unwrap(),"unexpected preexisting data change");
    let f=fixture();assert_eq!(f["attacks"].as_array().unwrap().len(),4);
    let mut ids=std::collections::HashSet::new();for a in &d.attack_stats {assert!(ids.insert(a.attack_id));}
    for r in f["attacks"].as_array().unwrap() {
        let id=name_to_id(r["name"].as_str().unwrap());assert!(contains(id));assert_eq!(r["id"],id);
        let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();assert_eq!(a.damage_id,name_to_id(r["row"]["damage_name"].as_str().unwrap()));
        assert!(matches!(a.attack_type,AttackType::Mel));assert!(matches!(a.defense_type,AttackType::Mel));
        let DamageType::Generic(m)=a.damage else{panic!()};assert_eq!(m.to_bits(),u32::from_str_radix(r["multiplier_bits"].as_str().unwrap(),16).unwrap());
        assert!(r["raw_chain"]["conditional_effects"].as_array().unwrap().is_empty());
    }
}
#[test]
fn local_dagger_ground_each_packet_hits_once_and_two_hit_sequence_and_lethal_work() {
    let d=data();let mut p=player();let mut target=enemy(10000);
    for (name,expected) in NAMES.into_iter().zip([193,232,425,290]) {
        let hp=target.hp;let hit=DealDamagePacket{attack_id:name_to_id(name),..Default::default()};
        assert_eq!(amount(p.damage_enemy(&mut target,&d,hit.clone()).unwrap()),expected);assert_eq!(target.hp,hp-expected);
        let mut low=enemy(1);assert!(matches!(p.damage_enemy(&mut low,&d,hit).unwrap(),BattleResult::Killed{..}));assert_eq!(low.hp,0);
    }
    // Supplied six-hit sequence exercises per-hit calculation; it is not a
    // client-animation/timing test or server generation of the second strike.
    let mut target=enemy(10000);for name in [NAMES[0],NAMES[0],NAMES[1],NAMES[1],NAMES[2],NAMES[2]] {
        p.damage_enemy(&mut target,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap();
    }assert_eq!(target.hp,8300);
    for name in ["TDagger:AA1Damage","TDagger:AA2Damage","TDagger:AA3Damage","TDagger:SpinDamage","TDagger:PA1"] {
        let before=target.hp;assert!(p.damage_enemy(&mut target,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).is_err());assert_eq!(target.hp,before);
    }
}
#[test]
fn local_dagger_ground_braver_normal_bonus_main_sub_and_exit() {
    use crate::{native_class_tree::{self,ClassTree},other_class_combat::OtherClassCombat};
    use pso2packetlib::protocol::models::character::ClassLevel;
    let d=data();let mut c=CharData::default();c.character.classes.braver_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.fighter_info=ClassLevel{level1:85,level2:85,exp:0};
    fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
        let n=native_class_tree::definition(6).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
        let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
        let add=rank-t.rank(name);if add==0 {t}else{t.learn(6,n.x,n.y,add,85,85).unwrap()}
    }
    c.native_class_trees.insert(6,learn(ClassTree::default(),"AttackAdvance",5));
    for (main,sub,active) in [(Class::Braver,Class::Unknown,true),(Class::Fighter,Class::Braver,true),(Class::Fighter,Class::Unknown,false)] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;let mut p=player();p.other_class_combat=OtherClassCombat::build(&c).unwrap();
        for (i,name) in NAMES.into_iter().enumerate() {let mut target=enemy(10000);let expected=if active {[261,313,574,391][i]}else{[193,232,425,290][i]};
            assert_eq!(amount(p.damage_enemy(&mut target,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap()),expected);assert_eq!(target.hp,10000-expected);}
    }
}
