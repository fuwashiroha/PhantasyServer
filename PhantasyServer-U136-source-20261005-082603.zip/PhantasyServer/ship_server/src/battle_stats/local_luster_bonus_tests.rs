use super::*;
use crate::{luster_combat::LusterCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::AttackType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(14).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)} else{t}} else{t};
    let add=rank-t.rank(name);if add==0 {t} else{t.learn(14,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Luster;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.luster_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut tree=ClassTree::default().at_level(14,85).unwrap();
    for (name,rank) in [("SlayerWeaponBonus1",10),("SlayerWeaponBonus2",10),("SlayerAllAttackBonus",10),("SlayerHighLevelBonus",5)] {tree=learn(tree,name,rank);}
    c.native_class_trees.insert(14,tree);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_luster_bonus_main_sub_weapon_gates_never_grant_subclass_exclusive_attacks() {
    let mut c=character();let attack=name_to_id("SlaGSlash:NA1_NA_Damage1");
    let main=LusterCombat::build(&c,Some(7)).unwrap();approx(main.multiplier(AttackType::Rng),4.150125);
    assert!(main.validate_attack(attack).is_ok());assert!(main.melee_region(attack));
    for weapon in [None,Some(1),Some(5),Some(8)] {approx(LusterCombat::build(&c,weapon).unwrap().multiplier(AttackType::Rng),1.575);}
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Luster;
    let sub=LusterCombat::build(&c,Some(7)).unwrap();
    for (attribute,power) in [(AttackType::Mel,2.499),(AttackType::Rng,2.28375),(AttackType::Tec,1.6275)] {approx(sub.multiplier(attribute),power);}
    assert!(!sub.melee_region(attack));assert!(sub.validate_attack(attack).is_err());
    c.character.classes.sub_class=Class::Unknown;approx(LusterCombat::build(&c,Some(7)).unwrap().multiplier(AttackType::Rng),1.0);
    c.character.classes.main_class=Class::Luster;c.character.classes.luster_info.level1=79;
    assert!(LusterCombat::build(&c,Some(7)).is_err());c.character.classes.luster_info.level1=85;
    c.character.classes.luster_info.level2=1;assert!(LusterCombat::build(&c,Some(7)).is_err());c.character.classes.luster_info.level2=85;
    c.native_class_trees.get_mut(&14).unwrap().ranks.remove("SlayerHighTecArts");assert!(LusterCombat::build(&c,Some(7)).is_err());
    c.native_class_trees.clear();approx(LusterCombat::build(&c,Some(7)).unwrap().multiplier(AttackType::Rng),1.0);
}
#[test]
fn local_luster_bonus_real_normal_and_pa_use_ranged_bonus_despite_melee_region() {
    let d=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap();
    let mut p=PlayerStats{base_rng_pwr:1020,base_mel_pwr:4000,
        luster_combat:LusterCombat::build(&character(),Some(7)).unwrap(),..Default::default()};
    for (name,expected) in [("SlaGSlash:NA1_NA_Damage1",5613),("SlaGSlash:PA1MS_NA_Damage1",6143)] {
        let mut e=EnemyStats{hp:100000,max_hp:100000,mel_def:100,rng_def:700,
            hitboxes:vec![EnemyHitbox{mel_mul:2.0,rng_mul:0.25,damage_mul:1.0,..Default::default()}],..Default::default()};
        let r=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap();
        let BattleResult::Damaged{dmg_packet}=r else{panic!()};assert_eq!(dmg_packet.dmg_amount as u32,expected);assert_eq!(e.hp,100000-expected);
    }
}
#[tokio::test]
async fn local_luster_bonus_durable_learning_reload_and_main_sub_transitions() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Luster;c.character.classes.luster_info=ClassLevel{level1:85,level2:85,exp:0};
        c.native_class_trees.insert(14,learn(ClassTree::default(),"SlayerHighTecArts",5));
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,14,2,5]);req[32]=10;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());
    }
    User::tick(user.lock().await).await.unwrap();let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(!user.lock().await.accepts_client_packets());
    assert!(tokio::time::timeout(std::time::Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;let saved=saved_character(&sql,1,1).await;
    assert_eq!(saved.native_class_trees[&14].rank("SlayerAllAttackBonus"),10);
    {let u=user.lock().await;assert!(u.accepts_client_packets());approx(u.get_stats().luster_combat.multiplier(AttackType::Rng),1.5);
        approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().luster_combat.multiplier(AttackType::Rng),1.5);assert_eq!(u.get_stats().hp,7);}
    auto_master(requests);
    for (main,sub,expected) in [(Class::Hunter,Class::Luster,1.5),(Class::Hunter,Class::Unknown,1.0),(Class::Luster,Class::Unknown,1.5)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();
        finish(&user).await;approx(user.lock().await.get_stats().luster_combat.multiplier(AttackType::Rng),expected);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
