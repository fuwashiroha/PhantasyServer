use super::*;
use crate::{other_class_combat::OtherClassCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use pso2packetlib::protocol::{Packet,ObjectHeader,models::character::ClassLevel,objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn evidence()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-braver-charge-shoot.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(6).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(6,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Braver;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.braver_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_braver_charge_all_ranks_exact_root_and_native_effect_refresh() {
    let f=evidence();let d=data();assert_eq!(f["charged_id"],name_to_id("CompoundBow:A1c1"));let mut c=character();
    for rank in 0..=5 {
        if rank>0 {c.native_class_trees.insert(6,learn(ClassTree::default(),"ChargeShoot",rank));}
        let expected=if rank==0 {1.0}else{f["damage_percent"][rank as usize-1].as_f64().unwrap() as f32/100.0};
        let packets=crate::class_passives::synchronize(ObjectHeader::default(),&c,Some(6)).unwrap();
        let removes:Vec<_>=packets.iter().enumerate().filter(|(_,p)|matches!(p,Packet::Unk0425(p) if p.unk3==170026)).collect();assert_eq!(removes.len(),1);
        let adds:Vec<_>=packets.iter().enumerate().filter(|(_,p)|matches!(p,Packet::Unk0424(p) if p.unk4==170026)).collect();
        if rank==0 {assert!(adds.is_empty());}else {
            assert_eq!(adds.len(),1);assert_eq!(adds[0].0,removes[0].0+1);
            let Packet::Unk0424(p)=adds[0].1 else{panic!()};assert_eq!(p.unk6[4..8],u32::from(rank).to_le_bytes());assert_eq!(p.unk6[8..12],4u32.to_le_bytes());
        }
        for (main,sub,active) in [(Class::Braver,Class::Unknown,true),(Class::Hunter,Class::Braver,true),(Class::Hunter,Class::Unknown,false)] {
            c.character.classes.main_class=main;c.character.classes.sub_class=sub;let stats=OtherClassCombat::build(&c).unwrap();
            for a in &d.attack_stats {approx(stats.charged_shot_multiplier(a.attack_id),if active && a.attack_id==name_to_id("CompoundBow:A1c1"){expected}else{1.0});}
        }
        c.character.classes.main_class=Class::Braver;c.character.classes.sub_class=Class::Unknown;
    }
    c.native_class_trees.get_mut(&6).unwrap().ranks.insert("ChargeShoot".into(),6);assert!(OtherClassCombat::build(&c).is_err());
}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_braver_charge_actual_bow_damage_stacks_once_and_charged_pa_excluded() {
    let d=data();let mut c=character();let t=learn(ClassTree::default(),"ChargeShoot",5);let t=learn(t,"AttackAdvance",5);c.native_class_trees.insert(6,learn(t,"BraverHighLevelBonus",5));
    let mut p=PlayerStats{hp:1000,max_hp:1000,base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,other_class_combat:OtherClassCombat::build(&c).unwrap(),..Default::default()};
    for (name,normal,charge) in [("CompoundBow:A1c0",true,false),("CompoundBow:A1c1",true,true),("CompoundBow:SA1",true,false),("CompoundBow:PA1c1",false,false),("CompoundBow:PA1c0",false,false),("Foie2",false,false),("Rifle:A1",true,false)] {
        let id=name_to_id(name);let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let m=match a.damage {DamageType::Generic(m)=>m,DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        let mul=1.05*if normal {1.35}else{1.0}*if charge {1.15}else{1.0};let expected=(900.0f32/5.0*1.05*m*mul).round() as u32;let mut e=enemy();
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected,"{name}");assert_eq!(e.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_braver_charge_native_save_reload_and_class_exit_remove_effect() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;
        let mut t=learn(ClassTree::default(),"ChargeShoot",1);t.ranks.remove("ChargeShoot");c.native_class_trees.insert(6,t);
        let n=native_class_tree::definition(6).unwrap().nodes.iter().find(|n|n.name=="ChargeShoot").unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,6,n.x,n.y]);req[32]=5;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
    finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&6].rank("ChargeShoot"),5);
    {let u=user.lock().await;approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().other_class_combat.charged_shot_multiplier(name_to_id("CompoundBow:A1c1")),1.15);assert_eq!(u.get_stats().hp,7);}
    let mut exited=saved.clone();exited.character.classes.main_class=Class::Hunter;exited.character.classes.sub_class=Class::Braver;
    let packets=crate::class_passives::synchronize(ObjectHeader::default(),&exited,Some(6)).unwrap();assert!(packets.iter().any(|p|matches!(p,Packet::Unk0425(p) if p.unk3==170026)));
    // U125 audits this subclass effect; native packet presence still is not projectile-speed acceptance.
    assert!(packets.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==170026 && p.unk6[4..8]==5u32.to_le_bytes())));
    for (main,sub,expected) in [(Class::Hunter,Class::Braver,1.15),(Class::Hunter,Class::Unknown,1.0),(Class::Braver,Class::Unknown,1.15)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().other_class_combat.charged_shot_multiplier(name_to_id("CompoundBow:A1c1")),expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
