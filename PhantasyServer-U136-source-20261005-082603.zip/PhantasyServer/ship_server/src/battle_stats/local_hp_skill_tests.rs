use super::*;
use crate::{other_class_combat::OtherClassCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-hp-conditional-skills.json")).unwrap()}
fn learn(t:ClassTree,slot:u8,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,slot,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Fighter;c.character.classes.sub_class=Class::Gunner;
    c.character.classes.fighter_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.gunner_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn full()->OtherClassCombat {
    let mut c=character();let t=learn(ClassTree::default(),3,"HalflineSlayer",10);c.native_class_trees.insert(3,learn(t,3,"DeadlineSlayer",10));c.native_class_trees.insert(4,learn(ClassTree::default(),4,"PerfectKeeper",10));OtherClassCombat::build(&c).unwrap()
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_hp_skills_all_rank_values_main_sub_and_invalid_saved_ranks() {
    for row in fixture()["skills"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let name=row["name"].as_str().unwrap();
        for (i,v) in row["values"].as_array().unwrap().iter().enumerate() {
            let mut c=character();let t=learn(ClassTree::default(),slot,name,i as u8+1);c.native_class_trees.insert(slot,t);
            for swap in [false,true] {
                c.character.classes.main_class=if swap {Class::Gunner}else{Class::Fighter};c.character.classes.sub_class=if swap {Class::Fighter}else{Class::Gunner};
                let actual=OtherClassCombat::build(&c).unwrap();let mut baseline=c.clone();baseline.native_class_trees.get_mut(&slot).unwrap().ranks.remove(name);let base=OtherClassCombat::build(&baseline).unwrap();
                if slot==4 {approx(actual.hp_multiplier(750,1000)*100.0,v.as_f64().unwrap() as f32);}else{assert_eq!(actual.hp_attack(250,1000)-base.hp_attack(250,1000),v.as_u64().unwrap() as u32);}
            }
            c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;let t=OtherClassCombat::build(&c).unwrap();assert_eq!(t.hp_attack(1,1000),0);approx(t.hp_multiplier(1000,1000),1.0);
            c.character.classes.sub_class=if slot==3{Class::Fighter}else{Class::Gunner};c.native_class_trees.get_mut(&slot).unwrap().ranks.insert(name.into(),11);assert!(OtherClassCombat::build(&c).is_err());
        }
    }
}
#[test]
fn local_hp_skills_exact_thresholds_nondivisible_maxima_zero_and_large_hp() {
    let t=full();
    for (hp,max,bonus,pk) in [(501,1000,0,1.0),(500,1000,100,1.0),(251,1000,100,1.0),(250,1000,250,1.0),(749,1000,0,1.0),(750,1000,0,1.2),(1000,1000,0,1.2),
        (51,101,0,1.0),(50,101,100,1.0),(26,101,100,1.0),(25,101,250,1.0),(75,101,0,1.0),(76,101,0,1.2),(0,1000,0,1.0),(0,0,0,1.0),
        (u32::MAX,u32::MAX,0,1.2),(u32::MAX/4,u32::MAX,250,1.0)] {
        assert_eq!(t.hp_attack(hp,max),bonus);approx(t.hp_multiplier(hp,max),pk);
    }
}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_hp_skills_actual_hits_follow_damage_and_hp_restore_without_stat_rebuild() {
    let d=data();let mut p=PlayerStats{hp:1000,max_hp:1000,base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,other_class_combat:full(),..Default::default()};
    for name in ["Sword:GA1","Rifle:PA3","Foie2"] {
        let id=name_to_id(name);let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let m=match a.damage {data_structs::stats::DamageType::Generic(m)=>m,data_structs::stats::DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        // Simulate authoritative HP changes; no claim of a new healing-item protocol.
        for (hp,flat,mult) in [(1000,0,1.2),(749,0,1.0),(500,100,1.0),(250,250,1.0),(501,0,1.0),(750,0,1.2)] {
            p.hp=hp;let expected=((900+flat) as f32/5.0*1.05*m*mult).round() as u32;let mut e=enemy();
            assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected);assert_eq!(e.hp,1000000-expected);
        }
    }
    let mut attacker=EnemyStats{min_mel_pwr:100,max_mel_pwr:100,..Default::default()};
    for (before,after,flat,pk) in [(760,739,0,1.0),(510,489,100,1.0),(260,239,250,1.0)] {
        p.hp=before;assert_eq!(amount(attacker.damage_player(&mut p,&d,DealDamagePacket{attack_id:name_to_id("StrikeAdd"),..Default::default()}).unwrap()),21);assert_eq!(p.hp,after);
        assert_eq!(p.other_class_combat.hp_attack(p.hp,p.max_hp),flat);approx(p.other_class_combat.hp_multiplier(p.hp,p.max_hp),pk);
    }
}
#[tokio::test]
async fn local_hp_skills_native_learning_save_reload_and_class_removal_preserve_hp() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    for (slot,name,class) in [(3,"HalflineSlayer",Class::Fighter),(3,"DeadlineSlayer",Class::Fighter),(4,"PerfectKeeper",Class::Gunner)] {
        {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;c.character.classes.main_class=class;c.character.classes.sub_class=Class::Unknown;
            let mut t=learn(ClassTree::default(),slot,name,1);t.ranks.remove(name);c.native_class_trees.insert(slot,t);
            let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,slot,n.x,n.y]);req[32]=10;
            handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
        finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&slot].rank(name),10);
        {let u=user.lock().await;let rebuilt=PlayerStats::prepare_equipment_update(&u,&saved).unwrap();assert_eq!(u.get_stats().hp,7);assert_eq!(u.get_stats().other_class_combat.hp_attack(1,1000),rebuilt.other_class_combat.hp_attack(1,1000));approx(u.get_stats().other_class_combat.hp_multiplier(1000,1000),rebuilt.other_class_combat.hp_multiplier(1000,1000));}
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:Class::Hunter,sub_class:Class::Unknown,..Default::default()})).await.unwrap();finish(&user).await;
        {let u=user.lock().await;assert_eq!(u.get_stats().hp,7);assert_eq!(u.get_stats().other_class_combat.hp_attack(1,1000),0);approx(u.get_stats().other_class_combat.hp_multiplier(1000,1000),1.0);}
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
