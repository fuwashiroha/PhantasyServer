use super::*;
use crate::{other_class_combat::OtherClassCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-other-class-stats.json")).unwrap()}
fn class(slot:u8)->Class {match slot {3=>Class::Fighter,4=>Class::Gunner,6=>Class::Braver,7=>Class::Bouncer,9=>Class::Summoner,_=>panic!()}}
fn character()->CharData {
    let mut c=CharData::default();for cls in [Class::Hunter,Class::Fighter,Class::Gunner,Class::Braver,Class::Bouncer,Class::Summoner] {
        c.character.classes.main_class=cls;*c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};
    }c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;c
}
fn learn(t:ClassTree,slot:u8,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,slot,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn full(slot:u8)->ClassTree {
    let mut t=ClassTree::default();for row in fixture()["effects"].as_array().unwrap().iter().filter(|r|r["slot"]==slot) {
        t=learn(t,slot,row["name"].as_str().unwrap(),row["node"]["max_rank"].as_u64().unwrap() as u8);
    }t
}
fn value(t:&OtherClassCombat,k:&str)->f32 {match k {"hp"=>t.hp as f32,"mel"=>t.mel as f32,"rng"=>t.rng as f32,"tec"=>t.tec as f32,"dex"=>t.dex as f32,"mel_def"=>t.mel_def as f32,"rng_def"=>t.rng_def as f32,"all_attack"=>{assert_eq!(t.mel,t.rng);assert_eq!(t.rng,t.tec);t.tec as f32},"all_defense"=>{assert_eq!(t.mel_def,t.rng_def);assert_eq!(t.rng_def,t.tec_def);t.tec_def as f32},"outgoing"=>t.outgoing,_=>panic!()}}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_other_class_all_34_nodes_36_rank_tables_and_invalid_allocations() {
    let f=fixture();assert_eq!(f["effects"].as_array().unwrap().len(),36);
    for row in f["effects"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let name=row["name"].as_str().unwrap();let kind=row["kind"].as_str().unwrap();
        for (i,v) in row["values"].as_array().unwrap().iter().enumerate() {
            let mut c=character();c.character.classes.main_class=class(slot);c.native_class_trees.insert(slot,learn(ClassTree::default(),slot,name,i as u8+1));
            let actual=value(&OtherClassCombat::build(&c).unwrap(),kind);c.native_class_trees.get_mut(&slot).unwrap().ranks.remove(name);
            let baseline=value(&OtherClassCombat::build(&c).unwrap(),kind);
            approx(if kind=="outgoing" {actual/baseline*100.0}else{actual-baseline},v.as_f64().unwrap() as f32);
        }
        let mut c=character();c.character.classes.main_class=class(slot);let mut t=full(slot);t.ranks.insert(name.into(),255);c.native_class_trees.insert(slot,t);assert!(OtherClassCombat::build(&c).is_err());
    }
}
#[test]
fn local_other_class_main_sub_full_stats_and_no_duplicate_defense_or_dex() {
    let d=data();for (slot,hp,mel,rng,tec,dex,md,rd,td) in [
        (3,100,200,0,0,50,50,0,0),(4,50,0,200,0,125,0,100,0),
        (6,0,50,50,0,125,0,0,0),(7,0,125,0,50,50,0,0,0),(9,150,200,200,200,100,200,200,200),
    ] {
        let mut c=character();c.native_class_trees.insert(slot,full(slot));
        for is_sub in [false,true] {
            c.character.classes.main_class=if is_sub{Class::Hunter}else{class(slot)};c.character.classes.sub_class=if is_sub{class(slot)}else{Class::Unknown};
            let sublevel=if is_sub{Some(85)}else{None};let mut empty=c.clone();empty.native_class_trees.clear();
            let base=PlayerStats::build_character_levels(&d,&empty,85,sublevel).unwrap();let got=PlayerStats::build_character_levels(&d,&c,85,sublevel).unwrap();
            assert_eq!((got.max_hp-base.max_hp,got.base_mel_pwr-base.base_mel_pwr,got.base_rng_pwr-base.base_rng_pwr,got.base_tec_pwr-base.base_tec_pwr,got.dex-base.dex,got.base_mel_def-base.base_mel_def,got.base_rng_def-base.base_rng_def,got.base_tec_def-base.base_tec_def),(hp,mel,rng,tec,dex,md,rd,td));approx(got.other_class_combat.outgoing,1.05);
        }
        c.character.classes.sub_class=Class::Unknown;assert_eq!(OtherClassCombat::build(&c).unwrap().hp,0);approx(OtherClassCombat::build(&c).unwrap().outgoing,1.0);
    }
    let mut c=character();c.character.classes.main_class=Class::Fighter;c.character.classes.sub_class=Class::Gunner;c.native_class_trees.insert(3,full(3));c.native_class_trees.insert(4,full(4));
    let t=OtherClassCombat::build(&c).unwrap();assert_eq!(t.hp,150);assert_eq!(t.dex,175);approx(t.outgoing,1.1025);
    c.character.get_level_mut().level1=79;assert!(OtherClassCombat::build(&c).is_err());
}
#[test]
fn local_other_class_high_level_bonuses_reach_actual_three_damage_types() {
    let d=data();let mut c=character();c.character.classes.main_class=Class::Fighter;c.character.classes.sub_class=Class::Gunner;
    for (slot,name) in [(3,"FighterHighLevelBonus"),(4,"GunnerHighLevelBonus")] {c.native_class_trees.insert(slot,learn(ClassTree::default(),slot,name,5));}
    let bonus=OtherClassCombat::build(&c).unwrap();approx(bonus.outgoing,1.1025);
    for name in ["Sword:GA1","Rifle:PA3","Foie2"] {
        let id=name_to_id(name);let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,other_class_combat:bonus.clone(),..Default::default()};
        let mut target=EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
        let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let m=match a.damage {data_structs::stats::DamageType::Generic(m)=>m,data_structs::stats::DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        let expected=(900.0f32/5.0*1.05*m*1.1025).round() as u32;
        let BattleResult::Damaged{dmg_packet}=p.damage_enemy(&mut target,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap() else{panic!()};assert_eq!(dmg_packet.dmg_amount as u32,expected);assert_eq!(target.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_other_class_native_learning_save_reload_and_class_exit_no_healing() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    for (slot,name,kind) in [(3,"FighterAtpStrikeUp1","mel"),(4,"GunnerAtpFirearmUp1","rng"),(6,"BraverDexUp1","dex"),(7,"BouncerDexUp1","dex"),(9,"SummonerHPUp1","hp")] {
        let rank=if slot==9{5}else{10};
        {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;c.character.classes.main_class=class(slot);c.native_class_trees.insert(slot,ClassTree::default());
            let node=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
            let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,slot,node.x,node.y]);req[32]=rank;
            handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
        finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&slot].rank(name),rank);
        {let u=user.lock().await;approx(value(&u.get_stats().other_class_combat,kind),50.0);assert_eq!(u.get_stats().hp,7);approx(value(&PlayerStats::prepare_equipment_update(&u,&saved).unwrap().other_class_combat,kind),50.0);}
        for (main,sub,expected) in [(Class::Hunter,class(slot),50.0),(Class::Hunter,Class::Unknown,0.0),(class(slot),Class::Unknown,50.0)] {
            crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
            let u=user.lock().await;approx(value(&u.get_stats().other_class_combat,kind),expected);assert_eq!(u.get_stats().hp,7);
        }
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
