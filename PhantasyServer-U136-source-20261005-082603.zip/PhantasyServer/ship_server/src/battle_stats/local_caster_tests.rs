use super::*;
use crate::{techniques::TechniqueCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::models::character::ClassLevel;
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-caster-stats.json")).unwrap()}
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn learn(t:ClassTree,slot:u8,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,slot,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Techer;
    c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.techer_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn full()->CharData {
    let mut c=character();for row in fixture()["skills"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let t=c.native_class_trees.remove(&slot).unwrap_or_default();
        c.native_class_trees.insert(slot,learn(t,slot,row["name"].as_str().unwrap(),row["node"]["max_rank"].as_u64().unwrap() as u8));
    }c
}
fn value(t:&TechniqueCombat,kind:&str)->f32 {match kind {"hp"=>t.hp() as f32,"mel"=>t.melee() as f32,"tec"=>t.tech_power() as f32,"dex"=>t.dex() as f32,"defense"=>t.tech_defense() as f32,"outgoing"=>t.outgoing(),_=>panic!()}}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_caster_all_thirteen_swiki_rank_values_through_validated_native_nodes() {
    let f=fixture();assert_eq!(f["skills"].as_array().unwrap().len(),13);
    for row in f["skills"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let name=row["name"].as_str().unwrap();let kind=row["kind"].as_str().unwrap();
        for (i,v) in row["values"].as_array().unwrap().iter().enumerate() {
            let mut c=character();let tree=learn(ClassTree::default(),slot,name,i as u8+1);c.native_class_trees.insert(slot,tree);
            let actual=value(&TechniqueCombat::build(&c).unwrap(),kind);
            c.native_class_trees.get_mut(&slot).unwrap().ranks.remove(name);
            let baseline=value(&TechniqueCombat::build(&c).unwrap(),kind);
            approx(if kind=="outgoing" {actual/baseline*100.0}else{actual-baseline},v.as_f64().unwrap() as f32);
        }
    }
    let mut c=full();c.character.classes.force_info.level1=79;assert!(TechniqueCombat::build(&c).is_err());
}
#[test]
fn local_caster_full_main_sub_bonuses_added_after_base_stat_scaling_and_class_exit() {
    let d=data();let mut c=full();
    for (main,sub,hp,mel,tec,dex,def,outgoing) in [
        (Class::Force,Class::Techer,50,50,370,100,100,1.1025),
        (Class::Techer,Class::Force,50,50,370,100,100,1.1025),
        (Class::Hunter,Class::Force,50,0,245,50,50,1.05),
        (Class::Hunter,Class::Techer,0,50,125,50,50,1.05),
        (Class::Hunter,Class::Unknown,0,0,0,0,0,1.0),
    ] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;
        let mut blank=c.clone();blank.native_class_trees.clear();let sublevel=if sub==Class::Unknown{None}else{Some(85)};
        let base=PlayerStats::build_character_levels(&d,&blank,85,sublevel).unwrap();let got=PlayerStats::build_character_levels(&d,&c,85,sublevel).unwrap();
        assert_eq!(got.max_hp-base.max_hp,hp);assert_eq!(got.base_mel_pwr-base.base_mel_pwr,mel);assert_eq!(got.base_tec_pwr-base.base_tec_pwr,tec);
        assert_eq!(got.dex-base.dex,dex);assert_eq!(got.base_tec_def-base.base_tec_def,def);approx(got.technique_combat.outgoing(),outgoing);
    }
}
#[test]
fn local_caster_high_level_bonus_applies_real_weapon_and_technique_damage_once() {
    let d=data();let mut c=character();
    for (slot,name) in [(2,"ForceHighLevelBonus"),(5,"TechterHighLevelBonus")] {c.native_class_trees.insert(slot,learn(ClassTree::default(),slot,name,5));}
    let tc=TechniqueCombat::build(&c).unwrap();approx(tc.outgoing(),1.1025);
    for name in ["Sword:GA1","Rifle:PA3","Foie2"] {
        let id=name_to_id(name);let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,..Default::default()};
        let e=EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
        // Golden from original descriptor and PHA, not ratio of already-rounded hits.
        let attack=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        let mul=match attack.damage {data_structs::stats::DamageType::Generic(m)=>m,data_structs::stats::DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        let expected=(900.0f32/5.0*1.05*mul*1.1025).round() as u32;
        p.technique_combat=tc.clone();let mut target=e;let BattleResult::Damaged{dmg_packet}=p.damage_enemy(&mut target,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap() else{panic!()};
        assert_eq!(dmg_packet.dmg_amount as u32,expected,"{name}");assert_eq!(target.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_caster_native_flat_skill_learning_persists_refreshes_without_healing() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    for (slot,class,name) in [(2,Class::Force,"ForceAtpTechnicUp1"),(5,Class::Techer,"TecherAtpTechnicUp1")] {
        {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;c.character.classes.main_class=class;c.character.classes.sub_class=Class::Unknown;
            c.native_class_trees.insert(slot,ClassTree::default());let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
            let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,slot,n.x,n.y]);req[32]=10;
            handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
        finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&slot].rank(name),10);
        let u=user.lock().await;assert_eq!(u.get_stats().technique_combat.tech_power(),50);assert_eq!(u.get_stats().hp,7);
        assert_eq!(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().base_tec_pwr,u.get_stats().base_tec_pwr);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
