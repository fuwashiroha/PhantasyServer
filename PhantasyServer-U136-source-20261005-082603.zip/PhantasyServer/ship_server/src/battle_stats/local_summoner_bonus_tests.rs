use super::*;
use crate::{other_class_combat::OtherClassCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-summoner-all-attack.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(9).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(9,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Summoner;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.summoner_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn full()->CharData {let mut c=character();let t=learn(ClassTree::default(),"AllAttackBonus1",5);c.native_class_trees.insert(9,learn(t,"AllAttackBonus2",5));c}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_summoner_bonus_all_ranks_stack_main_sub_and_exact_exclusions() {
    let f=fixture();assert_eq!(f["exclusions"].as_array().unwrap().len(),37);
    for name in ["AllAttackBonus1","AllAttackBonus2"] {for (i,v) in f["values"].as_array().unwrap().iter().enumerate() {
        let mut c=character();c.native_class_trees.insert(9,learn(ClassTree::default(),name,i as u8+1));let mut base=c.clone();base.native_class_trees.get_mut(&9).unwrap().ranks.remove(name);
        let t=OtherClassCombat::build(&c).unwrap();let b=OtherClassCombat::build(&base).unwrap();approx(t.summoner_multiplier(name_to_id("Foie2"))/b.summoner_multiplier(name_to_id("Foie2"))*100.0,v.as_f64().unwrap() as f32);
        for e in f["exclusions"].as_array().unwrap() {assert_eq!(e["id"].as_u64().unwrap() as u32,name_to_id(e["name"].as_str().unwrap()));approx(t.summoner_multiplier(e["id"].as_u64().unwrap() as u32),1.0);}
    }}
    let mut c=full();for (main,sub,expected) in [(Class::Summoner,Class::Unknown,1.3225),(Class::Hunter,Class::Summoner,1.3225),(Class::Hunter,Class::Unknown,1.0)] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;let t=OtherClassCombat::build(&c).unwrap();for name in ["Sword:GA1","Rifle:PA3","Foie2"] {approx(t.summoner_multiplier(name_to_id(name)),expected);}
    }
    c.character.classes.main_class=Class::Summoner;c.native_class_trees.get_mut(&9).unwrap().ranks.insert("AllAttackBonus1".into(),6);assert!(OtherClassCombat::build(&c).is_err());
}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_summoner_bonus_actual_damage_and_synthetic_excluded_routes_never_double_boost() {
    let d=data();let mut c=full();let t=c.native_class_trees.remove(&9).unwrap();c.native_class_trees.insert(9,learn(t,"SummonerHighLevelBonus",5));
    let mut p=PlayerStats{hp:1000,max_hp:1000,base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,other_class_combat:OtherClassCombat::build(&c).unwrap(),..Default::default()};
    for name in ["Sword:GA1","Rifle:PA3","Foie2"] {
        let id=name_to_id(name);let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let m=match a.damage {data_structs::stats::DamageType::Generic(m)=>m,data_structs::stats::DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        let expected=(900.0f32/5.0*1.05*m*(1.05*1.3225)).round() as u32;let mut e=enemy();assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected);assert_eq!(e.hp,1000000-expected);
    }
    let mut synthetic=d.clone();let mut template=d.attack_stats.iter().find(|a|a.attack_id==name_to_id("StrikeAdd")).unwrap().clone();
    for name in ["Partisan:PA10c1Exp","CompoundBow:PA9Exp","ZanbarseChaseA"] {
        let id=name_to_id(name);let mut e=enemy();assert!(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).is_err());assert_eq!(e.hp,1000000);
        // Synthetic descriptor verifies shared damage-route exclusion, not original explosion support.
        template.attack_id=id;synthetic.attack_stats.push(template.clone());let expected=(900.0f32/5.0*1.05*1.05).round() as u32;
        assert_eq!(amount(p.damage_enemy(&mut e,&synthetic,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected);assert_eq!(e.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_summoner_bonus_native_learning_persists_and_main_sub_exit_refreshes() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    for name in ["AllAttackBonus1","AllAttackBonus2"] {
        {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;
            let old=c.native_class_trees.remove(&9).unwrap_or_default();let mut t=learn(old,name,1);t.ranks.remove(name);c.native_class_trees.insert(9,t);
            let n=native_class_tree::definition(9).unwrap().nodes.iter().find(|n|n.name==name).unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,9,n.x,n.y]);req[32]=5;
            handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
        finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&9].rank(name),5);
        let u=user.lock().await;assert_eq!(u.get_stats().hp,7);approx(u.get_stats().other_class_combat.summoner_multiplier(name_to_id("Foie2")),if name=="AllAttackBonus1"{1.15}else{1.3225});
        approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().other_class_combat.summoner_multiplier(name_to_id("Foie2")),u.get_stats().other_class_combat.summoner_multiplier(name_to_id("Foie2")));
    }
    for (main,sub,expected) in [(Class::Hunter,Class::Summoner,1.3225),(Class::Hunter,Class::Unknown,1.0),(Class::Summoner,Class::Unknown,1.3225)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().other_class_combat.summoner_multiplier(name_to_id("Foie2")),expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
