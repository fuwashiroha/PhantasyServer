use super::*;
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,items::*,palette::*,models::{item_attrs::WeaponAttrs,character::ClassLevel}};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-weapon-enhancement.json")).unwrap()}
fn weapon(id:u16,subid:u16,grind:u8)->Item {Item{uuid:900,id:ItemId{item_type:1,id,subid,..Default::default()},data:ItemType::Weapon(WeaponItem{grind,..Default::default()}),..Default::default()}}
fn character(item:Item)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    *c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};let uuid=item.uuid;
    c.inventory.add_item(item);c.inventory.equip_item(uuid,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid,..Default::default()});c
}
#[test]
fn local_weapon_enhancement_source_tables_all_levels_and_original_category_correction() {
    let f=fixture();assert_eq!(f["old_tables"].as_array().unwrap().len(),7);
    for (index,rarities) in [vec![1,2,3],vec![4,5,6],vec![7,8,9],vec![10],vec![11],vec![12],vec![13]].into_iter().enumerate() {
        for rarity in rarities {for level in 0..=10 {assert_eq!(crate::weapon_enhancement::percent(false,rarity,level).unwrap(),f["old_tables"][index]["percent"][level as usize].as_u64().unwrap() as u32);}}
    }
    for rarity in 1..=15 {for level in 0..=35 {assert_eq!(crate::weapon_enhancement::percent(true,rarity,level).unwrap(),f["new_type_percent"][level as usize].as_u64().unwrap() as u32);}}
    for level in 11..=255 {assert!(crate::weapon_enhancement::percent(false,1,level).is_err());}
    for level in 36..=255 {assert!(crate::weapon_enhancement::percent(true,1,level).is_err());}
    for rarity in [0,14,15,255] {assert!(crate::weapon_enhancement::percent(false,rarity,1).is_err());}
    // Exact original INCA rows, independent of the previous hand-entered test gate.
    assert_eq!(f["category_evidence"][0]["item_id"]["id"],17);assert_eq!(f["category_evidence"][0]["name"],"デュアルブレード");
    assert_eq!(f["category_evidence"][1]["item_id"]["id"],18);assert_eq!(f["category_evidence"][1]["name"],"タクト");
    let rare:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-rare-mastery.json")).unwrap();assert_eq!(rare["tact_category"],f["category_evidence"][1]["item_id"]["id"]);
    for (category,expected) in [(17,true),(18,false)] {
        let c=character(weapon(category,0,0));assert_eq!(crate::rare_mastery::active(&c,&WeaponAttrs{id:category,subid:0,rarity:10,..Default::default()}).unwrap(),expected);
    }
}
#[test]
fn local_weapon_enhancement_known_catalogue_full_ranges_per_stat_floor_and_guards() {
    let d=data();let f=fixture();assert_eq!(f["weapon_rows"].as_array().unwrap().len(),19);let mut supported=0;
    for row in f["weapon_rows"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u16;let subid=row["subid"].as_u64().unwrap() as u16;
        let attrs=d.item_params.attrs.weapons.iter().find(|w|w.id==id && w.subid==subid).unwrap();
        let nt=row["new_type"].as_bool().unwrap();let max=if nt{35}else{10};
        for level in 0..=max {
            let item=weapon(id,subid,level);let r=crate::weapon_enhancement::powers(&item,attrs);
            if !row["supported"].as_bool().unwrap() && level>0 {assert!(matches!(r,Err(Error::InvalidInput("weapon_enhancement_source_conflict"))));continue;}
            let idx=match attrs.rarity{1..=3=>0,7..=9=>2,10=>3,_=>panic!()};let percent=if nt {100+level as u64}else{f["old_tables"][idx]["percent"][level as usize].as_u64().unwrap()};
            let expected=std::array::from_fn(|i| (row["base"][i].as_u64().unwrap()*percent/100) as u32);assert_eq!(r.unwrap(),expected);
            let c=character(item);let stats=PlayerStats::build_character_levels(&d,&c,85,None).unwrap();assert_eq!([stats.weapon_mel_pwr,stats.weapon_rng_pwr,stats.weapon_tec_pwr],expected);
        }
        if row["supported"].as_bool().unwrap(){supported+=1;assert!(crate::weapon_enhancement::powers(&weapon(id,subid,max+1),attrs).is_err());}
    }assert_eq!(supported,18);
    for (id,subid,level,expected) in [(7,229,35,[211,201,0]),(8,252,35,[0,243,0]),(9,257,35,[0,267,0]),(11,0,10,[102,0,138]),(13,0,10,[127,0,124]),(1,17,10,[789,0,0]),(1,21,10,[1012,0,0])] {
        let attrs=d.item_params.attrs.weapons.iter().find(|a|a.id==id && a.subid==subid).unwrap();let mut item=weapon(id,subid,level);
        assert_eq!(crate::weapon_enhancement::powers(&item,attrs).unwrap(),expected);
        let ItemType::Weapon(w)=&mut item.data else{unreachable!()};w.grind_percent=255;w.affixes=[1;8];w.potential=123;
        assert_eq!(crate::weapon_enhancement::powers(&item,attrs).unwrap(),expected,"no affix/potential/adjacent-percent multiplication");
    }
    let unknown=WeaponAttrs{id:1,subid:999,rarity:1,melee_dmg:100,..Default::default()};assert_eq!(crate::weapon_enhancement::powers(&weapon(1,999,0),&unknown).unwrap(),[100,0,0]);assert!(crate::weapon_enhancement::powers(&weapon(1,999,1),&unknown).is_err());
}
#[test]
fn local_weapon_enhancement_actual_rifle_damage_uses_enhanced_power() {
    // Rifle:A1 has the existing original 130% hit coefficient. Bounds include
    // that coefficient, the 90..100% weapon variance and final rounding.
    let d=data();for (level,lower,upper) in [(0,290,295),(35,305,312)] {
        let mut p=PlayerStats::build_character_levels(&d,&character(weapon(8,252,level)),85,None).unwrap();p.base_rng_pwr=1000;
        for _ in 0..32 {let mut e=EnemyStats{hp:100000,max_hp:100000,rng_def:100,hitboxes:vec![EnemyHitbox{damage_mul:1.0,rng_mul:1.0,..Default::default()}],..Default::default()};
            let r=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Rifle:A1"),..Default::default()}).unwrap();
            let amount=match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32};assert!((lower..=upper).contains(&amount),"{level}: {amount}");assert_eq!(e.hp,100000-amount);
        }
    }
}
#[tokio::test]
async fn local_weapon_enhancement_palette_save_reload_and_invalid_candidate_atomicity() {
    use crate::user::local_equipment_save_tests::{fixture as user_fixture,auto_master,finish,extend_fixture_weapon_attrs};use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=user_fixture().await;auto_master(requests);let d=data();
    {let mut u=user.lock().await;extend_fixture_weapon_attrs(&mut u,d.item_params.attrs.weapons.iter().cloned());let c=u.character.as_mut().unwrap();
        for (uuid,id,subid,grind) in [(900,7,229,35),(901,1,21,10),(902,8,252,36),(903,1,0,10)] {let mut item=weapon(id,subid,grind);item.uuid=uuid;c.inventory.add_item(item);}}
    for (uuid,expected) in [(900,[211,201,0]),(901,[1012,0,0]),(110,[100,0,0]),(900,[211,201,0])] {
        let mut req=UpdatePalettePacket::default();req.palettes[0].uuid=uuid;crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(req)).await.unwrap();assert!(!user.lock().await.accepts_client_packets());finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;let p=u.get_stats();assert_eq!([p.weapon_mel_pwr,p.weapon_rng_pwr,p.weapon_tec_pwr],expected);assert_eq!(p.hp,7);
        let p=PlayerStats::prepare_equipment_update(&u,&saved).unwrap();assert_eq!([p.weapon_mel_pwr,p.weapon_rng_pwr,p.weapon_tec_pwr],expected);
    }
    let before=rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap();let persisted=rmp_serde::to_vec(&saved_character(&sql,1,1).await).unwrap();
    for uuid in [902,903] {let mut req=UpdatePalettePacket::default();req.palettes[0].uuid=uuid;assert!(crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(req)).await.is_err());
        let u=user.lock().await;assert!(u.accepts_client_packets());assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);assert_eq!(u.get_stats().hp,7);drop(u);
        assert_eq!(rmp_serde::to_vec(&saved_character(&sql,1,1).await).unwrap(),persisted);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
