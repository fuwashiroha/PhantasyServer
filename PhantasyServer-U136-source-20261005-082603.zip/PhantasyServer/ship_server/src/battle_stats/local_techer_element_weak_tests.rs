use super::*;
use crate::{techniques::{self,TechniqueCombat},native_class_tree::{self,ClassTree},weapon_element::WeaponElement};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,items::*,palette::WeaponPalette,models::{character::ClassLevel,item_attrs::WeaponAttrs}};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-techer-element-weak.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(5).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(5,n.x,n.y,add,85,85).unwrap()}
}
fn character(rank:u8,element:u8)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Techer;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.techer_info=ClassLevel{level1:85,level2:85,exp:0};
    if rank>0 {c.native_class_trees.insert(5,learn(ClassTree::default(),"ElementalWeakPoint",rank));}
    c.inventory.add_item(Item{uuid:900,id:ItemId{item_type:1,id:13,..Default::default()},data:ItemType::Weapon(WeaponItem{element,force:if element==0 {0}else{50},..Default::default()}),..Default::default()});
    c.inventory.equip_item(900,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:900,..Default::default()});c
}
fn weapon(c:&CharData)->WeaponElement {WeaponElement::build(c,&WeaponAttrs{id:13,rarity:1,..Default::default()}).unwrap()}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_techer_element_weak_swiki_colspan_ranks_native_prerequisites_and_scope() {
    let f=fixture();assert_eq!(f["node"]["name"],"ElementalWeakPoint");assert_eq!(f["ability_registry"]["id"],160010);
    let id=name_to_id("Rifle:A1");
    for rank in 0..=5 {let expected=|label:&str| if rank==0 {1.0}else{f["percent"][label][rank as usize-1].as_u64().unwrap() as f32/100.0};
        for kind in 0..=6 {let mut c=character(rank,kind);
            for (main,sub,active) in [(Class::Techer,Class::Unknown,true),(Class::Force,Class::Techer,true),(Class::Hunter,Class::Techer,true),(Class::Force,Class::Unknown,false)] {
                c.character.classes.main_class=main;c.character.classes.sub_class=sub;let tc=TechniqueCombat::build(&c).unwrap();
                approx(tc.element_weak(id,"SoldierAnt",weapon(&c)),if !active {1.0}else if kind==1 || kind==5 {expected("弱点属性威力")}else{expected("非弱点属性威力")});
            }
        }
    }
    let mut c=character(5,1);c.native_class_trees.get_mut(&5).unwrap().ranks.remove("TecherAtpTechnicUp1");assert!(TechniqueCombat::build(&c).is_err());
    let mut c=character(5,1);c.character.classes.techer_info.level1=1;c.character.classes.techer_info.level2=1;assert!(TechniqueCombat::build(&c).is_err());
}
#[test]
fn local_techer_element_weak_all_technique_hits_use_own_element_and_weapon_routes_are_scoped() {
    let c=character(5,2);let tc=TechniqueCombat::build(&c).unwrap();let w=weapon(&c);let f=fixture();
    let all=techniques::attacks().values().map(|a|(a.id,a.element.as_str())).chain(techniques::compounds().values().map(|a|(a.id,a.element.as_str()))).collect::<Vec<_>>();assert_eq!(all.len(),345);
    for (id,element) in all {for (target,weak) in [("SoldierAnt",matches!(element,"fire"|"light")),("BigBeastA",matches!(element,"fire"|"wind"))] {
        approx(tc.element_weak(id,target,w),if weak {1.2}else{1.1});
    }}
    let f2:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-weapon-element.json")).unwrap();let fire=weapon(&character(5,1));
    for a in f2["attacks"].as_array().unwrap() {let id=a["id"].as_u64().unwrap() as u32;approx(tc.element_weak(id,"SoldierAnt",fire),1.2);approx(tc.element_weak(id,"SoldierAnt",w),1.1);}
    for a in f["unarmed"].as_array().unwrap() {approx(tc.element_weak(a["id"].as_u64().unwrap() as u32,"SoldierAnt",fire),1.1);}
    approx(tc.element_weak(u32::MAX,"SoldierAnt",fire),1.0);approx(tc.element_weak(name_to_id("Rifle:A1"),"unverified_enemy",fire),1.0);
    for a in f2["excluded"].as_array().unwrap().iter().filter(|a|a["source"].as_str().unwrap().starts_with("luster/")) {approx(tc.element_weak(a["id"].as_u64().unwrap() as u32,"SoldierAnt",fire),1.0);}
    // Compound masteries can stack both elements; EWH must use only each hit.
    approx(tc.element_weak(name_to_id("ZanZondeWind"),"SoldierAnt",fire),1.1);approx(tc.element_weak(name_to_id("ZanZondeWind"),"BigBeastA",w),1.2);
}
fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_techer_element_weak_actual_damage_uses_target_profile_not_region_or_weapon_for_tech() {
    let d=data();
    for (rank,kind,target,expected) in [(5,1,"SoldierAnt",328),(5,2,"SoldierAnt",300),(4,2,"SoldierAnt",273),(5,4,"BigBeastA",328),(5,4,"SoldierAnt",300)] {
        let c=character(rank,kind);let mut p=PlayerStats{base_rng_pwr:1000,technique_combat:TechniqueCombat::build(&c).unwrap(),weapon_element:weapon(&c),..Default::default()};
        let mut e=EnemyStats{name:target.into(),hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:1.0,rng_mul:1.0,fire_mul:4.0,ice_mul:5.0,wind_mul:6.0,..Default::default()}],..Default::default()};
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Rifle:A1"),..Default::default()}).unwrap()),expected);assert_eq!(e.hp,10000-expected);
    }
    let c=character(5,2);let tc=TechniqueCombat::build(&c).unwrap();
    for (name,target,expected) in [("Foie1","SoldierAnt",686),("ZanZondeWind","SoldierAnt",2287),("ZanZondeWind","BigBeastA",2495)] {
        let mut p=PlayerStats{base_tec_pwr:1000,technique_combat:tc.clone(),weapon_element:weapon(&c),..Default::default()};
        let mut e=EnemyStats{name:target.into(),hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:1.0,tec_mul:9.0,fire_mul:1.0,wind_mul:1.0,..Default::default()}],..Default::default()};
        // Original level1 Foie=8.25*.33; ZanZondeWind=30*.33. At1000TEC,
        // each yields210*original hit power*EWH, with no weapon-element damage.
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap()),expected);
    }
    let mut c=character(5,1);let w=weapon(&c);let tc=TechniqueCombat::build(&c).unwrap();let mut p=PlayerStats{base_rng_pwr:1000,weapon_rng_pwr:243,weapon_element:w,technique_combat:tc,..Default::default()};
    let mut e=EnemyStats{name:"SoldierAnt".into(),hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:1.0,rng_mul:0.0,fire_mul:1.2,..Default::default()}],..Default::default()};
    assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Rifle:A1"),..Default::default()}).unwrap()),48); //39.8034*1.2 once
    c.character.classes.main_class=Class::Hunter;assert_eq!(TechniqueCombat::build(&c).unwrap().element_weak(name_to_id("Rifle:A1"),"SoldierAnt",w),1.0);
}
#[tokio::test]
async fn local_techer_element_weak_native_learning_persists_reload_and_class_exit() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};use crate::sql::local_checkpoint_tests::saved_character;
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);let id=name_to_id("Foie1");
    {let mut u=user.lock().await;u.character.as_mut().unwrap().character.classes=character(0,0).character.classes;}
    for (name,add,expected) in [("TecherAtpTechnicUp1",3,1.0),("ElementalWeakPoint",4,1.20),("ElementalWeakPoint",1,1.20)] {
        let n=native_class_tree::definition(5).unwrap().nodes.iter().find(|n|n.name==name).unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,5,n.x,n.y]);req[32]=add;
        {let mut u=user.lock().await;handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;assert_eq!(u.get_stats().hp,7);
        approx(u.get_stats().technique_combat.element_weak(id,"SoldierAnt",WeaponElement::default()),expected);
        let p=PlayerStats::prepare_equipment_update(&u,&saved).unwrap();approx(p.technique_combat.element_weak(id,"SoldierAnt",WeaponElement::default()),expected);
    }
    assert_eq!(saved_character(&sql,1,1).await.native_class_trees[&5].rank("ElementalWeakPoint"),5);
    for (main,sub,bonus) in [(Class::Force,Class::Techer,1.2),(Class::Force,Class::Unknown,1.0),(Class::Techer,Class::Unknown,1.2)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().technique_combat.element_weak(id,"SoldierAnt",WeaponElement::default()),bonus);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
