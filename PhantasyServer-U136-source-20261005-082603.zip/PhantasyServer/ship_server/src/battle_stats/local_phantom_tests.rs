use super::*;
use data_structs::{SerDeFile,name_to_id};
use crate::{native_phantom_tree::PhantomTree,phantom_combat::PhantomCombat};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn target()->EnemyStats {EnemyStats{hp:100000,max_hp:100000,mel_def:100,rng_def:100,tec_def:900,
    hitboxes:vec![EnemyHitbox{mel_mul:2.0,rng_mul:1.0,tec_mul:0.5,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn hit(n:&str)->DealDamagePacket {DealDamagePacket{attack_id:name_to_id(n),..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_phantom_rod_hit_uses_tec_power_melee_defense_and_melee_region() {
    let mut p=PlayerStats{base_tec_pwr:1000,base_mel_pwr:10,
        phantom_combat:PhantomCombat{tree:Some(PhantomTree::default()),weapon:11},..Default::default()};
    let mut e=target();let damage=amount(p.damage_enemy(&mut e,&data(),hit("VlnRod:GA3")).unwrap());
    // Original normal 3 coefficient 6.2: (1000-100)/5 * 1.05 * 6.2 * 2.
    assert_eq!(damage,2344);assert_eq!(e.hp,97656);
}
#[test]
fn local_phantom_counter_learning_changes_real_damage_without_mutating_rejected_hits() {
    let mut p=PlayerStats{base_mel_pwr:1000,phantom_combat:PhantomCombat{tree:Some(PhantomTree::default()),weapon:14},..Default::default()};
    let mut e=target();let data=data();
    assert!(p.damage_enemy(&mut e,&data,hit("VillainCounterShotKatana")).is_err());assert_eq!(e.hp,100000);
    p.phantom_combat.tree=Some(PhantomTree::default().learn(0,0,1,85,85).unwrap().learn(1,3,5,85,85).unwrap());
    assert_eq!(amount(p.damage_enemy(&mut e,&data,hit("VillainCounterShotKatana")).unwrap()),5216);
    assert_eq!(e.hp,94784);
    p.phantom_combat.weapon=8;
    assert!(p.damage_enemy(&mut e,&data,hit("VillainCounterShotKatanaA")).is_err());assert_eq!(e.hp,94784);
}

#[test]
fn local_phantom_time_guard_controls_real_incoming_hp_and_expires() {
    use std::time::{Duration,Instant};
    use pso2packetlib::protocol::{ObjectHeader,ObjectType};
    let owner=ObjectHeader{id:1,entity_type:ObjectType::Player,..Default::default()};
    let req=DealDamagePacket{inflicter:owner,target:owner,attack_id:2598426158,hitbox_id:u32::MAX,..Default::default()};
    let now=Instant::now();let mut time=crate::phantom_time::PhantomTime::default();
    time.handle(owner,true,&req,now);
    let mut p=PlayerStats{hp:100,max_hp:100,..Default::default()};
    let mut e=EnemyStats{min_mel_pwr:100,max_mel_pwr:100,..Default::default()};let data=data();
    assert_eq!(amount(e.damage_player_with_phantom_guard(&mut p,&data,hit("StrikeAdd"),time.invulnerable(now+Duration::from_millis(4999))).unwrap()),0);
    assert_eq!(p.hp,100);
    assert_eq!(amount(e.damage_player_with_phantom_guard(&mut p,&data,hit("StrikeAdd"),time.invulnerable(now+Duration::from_secs(5))).unwrap()),21);
    assert_eq!(p.hp,79);
    assert!(e.damage_player_with_phantom_guard(&mut p,&data,hit("not_an_attack"),true).is_err());
    assert_eq!(p.hp,79); // immunity does not turn unknown requests into accepted hits
}
