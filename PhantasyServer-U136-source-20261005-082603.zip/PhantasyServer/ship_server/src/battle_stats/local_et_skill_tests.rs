use super::*;
use crate::{native_class_tree::{self,ClassTree},etoile_combat::EtoileCombat};
use data_structs::{SerDeFile,name_to_id,stats::AttackType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,items::*,palette::WeaponPalette};

fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(13).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(parent)=&n.parent {
        if t.rank(parent)<n.parent_rank {learn(t,parent,n.parent_rank)} else {t}
    } else {t};
    let count=rank-t.rank(name);
    if count==0 {t} else {t.learn(13,n.x,n.y,count,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Etole;
    c.character.classes.sub_class=Class::Unknown;
    c.character.classes.etole_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut tree=ClassTree::default().at_level(13,85).unwrap();
    for (name,rank) in [("MasterWeaponBonus1",10),("MasterWeaponBonus2",10),
        ("MasterAllAttackBonus",10),("MasterHighLevelBonus",5)] {tree=learn(tree,name,rank);}
    c.native_class_trees.insert(13,tree);c
}
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}

#[test]
fn local_et_bonus_main_sub_weapon_and_invalid_tree_gates() {
    let mut c=character();
    for w in [5,13,17] {approx(EtoileCombat::build(&c,Some(w)).unwrap().multiplier(AttackType::Mel),3.40554375);}
    // Adjacent categories are daggers, talis, katana and boots, not Et weapons.
    for w in [None,Some(4),Some(12),Some(14),Some(16)] {
        approx(EtoileCombat::build(&c,w).unwrap().multiplier(AttackType::Mel),1.4175);
    }
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Etole;
    for (a,v) in [(AttackType::Mel,1.4175),(AttackType::Rng,1.365),(AttackType::Tec,1.5225)] {
        approx(EtoileCombat::build(&c,Some(17)).unwrap().multiplier(a),v);
    }
    c.character.classes.sub_class=Class::Unknown;
    approx(EtoileCombat::build(&c,Some(17)).unwrap().multiplier(AttackType::Mel),1.0);
    c.character.classes.main_class=Class::Etole;
    c.character.classes.etole_info.level1=79;assert!(EtoileCombat::build(&c,Some(17)).is_err());
    c.character.classes.etole_info.level1=85;c.character.classes.etole_info.level2=1;
    assert!(EtoileCombat::build(&c,Some(17)).is_err());
    c.character.classes.etole_info.level2=85;
    c.native_class_trees.get_mut(&13).unwrap().ranks.remove("MasterDamageThrottling");
    assert!(EtoileCombat::build(&c,Some(17)).is_err());
    c.native_class_trees.clear();approx(EtoileCombat::build(&c,Some(17)).unwrap().multiplier(AttackType::Mel),1.0);
}

#[test]
fn local_et_bonus_rebuilt_equipment_and_real_pa_hit_use_learned_damage_once() {
    let d=data();let mut c=character();
    for id in [17,13,5,4] {
        let w=d.item_params.attrs.weapons.iter().find(|w|w.id==id).unwrap();
        let uuid=1000+id as u64;
        c.inventory.add_item(Item{uuid,id:ItemId{item_type:1,id,subid:w.subid,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
        c.inventory.equip_item(uuid,9).unwrap();
        c.palette.set_palette_data(0,WeaponPalette{uuid,..Default::default()});
        let mut p=PlayerStats::build_character_levels(&d,&c,85,None).unwrap();
        approx(p.etoile_combat.multiplier(AttackType::Mel),if id==4 {1.4175} else {3.40554375});
        // Independent deterministic PA golden: 900/5 * 1.05 * 27.09 * .1,
        // then both 1.55 bonuses, 1.35 all-attack and 1.05 high-level.
        p.base_mel_pwr=1000;p.weapon_mel_pwr=0;
        let mut enemy=EnemyStats{hp:100000,max_hp:100000,mel_def:100,
            hitboxes:vec![EnemyHitbox{mel_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
        let result=p.damage_enemy(&mut enemy,&d,DealDamagePacket{attack_id:name_to_id("MstDBlade:PA1_1"),..Default::default()}).unwrap();
        let BattleResult::Damaged{dmg_packet}=result else{panic!()};
        let expected=if id==4 {726} else {1744};
        assert_eq!(dmg_packet.dmg_amount as u32,expected);assert_eq!(enemy.hp,100000-expected);
    }
}

#[tokio::test]
async fn local_et_bonus_learning_waits_for_commit_reload_and_class_exit_clears() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();
        c.character.classes.main_class=Class::Etole;
        c.character.classes.etole_info=ClassLevel{level1:85,level2:85,exp:0};
        c.native_class_trees.insert(13,learn(ClassTree::default(),"MasterHPRestraint",1));
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());
        req[24..28].copy_from_slice(&[2,13,0,4]);req[32]=10;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();
        // Existing durable equipment pipeline publishes prospective state but
        // fences client actions and withholds all success/effect replies.
        approx(u.get_stats().etoile_combat.multiplier(AttackType::Mel),1.35);
        assert!(!u.accepts_client_packets());
    }
    User::tick(user.lock().await).await.unwrap();
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(!user.lock().await.accepts_client_packets());
    assert!(tokio::time::timeout(std::time::Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    finish(&user).await;
    let c=saved_character(&sql,1,1).await;
    assert_eq!(c.native_class_trees[&13].rank("MasterAllAttackBonus"),10);
    {
        let u=user.lock().await;
        assert!(u.accepts_client_packets());
        approx(u.get_stats().etoile_combat.multiplier(AttackType::Mel),1.35);
        approx(PlayerStats::prepare_equipment_update(&u,&c).unwrap().etoile_combat.multiplier(AttackType::Mel),1.35);
        assert_eq!(u.get_stats().hp,7);
    }
    auto_master(requests);
    for (main,sub,expected) in [(Class::Hunter,Class::Etole,1.35),(Class::Hunter,Class::Unknown,1.0),(Class::Etole,Class::Unknown,1.35)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();
        finish(&user).await;approx(user.lock().await.get_stats().etoile_combat.multiplier(AttackType::Mel),expected);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
