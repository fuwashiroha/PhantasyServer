use super::*;
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn evidence()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-et-dualblade-pa.json")).unwrap()}
fn hit(name:&str)->DealDamagePacket {DealDamagePacket{attack_id:name_to_id(name),..Default::default()}}
fn target(hp:u32)->EnemyStats {EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:650,tec_def:900,
    hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:0.5,tec_mul:0.2,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn amount(result:BattleResult)->u32 {match result {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_et_dualblade_compiled_additions_preserve_every_existing_record() {
    let current=data();let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-et-dualblade-pa-com-data.mp")).unwrap();
    assert_eq!(old.attack_stats.len(),785);assert_eq!(current.attack_stats.len(),1708+4+crate::techniques::count());
    for a in &old.attack_stats {assert_eq!(serde_json::to_value(a).unwrap(),serde_json::to_value(current.attack_stats.iter().find(|n|n.attack_id==a.attack_id).unwrap()).unwrap());}
    local_unit_tests::extend_previous_items(&mut old);
    let mut a=serde_json::to_value(old).unwrap();let mut b=serde_json::to_value(current).unwrap();
    a["item_params"]["pc_attrs"]=b["item_params"]["pc_attrs"].clone();a["item_params"]["vita_attrs"]=b["item_params"]["vita_attrs"].clone();
    a.as_object_mut().unwrap().remove("attack_stats");b.as_object_mut().unwrap().remove("attack_stats");assert_eq!(a,b);
}
#[test]
fn local_et_dualblade_original_hit_aliases_keep_unique_pa_ancestry_and_power_bits() {
    let data=data();let f=evidence();let rows=f["attacks"].as_array().unwrap();assert_eq!(rows.len(),63);
    for row in rows {
        let id=row["id"].as_u64().unwrap() as u32;assert_eq!(id,name_to_id(row["name"].as_str().unwrap()));
        let a=data.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        assert_eq!(a.damage_id,name_to_id(row["damage_name"].as_str().unwrap()));
        let DamageType::PA((pa,mul))=a.damage else{panic!("PA child must not become an unscaled generic hit")};
        assert_eq!(pa,name_to_id(row["pa"].as_str().unwrap()));
        assert_eq!(mul.to_bits(),u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap());
    }
    let tables=f["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),4);
    for (name,t) in tables {for (i,bits) in t["standard_bits"].as_array().unwrap().iter().enumerate() {
        assert_eq!(crate::pa_powers::power(name_to_id(name),i as u8+1).unwrap().to_bits(),u32::from_str_radix(bits.as_str().unwrap(),16).unwrap());
    }}
}
#[test]
fn local_et_dualblade_each_real_hit_and_its_aliases_damage_once_with_golden_values() {
    let data=data();let f=evidence();
    // Zero weapon variance, different off-type stats/defenses. Independent
    // expectations use swiki hit shares and original 2709/1650/1511/3342 power.
    let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:2500,base_tec_pwr:4200,..Default::default()};
    for (root,expected) in [
        ("MstDBlade:PA1_1",512),("MstDBlade:PA1_2",512),("MstDBlade:PA1_3",3072),("MstDBlade:PA1_EF",1024),
        ("MstDBlade:PA2_1_1",156),("MstDBlade:PA2_1_2",156),("MstDBlade:PA2_2",1403),("MstDBlade:PA2_EF_fast",156),("MstDBlade:PA2_EF",1247),
        ("MstDBlade:PA3_1",57),("MstDBlade:PA3_2_1",743),("MstDBlade:PA3_2_2",743),("MstDBlade:PA3_3",800),("MstDBlade:PA3_EF_R",628),("MstDBlade:PA3_EF_L",628),
        ("MstDBlade:PA4_1",1263),("MstDBlade:PA4_2_1",947),("MstDBlade:PA4_2_2",947),("MstDBlade:PA4_3",1895),("MstDBlade:PA4_EF_R",632),("MstDBlade:PA4_EF_L",632),
    ] {
        let aliases:Vec<_>=f["attacks"].as_array().unwrap().iter().filter(|a|a["source_root"]==root).collect();assert_eq!(aliases.len(),3);
        for a in aliases {for hp in [100000,1] {
            let mut e=target(hp);let result=p.damage_enemy(&mut e,&data,hit(a["name"].as_str().unwrap())).unwrap();
            assert_eq!(amount(result),expected,"{root}: {}",a["name"]);assert_eq!(e.hp,hp.saturating_sub(expected));
        }}
    }
}
