use super::*;
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use pso2packetlib::protocol::{Packet,items::*,palette::*,models::{character::ClassLevel,item_attrs::{WeaponAttrs,ItemAttributesPC,ItemAttributesVita}},objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-rare-mastery.json")).unwrap()}
pub(super) fn extend_previous_items(old:&mut ServerData) {
    let f=fixture();for row in f["rows"].as_array().unwrap() {
        let a:WeaponAttrs=serde_json::from_value(row["attrs"].clone()).unwrap();
        assert!(!old.item_params.attrs.weapons.iter().any(|w|w.id==a.id && w.subid==a.subid));old.item_params.attrs.weapons.push(a);
    }
    for n in f["names"].as_array().unwrap(){old.item_params.names.push(serde_json::from_value(n.clone()).unwrap());}
}
fn weapon(uuid:u64,category:u16,subid:u16)->Item {Item{uuid,id:ItemId{item_type:1,id:category,subid,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()}}
const CLASSES:[Class;8]=[Class::Hunter,Class::Ranger,Class::Force,Class::Fighter,Class::Gunner,Class::Techer,Class::Braver,Class::Bouncer];
fn character(category:u16,subid:u16)->CharData {
    let mut c=CharData::default();for class in CLASSES.into_iter().chain([Class::Summoner,Class::Hero,Class::Phantom,Class::Etole,Class::Luster]) {
        c.character.classes.main_class=class;*c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};
    }
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    c.inventory.add_item(weapon(501,category,subid));c.inventory.equip_item(501,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:501,..Default::default()});c
}
#[test]
fn local_rare_mastery_two_original_items_exact_delta_and_binary_roundtrip() {
    let current=data();let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-rare-mastery-com-data.mp")).unwrap();
    assert_eq!(old.item_params.attrs.weapons.len(),17);assert_eq!(current.item_params.attrs.weapons.len(),19);
    extend_previous_items(&mut old);old.item_params.pc_attrs=current.item_params.pc_attrs.clone();old.item_params.vita_attrs=current.item_params.vita_attrs.clone();
    old.attack_stats.sort_by_key(|a|a.attack_id);let mut sorted=current.clone();sorted.attack_stats.sort_by_key(|a|a.attack_id);
    assert!(serde_json::to_value(old).unwrap()==serde_json::to_value(sorted).unwrap(),"only two item rows/names/encoded containers may change");
    for (subid,rarity,mel,req) in [(17,9,451,578),(21,10,533,440)] {
        let w=current.item_params.attrs.weapons.iter().find(|w|w.id==1 && w.subid==subid).unwrap();assert_eq!((w.rarity,w.melee_dmg,w.range_dmg,w.gender_force_dmg.force_dmg,w.req_stat),(rarity,mel,0,0,req));
    }
    let mut bytes=vec![];current.item_params.attrs.write_attrs(&mut bytes).unwrap();let read=ItemAttributesPC::read_attrs(&mut std::io::Cursor::new(&bytes)).unwrap();assert_eq!(read.weapons,current.item_params.attrs.weapons);
    let vita:ItemAttributesVita=current.item_params.attrs.clone().into();let mut bytes=vec![];vita.write_attrs(&mut bytes).unwrap();let read=ItemAttributesVita::read_attrs(&mut std::io::Cursor::new(bytes)).unwrap();assert_eq!(read.weapons,vita.weapons);
}
#[test]
fn local_rare_mastery_eight_initial_nodes_main_only_rarity_and_tact_gates() {
    let f=fixture();assert_eq!(f["effects"].as_array().unwrap().len(),8);
    // Synthetic rarity boundary matrix does not assert equipment requirements.
    for category in [1,8,11,13,17,18] {let mut c=character(category,21);
        for (slot,class) in CLASSES.into_iter().enumerate() {
            c.character.classes.main_class=class;c.character.classes.sub_class=CLASSES[(slot+1)%8];
            let t=crate::native_class_tree::ClassTree::default().at_level(slot as u8,85).unwrap();
            let n=&f["effects"][slot]["node"];assert_eq!(t.rank(n["name"].as_str().unwrap()),1);assert_eq!(n["cost"],0);
            for rarity in 1..=15 {let attrs=WeaponAttrs{id:category,subid:21,rarity,..Default::default()};assert_eq!(crate::rare_mastery::active(&c,&attrs).unwrap(),rarity>=10 && category!=18);}
        }
        for class in [Class::Summoner,Class::Hero,Class::Phantom,Class::Etole,Class::Luster] {
            c.character.classes.main_class=class;c.character.classes.sub_class=Class::Hunter;
            assert!(!crate::rare_mastery::active(&c,&WeaponAttrs{id:category,subid:21,rarity:10,..Default::default()}).unwrap());
        }
    }
    let d=data();for subid in [17,21] {let c=character(1,subid);let p=PlayerStats::build_character_levels(&d,&c,85,None).unwrap();assert_eq!(p.rare_mastery,subid==21);}
    let mut c=character(1,21);c.native_class_trees.insert(0,crate::native_class_tree::ClassTree{ranks:std::collections::BTreeMap::from([("HunterAtpStrikeUp1".into(),11)]),..Default::default()});
    assert!(PlayerStats::build_character_levels(&d,&c,85,None).is_err());
}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_rare_mastery_physical_pa_and_technique_damage_multiply_once() {
    let d=data();let built=PlayerStats::build_character_levels(&d,&character(1,21),85,None).unwrap();assert!(built.rare_mastery);
    // Remove weapon variance to isolate the independently sourced 110% modifier.
    let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,rare_mastery:built.rare_mastery,..Default::default()};
    for name in ["TDagger:GA1Damage","Rifle:A1","CompoundBow:PA1c1","Foie1","Foie2"] {
        let id=name_to_id(name);let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let mul=match a.damage {DamageType::Generic(m)=>m,DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        for active in [false,true] {p.rare_mastery=active;let expected=(900.0f32/5.0*1.05*mul*if active{1.10}else{1.0}).round() as u32;
            for hp in [100000,1] {let mut e=EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{damage_mul:1.0,mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,..Default::default()}],..Default::default()};
                let r=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap();assert_eq!(amount(r),expected);assert_eq!(e.hp,hp.saturating_sub(expected));
            }
        }
    }
}
#[tokio::test]
async fn local_rare_mastery_saved_palette_and_class_refresh_keep_injured_hp() {
    use crate::user::local_equipment_save_tests::{fixture as user_fixture,extend_fixture_weapon_attrs,auto_master,finish};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=user_fixture().await;auto_master(requests);let compiled=data();
    {let mut u=user.lock().await;extend_fixture_weapon_attrs(&mut u,compiled.item_params.attrs.weapons.iter().cloned());let c=u.character.as_mut().unwrap();c.character.classes=character(1,21).character.classes;
        c.inventory.add_item(weapon(501,1,21));c.inventory.add_item(weapon(502,1,17));c.palette.set_palette_data(2,WeaponPalette{uuid:501,..Default::default()});c.palette.set_palette_data(3,WeaponPalette{uuid:502,..Default::default()});}
    for (palette,expected) in [(2,true),(3,false),(0,false),(2,true)] {
        crate::user::packet_handler(user.lock().await,Packet::SetPalette(SetPalettePacket{palette,..Default::default()})).await.unwrap();finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;assert_eq!(u.get_stats().rare_mastery,expected);assert_eq!(u.get_stats().hp,7);
        assert_eq!(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().rare_mastery,expected);
    }
    for (main,sub,expected) in [(Class::Force,Class::Techer,true),(Class::Summoner,Class::Hunter,false),(Class::Techer,Class::Unknown,true)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;assert_eq!(u.get_stats().rare_mastery,expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
