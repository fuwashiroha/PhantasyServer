use super::*;
use data_structs::{SerDeFile,name_to_id};
use crate::hero_skills::HeroSkills;

fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn enemy(hp:u32)->EnemyStats {EnemyStats {hp,max_hp:hp,exp:10,mel_def:200,rng_def:50,tec_def:100,
    hitboxes:vec![EnemyHitbox {damage_mul:1.0,mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,..Default::default()}],..Default::default()}}
fn player()->PlayerStats {PlayerStats {base_mel_pwr:1000,base_rng_pwr:400,base_tec_pwr:700,..Default::default()}}
fn hit(n:&str)->DealDamagePacket {DealDamagePacket {attack_id:name_to_id(n),..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}

#[test]
fn local_hero_switch_attack_roots_match_assets_and_damage_without_normal_bonus() {
    let data=data();
    let evidence:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-hero-switch-attacks.json")).unwrap();
    for (name,expected) in [("WpnmanSword:WpnChangeAttackTalis",1680),("WpnmanTMachineGun:WpnChangeAttackTalis",184)] {
        let id=name_to_id(name);
        let row=data.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        let pinned=evidence.as_array().unwrap().iter().find(|r|r["id"]==id).unwrap();
        assert_eq!(row.damage_id,id);
        let data_structs::stats::DamageType::Generic(m)=row.damage else {panic!()};
        assert_eq!(m.to_bits(),u32::from_str_radix(pinned["multiplier_bits"].as_str().unwrap(),16).unwrap());
        assert!(!crate::hero_skills::is_normal_attack(id));
        assert!(!crate::hero_skills::is_counter(id));
        let mut p=player();p.hero_weapon=true;p.hero_skills=p.hero_skills.with_test_rank("normal",5,85).unwrap();
        for hp in [10000,1] {
            let mut target=enemy(hp);
            assert_eq!(amount(p.damage_enemy(&mut target,&data,hit(name)).unwrap()),expected);
            assert_eq!(target.hp,hp.saturating_sub(expected));
        }
    }
}

#[test]
fn local_hero_compiled_delta_preserves_all_old_records_and_other_data() {
    let current=data();let before=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-hero-com-data.mp")).unwrap();
    assert_eq!(before.attack_stats.len(),422);assert_eq!(current.attack_stats.len(),1708+4+crate::techniques::count());
    for old in &before.attack_stats {
        let new=current.attack_stats.iter().find(|a|a.attack_id==old.attack_id).unwrap();
        assert_eq!(serde_json::to_value(new).unwrap(),serde_json::to_value(old).unwrap());
    }
    let mut before=before;local_unit_tests::extend_previous_items(&mut before);
    before.item_params.pc_attrs=current.item_params.pc_attrs.clone();before.item_params.vita_attrs=current.item_params.vita_attrs.clone();
    let mut a=serde_json::to_value(before).unwrap();let mut b=serde_json::to_value(&current).unwrap();
    a.as_object_mut().unwrap().remove("attack_stats");b.as_object_mut().unwrap().remove("attack_stats");assert_eq!(a,b);
    let ids:std::collections::HashSet<_>=current.attack_stats.iter().map(|r|r.attack_id).collect();assert_eq!(ids.len(),1708+4+crate::techniques::count());
}

#[test]
fn local_hero_twelve_pa_tables_and_forty_eight_hit_bits_match_assets() {
    let data=data();let f:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-hero-parameters.json")).unwrap();
    let rows=f["attacks"].as_array().unwrap();assert_eq!(rows.len(),48);
    for r in rows {
        let a=data.attack_stats.iter().find(|a|a.attack_id==name_to_id(r["attack_name"].as_str().unwrap())).unwrap();
        assert_eq!(a.damage_id,name_to_id(r["damage_name"].as_str().unwrap()));
        assert_eq!(serde_json::to_value(&a.attack_type).unwrap(),r["attack_type"]);
        assert_eq!(serde_json::to_value(&a.defense_type).unwrap(),r["defense_type"]);
        let bits=u32::from_str_radix(r["multiplier_bits"].as_str().unwrap(),16).unwrap();
        match a.damage {
            data_structs::stats::DamageType::Generic(m)=>{assert_eq!(m.to_bits(),bits);assert!(r["damage"].get("Generic").is_some());},
            data_structs::stats::DamageType::PA((id,m))=>{assert_eq!(m.to_bits(),bits);assert_eq!(id,name_to_id(r["damage"]["PA"]["name"].as_str().unwrap()));}
        }
    }
    let tables=f["pa_tables"].as_object().unwrap();assert_eq!(tables.len(),12);
    for (name,t) in tables {
        for (i,b) in t["standard_bits"].as_array().unwrap().iter().enumerate() {
            assert_eq!(crate::pa_powers::power(name_to_id(name),(i+1) as u8).unwrap().to_bits(),u32::from_str_radix(b.as_str().unwrap(),16).unwrap());
        }
        for l in [0,18,255] {assert!(crate::pa_powers::power(name_to_id(name),l).is_none());}
    }
}

#[test]
fn local_hero_all_hits_damage_and_kill_correctly() {
    let data=data();let cases:Vec<(String,u32)>=serde_json::from_str(include_str!("../../testdata/classic-hero-damage-expectations.json")).unwrap();
    assert_eq!(cases.len(),48);
    for (name,expected) in cases {
        for hp in [100000,1] {
            let mut target=enemy(hp);let result=player().damage_enemy(&mut target,&data,hit(&name)).unwrap();
            match &result {BattleResult::Killed{exp_amount,..}=>{assert_eq!(hp,1);assert_eq!(*exp_amount,10);},BattleResult::Damaged{..}=>assert_eq!(hp,100000)}
            assert_eq!(amount(result),expected,"{name}");assert_eq!(target.hp,hp.saturating_sub(expected));
        }
    }
}

#[test]
fn local_hero_unknown_and_conditional_attacks_remain_errors_without_hp_changes() {
    let data=data();
    for n in ["WpnmanSword:Unknown","WpnmanTalis:WpnmanTimeFinishA1Anti"] {
        let mut target=enemy(999);assert!(matches!(player().damage_enemy(&mut target,&data,hit(n)),Err(Error::NoDamageInfo(_))));assert_eq!(target.hp,999);
    }
}

#[test]
fn local_hero_passive_stacking_does_not_apply_normal_bonus_to_pa_or_other_weapon() {
    let data=data();let mut p=player();p.hero_weapon=true;
    for (key,rank) in [("weapon1",10),("weapon2",10),("normal",5),("high",5)] {p.hero_skills=p.hero_skills.with_test_rank(key,rank,85).unwrap();}
    for (name,normal) in [("WpnmanSword:GA1",true),("WpnmanSword:PA3_1",false),("WpnmanTMachineGun:PA1Dodge",false)] {
        let expected_mul=1.05*1.5*1.5*if normal {1.2}else{1.0};
        assert!((p.hero_skills.outgoing(true,crate::hero_skills::is_normal_attack(name_to_id(name)))-expected_mul).abs()<0.00001);
        let base=amount(player().damage_enemy(&mut enemy(100000),&data,hit(name)).unwrap());
        let actual=amount(p.damage_enemy(&mut enemy(100000),&data,hit(name)).unwrap());
        assert!((actual as f32-base as f32*expected_mul).abs()<3.0);
    }
    assert!((p.hero_skills.outgoing(false,true)-1.05).abs()<0.00001);
    assert_eq!(HeroSkills::default().outgoing(true,true),1.0);
}

#[test]
fn local_hero_stat_passives_only_apply_to_hero_and_do_not_stack_on_rebuild() {
    let data=data();let mut c=CharData::default();c.character.classes.main_class=Class::Hero;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.hero_info.level1=85;
    let base=PlayerStats::build_character_levels(&data,&c,85,None).unwrap();
    for key in ["hp","attack","defense"] {c.hero_test_skills=c.hero_test_skills.with_test_rank(key,10,85).unwrap();}
    let p=PlayerStats::build_character_levels(&data,&c,85,None).unwrap();
    assert_eq!(p.max_hp,base.max_hp+50);assert_eq!(p.base_mel_pwr,base.base_mel_pwr+50);
    assert_eq!(p.base_rng_pwr,base.base_rng_pwr+50);assert_eq!(p.base_tec_pwr,base.base_tec_pwr+50);
    assert_eq!(p.dex,base.dex+50);assert_eq!(p.base_mel_def,base.base_mel_def+50);
    assert_eq!(p.base_rng_def,base.base_rng_def+50);assert_eq!(p.base_tec_def,base.base_tec_def+50);
    assert_eq!(format!("{p:?}"),format!("{:?}",PlayerStats::build_character_levels(&data,&c,85,None).unwrap()));
    c.character.classes.main_class=Class::Hunter;
    let a=PlayerStats::build_character_levels(&data,&c,85,None).unwrap();c.hero_test_skills=Default::default();
    let b=PlayerStats::build_character_levels(&data,&c,85,None).unwrap();assert_eq!(format!("{a:?}"),format!("{b:?}"));
}

#[test]
fn local_hero_flash_guard_reduces_incoming_damage_in_all_three_routes() {
    let mut data=data();
    for typ in [data_structs::stats::AttackType::Mel,data_structs::stats::AttackType::Rng,data_structs::stats::AttackType::Tec] {
        let row=&mut data.attack_stats[0];row.attack_type=typ.clone();row.defense_type=typ;row.damage=data_structs::stats::DamageType::Generic(1.0);let id=row.attack_id;
        let mut e=EnemyStats {min_mel_pwr:1000,max_mel_pwr:1000,min_rng_pwr:1000,max_rng_pwr:1000,min_tec_pwr:1000,max_tec_pwr:1000,..Default::default()};
        let mut p=PlayerStats{hp:10000,max_hp:10000,..Default::default()};
        p.hero_skills=p.hero_skills.with_test_rank("guard",10,85).unwrap();
        let result=e.damage_player(&mut p,&data,DealDamagePacket{attack_id:id,..Default::default()}).unwrap();
        assert_eq!(amount(result),189);assert_eq!(p.hp,9811);
    }
}

#[test]
fn local_hero_aura_original_damage_and_native_skill_gate(){
    let data=data();let fixture:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-hero-aura.json")).unwrap();
    let row=data.attack_stats.iter().find(|a|a.attack_id==4293352205).unwrap();
    assert_eq!(row.damage_id,name_to_id("WpnmanSword:ShotCharge2A"));
    let data_structs::stats::DamageType::Generic(m)=row.damage else {panic!()};
    assert_eq!(m.to_bits(),u32::from_str_radix(fixture["multiplier_bits"].as_str().unwrap(),16).unwrap());
    let mut p=player();let mut e=enemy(100000);
    assert!(p.damage_enemy(&mut e,&data,hit("WpnmanSword:ShotCharge2")).is_err());assert_eq!(e.hp,100000);
    p.hero_weapon=true;
    assert!(p.damage_enemy(&mut e,&data,hit("WpnmanSword:ShotCharge2")).is_err());
    for (rank,mul) in [(1,1.0),(2,1.05),(3,1.07),(4,1.09),(5,1.10)] {
        p.hero_skills=HeroSkills::default().with_test_rank("aura",rank,85).unwrap();
        let expected=(800.0_f32/5.0*1.05*m*mul).round() as u32;
        assert_eq!(amount(p.damage_enemy(&mut enemy(100000),&data,hit("WpnmanSword:ShotCharge2")).unwrap()),expected);
        assert_eq!(p.hero_skills.conditional_power(name_to_id("WpnmanSword:ShotCharge")),1.0);
    }
}

#[test]
fn local_hero_counter_rank_boost_excludes_brand_new_star_and_normal_steps(){
    let data=data();
    for (rank,mul) in [(1,1.0),(2,1.05),(3,1.07),(4,1.09),(5,1.10)] {
        let mut p=player();p.hero_weapon=true;p.hero_skills=HeroSkills::default().with_test_rank("counter",rank,85).unwrap();
        for n in ["WpnmanSword:HCSA1","WpnmanTalis:HCSA1","WpnmanTalis:HCSA1_op","WpnmanTMachineGun:HCShot"] {
            let base=amount(player().damage_enemy(&mut enemy(100000),&data,hit(n)).unwrap());
            let actual=amount(p.damage_enemy(&mut enemy(100000),&data,hit(n)).unwrap());
            assert!((actual as f32-base as f32*mul).abs()<2.0,"{n} rank {rank}");
        }
        for n in ["WpnmanTMachineGun:PA1Dodge","WpnmanTMachineGun:SA1","WpnmanSword:PA3_1"] {
            assert_eq!(amount(p.damage_enemy(&mut enemy(100000),&data,hit(n)).unwrap()),amount(player().damage_enemy(&mut enemy(100000),&data,hit(n)).unwrap()));
        }
    }
}

#[test]
fn local_hero_weak_critical_uses_max_damage_without_extra_damage_multiplier(){
    let data=data();let mut p=player();p.hero_weapon=true;p.weapon_mel_pwr=1000;
    p.hero_skills=HeroSkills::default().with_test_rank("weak",1,85).unwrap();
    let mut e=enemy(100000);e.hitboxes[0].mel_mul=2.0;
    let expected=(1800.0_f32/5.0*1.05*2.0*1.8).round() as u32;
    // Actual SoldierAnt Weak region stores the weakness in damage_mul, whereas
    // other regions store a per-damage-type multiplier. Both affect the hit.
    for (part,common) in [(2.0,1.0),(1.0,2.0)] {
        e.hitboxes[0].mel_mul=part;e.hitboxes[0].damage_mul=common;
        for _ in 0..16 {e.hp=100000;assert_eq!(amount(p.damage_enemy(&mut e,&data,hit("WpnmanSword:GA1")).unwrap()),expected);}
    }
    for (rank,bonus) in [(1,110),(2,120),(3,130),(4,140),(5,150)] {
        assert_eq!(HeroSkills::default().with_test_rank("weak",rank,85).unwrap().physical_weak_critical_bonus(),bonus);
    }
}

#[test]
fn local_hero_will_survival_returns_live_hp_then_respects_invulnerability(){
    let mut data=data();let row=&mut data.attack_stats[0];row.attack_type=data_structs::stats::AttackType::Mel;
    row.defense_type=data_structs::stats::AttackType::Mel;row.damage=data_structs::stats::DamageType::Generic(1.0);let id=row.attack_id;
    let mut e=EnemyStats{min_mel_pwr:1000,max_mel_pwr:1000,..Default::default()};
    let mut p=PlayerStats{hp:100,max_hp:100,..Default::default()};p.hero_skills=HeroSkills::default().with_test_rank("will",5,85).unwrap();p.begin_hero_quest();
    let r=e.damage_player(&mut p,&data,DealDamagePacket{attack_id:id,..Default::default()}).unwrap();
    assert!(matches!(r,BattleResult::Damaged{..}));assert_eq!(amount(r),99);assert_eq!(p.hp,1);
    assert_eq!(amount(e.damage_player(&mut p,&data,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),0);
    assert_eq!(p.hp,1);p.end_hero_quest();
    assert!(matches!(e.damage_player(&mut p,&data,DealDamagePacket{attack_id:id,..Default::default()}).unwrap(),BattleResult::Killed{..}));
}

#[test]
fn local_hero_talis_reported_roots_damage_each_tick_without_normal_bonus() {
    let data=data();
    // Original factors: 12.52 * 0.14 for Wise Hound, 4.5 for MarkShot.
    for (name,id,expected,damage_name) in [
        ("WpnmanTalis:PA2",1266037451,221,"WpnmanTalis:PA2AtkCore"),
        ("WpnmanTalis:MarkShot",692201308,567,"WpnmanTalis:MarkShotAtk")
    ] {
        assert_eq!(name_to_id(name),id);
        let row=data.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
        assert_eq!(row.damage_id,name_to_id(damage_name));
        assert!(!crate::hero_skills::is_normal_attack(id));
        let mut p=player();p.hero_weapon=true;p.hero_skills=p.hero_skills.with_test_rank("normal",5,85).unwrap();
        let mut target=enemy(10000);
        for tick in 1..=4 {
            assert_eq!(amount(p.damage_enemy(&mut target,&data,hit(name)).unwrap()),expected);
            assert_eq!(target.hp,10000-tick*expected);
        }
        let mut target=enemy(1);
        assert!(matches!(p.damage_enemy(&mut target,&data,hit(name)).unwrap(),BattleResult::Killed{..}));
        assert_eq!(target.hp,0);
    }
}

#[test]
fn local_hero_three_weapon_finishes_preserve_original_bits_and_apply_reported_hits() {
    let data=data();
    let evidence:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-hero-finish.json")).unwrap();
    let rows=evidence["attacks"].as_array().unwrap();assert_eq!(rows.len(),14);
    for r in rows {
        let name=r["row"]["attack_name"].as_str().unwrap();let id=name_to_id(name);
        assert_eq!(id,r["id"].as_u64().unwrap() as u32);
        let row=data.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        assert_eq!(row.damage_id,id);
        let data_structs::stats::DamageType::Generic(m)=row.damage else {panic!()};
        assert_eq!(m.to_bits(),u32::from_str_radix(r["multiplier_bits"].as_str().unwrap(),16).unwrap());
        let pure=match row.attack_type {data_structs::stats::AttackType::Mel=>1000.0,data_structs::stats::AttackType::Rng=>400.0,data_structs::stats::AttackType::Tec=>700.0};
        let defense=match row.defense_type {data_structs::stats::AttackType::Mel=>200.0,data_structs::stats::AttackType::Rng=>50.0,data_structs::stats::AttackType::Tec=>100.0};
        let expected=((pure-defense)/5.0*1.05*m).round() as u32;
        for hp in [100000,1] {
            let mut target=enemy(hp);
            assert_eq!(amount(player().damage_enemy(&mut target,&data,hit(name)).unwrap()),expected,"{name}");
            assert_eq!(target.hp,hp.saturating_sub(expected));
        }
    }
    for (id,m) in [(2268332858,17.0),(2268332813,42.0),(170999070,30.0)] {
        let row=data.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        assert!(matches!(row.damage,data_structs::stats::DamageType::Generic(x) if x==m));
    }
}
