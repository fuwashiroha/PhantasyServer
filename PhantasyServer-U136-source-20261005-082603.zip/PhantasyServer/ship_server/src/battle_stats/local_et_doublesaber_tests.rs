use super::*;
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use crate::etoile_combat::EtoileCombat;
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn evidence()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-et-doublesaber-attacks.json")).unwrap()}
fn target(hp:u32)->EnemyStats {EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:500,tec_def:800,
    hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:0.5,tec_mul:0.2,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn hit(name:&str)->DealDamagePacket {DealDamagePacket{attack_id:name_to_id(name),..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Etole;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.etole_info.level1=85;c.character.classes.etole_info.level2=85;c
}
#[test]
fn local_et_doublesaber_complete_damage_chains_preserve_existing_data_and_pa_ancestry() {
    let current=data();let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-et-doublesaber-com-data.mp")).unwrap();
    assert_eq!(old.attack_stats.len(),848);assert_eq!(current.attack_stats.len(),1708+4+crate::techniques::count());
    for a in &old.attack_stats {assert_eq!(serde_json::to_value(a).unwrap(),serde_json::to_value(current.attack_stats.iter().find(|n|n.attack_id==a.attack_id).unwrap()).unwrap());}
    let f=evidence();assert_eq!(f["attacks"].as_array().unwrap().len(),87);
    assert_eq!(crate::etoile_combat::new_doublesaber_attacks().len(),71);
    for row in f["attacks"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;assert_eq!(id,name_to_id(row["name"].as_str().unwrap()));
        let d=current.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        let bits=u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap();
        match &d.damage {
            DamageType::PA((pa,m))=>{assert_eq!(*pa,name_to_id(row["unique_pa_parent"].as_str().unwrap()));assert_eq!(m.to_bits(),bits);}
            DamageType::Generic(m)=>{assert!(row["unique_pa_parent"].is_null());assert_eq!(m.to_bits(),bits);}
        }
    }
    for (pa,table) in f["pa_tables"].as_object().unwrap() {for (i,bits) in table["standard_bits"].as_array().unwrap().iter().enumerate() {
        assert_eq!(crate::pa_powers::power(name_to_id(pa),i as u8+1).unwrap().to_bits(),u32::from_str_radix(bits.as_str().unwrap(),16).unwrap());
    }}
    local_unit_tests::extend_previous_items(&mut old);
    let mut a=serde_json::to_value(old).unwrap();let mut b=serde_json::to_value(current).unwrap();
    a["item_params"]["pc_attrs"]=b["item_params"]["pc_attrs"].clone();a["item_params"]["vita_attrs"]=b["item_params"]["vita_attrs"].clone();
    a.as_object_mut().unwrap().remove("attack_stats");b.as_object_mut().unwrap().remove("attack_stats");assert_eq!(a,b);
}
#[test]
fn local_et_doublesaber_each_original_hit_alias_has_one_golden_hp_change() {
    let d=data();let f=evidence();
    let mut player=PlayerStats{base_mel_pwr:1020,base_rng_pwr:1700,base_tec_pwr:2400,
        etoile_combat:EtoileCombat::build(&character(),Some(5)).unwrap(),..Default::default()};
    // (1020-100)/5 * 1.05 =193.2. Choose off-half-boundary goldens
    // for descriptor routing; explicitly test the existing f32 boundary below.
    let goldens=[
        ("GA1Damage",580),("GA2Damage",831),("GA3Damage",715),
        ("AA1Damage",580),("AA2Damage",831),("AA3Damage",715),
        ("G0PhilosophyDamage",1256),("G1PhilosophyDamage",2512),
        ("SA1Damage",1642),("SA1Damage2",3091),("SA1Damage3",1642),("SA1Damage4",3864),
        ("WA2Damage1",1024),("WA2Damage2",1739),("WA2Damage3",3864),
        ("WA3Damage1",1024),("WA3Damage2",3864),("WA3Damage3",1739),("WADamage1",850),
        ("PA1Damage1",1258),("PA1Damage2",408),("PA1Damage3",748),
        ("PA2Damage1",693),("PA2Damage2",652),("PA2Damage3",693),
        ("PA3Damage1",728),("PA3Damage4",754),("PA4Damage1",2080),("PA4Damage2",6965),
    ];
    for (suffix,expected) in goldens {
        let root=format!("MstDSaber:{suffix}");
        let aliases:Vec<_>=f["attacks"].as_array().unwrap().iter().filter(|r|r["source_roots"].as_array().unwrap().iter().any(|v|v==&root)).collect();
        assert_eq!(aliases.len(),3,"{root}");
        for row in aliases {for hp in [100000,1] {
            let mut e=target(hp);let dmg=amount(player.damage_enemy(&mut e,&d,hit(row["name"].as_str().unwrap())).unwrap());
            assert_eq!(dmg,expected,"{}",row["name"]);assert_eq!(e.hp,hp.saturating_sub(expected));
        }}
    }
    // The existing server computes the 1.05 correction in f32. This case
    // falls just below 1228.5; preserve it without claiming original parity.
    player.base_mel_pwr=1000;
    for suffix in ["","A","B"] {
        let mut enemy=target(100000);
        assert_eq!(amount(player.damage_enemy(&mut enemy,&d,hit(&format!("MstDSaber:G0PhilosophyDamage{suffix}"))).unwrap()),1228);
        assert_eq!(enemy.hp,98772);
    }
}
#[test]
fn local_et_doublesaber_new_ids_reject_wrong_class_weapon_and_non_damage_effects() {
    let d=data();let f=evidence();let mut c=character();
    for (main,sub,weapon) in [(Class::Etole,Class::Unknown,17),(Class::Hunter,Class::Etole,5),(Class::Phantom,Class::Unknown,5)] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;
        let mut player=PlayerStats{base_mel_pwr:1000,etoile_combat:EtoileCombat::build(&c,Some(weapon)).unwrap(),..Default::default()};
        for row in f["attacks"].as_array().unwrap().iter().filter(|r|r["added"]==true) {
            let mut e=target(100);assert!(matches!(player.damage_enemy(&mut e,&d,hit(row["name"].as_str().unwrap())),Err(Error::InvalidInput("etoile_attack_class_or_weapon"))));assert_eq!(e.hp,100);
        }
    }
    c.character.classes.main_class=Class::Etole;c.character.classes.sub_class=Class::Unknown;
    let mut player=PlayerStats{base_mel_pwr:1000,etoile_combat:EtoileCombat::build(&c,Some(5)).unwrap(),..Default::default()};
    for row in f["deferred"].as_array().unwrap() {
        let mut e=target(100);assert!(matches!(player.damage_enemy(&mut e,&d,hit(row["name"].as_str().unwrap())),Err(Error::NoDamageInfo(_))));assert_eq!(e.hp,100);
    }
}
