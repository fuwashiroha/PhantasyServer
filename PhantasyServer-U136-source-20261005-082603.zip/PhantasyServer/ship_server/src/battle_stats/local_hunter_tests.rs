use super::*;
use crate::{hunter_combat::HunterCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::AttackType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(0).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)} else{t}} else{t};
    let add=rank-t.rank(name);if add==0 {t} else{t.learn(0,n.x,n.y,add,85,85).unwrap()}
}
fn character(skills:&[(&str,u8)])->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
    c.character.classes.ranger_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut t=ClassTree::default().at_level(0,85).unwrap();for (n,r) in skills {t=learn(t,n,*r);}
    c.native_class_trees.insert(0,t);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_hunter_main_sub_validation_and_multiplicative_guards() {
    let mut c=character(&[("MaterialDefence1",10),("MaterialDefence2",10),("TechDefence",10),("HunterHighLevelBonus",5)]);
    for main in [Class::Hunter,Class::Ranger] {
        c.character.classes.main_class=main;c.character.classes.sub_class=if main==Class::Hunter {Class::Unknown}else{Class::Hunter};
        let h=HunterCombat::build(&c).unwrap();approx(h.incoming(AttackType::Mel),0.64);approx(h.incoming(AttackType::Rng),0.64);
        approx(h.incoming(AttackType::Tec),0.7);approx(h.outgoing(),1.05);
    }
    c.character.classes.sub_class=Class::Unknown;let h=HunterCombat::build(&c).unwrap();assert_eq!(h.hp(),0);approx(h.incoming(AttackType::Mel),1.0);approx(h.outgoing(),1.0);
    c.character.classes.sub_class=Class::Hunter;c.character.classes.hunter_info.level1=79;assert!(HunterCombat::build(&c).is_err());
    c.character.classes.hunter_info.level1=85;c.character.classes.hunter_info.level2=1;assert!(HunterCombat::build(&c).is_err());
    c.character.classes.hunter_info.level2=85;c.native_class_trees.get_mut(&0).unwrap().ranks.remove("GuardStance");assert!(HunterCombat::build(&c).is_err());
    let c=character(&[("MaterialDefence1",5),("MaterialDefence2",5)]);approx(HunterCombat::build(&c).unwrap().incoming(AttackType::Mel),0.81);
    let c=character(&[("MaterialDefence1",10)]);approx(HunterCombat::build(&c).unwrap().incoming(AttackType::Mel),0.8);
}
#[test]
fn local_hunter_full_subclass_flat_stats_stacking_units_and_reload() {
    use pso2packetlib::protocol::items::*;
    let d=data();
    for skills in [vec![("HunterHPUp1",10),("HunterHPUp2",10),("HunterHPUp3",10)],
        vec![("HunterAtpStrikeUp1",10),("HunterAtpStrikeUp2",10),("HunterAtpStrikeUp3",10),("HunterDexUp1",10),("HunterDfpStrikeUp1",10)]] {
        let mut c=character(&skills);let h=HunterCombat::build(&c).unwrap();
        if skills[0].0=="HunterHPUp1" {assert_eq!(h.hp(),225);} else{assert_eq!(h.melee(),225);assert_eq!(h.dex(),50);assert_eq!(h.defense(),50);}
        for main in [Class::Hunter,Class::Ranger] {
            c.character.classes.main_class=main;c.character.classes.sub_class=if main==Class::Hunter {Class::Unknown}else{Class::Hunter};
            let sub=if main==Class::Hunter {None}else{Some(85)};
            // A level 1 main caps subclass base stats, but not learned flat bonuses.
            let mut base=c.clone();base.native_class_trees.clear();
            let a=PlayerStats::build_character_levels(&d,&base,1,sub).unwrap();let b=PlayerStats::build_character_levels(&d,&c,1,sub).unwrap();
            assert_eq!(b.max_hp,a.max_hp+h.hp());assert_eq!(b.base_mel_pwr,a.base_mel_pwr+h.melee());assert_eq!(b.dex,a.dex+h.dex());
            assert_eq!(b.base_mel_def,a.base_mel_def+h.defense());assert_eq!(b.base_rng_def,a.base_rng_def);assert_eq!(b.base_tec_pwr,a.base_tec_pwr);
        }
        c.inventory.add_item(Item{uuid:800,id:ItemId{item_type:5,id:1,subid:0,..Default::default()},data:ItemType::Unit(UnitItem::default()),..Default::default()});
        let before=PlayerStats::build_character_levels(&d,&c,85,Some(85)).unwrap();c.inventory.equip_item(800,0).unwrap();
        let loaded:CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&c).unwrap()).unwrap();
        let after=PlayerStats::build_character_levels(&d,&loaded,85,Some(85)).unwrap();
        assert_eq!(after.max_hp,before.max_hp+10);assert_eq!(after.base_mel_def,before.base_mel_def+33);assert_eq!(after.base_mel_pwr,before.base_mel_pwr);
    }
}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_hunter_live_damage_path_selects_defense_category_and_highlevel_all_attacks() {
    let mut d=data();let id=name_to_id("StrikeAdd");
    let h=HunterCombat::build(&character(&[("MaterialDefence1",10),("MaterialDefence2",10),("TechDefence",10),("HunterHighLevelBonus",5)])).unwrap();
    for defense in [AttackType::Mel,AttackType::Rng,AttackType::Tec] {for source in [AttackType::Mel,AttackType::Rng,AttackType::Tec] {
        // Cross-category synthetic cases isolate the two descriptor channels.
        let desc=d.attack_stats.iter_mut().find(|a|a.attack_id==id).unwrap();desc.attack_type=source.clone();desc.defense_type=defense.clone();
        let mut p=PlayerStats{hp:10000,max_hp:10000,hunter_combat:h.clone(),..Default::default()};
        let mut e=EnemyStats{min_mel_pwr:1000,max_mel_pwr:1000,min_rng_pwr:1000,max_rng_pwr:1000,min_tec_pwr:1000,max_tec_pwr:1000,..Default::default()};
        let expected=match defense {AttackType::Tec=>147,_=>134};
        let got=amount(e.damage_player(&mut p,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap());assert_eq!(got,expected);assert_eq!(p.hp,10000-expected);
        let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,hunter_combat:h.clone(),..Default::default()};
        let mut e=EnemyStats{hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),220);
    }}
}
#[tokio::test]
async fn local_hunter_native_learn_durable_ack_reload_and_class_exit_preserve_hp() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
        c.character.classes.ranger_info=ClassLevel{level1:85,level2:85,exp:0};
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,0,0,0]);req[32]=10;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());
    }
    User::tick(user.lock().await).await.unwrap();let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(tokio::time::timeout(std::time::Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();finish(&user).await;
    let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&0].rank("HunterHPUp1"),10);
    {let u=user.lock().await;assert_eq!(u.get_stats().hunter_combat.hp(),50);assert_eq!(u.get_stats().hp,7);assert_eq!(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().max_hp,u.get_stats().max_hp);}
    auto_master(requests);
    for (main,sub,bonus) in [(Class::Ranger,Class::Hunter,50),(Class::Ranger,Class::Unknown,0),(Class::Hunter,Class::Unknown,50)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;assert_eq!(u.get_stats().hunter_combat.hp(),bonus);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.get_stats_mut().local_set_current_hp(0);
    let dead={let u=user.lock().await;PlayerStats::prepare_hero_update(&u,u.character.as_ref().unwrap()).unwrap()};assert_eq!(dead.hp,0);
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
