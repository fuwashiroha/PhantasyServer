use super::*;
use crate::{ranger_combat::RangerCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-ranger-weak-hit.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(1).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(1,n.x,n.y,add,85,85).unwrap()}
}
fn character(a:u8,b:u8)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Ranger;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.ranger_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut t=ClassTree::default().at_level(1,85).unwrap();if a>0 {t=learn(t,"WeakSnipeBonus1",a);}if b>0 {t=learn(t,"WeakSnipeBonus2",b);}c.native_class_trees.insert(1,t);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_ranger_weak_all_valid_rank_pairs_native_prerequisites_and_main_sub_scope() {
    let f=fixture();let id=name_to_id("Rifle:A1");
    for a in 0..=10 {for b in 0..=10 {if a<3 && b>0 {continue;}
        let mut c=character(a,b);let percent=|r:u8| if r==0 {1.0}else{f["values"][r as usize-1].as_u64().unwrap() as f32/100.0};
        for (main,sub) in [(Class::Ranger,Class::Unknown),(Class::Hunter,Class::Ranger)] {
            c.character.classes.main_class=main;c.character.classes.sub_class=sub;
            approx(RangerCombat::build(&c).unwrap().weak_hit(id,1.0,2.0),percent(a)*percent(b));
        }
        c.character.classes.sub_class=Class::Unknown;approx(RangerCombat::build(&c).unwrap().weak_hit(id,1.0,2.0),1.0);
    }}
    let mut c=character(10,10);c.native_class_trees.get_mut(&1).unwrap().ranks.remove("RangerDexUp1");assert!(RangerCombat::build(&c).is_err());
    let mut c=character(10,10);c.character.classes.ranger_info.level1=1;c.character.classes.ranger_info.level2=1;assert!(RangerCombat::build(&c).is_err());
    assert_eq!(f["ability_registry"]["WeakSnipeBonus1"]["id"],120008);assert_eq!(f["ability_registry"]["WeakSnipeBonus2"]["id"],120009);
}
#[test]
fn local_ranger_weak_original_hit_routes_threshold_and_ranged_stat_melee_exclusion() {
    let d=data();let f=fixture();let r=RangerCombat::build(&character(10,10)).unwrap();let mut seen=std::collections::HashSet::new();
    assert_eq!(f["attacks"].as_array().unwrap().len(),76);assert_eq!(f["excluded"].as_array().unwrap().len(),1980);
    for (key,bonus) in [("attacks",1.3225),("excluded",1.0)] {for hit in f[key].as_array().unwrap() {
        let id=hit["id"].as_u64().unwrap() as u32;assert!(seen.insert(id));assert_eq!(id,name_to_id(hit["name"].as_str().unwrap()));assert!(d.attack_stats.iter().any(|a|a.attack_id==id));approx(r.weak_hit(id,2.0,1.0),bonus);
    }}assert_eq!(seen.len(),2056);
    let id=name_to_id("Rifle:A1");
    for (common,ranged,expected) in [(1.0,1.149,1.0),(1.0,1.15,1.3225),(1.149,0.5,1.0),(1.15,0.5,1.3225),
        (1.1,1.0,1.0),(1.0,1.6,1.3225),(1.18,0.85,1.3225),(1.1,1.1,1.3225)] {approx(r.weak_hit(id,common,ranged),expected);}
    let crazy=name_to_id("Launcher:PA7");let a=d.attack_stats.iter().find(|a|a.attack_id==crazy).unwrap();
    assert!(matches!(a.attack_type,data_structs::stats::AttackType::Rng));assert!(matches!(a.defense_type,data_structs::stats::AttackType::Mel));approx(r.weak_hit(crazy,2.0,2.0),1.0);
    approx(r.weak_hit(u32::MAX,2.0,2.0),1.0);
}
fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_ranger_weak_actual_damage_common_or_ranged_region_and_element_once() {
    let d=data();let r=RangerCombat::build(&character(10,10)).unwrap();let id=name_to_id("Rifle:A1");
    for (common,ranged,expected) in [(1.0,1.0,273),(1.1,1.0,300),(1.0,2.0,722),(1.18,0.85,362)] {
        let mut p=PlayerStats{base_rng_pwr:1000,ranger_combat:r.clone(),..Default::default()};
        let mut e=EnemyStats{hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:common,rng_mul:ranged,fire_mul:10.0,..Default::default()}],..Default::default()};
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected);assert_eq!(e.hp,10000-expected);
    }
    use pso2packetlib::protocol::{items::*,palette::WeaponPalette,models::item_attrs::WeaponAttrs};
    let mut c=character(10,10);c.inventory.add_item(Item{uuid:900,id:ItemId{item_type:1,id:8,subid:252,..Default::default()},
        data:ItemType::Weapon(WeaponItem{element:1,force:50,..Default::default()}),..Default::default()});c.inventory.equip_item(900,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:900,..Default::default()});
    let w=crate::weapon_element::WeaponElement::build(&c,&WeaponAttrs{id:8,subid:252,rarity:1,..Default::default()}).unwrap();
    let mut p=PlayerStats{base_rng_pwr:1000,weapon_rng_pwr:243,ranger_combat:r,weapon_element:w,..Default::default()};
    let mut e=EnemyStats{hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:2.0,rng_mul:0.0,fire_mul:1.2,..Default::default()}],..Default::default()};
    // 243*.5*1.2*.21*1.3*2*1.3225 =105.28; no physical term.
    assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),105);
}
#[tokio::test]
async fn local_ranger_weak_native_learning_saved_reloaded_and_removed_on_class_exit() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};use crate::sql::local_checkpoint_tests::saved_character;
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);let id=name_to_id("Rifle:A1");
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character(0,0).character.classes;}
    for (name,rank,expected) in [("RangerDexUp1",3,1.0),("WeakSnipeBonus1",10,1.15),("WeakSnipeBonus2",10,1.3225)] {
        let n=native_class_tree::definition(1).unwrap().nodes.iter().find(|n|n.name==name).unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,1,n.x,n.y]);req[32]=rank;
        {let mut u=user.lock().await;handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}finish(&user).await;
        let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&1].rank(name),rank);
        let u=user.lock().await;assert_eq!(u.get_stats().hp,7);approx(u.get_stats().ranger_combat.weak_hit(id,1.0,2.0),expected);
        approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().ranger_combat.weak_hit(id,1.0,2.0),expected);
    }
    for (main,sub,bonus) in [(Class::Hunter,Class::Ranger,1.3225),(Class::Hunter,Class::Unknown,1.0),(Class::Ranger,Class::Unknown,1.3225)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().ranger_combat.weak_hit(id,1.0,2.0),bonus);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
