use super::*;
use crate::{luster_combat::{self,LusterCombat},native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::{DamageType,AttackType}};
use pso2packetlib::protocol::{items::*,palette::WeaponPalette};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-luster-attacks.json")).unwrap()}
fn character(learned:bool)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Luster;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.luster_info.level1=100;c.character.classes.luster_info.level2=100;
    let mut tree=ClassTree::default().at_level(14,100).unwrap();
    if learned {
        let names:std::collections::BTreeSet<_>=luster_combat::attacks().values().flat_map(|a|a.required_skills.iter()).collect();
        for name in names {let n=native_class_tree::definition(14).unwrap().nodes.iter().find(|n|&n.name==name).unwrap();tree=tree.learn(14,n.x,n.y,1,100,100).unwrap();}
    }
    c.native_class_trees.insert(14,tree);c
}
fn player()->PlayerStats {PlayerStats{base_rng_pwr:1020,base_mel_pwr:4000,base_tec_pwr:7000,
    luster_combat:LusterCombat::build(&character(true),Some(7)).unwrap(),..Default::default()}}
fn enemy(hp:u32)->EnemyStats {EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:700,tec_def:900,
    hitboxes:vec![EnemyHitbox{mel_mul:2.0,rng_mul:0.25,tec_mul:0.1,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn hit(n:&str)->DealDamagePacket {DealDamagePacket{attack_id:name_to_id(n),..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_luster_all_original_bits_pa_ancestry_and_previous_compiled_data_survive() {
    let d=data();let f=fixture();assert_eq!(luster_combat::attacks().len(),789);assert_eq!(d.attack_stats.len(),1708+4+crate::techniques::count());
    let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-luster-com-data.mp")).unwrap();assert_eq!(old.attack_stats.len(),919);
    for a in &old.attack_stats {assert_eq!(serde_json::to_value(a).unwrap(),serde_json::to_value(d.attack_stats.iter().find(|n|n.attack_id==a.attack_id).unwrap()).unwrap());}
    for a in f["attacks"].as_array().unwrap() {
        let id=a["id"].as_u64().unwrap() as u32;assert_eq!(id,name_to_id(a["name"].as_str().unwrap()));
        let row=d.attack_stats.iter().find(|r|r.attack_id==id).unwrap();
        assert!(matches!(row.attack_type,AttackType::Rng));assert!(matches!(row.defense_type,AttackType::Mel));
        assert_eq!(row.damage_id,name_to_id(a["row"]["damage_name"].as_str().unwrap()));
        let bits=u32::from_str_radix(a["multiplier_bits"].as_str().unwrap(),16).unwrap();
        match row.damage {DamageType::Generic(m)=>{assert_eq!(m.to_bits(),bits);assert!(a["unique_pa_parent"].is_null());},
            DamageType::PA((pa,m))=>{assert_eq!(m.to_bits(),bits);assert_eq!(pa,name_to_id(a["unique_pa_parent"].as_str().unwrap()));}}
    }
    for (name,t) in f["pa_tables"].as_object().unwrap() {for (i,b) in t["standard_bits"].as_array().unwrap().iter().enumerate() {
        assert_eq!(crate::pa_powers::power(name_to_id(name),i as u8+1).unwrap().to_bits(),u32::from_str_radix(b.as_str().unwrap(),16).unwrap());
    }}
    local_unit_tests::extend_previous_items(&mut old);
    let mut a=serde_json::to_value(old).unwrap();let mut b=serde_json::to_value(d).unwrap();
    a["item_params"]["pc_attrs"]=b["item_params"]["pc_attrs"].clone();a["item_params"]["vita_attrs"]=b["item_params"]["vita_attrs"].clone();
    a.as_object_mut().unwrap().remove("attack_stats");b.as_object_mut().unwrap().remove("attack_stats");assert_eq!(a,b);
}
#[test]
fn local_luster_all_aliases_hit_once_and_goldens_use_ranged_power_melee_defense_region() {
    let d=data();let f=fixture();let mut p=player();let mut damage_by_leaf=std::collections::BTreeMap::new();
    for a in f["attacks"].as_array().unwrap() {
        let name=a["name"].as_str().unwrap();let leaf=a["row"]["damage_name"].as_str().unwrap();
        let mut e=enemy(1_000_000);let dealt=amount(p.damage_enemy(&mut e,&d,hit(name)).unwrap());
        assert_eq!(e.hp,1_000_000-dealt);
        if let Some(prior)=damage_by_leaf.insert(leaf,dealt) {assert_eq!(prior,dealt,"alias {name}");}
        let mut e=enemy(1);let again=amount(p.damage_enemy(&mut e,&d,hit(name)).unwrap());
        assert_eq!(again,dealt);assert_eq!(e.hp,1u32.saturating_sub(dealt));
    }
    assert_eq!(damage_by_leaf.len(),323);
    // Independent expectations: (1020 ranged - 100 melee def)/5 *1.05 *2
    // (melee region), then the original coefficient and PA displayed power.
    for (name,expected) in [
        ("SlaGSlash:NA1_NA_Damage1",1352),("SlaGSlash:NA1_FM_Damage1",1352),
        ("SlaGSlash:NA1_ZZ_Damage1",1352),("SlaGSlash:NA1_BG_Damage1",116),
        ("SlaGSlash:NrmAtkShot_BG_Damage1_1",1314),
        ("SlaGSlash:StpAtk2_NA_Damage1",6955),("SlaGSlash:SftAtk2_FM_Damage1",6182),
        ("SlaGSlash:TimeStart_Damage1",3864),("SlaGSlash:TimeFin_Damage1",2705),
        ("SlaGSlash:TimeFin_Damage2",3091),("SlaGSlash:TimeFin_Damage3",2318),("SlaGSlash:TimeFin_Damage4",4637),
        ("SlaGSlash:PA1MS_NA_Damage1",1480),("SlaGSlash:PA1MS_ZZ_Damage1",1332),
        ("SlaGSlash:PA1SS_FM_Damage1",2530),
        ("SlaGSlash:PA2MS_NA_Damage1",1124),("SlaGSlash:PA3MS_NA_Damage1",1021),("SlaGSlash:PA4MS_NA_Damage1",1045),
    ] {assert_eq!(amount(p.damage_enemy(&mut enemy(1_000_000),&d,hit(name)).unwrap()),expected,"{name}");}
    assert!(!p.luster_combat.melee_region(name_to_id("Rifle:GA1")));
}
#[test]
fn local_luster_learned_gates_cover_aliases_and_reject_wrong_class_weapon_effect_roots() {
    let f=fixture();let d=data();let mut c=character(false);
    let unlearned=LusterCombat::build(&c,Some(7)).unwrap();
    for a in luster_combat::attacks().values() {assert_eq!(unlearned.validate_attack(a.id).is_ok(),a.required_skills.is_empty());}
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Luster;
    for combat in [LusterCombat::build(&c,Some(7)).unwrap(),LusterCombat::build(&character(true),Some(5)).unwrap(),LusterCombat::build(&character(true),None).unwrap()] {
        let mut p=player();p.luster_combat=combat;
        for a in f["attacks"].as_array().unwrap() {let mut e=enemy(100);assert!(p.damage_enemy(&mut e,&d,hit(a["name"].as_str().unwrap())).is_err());assert_eq!(e.hp,100);}
    }
    let mut p=player();
    for a in f["deferred"].as_array().unwrap() {let mut e=enemy(100);assert!(matches!(p.damage_enemy(&mut e,&d,hit(a["name"].as_str().unwrap())),Err(Error::NoDamageInfo(_))));assert_eq!(e.hp,100);}
    let mut c=character(true);c.character.classes.luster_info.level1=85;
    assert!(LusterCombat::build(&c,Some(7)).is_err(),"95-level skills must not bypass saved level validation");
}
#[test]
fn local_luster_stats_rebuild_uses_equipped_weapon_saved_ranks_and_clears_on_class_exit() {
    let d=data();let mut c=character(true);let w=d.item_params.attrs.weapons.iter().find(|w|w.id==7).unwrap();
    c.inventory.add_item(Item{uuid:110,id:ItemId{item_type:1,id:7,subid:w.subid,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
    c.inventory.equip_item(110,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:110,..Default::default()});
    let id=name_to_id("SlaGSlash:NA4_FM_Damage1");
    let p=PlayerStats::build_character_levels(&d,&c,100,None).unwrap();assert!(p.luster_combat.validate_attack(id).is_ok());
    c.native_class_trees=character(false).native_class_trees;
    assert!(PlayerStats::build_character_levels(&d,&c,100,None).unwrap().luster_combat.validate_attack(id).is_err());
    c.native_class_trees=character(true).native_class_trees;
    let wire=rmp_serde::to_vec(&c).unwrap();let mut loaded:CharData=rmp_serde::from_slice(&wire).unwrap();
    assert!(PlayerStats::build_character_levels(&d,&loaded,100,None).unwrap().luster_combat.validate_attack(id).is_ok());
    loaded.character.classes.main_class=Class::Hunter;loaded.character.classes.sub_class=Class::Luster;
    assert!(PlayerStats::build_character_levels(&d,&loaded,1,Some(100)).unwrap().luster_combat.validate_attack(id).is_err());
}
