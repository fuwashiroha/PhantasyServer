use super::*;
use crate::{techniques::{self,TechniqueCombat},native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-technique-attacks.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(2).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(2,n.x,n.y,add,85,85).unwrap()}
}
fn character(skills:&[(&str,u8)])->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut t=ClassTree::default().at_level(2,85).unwrap();for (n,r) in skills {t=learn(t,n,*r);}c.native_class_trees.insert(2,t);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,mel_def:6000,rng_def:5000,tec_def:100,
    hitboxes:vec![EnemyHitbox{mel_mul:0.01,rng_mul:0.02,tec_mul:0.03,damage_mul:1.0,fire_mul:1.2,ice_mul:1.3,thunder_mul:1.4,wind_mul:1.5,light_mul:1.6,dark_mul:1.7,..Default::default()}],..Default::default()}}
#[test]
fn local_technique_original_bits_all_tables_and_exact_compiled_delta() {
    let d=data();let f=fixture();assert_eq!(techniques::attacks().len(),282);assert_eq!(d.attack_stats.len(),2057);
    let old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-technique-com-data.mp")).unwrap();assert_eq!(old.attack_stats.len(),1708);
    let mut filtered=d.clone();filtered.attack_stats.retain(|a|!techniques::contains(a.attack_id) && !local_dagger_ground_tests::contains(a.attack_id));
    // Compiler ordering may change; compare sorted attack records and all other data.
    let mut expected=old;filtered.attack_stats.sort_by_key(|a|a.attack_id);expected.attack_stats.sort_by_key(|a|a.attack_id);
    local_rare_mastery_tests::extend_previous_items(&mut expected);expected.item_params.pc_attrs=filtered.item_params.pc_attrs.clone();expected.item_params.vita_attrs=filtered.item_params.vita_attrs.clone();
    assert!(serde_json::to_value(filtered).unwrap()==serde_json::to_value(expected).unwrap(),"unexpected non-technique data change");
    let mut ids=std::collections::HashSet::new();for a in &d.attack_stats {assert!(ids.insert(a.attack_id));}
    for row in f["attacks"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        assert_eq!(a.damage_id,name_to_id(row["row"]["damage_name"].as_str().unwrap()));
        let DamageType::PA((pa,m))=a.damage else{panic!()};assert_eq!(pa,name_to_id(row["table"].as_str().unwrap()));
        assert_eq!(m.to_bits(),u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap());
    }
    assert_eq!(f["tables"].as_object().unwrap().len(),35);
    for (name,t) in f["tables"].as_object().unwrap() {for (i,b) in t["standard_bits"].as_array().unwrap().iter().enumerate() {
        assert_eq!(crate::pa_powers::power(name_to_id(name),i as u8+1).unwrap().to_bits(),u32::from_str_radix(b.as_str().unwrap(),16).unwrap());
    }}
}
#[test]
fn local_technique_all_aliases_one_hp_change_correct_element_and_foie_golden() {
    let d=data();let f=fixture();let mut p=PlayerStats{base_tec_pwr:1100,base_mel_pwr:9000,base_rng_pwr:8000,..Default::default()};
    let mut leaves=std::collections::BTreeMap::new();
    for row in f["attacks"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;let mut e=enemy();let element=techniques::region(id,&e.hitboxes[0]).unwrap();
        let power=f["tables"][row["table"].as_str().unwrap()]["standard_values"][0].as_f64().unwrap() as f32;
        let mul=f32::from_bits(u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap());
        let expected=(1000.0f32/5.0*1.05*element*(power*mul)).round() as u32;
        let got=amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap());assert_eq!(got,expected);assert_eq!(e.hp,1000000-got);
        if let Some(previous)=leaves.insert(row["row"]["damage_name"].as_str().unwrap(),got){assert_eq!(previous,got);}
    }
    // Original Fire01 Lv1=8.25, full charged hit=100%, uncharged=33%.
    assert_eq!(crate::pa_powers::power(name_to_id("Fire01"),1).unwrap(),8.25);
    for (name,power) in [("Foie2",2079),("Foie1",686)] {assert_eq!(amount(p.damage_enemy(&mut enemy(),&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap()),power);}
    // Altering TEC region cannot multiply ordinary elemental technique damage again.
    let mut e=enemy();e.hitboxes[0].tec_mul=90.0;assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Foie2"),..Default::default()}).unwrap()),2079);
    let mut e=enemy();e.hitboxes[0].fire_mul=0.0;assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Foie2"),..Default::default()}).unwrap()),0);
    assert!(techniques::region(name_to_id("Rod:GA1"),&enemy().hitboxes[0]).is_none());
}
#[test]
fn local_technique_force_charge_skills_main_sub_all_ranks_and_original_state_split() {
    for (name,charged,values) in [
        ("TechNonChargeBonus1",false,vec![1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10]),
        ("TechChargeBonus1",true,vec![1.01,1.02,1.03,1.04,1.05,1.06,1.07,1.08,1.09,1.10]),
        ("TechChargeBonus2",true,vec![1.01,1.03,1.05,1.07,1.10]),
    ] {for (i,v) in values.iter().enumerate() {
        let c=character(&[(name,i as u8+1)]);let t=TechniqueCombat::build(&c).unwrap();
        for a in techniques::attacks().values() {approx(t.multiplier(a.id),if a.charged==charged {*v}else{1.0});}
        approx(t.multiplier(name_to_id("Rod:GA1")),1.0);
    }}
    let mut c=character(&[("TechChargeBonus1",10),("TechChargeBonus2",5),("TechNonChargeBonus1",10)]);
    for main in [Class::Force,Class::Hunter] {c.character.classes.main_class=main;c.character.classes.sub_class=if main==Class::Force {Class::Unknown}else{Class::Force};
        let t=TechniqueCombat::build(&c).unwrap();approx(t.multiplier(name_to_id("Foie2")),1.21);approx(t.multiplier(name_to_id("Foie1")),1.10);
        // Rabarta/Gimegido charged leaves retain original flag4: do not mistake it for a charge flag.
        approx(t.multiplier(name_to_id("Rabarta2")),1.21);approx(t.multiplier(name_to_id("Gimegido2")),1.21);
    }
    c.character.classes.sub_class=Class::Unknown;approx(TechniqueCombat::build(&c).unwrap().multiplier(name_to_id("Foie2")),1.0);
    c.character.classes.sub_class=Class::Force;c.character.classes.force_info.level2=1;assert!(TechniqueCombat::build(&c).is_err());
    c.character.classes.force_info.level2=85;c.native_class_trees.get_mut(&2).unwrap().ranks.remove("ForceAtpTechnicUp1");assert!(TechniqueCombat::build(&c).is_err());
}
#[tokio::test]
async fn local_technique_native_fo_learning_saved_and_class_transition_refreshes_effect() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Force;
        c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
        c.native_class_trees.insert(2,learn(ClassTree::default(),"ForceAtpTechnicUp1",1));
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,2,2,8]);req[32]=5;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
    finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&2].rank("TechChargeBonus2"),5);
    {let u=user.lock().await;approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().technique_combat.multiplier(name_to_id("Foie2")),1.1);assert_eq!(u.get_stats().hp,7);}
    for (main,sub,expected) in [(Class::Hunter,Class::Force,1.1),(Class::Hunter,Class::Unknown,1.0),(Class::Force,Class::Unknown,1.1)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().technique_combat.multiplier(name_to_id("Foie2")),expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
#[test]
fn local_technique_u116_preserves_previous_catalogue_and_every_unrelated_record() {
    let old:serde_json::Value=serde_json::from_str(include_str!("../../testdata/pre-u116-technique-attacks.json")).unwrap();
    let now=fixture();
    for row in old["attacks"].as_array().unwrap() {
        assert_eq!(now["attacks"].as_array().unwrap().iter().find(|r|r["id"]==row["id"]).unwrap(),row);
    }
    for (key,value) in old["tables"].as_object().unwrap() {assert_eq!(&now["tables"][key],value);}
    let old_ids:std::collections::HashSet<u32>=old["attacks"].as_array().unwrap().iter().map(|r|r["id"].as_u64().unwrap() as u32).collect();
    let mut previous=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-u116-com-data.mp")).unwrap();
    let mut current=data();assert_eq!(current.attack_stats.len()-previous.attack_stats.len(),208);
    current.attack_stats.retain(|a|(!techniques::contains(a.attack_id)||old_ids.contains(&a.attack_id)) && !local_dagger_ground_tests::contains(a.attack_id));
    previous.attack_stats.sort_by_key(|a|a.attack_id);current.attack_stats.sort_by_key(|a|a.attack_id);
    local_rare_mastery_tests::extend_previous_items(&mut previous);previous.item_params.pc_attrs=current.item_params.pc_attrs.clone();previous.item_params.vita_attrs=current.item_params.vita_attrs.clone();
    assert!(serde_json::to_value(previous).unwrap()==serde_json::to_value(current).unwrap(),"U116 changed previous game data");
}
#[test]
fn local_technique_u116_multi_hit_damage_charge_and_deferred_carriers() {
    let d=data();let c=character(&[("TechChargeBonus1",10),("TechChargeBonus2",5),("TechNonChargeBonus1",10)]);
    let mut p=PlayerStats{base_tec_pwr:1100,technique_combat:TechniqueCombat::build(&c).unwrap(),..Default::default()};
    // Each input represents a real damage request, not a synthetic cast or timer.
    // Keep impact separate from flames, first lightning hit separate from channel ticks.
    for (name,table,coefficient,charged,hits) in [
        ("Nafoie1","Fire06",0.50,false,1),("Nafoie2","Fire06",1.00,true,1),
        ("NafoieExp1","Fire06",0.06,false,2),("NafoieExp2","Fire06",0.13,true,5),
        ("SabartaExp1","Ice04",0.44,false,1),("SabartaExp21","Ice04",0.34,true,1),
        ("SabartaExp22","Ice04",0.34,true,1),("SabartaExp23","Ice04",0.34,true,1),
        ("Nabarta1","Ice06",1.00,false,3),
        ("Nazonde1","Thunder06",0.04,false,1),("Nazonde2","Thunder06",0.10,true,1),
        ("NazondeExp1","Thunder06",0.02,false,3),("NazondeExp2","Thunder06",0.06,true,3),
        ("Nagrantz1","Light06",0.15,false,3),("Nagrantz2","Light06",0.15,true,7),
        ("Ilgrantz1","Light07",0.07,false,3),("Ilgrantz2","Light07",0.12,true,10),
        ("Namegido1","Dark06",0.30,false,1),("Namegido2","Dark06",1.00,true,1),
    ] {
        let id=name_to_id(name);let mut e=enemy();let state=techniques::attacks().get(&id).unwrap();assert_eq!(state.charged,charged);
        let skill=if charged {1.21}else{1.10};approx(p.technique_combat.multiplier(id),skill);
        let expected=(1000.0f32/5.0*1.05*techniques::region(id,&e.hitboxes[0]).unwrap()*(crate::pa_powers::power(name_to_id(table),1).unwrap()*coefficient)*skill).round() as u32;
        for _ in 0..hits {assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected,"{name}");}
        assert_eq!(e.hp,1000000-expected*hits);
    }
    // Unresolved carriers, target-stack orchestrators and crafts must not become flat damage.
    for name in ["Sabarta1","Sabarta2","Zodiarl1","Zodiarl2","IlbartaExpS1","IlbartaExpL2","NabartaC1","BefoieC2","SezanCExp2"] {
        let id=name_to_id(name);assert!(!techniques::attacks().contains_key(&id));let mut e=enemy();
        assert!(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).is_err(),"{name}");assert_eq!(e.hp,1000000);
    }
}
