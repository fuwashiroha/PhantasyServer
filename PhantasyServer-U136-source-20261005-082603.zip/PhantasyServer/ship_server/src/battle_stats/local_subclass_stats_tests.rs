//! The 20% contribution and main-level cap come from the Classic manual.
//! Synthetic combat rows test integration with the existing formula; they do
//! not certify the complete original formula, rounding or class eligibility.
use super::*;
use data_structs::stats::{LevelStats, AttackStats, AttackType};
use pso2packetlib::protocol::models::character::{ClassLevel, Race, Gender};

fn values(s: &PlayerStats) -> [u32;8] {
    [s.max_hp,s.dex,s.base_mel_pwr,s.base_rng_pwr,s.base_tec_pwr,
        s.base_mel_def,s.base_rng_def,s.base_tec_def]
}
fn fixture() -> (ServerData,CharData) {
    let mut data=ServerData::default();
    data.player_stats.modifiers=vec![Default::default();8];
    data.player_stats.stats=vec![
        vec![LevelStats{hp:400.,dex:20.,mel_pow:120.,rng_pow:80.,tec_pow:40.,
            mel_def:60.,rng_def:50.,tec_def:30.,..Default::default()}],
        vec![LevelStats{hp:200.,dex:24.,mel_pow:20.,rng_pow:80.,tec_pow:30.,
            mel_def:40.,rng_def:45.,tec_def:50.,..Default::default()},
            LevelStats{hp:300.,dex:44.,mel_pow:40.,rng_pow:160.,tec_pow:60.,
            mel_def:80.,rng_def:90.,tec_def:100.,..Default::default()}],
    ];
    let mut c=CharData::default();c.character.classes.sub_class=Class::Unknown;
    (data,c)
}

#[test]
fn local_subclass_twenty_percent_all_base_fields_and_main_level_cap() {
    let (data,mut c)=fixture();
    for (main,sub,level,sublevel,expected) in [
        (Class::Ranger,Class::Unknown,2,None,[300,44,40,160,60,80,90,100]),
        (Class::Ranger,Class::Hunter,2,Some(1),[380,48,64,176,68,92,100,106]),
        (Class::Hunter,Class::Ranger,1,Some(2),[440,24,124,96,46,68,59,40]),
    ] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;
        let before=rmp_serde::to_vec(&c).unwrap();
        let stats=PlayerStats::build_character_levels(&data,&c,level,sublevel).unwrap();
        assert_eq!(values(&stats),expected);
        assert_eq!(stats.hp,expected[0]);
        assert_eq!(rmp_serde::to_vec(&c).unwrap(),before);
    }
}

#[test]
fn local_subclass_twenty_percent_changes_actual_attack_and_defense_damage() {
    let (mut data,mut c)=fixture();
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Ranger;
    data.player_stats.stats[0][0]=LevelStats{hp:5000.,mel_pow:500.,rng_pow:500.,tec_pow:500.,
        mel_def:100.,rng_def:200.,tec_def:300.,..Default::default()};
    data.player_stats.stats[1][0]=LevelStats{hp:1000.,mel_pow:1000.,rng_pow:1000.,tec_pow:1000.,
        mel_def:1000.,rng_def:1000.,tec_def:1000.,..Default::default()};
    data.attack_stats=[AttackType::Mel,AttackType::Rng,AttackType::Tec].into_iter().enumerate()
        .map(|(i,t)|AttackStats{attack_id:i as u32,defense_type:t.clone(),attack_type:t,..Default::default()}).collect();
    for (id,incoming) in [147,126,105].into_iter().enumerate() {
        let mut player=PlayerStats::build_character_levels(&data,&c,1,Some(1)).unwrap();
        let mut enemy=EnemyStats{hp:25000,max_hp:25000,min_mel_pwr:1000,max_mel_pwr:1000,
            min_rng_pwr:1000,max_rng_pwr:1000,min_tec_pwr:1000,max_tec_pwr:1000,
            hitboxes:vec![EnemyHitbox{damage_mul:1.,mel_mul:1.,rng_mul:1.,tec_mul:1.,..Default::default()}],
            ..Default::default()};
        let hit=DealDamagePacket{attack_id:id as u32,..Default::default()};
        // No weapon variance; existing formula is attack / 5 * 1.05.
        let BattleResult::Damaged{dmg_packet}=player.damage_enemy(&mut enemy,&data,hit.clone()).unwrap() else {panic!()};
        assert_eq!(dmg_packet.dmg_amount,147);assert_eq!(enemy.hp,24853);
        let BattleResult::Damaged{dmg_packet}=enemy.damage_player(&mut player,&data,hit).unwrap() else {panic!()};
        assert_eq!(dmg_packet.dmg_amount,incoming);assert_eq!(player.hp,5200-incoming as u32);
    }
}

#[tokio::test]
async fn local_subclass_twenty_percent_normal_build_and_equipment_update_with_compiled_rows() {
    let (sql,requests,user,_peer)=crate::user::local_equipment_save_tests::fixture().await;
    crate::user::local_equipment_save_tests::auto_master(requests);
    {
        let mut u=user.lock().await;
        let c=u.character.as_mut().unwrap();
        c.character.look.race=Race::Human;c.character.look.gender=Gender::Male;
        c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Ranger;
        c.character.classes.hunter_info=ClassLevel{level1:1,level2:1,exp:0};
        c.character.classes.ranger_info=ClassLevel{level1:1,level2:1,exp:0};
        // Independent constants from checked-in Hunter/Ranger level-1 rows
        // and Human male modifiers. Weapon contribution remains separate.
        let expected=[247,114,109,101,86,109,90,86];
        let built=PlayerStats::build(&u).unwrap();assert_eq!(values(&built),expected);
        assert_eq!(built.local_weapon_powers(),(100,0,0));
        let c=u.character.as_ref().unwrap().clone();let before=rmp_serde::to_vec(&c).unwrap();
        let prospective=PlayerStats::prepare_equipment_update(&u,&c).unwrap();
        assert_eq!(values(&prospective),expected);assert_eq!(prospective.hp,7);
        PlayerStats::update(&mut u).unwrap();assert_eq!(values(u.get_stats()),expected);
        assert_eq!(u.get_stats().hp,7);assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);
        u.queue_disconnect();
    }
    sql.drain_session_saves().await.unwrap();
}
