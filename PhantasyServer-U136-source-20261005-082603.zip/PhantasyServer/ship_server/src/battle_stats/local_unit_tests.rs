//! Original item identities + independently checked swiki rows; backend only.
use super::*;
use data_structs::SerDeFile;
use pso2packetlib::protocol::{Packet,items::*, models::character::ClassLevel};
fn data()->ServerData { ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap() }
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-unit-stats.json")).unwrap()}
pub(super) fn extend_previous_items(old:&mut ServerData) {
    let f=fixture();assert!(old.item_params.attrs.data6.is_empty());
    for row in f["rows"].as_array().unwrap() {old.item_params.attrs.data6.push(serde_json::from_value(row["attrs"].clone()).unwrap());}
    for row in f["names"].as_array().unwrap() {old.item_params.names.push(serde_json::from_value(row.clone()).unwrap());}
    local_rare_mastery_tests::extend_previous_items(old);
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    *c.character.get_level_mut()=ClassLevel{level1:1,level2:1,exp:0};c
}
fn unit(uuid:u64,id:u16,level:u8)->Item {
    Item{uuid,id:ItemId{item_type:5,id,subid:0,..Default::default()},data:ItemType::Unit(UnitItem{enh_level:level,..Default::default()}),..Default::default()}
}
fn stats(d:&ServerData,c:&CharData)->PlayerStats {PlayerStats::build_character_levels(d,c,1,None).unwrap()}
#[test]
fn local_units_exact_catalogue_delta_and_binary_roundtrip() {
    use pso2packetlib::protocol::models::item_attrs::{ItemAttributesPC,ItemAttributesVita};
    let mut current=data();current.attack_stats.retain(|a|!crate::techniques::contains(a.attack_id) && !local_dagger_ground_tests::contains(a.attack_id));let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-unit-stats-com-data.mp")).unwrap();
    extend_previous_items(&mut old);old.item_params.pc_attrs=current.item_params.pc_attrs.clone();old.item_params.vita_attrs=current.item_params.vita_attrs.clone();
    assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(&current).unwrap());
    assert_eq!(current.item_params.attrs.data6.len(),4);
    for a in current.item_params.attrs.data6.iter() {assert_eq!(a.stats.hp,10);}
    let mut bytes=vec![];current.item_params.attrs.write_attrs(&mut bytes).unwrap();
    let decoded=ItemAttributesPC::read_attrs(&mut std::io::Cursor::new(bytes)).unwrap();assert_eq!(decoded.data6,current.item_params.attrs.data6);
    let vita:ItemAttributesVita=current.item_params.attrs.clone().into();let mut bytes=vec![];vita.write_attrs(&mut bytes).unwrap();
    let decoded=ItemAttributesVita::read_attrs(&mut std::io::Cursor::new(bytes)).unwrap();assert_eq!(decoded.data6,vita.data6);
}
#[test]
fn local_units_equipped_only_each_enhancement_rank_and_per_unit_rounding() {
    let d=data();let base=stats(&d,&character());
    for id in 1..=4 {for level in 0..=10 {
        let mut c=character();c.inventory.add_item(unit(200,id,level));
        assert_eq!(stats(&d,&c).max_hp,base.max_hp,"bag items grant no bonus");
        c.inventory.equip_item(200,0).unwrap();let s=stats(&d,&c);
        let defense=if id==4 {[25,10,10]}else{[33,24,47]};
        let percent=fixture()["enhancement_percent"][level as usize].as_u64().unwrap() as u32;
        assert_eq!([s.base_mel_def-base.base_mel_def,s.base_rng_def-base.base_rng_def,s.base_tec_def-base.base_tec_def],defense.map(|n|n*percent/100));
        assert_eq!(s.max_hp,base.max_hp+10);assert_eq!(s.dex,base.dex);
        let saved:CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&c).unwrap()).unwrap();assert_eq!(stats(&d,&saved).max_hp,s.max_hp);
    }}
    let mut c=character();for i in 0..3 {c.inventory.add_item(unit(300+i,4,1));c.inventory.equip_item(300+i,i as u32).unwrap();}
    let s=stats(&d,&c);assert_eq!(s.base_rng_def-base.base_rng_def,30,"floor each unit 10*1.04 before summing");assert_eq!(s.max_hp-base.max_hp,30);
}
#[test]
fn local_units_actual_incoming_damage_changes_and_invalid_records_reject() {
    let mut d=data();let base=stats(&d,&character());let mut c=character();c.inventory.add_item(unit(200,1,10));c.inventory.equip_item(200,0).unwrap();
    let mut naked=base.clone();let mut equipped=stats(&d,&c);
    // Same real damage descriptor, deterministic synthetic enemy; non-elemental
    // defense contribution is tested separately from pending resistance work.
    let attack=DealDamagePacket{attack_id:data_structs::name_to_id("StrikeAdd"),..Default::default()};
    let mut enemy=EnemyStats{min_mel_pwr:base.base_mel_def+500,max_mel_pwr:base.base_mel_def+500,..Default::default()};
    fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
    let a=amount(enemy.damage_player(&mut naked,&d,attack.clone()).unwrap());let b=amount(enemy.damage_player(&mut equipped,&d,attack).unwrap());assert!(b<a);
    d.item_params.attrs.data6.clear();assert!(stats_result(&d,&c).is_err());
    fn stats_result(d:&ServerData,c:&CharData)->Result<PlayerStats,Error>{PlayerStats::build_character_levels(d,c,1,None)}
    let d=data();let mut c=character();c.inventory.add_item(unit(200,1,11));c.inventory.equip_item(200,0).unwrap();assert!(stats_result(&d,&c).is_err());
}
#[tokio::test]
async fn local_units_real_equip_unequip_durable_readback_preserves_injured_and_dead_hp() {
    use crate::user::{packet_handler,local_equipment_save_tests::{fixture as user_fixture,auto_master,finish}};
    let (sql,requests,user,_peer)=user_fixture().await;auto_master(requests);
    let base;
    {
        let mut u=user.lock().await;
        assert_eq!(u.get_blockdata().server_data.item_params.attrs.data6.len(),4);
        base=u.get_stats().max_hp;u.character.as_mut().unwrap().inventory.add_item(unit(900,1,10));
    }
    packet_handler(user.lock().await,Packet::EquipItemRequest(EquipItemRequestPacket{uuid:900,equipment_pos:0,..Default::default()})).await.unwrap();
    assert!(!user.lock().await.accepts_client_packets());finish(&user).await;
    {let u=user.lock().await;assert_eq!(u.get_stats().get_hp(),(7,base+10));}
    let saved=crate::sql::local_checkpoint_tests::saved_character(&sql,1,1).await;assert_eq!(saved.inventory.equipped_units().unwrap().len(),1);
    let before=rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap();
    let transfer=Packet::MoveToStorageRequest(MoveToStorageRequestPacket{uuids:vec![MoveStorageItemRequest{uuid:900,amount:1,storage_id:0,..Default::default()}]});
    assert!(packet_handler(user.lock().await,transfer.clone()).await.is_err());
    assert_eq!(rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap(),before);
    assert!(user.lock().await.accepts_client_packets());
    assert_eq!(user.lock().await.get_stats().get_hp(),(7,base+10));
    {user.lock().await.get_stats_mut().local_set_current_hp(0);}
    packet_handler(user.lock().await,Packet::UnequipItemRequest(UnequipItemRequestPacket{uuid:900,equipment_pos:0,..Default::default()})).await.unwrap();finish(&user).await;
    assert_eq!(user.lock().await.get_stats().get_hp(),(0,base));
    assert!(crate::sql::local_checkpoint_tests::saved_character(&sql,1,1).await.inventory.equipped_units().unwrap().is_empty());
    packet_handler(user.lock().await,transfer).await.unwrap();finish(&user).await;
    assert!(user.lock().await.character.as_ref().unwrap().inventory.get_inv_item(900).is_err());
    assert_eq!(user.lock().await.get_stats().get_hp(),(0,base));
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
