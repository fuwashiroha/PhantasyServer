use super::*;
use crate::{techniques::{self,TechniqueCombat},native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-element-masteries.json")).unwrap()}
fn learn(t:ClassTree,slot:u8,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,slot,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Techer;
    c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.techer_info=ClassLevel{level1:85,level2:85,exp:0};
    c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn full()->CharData {
    let mut c=character();for row in fixture()["skills"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let tree=c.native_class_trees.remove(&slot).unwrap_or_default();
        c.native_class_trees.insert(slot,learn(tree,slot,row["name"].as_str().unwrap(),row["node"]["max_rank"].as_u64().unwrap() as u8));
    }
    let mut tree=c.native_class_trees.remove(&2).unwrap();for (name,rank) in [("TechChargeBonus1",10),("TechChargeBonus2",5),("TechNonChargeBonus1",10)] {tree=learn(tree,2,name,rank);}
    c.native_class_trees.insert(2,tree);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_mastery_all_twelve_original_nodes_every_rank_element_and_prerequisites() {
    let f=fixture();assert_eq!(f["skills"].as_array().unwrap().len(),12);
    for row in f["skills"].as_array().unwrap() {
        let slot=row["slot"].as_u64().unwrap() as u8;let name=row["name"].as_str().unwrap();
        let node=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();assert_eq!(node.max_rank,row["percent"].as_array().unwrap().len() as u8);
        for (i,pct) in row["percent"].as_array().unwrap().iter().enumerate() {
            let mut c=character();let t=learn(ClassTree::default(),slot,name,i as u8+1);c.native_class_trees.insert(slot,t);
            let tc=TechniqueCombat::build(&c).unwrap();let expected=pct.as_f64().unwrap() as f32/100.0 * if name.ends_with('2') {1.08}else{1.0};
            for a in techniques::attacks().values() {approx(tc.multiplier(a.id),if a.element==row["element"].as_str().unwrap(){expected}else{1.0});}
            // All max-rank values and intermediate values went through real prerequisite/SP validation.
            c.native_class_trees.get_mut(&slot).unwrap().ranks.remove(node.parent.as_ref().unwrap());assert!(TechniqueCombat::build(&c).is_err());
        }
    }
}
#[test]
fn local_mastery_fo_te_main_sub_stacking_and_nontech_exclusions() {
    let mut c=full();
    for (main,sub,has_fo,has_te) in [(Class::Force,Class::Techer,true,true),(Class::Techer,Class::Force,true,true),
        (Class::Force,Class::Unknown,true,false),(Class::Techer,Class::Unknown,false,true),(Class::Hunter,Class::Techer,false,true),(Class::Hunter,Class::Unknown,false,false)] {
        c.character.classes.main_class=main;c.character.classes.sub_class=sub;let t=TechniqueCombat::build(&c).unwrap();
        for a in techniques::attacks().values() {
            let covered=if matches!(a.element.as_str(),"fire"|"ice"|"thunder"){has_fo}else{has_te};
            let expected=if covered{1.44}else{1.0} * if has_fo {if a.charged{1.21}else{1.10}}else{1.0};approx(t.multiplier(a.id),expected);
        }
        for name in ["Rod:GA1","Wand:GA1","Shifta","Deband","Resta","ZanbarseChaseA"] {approx(t.multiplier(name_to_id(name)),1.0);}
    }
    c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Techer;c.character.classes.techer_info.level2=1;assert!(TechniqueCombat::build(&c).is_err());
}
#[test]
fn local_mastery_actual_damage_multiplies_element_and_charge_once() {
    let d=data();let c=full();let mut p=PlayerStats{base_tec_pwr:1100,technique_combat:TechniqueCombat::build(&c).unwrap(),..Default::default()};
    let f:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-technique-attacks.json")).unwrap();
    for a in f["attacks"].as_array().unwrap() {
        let id=a["id"].as_u64().unwrap() as u32;let mut e=EnemyStats{hp:1000000,max_hp:1000000,tec_def:100,
            hitboxes:vec![EnemyHitbox{tec_mul:0.03,damage_mul:1.0,fire_mul:1.2,ice_mul:1.2,thunder_mul:1.2,wind_mul:1.2,light_mul:1.2,dark_mul:1.2,..Default::default()}],..Default::default()};
        let power=f["tables"][a["table"].as_str().unwrap()]["standard_values"][0].as_f64().unwrap() as f32;
        let mul=f32::from_bits(u32::from_str_radix(a["multiplier_bits"].as_str().unwrap(),16).unwrap());let skill=1.44f32*if a["charged"].as_bool().unwrap(){1.21}else{1.10};
        let expected=(1000.0f32/5.0*1.05*1.2*(power*mul)*skill).round() as u32;
        let BattleResult::Damaged{dmg_packet}=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap() else{panic!()};
        assert_eq!(dmg_packet.dmg_amount as u32,expected);assert_eq!(e.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_mastery_native_te_learning_durable_reply_reload_and_class_exit() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Techer;
        c.character.classes.techer_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
        c.native_class_trees.insert(5,learn(ClassTree::default(),5,"MasteryWind1",2));
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,5,0,12]);req[32]=5;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
    User::tick(user.lock().await).await.unwrap();let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(tokio::time::timeout(std::time::Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();finish(&user).await;
    let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&5].rank("MasteryWind2"),5);
    {let u=user.lock().await;approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().technique_combat.multiplier(name_to_id("Zan2")),1.296);assert_eq!(u.get_stats().hp,7);}
    auto_master(requests);
    for (main,sub,expected) in [(Class::Hunter,Class::Techer,1.296),(Class::Hunter,Class::Unknown,1.0),(Class::Techer,Class::Unknown,1.296)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().technique_combat.multiplier(name_to_id("Zan2")),expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
