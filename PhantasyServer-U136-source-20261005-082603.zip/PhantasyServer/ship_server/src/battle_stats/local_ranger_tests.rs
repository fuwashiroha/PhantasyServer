use super::*;
use crate::{ranger_combat::RangerCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::AttackType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(1).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)} else{t}} else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(1,n.x,n.y,add,85,85).unwrap()}
}
fn character(skills:&[(&str,u8)])->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Ranger;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.ranger_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
    let mut t=ClassTree::default().at_level(1,85).unwrap();for (n,r) in skills {t=learn(t,n,*r);}c.native_class_trees.insert(1,t);c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_ranger_main_sub_flat_stats_native_gates_and_hunter_stacking() {
    let d=data();let mut c=character(&[("RangerAtpFirearmUp1",10),("RangerAtpFirearmUp2",10),("RangerDexUp1",10),
        ("RangerDexUp2",10),("RangerDexUp3",10),("RangerDfpFirearmUp1",10),("RangerHighLevelBonus",5),("FirstHit",5)]);
    for main in [Class::Ranger,Class::Hunter] {
        c.character.classes.main_class=main;c.character.classes.sub_class=if main==Class::Ranger {Class::Unknown}else{Class::Ranger};
        let sub=if main==Class::Ranger {None}else{Some(85)};
        let r=RangerCombat::build(&c).unwrap();assert_eq!(r.ranged(),125);assert_eq!(r.dex(),225);assert_eq!(r.defense(),50);approx(r.outgoing(100,100),1.26);
        let mut base=c.clone();base.native_class_trees.clear();
        let a=PlayerStats::build_character_levels(&d,&base,1,sub).unwrap();let b=PlayerStats::build_character_levels(&d,&c,1,sub).unwrap();
        assert_eq!(b.base_rng_pwr,a.base_rng_pwr+125);assert_eq!(b.base_rng_def,a.base_rng_def+50);assert_eq!(b.dex,a.dex+225);
        assert_eq!(b.max_hp,a.max_hp);assert_eq!(b.base_mel_pwr,a.base_mel_pwr);assert_eq!(b.base_tec_pwr,a.base_tec_pwr);
    }
    // Hu and Ra can be learned together; only each class's stat channels increase.
    let mut h=ClassTree::default();h=h.learn(0,0,0,10,85,85).unwrap();c.native_class_trees.insert(0,h);
    let p=PlayerStats::build_character_levels(&d,&c,85,Some(85)).unwrap();assert_eq!(p.hunter_combat.hp(),50);assert_eq!(p.ranger_combat.ranged(),125);
    let decoded:CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&c).unwrap()).unwrap();assert_eq!(PlayerStats::build_character_levels(&d,&decoded,85,Some(85)).unwrap().max_hp,p.max_hp);
    c.character.classes.sub_class=Class::Unknown;assert_eq!(RangerCombat::build(&c).unwrap().dex(),0);
    c.character.classes.sub_class=Class::Ranger;c.character.classes.ranger_info.level1=79;assert!(RangerCombat::build(&c).is_err());
    c.character.classes.ranger_info.level1=85;c.character.classes.ranger_info.level2=1;assert!(RangerCombat::build(&c).is_err());
    c.character.classes.ranger_info.level2=85;c.native_class_trees.get_mut(&1).unwrap().ranks.remove("RangerDexUp1");assert!(RangerCombat::build(&c).is_err());
}
fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_ranger_first_hit_all_attack_types_target_hp_each_hit_and_other_players() {
    let mut d=data();let id=name_to_id("StrikeAdd");
    let r=RangerCombat::build(&character(&[("FirstHit",5),("RangerHighLevelBonus",5)])).unwrap();
    approx(r.outgoing(0,0),1.05);approx(r.outgoing(0,100),1.05);approx(r.outgoing(99,100),1.05);
    for source in [AttackType::Mel,AttackType::Rng,AttackType::Tec] {
        d.attack_stats.iter_mut().find(|a|a.attack_id==id).unwrap().attack_type=source;
        let player=||PlayerStats{base_mel_pwr:100,base_rng_pwr:100,base_tec_pwr:100,ranger_combat:r.clone(),..Default::default()};
        let enemy=||EnemyStats{hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
        let a=DealDamagePacket{attack_id:id,..Default::default()};let mut e=enemy();let mut p=player();
        assert_eq!(amount(p.damage_enemy(&mut e,&d,a.clone()).unwrap()),26);
        assert_eq!(amount(p.damage_enemy(&mut e,&d,a.clone()).unwrap()),22);
        // A different attacker must not regain the target's first-hit bonus.
        assert_eq!(amount(player().damage_enemy(&mut e,&d,a.clone()).unwrap()),22);assert_eq!(e.hp,10000-70);
        let mut fresh=enemy();assert_eq!(amount(p.damage_enemy(&mut fresh,&d,a.clone()).unwrap()),26);
        let mut damaged=enemy();damaged.hp-=1;assert_eq!(amount(p.damage_enemy(&mut damaged,&d,a).unwrap()),22);
    }
}
#[tokio::test]
async fn local_ranger_native_learning_durable_reload_and_main_sub_removal() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,mut requests,user,mut peer)=fixture().await;
    {
        let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Ranger;
        c.character.classes.ranger_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,1,2,2]);req[32]=10;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());
    }
    User::tick(user.lock().await).await.unwrap();let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
    assert!(tokio::time::timeout(std::time::Duration::from_millis(20),peer.read_packet_async()).await.is_err());
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();finish(&user).await;
    let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&1].rank("RangerAtpFirearmUp1"),10);
    {let u=user.lock().await;assert_eq!(u.get_stats().ranger_combat.ranged(),50);assert_eq!(u.get_stats().hp,7);assert_eq!(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().base_rng_pwr,u.get_stats().base_rng_pwr);}
    auto_master(requests);
    for (main,sub,bonus) in [(Class::Hunter,Class::Ranger,50),(Class::Hunter,Class::Unknown,0),(Class::Ranger,Class::Unknown,50)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;assert_eq!(u.get_stats().ranger_combat.ranged(),bonus);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
