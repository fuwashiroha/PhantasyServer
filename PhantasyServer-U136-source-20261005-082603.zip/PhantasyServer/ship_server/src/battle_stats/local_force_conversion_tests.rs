use super::*;
use crate::{techniques::{self,TechniqueCombat},native_class_tree::ClassTree,weapon_element::WeaponElement};
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,items::*,palette::*,models::{character::ClassLevel,item_attrs::WeaponAttrs}};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-force-element-conversion.json")).unwrap()}
fn item(uuid:u64,element:u8,force:u8)->Item {Item{uuid,id:ItemId{item_type:1,id:13,..Default::default()},data:ItemType::Weapon(WeaponItem{element,force,..Default::default()}),..Default::default()}}
fn character(rank:u8,element:u8,force:u8)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.force_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.techer_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};
    if rank>0 {c.native_class_trees.insert(2,ClassTree::default().learn(2,4,5,rank,85,85).unwrap());}
    c.inventory.add_item(item(900,element,force));c.inventory.equip_item(900,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:900,..Default::default()});c
}
fn weapon(c:&CharData)->WeaponElement {WeaponElement::build(c,&WeaponAttrs{id:13,rarity:13,..Default::default()}).unwrap()}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
#[test]
fn local_force_conversion_source_all_ranks_elements_strengths_and_main_only_gate() {
    let f=fixture();assert_eq!(f["node"]["name"],"ErementConversion");assert_eq!(f["ability_registry"]["id"],130030);
    let id=name_to_id("Foie1");
    for rank in 0..=5 {for element in 0..=6 {for strength in 0..=60 {
        let mut c=character(rank,element,strength);let w=weapon(&c);let tc=TechniqueCombat::build(&c).unwrap();
        let expected=if rank==0 || element==0 {1.0}else{1.0+strength as f32/100.0*f["percent"][if element==1 {"同属性値変換率"}else{"他属性値変換率"}][rank as usize-1].as_u64().unwrap() as f32/100.0};
        approx(tc.element_conversion(id,w),expected);
        c.character.classes.main_class=Class::Techer;c.character.classes.sub_class=Class::Force;approx(TechniqueCombat::build(&c).unwrap().element_conversion(id,w),1.0);
    }}}
    let mut c=character(5,1,50);c.character.classes.force_info.level1=1;c.character.classes.force_info.level2=1;assert!(TechniqueCombat::build(&c).is_err());
}
#[test]
fn local_force_conversion_every_original_technique_hit_and_nontech_exclusion() {
    let all=techniques::attacks().values().map(|a|(a.id,a.element.as_str())).chain(techniques::compounds().values().map(|a|(a.id,a.element.as_str()))).collect::<Vec<_>>();assert_eq!(all.len(),345);
    for (kind,element) in [(1,"fire"),(2,"ice"),(3,"thunder"),(4,"wind"),(5,"light"),(6,"dark")] {
        let c=character(5,kind,60);let tc=TechniqueCombat::build(&c).unwrap();let w=weapon(&c);
        for (id,hit_element) in &all {approx(tc.element_conversion(*id,w),if *hit_element==element {1.30}else{1.27});}
        for id in data().attack_stats.iter().map(|a|a.attack_id).filter(|id|!techniques::contains(*id)) {approx(tc.element_conversion(id,w),1.0);}
        approx(tc.element_conversion(u32::MAX,w),1.0);
    }
    for e in fixture()["examples"].as_array().unwrap() {let strength=e["strength"].as_u64().unwrap() as u8;let c=character(5,1,strength);let w=weapon(&c);
        approx(w.technique_conversion(5,"fire"),1.0+e["match_percent"].as_f64().unwrap() as f32/100.0);approx(w.technique_conversion(5,"ice"),1.0+e["mismatch_percent"].as_f64().unwrap() as f32/100.0);
    }
}
fn amount(r:BattleResult)->u32 {match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_force_conversion_actual_original_technique_damage_and_te_ewh_stack_once() {
    let d=data();
    for (name,kind,strength,ewh,expected) in [("Foie1",1,50,false,715),("Foie1",2,50,false,700),("Foie1",1,60,false,743),("Foie1",2,60,false,726),
        ("Foie1",1,50,true,858),("ZanZondeWind",4,50,false,2599),("ZanZondeWind",1,50,false,2547)] {
        let mut c=character(5,kind,strength);
        if ewh {c.character.classes.sub_class=Class::Techer;c.native_class_trees.insert(5,ClassTree::default().learn(5,0,0,3,85,85).unwrap().learn(5,5,11,5,85,85).unwrap());}
        let mut p=PlayerStats{base_tec_pwr:1000,technique_combat:TechniqueCombat::build(&c).unwrap(),weapon_element:weapon(&c),..Default::default()};
        let mut e=EnemyStats{name:"SoldierAnt".into(),hp:10000,max_hp:10000,hitboxes:vec![EnemyHitbox{damage_mul:1.0,tec_mul:9.0,fire_mul:1.0,wind_mul:1.0,..Default::default()}],..Default::default()};
        // Original level1 hit factors: Foie1=8.25*.33; ZanZondeWind=30*.33.
        // At1000TEC the base values are571.725 /2079 before EC and optional EWH.
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id(name),..Default::default()}).unwrap()),expected,"{name} {kind} {strength} {ewh}");assert_eq!(e.hp,10000-expected);
    }
}
#[tokio::test]
async fn local_force_conversion_native_learning_palette_save_reload_and_main_class_exit() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master,extend_fixture_weapon_attrs},handlers};use crate::sql::local_checkpoint_tests::saved_character;
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);let d=data();let id=name_to_id("Foie1");
    {let mut u=user.lock().await;extend_fixture_weapon_attrs(&mut u,d.item_params.attrs.weapons.iter().cloned());let c=u.character.as_mut().unwrap();c.character.classes=character(0,0,0).character.classes;
        c.inventory.add_item(item(900,1,50));c.inventory.add_item(item(901,2,50));c.inventory.equip_item(900,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:900,..Default::default()});
        let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,2,4,5]);req[32]=5;handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
    finish(&user).await;assert_eq!(saved_character(&sql,1,1).await.native_class_trees[&2].rank("ErementConversion"),5);
    for (uuid,expected) in [(900,1.25),(901,1.225),(110,1.0),(900,1.25)] {
        let mut req=UpdatePalettePacket::default();req.palettes[0].uuid=uuid;crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(req)).await.unwrap();finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;let p=u.get_stats();approx(p.technique_combat.element_conversion(id,p.weapon_element),expected);assert_eq!(p.hp,7);
        let p=PlayerStats::prepare_equipment_update(&u,&saved).unwrap();approx(p.technique_combat.element_conversion(id,p.weapon_element),expected);
    }
    for (main,sub,bonus) in [(Class::Techer,Class::Force,1.0),(Class::Force,Class::Techer,1.25),(Class::Hunter,Class::Force,1.0),(Class::Force,Class::Unknown,1.25)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;let p=u.get_stats();approx(p.technique_combat.element_conversion(id,p.weapon_element),bonus);assert_eq!(p.hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
