use super::*;
use crate::{luster_combat::LusterCombat,native_class_tree::ClassTree};
use data_structs::{SerDeFile,name_to_id,stats::{AttackType,DamageType}};
use pso2packetlib::protocol::{Packet,items::*,palette::*,models::character::ClassLevel,objects::ChangeClassRequestPacket};
const CASES:[(Class,&str,f32,f32);9]=[
    (Class::Hunter,"Hu",1.40,1.45),(Class::Fighter,"Fi",1.10,1.15),
    (Class::Ranger,"Ra",2.50,1.10),(Class::Gunner,"Gu",1.60,1.30),
    (Class::Force,"Fo",2.50,2.40),(Class::Techer,"Te",1.90,1.85),
    (Class::Braver,"Br",1.90,1.85),(Class::Bouncer,"Bo",1.80,1.70),(Class::Summoner,"Su",1.55,1.50)];
fn character()->CharData {
    let mut c=CharData::default();
    for class in CASES.iter().map(|x|x.0).chain([Class::Luster]) {
        c.character.classes.main_class=class;*c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};
    }
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Luster;c
}
fn approx(a:f32,b:f32) {assert!((a-b).abs()<0.00001,"{a} != {b}");}
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}

#[test]
fn local_sub_luster_nine_raw_tables_and_original_initial_node_without_sp() {
    let f:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-sub-luster-gunslash.json")).unwrap();
    assert_eq!(f["original_node"]["name"],"SlayerTalent");assert_eq!(f["original_node"]["initial"],true);assert_eq!(f["original_effect"]["kind"],16);
    let t=ClassTree::default().at_level(14,1).unwrap();assert_eq!(t.rank("SlayerTalent"),1);assert_eq!(t.spent(14).unwrap(),0);
    let mut c=character();c.character.classes.luster_info=ClassLevel{level1:1,level2:1,exp:0};
    for (class,label,melee,ranged) in CASES {
        let row=f["raw_factors"].as_array().unwrap().iter().find(|r|r[0]==label).unwrap();
        approx(row[1].as_str().unwrap().trim_end_matches('%').parse::<f32>().unwrap()/100.0,melee);
        approx(row[2].as_str().unwrap().trim_end_matches('%').parse::<f32>().unwrap()/100.0,ranged);
        c.character.classes.main_class=class;let effect=LusterCombat::build(&c,Some(7)).unwrap();
        approx(effect.multiplier(AttackType::Mel),melee);approx(effect.multiplier(AttackType::Rng),ranged);approx(effect.multiplier(AttackType::Tec),1.0);
    }
}

#[test]
fn local_sub_luster_weapon_class_and_technique_gates_and_tree_validation() {
    let mut c=character();
    for (class,_,_,_) in CASES {
        c.character.classes.main_class=class;
        for weapon in [None,Some(1),Some(8),Some(18)] {
            let effect=LusterCombat::build(&c,weapon).unwrap();
            for ty in [AttackType::Mel,AttackType::Rng,AttackType::Tec] {approx(effect.sub_gunslash(ty),1.0);}
        }
        assert!(LusterCombat::build(&c,Some(7)).unwrap().validate_attack(name_to_id("SlaGSlash:NA1_NA_Damage1")).is_err());
    }
    for class in [Class::Unknown,Class::Hero,Class::Phantom,Class::Etole,Class::Luster] {
        c.character.classes.main_class=class;let effect=LusterCombat::build(&c,Some(7)).unwrap();
        approx(effect.sub_gunslash(AttackType::Mel),1.0);approx(effect.sub_gunslash(AttackType::Rng),1.0);
    }
    c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    approx(LusterCombat::build(&c,Some(7)).unwrap().sub_gunslash(AttackType::Rng),1.0);
    c.character.classes.sub_class=Class::Luster;
    c.native_class_trees.insert(14,ClassTree {ranks:std::collections::BTreeMap::from([("SlayerAllAttackBonus".into(),11)]),..Default::default()});
    assert!(LusterCombat::build(&c,Some(7)).is_err());
}

#[test]
fn local_sub_luster_all_original_gunslash_hits_and_mixed_pa_damage_apply_once() {
    let d=data();
    let source:serde_json::Value=serde_json::from_str(include_str!("../../../data/attack_stats/player/common/gunslash.json")).unwrap();
    assert!(source.as_array().unwrap().len()>20);
    let mut c=character();
    for (class,_,melee,ranged) in CASES {
        c.character.classes.main_class=class;
        let mut p=PlayerStats{base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,luster_combat:LusterCombat::build(&c,Some(7)).unwrap(),..Default::default()};
        for row in source.as_array().unwrap() {
            let id=name_to_id(row["attack_name"].as_str().unwrap());let hit=d.attack_stats.iter().find(|h|h.attack_id==id).unwrap();
            let factor=match hit.attack_type {AttackType::Mel=>melee,AttackType::Rng=>ranged,AttackType::Tec=>panic!("ordinary gunslash fixture unexpectedly TEC")};
            let power=match hit.damage {DamageType::Generic(m)=>m,DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
            let expected=(900.0f32/5.0*1.05*power*factor).round() as u32;
            for hp in [100000,1] {
                let mut e=EnemyStats{hp,max_hp:hp,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()};
                assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected);
                assert_eq!(e.hp,hp.saturating_sub(expected));
            }
        }
        // Actual technique request remains unboosted despite equipped Gunslash.
        let mut e=EnemyStats{hp:100000,max_hp:100000,tec_def:100,hitboxes:vec![EnemyHitbox{damage_mul:1.0,fire_mul:1.0,..Default::default()}],..Default::default()};
        let first=amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Foie1"),..Default::default()}).unwrap());
        p.luster_combat=LusterCombat::default();
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Foie1"),..Default::default()}).unwrap()),first);
    }
}

#[tokio::test]
async fn local_sub_luster_saved_palette_and_main_sub_changes_rebuild_bonus() {
    use crate::user::local_equipment_save_tests::{fixture,auto_master,finish,extend_fixture_weapon_attrs};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);let d=data();
    {let mut u=user.lock().await;extend_fixture_weapon_attrs(&mut u,d.item_params.attrs.weapons.iter().cloned());let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;
        c.inventory.add_item(Item{uuid:900,id:ItemId{item_type:1,id:7,subid:229,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
        c.palette.set_palette_data(2,WeaponPalette{uuid:900,..Default::default()});}
    for (palette,factor) in [(2,1.45),(0,1.0),(2,1.45)] {
        crate::user::packet_handler(user.lock().await,Packet::SetPalette(SetPalettePacket{palette,..Default::default()})).await.unwrap();finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;
        approx(u.get_stats().luster_combat.sub_gunslash(AttackType::Rng),factor);assert_eq!(u.get_stats().hp,7);
        approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().luster_combat.sub_gunslash(AttackType::Rng),factor);
    }
    for (main,sub,factor) in [(Class::Force,Class::Luster,2.40),(Class::Force,Class::Unknown,1.0),(Class::Ranger,Class::Luster,1.10),(Class::Luster,Class::Unknown,1.0)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;
        approx(u.get_stats().luster_combat.sub_gunslash(AttackType::Rng),factor);assert_eq!(u.get_stats().hp,7);
        approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().luster_combat.sub_gunslash(AttackType::Rng),factor);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
