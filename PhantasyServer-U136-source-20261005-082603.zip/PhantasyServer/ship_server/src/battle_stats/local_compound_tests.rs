use super::*;
use crate::{techniques::{self,TechniqueCombat},native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,items::*,palette::WeaponPalette};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-compound-techniques.json")).unwrap()}
fn learn(t:ClassTree,slot:u8,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(slot).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,slot,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(slot,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Force;c.character.classes.sub_class=Class::Techer;
    for slot in [0,2,5] {let info=ClassLevel{level1:85,level2:85,exp:0};match slot {0=>c.character.classes.hunter_info=info,2=>c.character.classes.force_info=info,_=>c.character.classes.techer_info=info};}
    c
}
fn equip(c:&mut CharData,d:&ServerData,id:u16) {
    let w=d.item_params.attrs.weapons.iter().find(|w|w.id==id).unwrap();let uuid=10000+u64::from(id);
    c.inventory.add_item(Item{uuid,id:ItemId{item_type:1,id,subid:w.subid,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
    c.inventory.equip_item(uuid,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid,..Default::default()});
}
fn full()->CharData {
    let mut c=character();for (slot,names) in [(2,["MasteryFire","MasteryIce","MasteryLightning"]),(5,["MasteryWind","MasteryLight","MasteryDark"])] {
        let mut tree=ClassTree::default();for name in names {tree=learn(tree,slot,&format!("{name}1"),10);tree=learn(tree,slot,&format!("{name}2"),5);}
        if slot==2 {for (name,rank) in [("TechChargeBonus1",10),("TechChargeBonus2",5),("TechNonChargeBonus1",10)] {tree=learn(tree,slot,name,rank);}}
        c.native_class_trees.insert(slot,tree);
    }c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<1e-5,"{a} != {b}");}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,tec_def:100,mel_def:5000,rng_def:4000,
    hitboxes:vec![EnemyHitbox{tec_mul:99.0,damage_mul:1.0,fire_mul:1.2,ice_mul:1.3,thunder_mul:1.4,wind_mul:1.5,light_mul:1.6,dark_mul:1.7,..Default::default()}],..Default::default()}}
#[test]
fn local_compound_original_single_level_bits_and_exact_data_delta() {
    let d=data();let f=fixture();assert_eq!(techniques::compounds().len(),63);assert_eq!(d.attack_stats.len(),2057);
    let mut old=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-u117-com-data.mp")).unwrap();
    let mut filtered=d.clone();filtered.attack_stats.retain(|a|!techniques::compounds().contains_key(&a.attack_id) && !local_dagger_ground_tests::contains(a.attack_id));
    old.attack_stats.sort_by_key(|a|a.attack_id);filtered.attack_stats.sort_by_key(|a|a.attack_id);
    local_rare_mastery_tests::extend_previous_items(&mut old);old.item_params.pc_attrs=filtered.item_params.pc_attrs.clone();old.item_params.vita_attrs=filtered.item_params.vita_attrs.clone();
    assert!(serde_json::to_value(old).unwrap()==serde_json::to_value(filtered).unwrap(),"unexpected previous data modification");
    let mut ids=std::collections::HashSet::new();for a in &d.attack_stats {assert!(ids.insert(a.attack_id));}
    for row in f["attacks"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();
        assert_eq!(a.damage_id,name_to_id(row["row"]["damage_name"].as_str().unwrap()));
        let DamageType::PA((pa,m))=a.damage else{panic!()};assert_eq!(pa,name_to_id(row["table"].as_str().unwrap()));
        assert_eq!(m.to_bits(),u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap());
    }
    for (name,t) in f["tables"].as_object().unwrap() {
        let id=name_to_id(name);assert_eq!(crate::pa_powers::power(id,1).unwrap().to_bits(),u32::from_str_radix(t["power_bits"].as_str().unwrap(),16).unwrap());
        for level in [0,2,17,255] {assert!(crate::pa_powers::power(id,level).is_none());}
    }
}
#[test]
fn local_compound_dual_masteries_single_element_hp_and_no_uncharged_bonus() {
    let d=data();let mut c=full();equip(&mut c,&d,11);
    let mut p=PlayerStats::build_character_levels(&d,&c,85,Some(85)).unwrap();p.base_tec_pwr=1100;p.weapon_tec_pwr=0;
    for row in fixture()["attacks"].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;let mut e=enemy();let skill=1.44f32*1.44*1.21;approx(p.technique_combat.multiplier(id),skill);
        let power=fixture()["tables"][row["table"].as_str().unwrap()]["power"].as_f64().unwrap() as f32;
        let mul=f32::from_bits(u32::from_str_radix(row["multiplier_bits"].as_str().unwrap(),16).unwrap());
        let expected=(1000.0f32/5.0*1.05*techniques::region(id,&e.hitboxes[0]).unwrap()*(power*mul)*skill).round() as u32;
        let BattleResult::Damaged{dmg_packet}=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap() else{panic!()};
        assert_eq!(dmg_packet.dmg_amount as u32,expected);assert_eq!(e.hp,1000000-expected);
    }
    // A matching mastery enhances both components; unrelated elements do not.
    for (slot,name,expected_pair) in [(2,"MasteryLightning1",["wind","thunder"]),(5,"MasteryDark1",["fire","dark"]),(2,"MasteryIce1",["ice","light"])] {
        let mut c=character();c.native_class_trees.insert(slot,learn(ClassTree::default(),slot,name,10));let t=TechniqueCombat::build(&c).unwrap();
        for a in techniques::compounds().values() {approx(t.multiplier(a.id),if expected_pair.contains(&a.element.as_str()){1.2}else{1.0});}
    }
    let mut c=character();c.native_class_trees.insert(2,learn(ClassTree::default(),2,"TechNonChargeBonus1",10));let t=TechniqueCombat::build(&c).unwrap();
    for id in techniques::compounds().keys() {approx(t.multiplier(*id),1.0);}
}
#[test]
fn local_compound_all_aliases_require_main_class_and_equipped_magic_weapon() {
    let d=data();
    for (main,sub) in [(Class::Force,Class::Techer),(Class::Techer,Class::Force),(Class::Hunter,Class::Force),(Class::Hunter,Class::Techer)] {
        for weapon in [None,Some(1),Some(8),Some(11),Some(12),Some(13),Some(14),Some(16)] {
            let mut c=character();c.character.classes.main_class=main;c.character.classes.sub_class=sub;
            if let Some(w)=weapon {equip(&mut c,&d,w);}
            let mut p=PlayerStats::build_character_levels(&d,&c,85,Some(85)).unwrap();let allowed=matches!(main,Class::Force|Class::Techer)&&matches!(weapon,Some(11|12|13));
            for id in techniques::compounds().keys() {
                let mut e=enemy();let result=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:*id,..Default::default()});assert_eq!(result.is_ok(),allowed);
                if !allowed {assert_eq!(e.hp,1000000);}
            }
            assert!(p.technique_combat.validate_attack(name_to_id("Foie2")).is_ok());
        }
    }
}
#[tokio::test]
async fn local_compound_no_tree_native_class_transitions_refresh_eligibility() {
    use crate::user::local_equipment_save_tests::{fixture,finish,auto_master};
    use pso2packetlib::protocol::objects::ChangeClassRequestPacket;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    {let mut u=user.lock().await;
        let rod=data().item_params.attrs.weapons.iter().find(|w|w.id==11).unwrap().clone();
        crate::user::local_equipment_save_tests::extend_fixture_weapon_attrs(&mut u,[rod]);
        let d=u.get_blockdata().server_data.clone();let c=u.character.as_mut().unwrap();
        c.character.classes=character().character.classes;equip(c,&d,11);assert!(c.native_class_trees.is_empty());}
    for (main,sub,allowed) in [(Class::Force,Class::Unknown,true),(Class::Hunter,Class::Force,false),(Class::Techer,Class::Force,true),(Class::Hunter,Class::Unknown,false)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;assert_eq!(u.get_stats().technique_combat.validate_attack(name_to_id("FoieMegido")).is_ok(),allowed);assert_eq!(u.get_stats().hp,7);
    }
    crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:Class::Force,sub_class:Class::Unknown,..Default::default()})).await.unwrap();finish(&user).await;
    for (palette,allowed) in [(1,false),(0,true)] {
        crate::user::packet_handler(user.lock().await,Packet::SetPalette(pso2packetlib::protocol::palette::SetPalettePacket{palette,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;assert_eq!(u.get_stats().technique_combat.validate_attack(name_to_id("FoieMegido")).is_ok(),allowed);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
