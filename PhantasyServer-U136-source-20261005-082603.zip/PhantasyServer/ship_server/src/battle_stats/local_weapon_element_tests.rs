use super::*;
use data_structs::{SerDeFile,name_to_id};
use pso2packetlib::protocol::{Packet,items::*,palette::*,models::{item_attrs::WeaponAttrs,character::ClassLevel}};
use crate::weapon_element::WeaponElement;
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn item(id:u16,subid:u16,element:u8,force:u8)->Item {Item{uuid:900,id:ItemId{item_type:1,id,subid,..Default::default()},data:ItemType::Weapon(WeaponItem{element,force,..Default::default()}),..Default::default()}}
fn character(item:Item)->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
    *c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};let uuid=item.uuid;
    c.inventory.add_item(item);c.inventory.equip_item(uuid,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid,..Default::default()});c
}
fn element(kind:u8,strength:u8)->WeaponElement {
    WeaponElement::build(&character(item(8,252,kind,strength)),&WeaponAttrs{id:8,subid:252,rarity:13,..Default::default()}).unwrap()
}
fn regions()->EnemyHitbox {EnemyHitbox{damage_mul:1.0,mel_mul:7.0,rng_mul:8.0,tec_mul:9.0,
    fire_mul:1.2,ice_mul:1.3,thunder_mul:1.4,wind_mul:1.5,light_mul:1.6,dark_mul:1.7,..Default::default()}}
#[test]
fn local_weapon_element_audited_routes_six_regions_and_explicit_exclusions() {
    let d=data();let f:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-weapon-element.json")).unwrap();
    assert_eq!(f["attacks"].as_array().unwrap().len(),916);assert_eq!(f["excluded"].as_array().unwrap().len(),1140);
    let h=regions();let mut ids=std::collections::HashSet::new();
    for (key,included) in [("attacks",true),("excluded",false)] {for row in f[key].as_array().unwrap() {
        let id=row["id"].as_u64().unwrap() as u32;assert!(ids.insert(id));assert_eq!(id,name_to_id(row["name"].as_str().unwrap()));assert!(d.attack_stats.iter().any(|a|a.attack_id==id));
        for (kind,expected) in [(1,360.0),(2,390.0),(3,420.0),(4,450.0),(5,480.0),(6,510.0)] {
            let got=element(kind,30).power(id,1000,&h);assert!((got-if included {expected}else{0.0}).abs()<0.001,"{key} {id} {kind} {got}");
        }
    }}
    assert_eq!(ids.len(),2056);assert_eq!(d.attack_stats.len(),2057);
    assert_eq!(element(1,50).power(u32::MAX,1000,&h),0.0);
    assert_eq!(element(0,50).power(name_to_id("Rifle:A1"),1000,&h),0.0);
    assert_eq!(element(1,0).power(name_to_id("Rifle:A1"),1000,&h),0.0);
}
#[test]
fn local_weapon_element_saved_value_validation_and_luster_non_element_scope() {
    for rarity in 1..=15 {for strength in [0,1,50,51,60,61,255] {for kind in 0..=7 {
        let c=character(item(7,229,kind,strength));let attrs=WeaponAttrs{id:7,subid:229,rarity,..Default::default()};
        assert_eq!(WeaponElement::build(&c,&attrs).is_ok(),kind<=6 && strength<=if rarity>=13 {60}else{50});
    }}}
    for (main,sub,category,expected) in [(Class::Luster,Class::Unknown,7,0.0),(Class::Hunter,Class::Luster,7,600.0),(Class::Luster,Class::Unknown,8,600.0)] {
        let mut c=character(item(category,0,1,50));c.character.classes.main_class=main;c.character.classes.sub_class=sub;
        let w=WeaponElement::build(&c,&WeaponAttrs{id:category,rarity:1,..Default::default()}).unwrap();
        assert_eq!(w.power(name_to_id("Rifle:A1"),1000,&regions()),expected);
    }
    let c=character(item(8,252,1,50));assert!(WeaponElement::build(&c,&WeaponAttrs{id:8,subid:253,rarity:1,..Default::default()}).is_err());
    assert!(WeaponElement::build(&c,&WeaponAttrs{id:8,subid:252,rarity:0,..Default::default()}).is_err());
}
#[test]
fn local_weapon_element_real_damage_fixed_component_stat_selection_and_multipliers() {
    let d=data();let mut weapon=item(8,252,1,50);let ItemType::Weapon(w)=&mut weapon.data else{unreachable!()};w.grind=35;
    let mut p=PlayerStats::build_character_levels(&d,&character(weapon),85,None).unwrap();p.base_rng_pwr=1000;
    assert_eq!(p.weapon_rng_pwr,243);
    // Hand-derived: 243*0.5*1.2 /5*1.05*1.3 =39.8034.
    // Physical region0 isolates the fixed term from defense and variance.
    for (region,defense,mul,lower,upper) in [(0.0,100,1.0,40,40),(0.0,9999,1.0,40,40),(0.0,100,2.0,80,80),(2.0,100,1.0,651,664)] {
        for _ in 0..32 {let mut h=regions();h.rng_mul=region;h.damage_mul=mul;
            let mut e=EnemyStats{hp:100000,max_hp:100000,rng_def:defense,hitboxes:vec![h],..Default::default()};
            let r=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Rifle:A1"),..Default::default()}).unwrap();
            let amount=match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32};
            assert!((lower..=upper).contains(&amount),"{region} {defense}: {amount}");assert_eq!(e.hp,100000-amount);
        }
    }
    // Ordinary thrown Talis is a TEC-stat weapon hit, not a technique.
    let mut p=PlayerStats{base_tec_pwr:1000,weapon_tec_pwr:1000,weapon_mel_pwr:9000,weapon_rng_pwr:8000,weapon_element:element(1,50),..Default::default()};
    let mut h=regions();h.tec_mul=0.0;let mut e=EnemyStats{hp:10000,max_hp:10000,hitboxes:vec![h],..Default::default()};
    let r=p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:name_to_id("Talis:GA1"),..Default::default()}).unwrap();
    let amount=match r{BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32};assert_eq!(amount,73); // 1000*.5*1.2*.21*.58
}
#[tokio::test]
async fn local_weapon_element_palette_persistence_rebuild_and_invalid_value_atomicity() {
    use crate::user::local_equipment_save_tests::{fixture,auto_master,finish,extend_fixture_weapon_attrs};use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);let d=data();
    {let mut u=user.lock().await;extend_fixture_weapon_attrs(&mut u,d.item_params.attrs.weapons.iter().cloned());let c=u.character.as_mut().unwrap();
        for (uuid,kind,strength) in [(900,1,50),(901,6,30),(902,1,51),(903,7,50)] {let mut w=item(8,252,kind,strength);w.uuid=uuid;c.inventory.add_item(w);}}
    let id=name_to_id("Rifle:A1");let h=regions();
    for (uuid,expected) in [(900,600.0),(901,510.0),(110,0.0),(900,600.0)] {
        let mut req=UpdatePalettePacket::default();req.palettes[0].uuid=uuid;crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(req)).await.unwrap();finish(&user).await;
        let saved=saved_character(&sql,1,1).await;let u=user.lock().await;let p=u.get_stats();assert!((p.weapon_element.power(id,1000,&h)-expected).abs()<0.001);assert_eq!(p.hp,7);
        let p=PlayerStats::prepare_equipment_update(&u,&saved).unwrap();assert!((p.weapon_element.power(id,1000,&h)-expected).abs()<0.001);
    }
    let before=rmp_serde::to_vec(user.lock().await.character.as_ref().unwrap()).unwrap();let persisted=rmp_serde::to_vec(&saved_character(&sql,1,1).await).unwrap();
    for uuid in [902,903] {let mut req=UpdatePalettePacket::default();req.palettes[0].uuid=uuid;assert!(crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(req)).await.is_err());
        let u=user.lock().await;assert!(u.accepts_client_packets());assert_eq!(rmp_serde::to_vec(u.character.as_ref().unwrap()).unwrap(),before);assert_eq!(u.get_stats().hp,7);drop(u);
        assert_eq!(rmp_serde::to_vec(&saved_character(&sql,1,1).await).unwrap(),persisted);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
