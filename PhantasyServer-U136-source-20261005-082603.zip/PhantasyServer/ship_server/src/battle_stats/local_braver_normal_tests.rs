use super::*;
use crate::{other_class_combat::OtherClassCombat,native_class_tree::{self,ClassTree}};
use data_structs::{SerDeFile,name_to_id,stats::DamageType};
use pso2packetlib::protocol::{Packet,models::character::ClassLevel,objects::ChangeClassRequestPacket};
fn data()->ServerData {ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-braver-normal-attacks.json")).unwrap()}
fn learn(t:ClassTree,name:&str,rank:u8)->ClassTree {
    let n=native_class_tree::definition(6).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
    let t=if let Some(p)=&n.parent {if t.rank(p)<n.parent_rank {learn(t,p,n.parent_rank)}else{t}}else{t};
    let add=rank-t.rank(name);if add==0 {t}else{t.learn(6,n.x,n.y,add,85,85).unwrap()}
}
fn character()->CharData {
    let mut c=CharData::default();c.character.classes.main_class=Class::Braver;c.character.classes.sub_class=Class::Unknown;
    c.character.classes.braver_info=ClassLevel{level1:85,level2:85,exp:0};c.character.classes.hunter_info=ClassLevel{level1:85,level2:85,exp:0};c
}
fn approx(a:f32,b:f32){assert!((a-b).abs()<0.0001,"{a} != {b}");}
#[test]
fn local_braver_normal_ranks_original_catalogue_and_no_generic_fallback() {
    let f=fixture();let d=data();let rows=f["attacks"].as_array().unwrap();assert_eq!(rows.len(),84);
    let ids:std::collections::HashSet<u32>=rows.iter().map(|r|r["id"].as_u64().unwrap() as u32).collect();assert_eq!(ids.len(),84);
    for r in rows {
        let id=r["id"].as_u64().unwrap() as u32;assert_eq!(id,name_to_id(r["name"].as_str().unwrap()));
        let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();assert_eq!(a.damage_id,name_to_id(r["row"]["damage_name"].as_str().unwrap()));
        let DamageType::Generic(m)=a.damage else{panic!("normal catalogue contains PA")};
        assert_eq!(m.to_bits(),u32::from_str_radix(r["multiplier_bits"].as_str().unwrap(),16).unwrap());
    }
    for (i,value) in f["values"].as_array().unwrap().iter().enumerate() {
        let mut c=character();c.native_class_trees.insert(6,learn(ClassTree::default(),"AttackAdvance",i as u8+1));
        for (main,sub,active) in [(Class::Braver,Class::Unknown,true),(Class::Hunter,Class::Braver,true),(Class::Hunter,Class::Unknown,false)] {
            c.character.classes.main_class=main;c.character.classes.sub_class=sub;let stats=OtherClassCombat::build(&c).unwrap();
            // Exhaustive compiled catalogue check: PA, tech and advanced-class Generic attacks never leak in.
            for a in &d.attack_stats {approx(stats.normal_multiplier(a.attack_id),if active && ids.contains(&a.attack_id){value.as_f64().unwrap() as f32/100.0}else{1.0});}
            for name in ["Wand:Explosion","TDagger:SpinDamage","unknown-normal"] {approx(stats.normal_multiplier(name_to_id(name)),1.0);}
        }
    }
    let mut c=character();c.native_class_trees.insert(6,learn(ClassTree::default(),"AttackAdvance",5));
    for r in f["deferred_variants"].as_array().unwrap() {approx(OtherClassCombat::build(&c).unwrap().normal_multiplier(r["id"].as_u64().unwrap() as u32),1.0);}
    c.native_class_trees.get_mut(&6).unwrap().ranks.insert("AttackAdvance".into(),6);assert!(OtherClassCombat::build(&c).is_err());
}
fn enemy()->EnemyStats {EnemyStats{hp:1000000,max_hp:1000000,mel_def:100,rng_def:100,tec_def:100,hitboxes:vec![EnemyHitbox{mel_mul:1.0,rng_mul:1.0,tec_mul:1.0,fire_mul:1.0,damage_mul:1.0,..Default::default()}],..Default::default()}}
fn amount(r:BattleResult)->u32 {match r {BattleResult::Damaged{dmg_packet}|BattleResult::Killed{dmg_packet,..}=>dmg_packet.dmg_amount as u32}}
#[test]
fn local_braver_normal_actual_damage_all_catalogue_hits_and_pa_tech_exclusions() {
    let d=data();let f=fixture();let mut c=character();let t=learn(ClassTree::default(),"AttackAdvance",5);c.native_class_trees.insert(6,learn(t,"BraverHighLevelBonus",5));
    let mut p=PlayerStats{hp:1000,max_hp:1000,base_mel_pwr:1000,base_rng_pwr:1000,base_tec_pwr:1000,other_class_combat:OtherClassCombat::build(&c).unwrap(),..Default::default()};
    let mut cases:Vec<(u32,bool)>=f["attacks"].as_array().unwrap().iter().map(|r|(r["id"].as_u64().unwrap() as u32,true)).collect();
    cases.extend(["Rifle:PA3","Foie2","StrikeAdd","Partisan:SB1Damage","Knuckle:GA1Damage2","Launcher:A1US"].map(|n|(name_to_id(n),false)));
    for (id,normal) in cases {
        let a=d.attack_stats.iter().find(|a|a.attack_id==id).unwrap();let m=match a.damage {DamageType::Generic(m)=>m,DamageType::PA((pa,m))=>crate::pa_powers::power(pa,1).unwrap()*m};
        let expected=(900.0f32/5.0*1.05*m*(1.05*if normal {1.35}else{1.0})).round() as u32;let mut e=enemy();
        assert_eq!(amount(p.damage_enemy(&mut e,&d,DealDamagePacket{attack_id:id,..Default::default()}).unwrap()),expected,"attack {id}");assert_eq!(e.hp,1000000-expected);
    }
}
#[tokio::test]
async fn local_braver_normal_native_learning_save_reload_and_main_sub_exit() {
    use crate::user::{local_equipment_save_tests::{fixture,finish,auto_master},handlers};
    use crate::sql::local_checkpoint_tests::saved_character;
    let (sql,requests,user,_peer)=fixture().await;auto_master(requests);
    {let mut u=user.lock().await;let c=u.character.as_mut().unwrap();c.character.classes=character().character.classes;
        let mut t=learn(ClassTree::default(),"AttackAdvance",1);t.ranks.remove("AttackAdvance");c.native_class_trees.insert(6,t);
        let n=native_class_tree::definition(6).unwrap().nodes.iter().find(|n|n.name=="AttackAdvance").unwrap();let mut req=vec![0;68];req[12..16].copy_from_slice(&1u32.to_le_bytes());req[24..28].copy_from_slice(&[2,6,n.x,n.y]);req[32]=5;
        handlers::native_hero::prepare_operation(&mut u,&req).unwrap();assert!(!u.accepts_client_packets());}
    finish(&user).await;let saved=saved_character(&sql,1,1).await;assert_eq!(saved.native_class_trees[&6].rank("AttackAdvance"),5);
    {let u=user.lock().await;approx(PlayerStats::prepare_equipment_update(&u,&saved).unwrap().other_class_combat.normal_multiplier(name_to_id("Sword:GA1")),1.35);assert_eq!(u.get_stats().hp,7);}
    for (main,sub,expected) in [(Class::Hunter,Class::Braver,1.35),(Class::Hunter,Class::Unknown,1.0),(Class::Braver,Class::Unknown,1.35)] {
        crate::user::packet_handler(user.lock().await,Packet::ChangeClassRequest(ChangeClassRequestPacket{main_class:main,sub_class:sub,..Default::default()})).await.unwrap();finish(&user).await;
        let u=user.lock().await;approx(u.get_stats().other_class_combat.normal_multiplier(name_to_id("Sword:GA1")),expected);assert_eq!(u.get_stats().hp,7);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
