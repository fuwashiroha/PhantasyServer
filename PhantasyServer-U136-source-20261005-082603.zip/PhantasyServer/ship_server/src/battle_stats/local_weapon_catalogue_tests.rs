//! Curated exact named items, not a general packed item decoder.
use super::*;
use data_structs::SerDeFile;
use pso2packetlib::protocol::{items::{Item,ItemId,ItemType,WeaponItem},palette::{WeaponPalette,UpdatePalettePacket},Packet,
    models::{item_attrs::{ItemAttributesPC,ItemAttributesVita,WeaponAttrs},character::ClassLevel}};
use std::{path::Path,io::Cursor};
fn data()->ServerData {ServerData::load_from_mp_comp(Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap()}
fn fixture()->serde_json::Value {serde_json::from_str(include_str!("../../testdata/classic-representative-weapons.json")).unwrap()}
fn powers(s:&PlayerStats)->[u32;3] {[s.weapon_mel_pwr,s.weapon_rng_pwr,s.weapon_tec_pwr]}

#[test]
fn local_weapon_catalogue_exact_delta_and_pc_vita_attribute_roundtrip() {
    let current=data();let mut before=ServerData::load_from_mp_comp(Path::new(env!("CARGO_MANIFEST_DIR")).join("testdata/pre-representative-weapons-com-data.mp")).unwrap();
    let f=fixture();assert_eq!(before.item_params.attrs.weapons.len(),4);assert_eq!(current.item_params.attrs.weapons.len(),19);
    for fix in f["corrections"].as_array().unwrap() {
        let w=before.item_params.attrs.weapons.iter_mut().find(|r|u64::from(r.id)==fix["id"].as_u64().unwrap() && u64::from(r.subid)==fix["subid"].as_u64().unwrap()).unwrap();
        let mut value=serde_json::to_value(&*w).unwrap();let key=fix["field"].as_str().unwrap();assert_eq!(value[key],fix["before"]);value[key]=fix["after"].clone();*w=serde_json::from_value(value).unwrap();
    }
    for row in f["additions"].as_array().unwrap() {before.item_params.attrs.weapons.push(serde_json::from_value::<WeaponAttrs>(row["attrs"].clone()).unwrap());}
    for row in f["names"].as_array().unwrap() {before.item_params.names.push(serde_json::from_value(row.clone()).unwrap());}
    // Later combat additions are checked by their own exact-delta tests.
    // Every pre-existing attack must still be byte-equivalent as serialized.
    for old in &before.attack_stats {
        let new=current.attack_stats.iter().find(|a|a.attack_id==old.attack_id).unwrap();
        assert_eq!(serde_json::to_value(old).unwrap(),serde_json::to_value(new).unwrap());
    }
    before.attack_stats=current.attack_stats.clone();
    local_unit_tests::extend_previous_items(&mut before);
    // Apart from later attacks and regenerated ICE containers, preserve every
    // other compiled section, attribute group, old name and row.
    before.item_params.pc_attrs=current.item_params.pc_attrs.clone();before.item_params.vita_attrs=current.item_params.vita_attrs.clone();
    assert!(serde_json::to_value(&before).unwrap()==serde_json::to_value(&current).unwrap(),"Unexpected change outside weapon catalogue and later attack additions");
    assert_eq!(current.item_params.names.len(),26);
    let mut encoded=vec![];current.item_params.attrs.write_attrs(&mut encoded).unwrap();
    let mut reader=Cursor::new(&encoded);let decoded=ItemAttributesPC::read_attrs(&mut reader).unwrap();assert_eq!(reader.position() as usize,encoded.len());
    assert_eq!(serde_json::to_value(&decoded.weapons).unwrap(),serde_json::to_value(&current.item_params.attrs.weapons).unwrap());
    // data18 defaults empty in memory but has 406 required binary rows.
    let mut reencoded=vec![];decoded.write_attrs(&mut reencoded).unwrap();assert_eq!(reencoded,encoded);
    let vita:ItemAttributesVita=current.item_params.attrs.clone().into();let mut encoded=vec![];vita.write_attrs(&mut encoded).unwrap();
    let mut reader=Cursor::new(&encoded);let decoded=ItemAttributesVita::read_attrs(&mut reader).unwrap();assert_eq!(reader.position() as usize,encoded.len());
    assert_eq!(serde_json::to_value(&decoded.weapons).unwrap(),serde_json::to_value(&vita.weapons).unwrap());
    let mut reencoded=vec![];decoded.write_attrs(&mut reencoded).unwrap();assert_eq!(reencoded,encoded);
}

#[test]
fn local_weapon_catalogue_all_categories_build_correct_stats_and_saved_palettes() {
    let data=data();let expected=[(1,0,94,0,0),(2,0,81,0,0),(3,0,76,0,0),(4,0,59,0,0),(5,0,63,0,0),(6,0,89,0,0),
        (7,229,157,149,0),(8,252,0,180,0),(9,257,0,198,0),(10,0,0,86,0),(11,0,68,0,92),(12,0,0,0,78),
        (13,0,85,0,83),(14,0,79,0,0),(15,0,0,79,0),(16,0,78,0,79),(17,0,84,0,0)];
    for (id,subid,mel,rng,tec) in expected {
        let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;c.character.classes.sub_class=Class::Unknown;
        *c.character.get_level_mut()=ClassLevel{level1:1,level2:1,exp:0};
        c.inventory.add_item(Item{uuid:900,id:ItemId{item_type:1,id,subid,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
        c.inventory.equip_item(900,9).unwrap();c.palette.set_palette_data(0,WeaponPalette{uuid:900,..Default::default()});
        // Build reads the exact equipped identity; class eligibility is not
        // claimed by this synthetic all-category test.
        let stats=PlayerStats::build_character_levels(&data,&c,1,None).unwrap();assert_eq!(powers(&stats),[mel,rng,tec],"category {id}");
        let restored:CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&c).unwrap()).unwrap();
        assert_eq!(powers(&PlayerStats::build_character_levels(&data,&restored,1,None).unwrap()),[mel,rng,tec]);
        assert!(data.item_params.names.iter().any(|n|n.id.id==id && n.id.subid==subid && !n.jp_name.is_empty()));
    }
    let bow=data.item_params.attrs.weapons.iter().find(|r|r.id==15).unwrap();assert_eq!(serde_json::to_value(bow.req_stat_type).unwrap(),"DEX");
}

#[tokio::test]
async fn local_weapon_catalogue_real_equip_saves_and_preserves_injured_hp() {
    use crate::user::local_equipment_save_tests::{fixture as user_fixture,auto_master,finish};
    let (sql,requests,user,_peer)=user_fixture().await;auto_master(requests);
    let compiled=data();let f=fixture();
    {
        let mut u=user.lock().await;
        // Preserve the fixture's old equipment rows so transitions can validate
        // both old and new weapons; all new rows come from the compiled data.
        crate::user::local_equipment_save_tests::extend_fixture_weapon_attrs(&mut u,compiled.item_params.attrs.weapons.iter().cloned());
        let c=u.character.as_mut().unwrap();c.character.classes.main_class=Class::Etole;
        *c.character.get_level_mut()=ClassLevel{level1:85,level2:85,exp:0};
        for row in f["additions"].as_array().unwrap() {
            let id:ItemId=serde_json::from_value(row["id"].clone()).unwrap();
            c.inventory.add_item(Item{uuid:1000+u64::from(id.id),id,data:ItemType::Weapon(WeaponItem::default()),..Default::default()});
        }
    }
    for row in f["additions"].as_array().unwrap() {
        let id=row["id"]["id"].as_u64().unwrap();let uuid=1000+id;
        let mut request=UpdatePalettePacket::default();request.palettes[0].uuid=uuid;
        Box::pin(crate::user::packet_handler(user.lock().await,Packet::UpdatePalette(request))).await.unwrap();
        finish(&user).await;
        let expected=[row["attrs"]["melee_dmg"].as_u64().unwrap() as u32,row["attrs"]["range_dmg"].as_u64().unwrap() as u32,row["attrs"]["force_dmg"].as_u64().unwrap() as u32];
        let u=user.lock().await;assert_eq!(powers(u.get_stats()),expected);assert_eq!(u.get_stats().get_hp().0,7);drop(u);
        let saved=crate::sql::local_checkpoint_tests::saved_character(&sql,1,1).await;
        assert_eq!(saved.palette.get_current_item(&saved.inventory).unwrap().unwrap().uuid,uuid);
        assert_eq!(powers(&PlayerStats::build_character_levels(&compiled,&saved,85,None).unwrap()),expected);
    }
    user.lock().await.queue_disconnect();sql.drain_session_saves().await.unwrap();
}
