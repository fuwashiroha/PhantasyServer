//! Accounting for the future Rockbear scene. No original scene is enabled yet.
//! Timed/free modes are sourced from quest_00161500.text and the saved wiki.
//! Keep displayed damage and HP loss separate until overkill semantics are proven.
use crate::Error;
use std::{collections::HashSet, time::{Duration, Instant}};

#[derive(Clone, Copy, Debug)]
pub(crate) enum Mode { TwentySeconds, Free }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum End { Elapsed, TargetKilled, Cancelled }
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct Total {
    pub player: u32,
    pub hits: u64,
    pub displayed: u64,
    pub hp_loss: u64,
    pub invalid: bool,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Snapshot {
    pub totals: Vec<Total>,
    pub ended: Option<End>,
}
pub(crate) struct Measurement {
    zone: u32,
    enemy: u32,
    started: Instant,
    deadline: Option<Instant>,
    excluded: HashSet<u32>,
    snapshot: Snapshot,
}
impl Measurement {
    pub(crate) fn new(zone:u32, enemy:u32, players:&[u32], mode:Mode, excluded:&[u32], now:Instant)->Result<Self,Error> {
        if enemy==0 || players.is_empty() || players.len()>4 || players.contains(&0)
            || players.iter().copied().collect::<HashSet<_>>().len()!=players.len() || excluded.len()>4096 {
            return Err(Error::InvalidInput("damage_measurement_profile"));
        }
        Ok(Self{zone,enemy,started:now,deadline:match mode {Mode::TwentySeconds=>Some(now+Duration::from_secs(20)),Mode::Free=>None},
            excluded:excluded.iter().copied().collect(),snapshot:Snapshot{totals:players.iter().map(|&player|Total{player,..Default::default()}).collect(),ended:None}})
    }
    fn expire(&mut self, now:Instant) {
        // Explicit half-open server interval [start, start+20s). Original UI
        // frame-boundary convention remains unverified; never claim parity.
        if self.snapshot.ended.is_none() && self.deadline.is_some_and(|end|now>=end) {
            self.snapshot.ended=Some(End::Elapsed);
        }
    }
    pub(crate) fn snapshot(&mut self,now:Instant)->Snapshot {self.expire(now);self.snapshot.clone()}
    pub(crate) fn cancel(&mut self,now:Instant) {
        self.expire(now);
        if self.snapshot.ended.is_none() {self.snapshot.ended=Some(End::Cancelled);}
    }
    // Call exactly once, after all fallible combat work, at HP/kill commit.
    // This is not network-packet deduplication: repeated PA segments are valid.
    pub(crate) fn committed(&mut self,zone:u32,enemy:u32,player:u32,attack:u32,displayed:i32,hp_loss:u32,killed:bool,now:Instant) {
        self.expire(now);
        if self.snapshot.ended.is_some() || now<self.started || zone!=self.zone || enemy!=self.enemy {return;}
        if !self.excluded.contains(&attack) {
            if let Some(total)=self.snapshot.totals.iter_mut().find(|r|r.player==player) {
                let shown=u64::try_from(displayed).unwrap_or_else(|_|{total.invalid=true;0});
                for (slot,amount) in [(&mut total.hits,1),(&mut total.displayed,shown),(&mut total.hp_loss,u64::from(hp_loss))] {
                    match slot.checked_add(amount) {Some(value)=>*slot=value,None=>{*slot=u64::MAX;total.invalid=true;}}
                }
            }
        }
        if killed {self.snapshot.ended=Some(End::TargetKilled);}
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_measurement_timer_filters_multihit_and_overkill_are_separate() {
        let now=Instant::now();let mut m=Measurement::new(7,9,&[1,2],Mode::TwentySeconds,&[99],now).unwrap();
        for (zone,enemy,player,attack) in [(8,9,1,1),(7,8,1,1),(7,9,3,1),(7,9,1,99)] {
            m.committed(zone,enemy,player,attack,40,40,false,now);
        }
        m.committed(7,9,1,1,40,40,false,now-Duration::from_secs(1));
        assert!(m.snapshot(now).totals.iter().all(|r|r.hits==0));
        // Same attack hash is allowed twice: multihit is not a duplicate kill.
        m.committed(7,9,1,1,40,40,false,now);
        m.committed(7,9,1,1,40,40,false,now+Duration::from_secs(1));
        m.committed(7,9,2,1,50,5,false,now+Duration::from_secs(20)-Duration::from_nanos(1));
        let before=m.snapshot(now+Duration::from_secs(19));
        assert_eq!(before.totals[0],Total{player:1,hits:2,displayed:80,hp_loss:80,invalid:false});
        assert_eq!(before.totals[1].displayed,50);assert_eq!(before.totals[1].hp_loss,5);
        m.committed(7,9,1,1,100,100,false,now+Duration::from_secs(20));
        let ended=m.snapshot(now+Duration::from_secs(20));
        assert_eq!(ended.totals,before.totals);assert_eq!(ended.ended,Some(End::Elapsed));
        m.cancel(now+Duration::from_secs(21));assert_eq!(m.snapshot(now+Duration::from_secs(21)),ended);
        // Expiry can be observed without another hit.
        let mut empty=Measurement::new(7,10,&[1],Mode::TwentySeconds,&[],now).unwrap();
        assert_eq!(empty.snapshot(now+Duration::from_secs(20)).ended,Some(End::Elapsed));
    }
    #[test]
    fn local_measurement_free_kill_cancel_and_fresh_round_do_not_leak() {
        let now=Instant::now();let later=now+Duration::from_secs(600);
        let mut m=Measurement::new(7,9,&[1],Mode::Free,&[99],now).unwrap();
        m.committed(7,8,1,1,40,40,true,later);assert_eq!(m.snapshot(later).ended,None);
        m.committed(7,9,1,1,40,40,false,later);assert_eq!(m.snapshot(later).totals[0].hits,1);
        // Even an excluded attack ends the round when its target dies.
        m.committed(7,9,1,99,40,1,true,later);
        let end=m.snapshot(later);assert_eq!(end.ended,Some(End::TargetKilled));
        m.committed(7,9,1,1,40,0,true,later);assert_eq!(m.snapshot(later),end);
        let mut fresh=Measurement::new(7,10,&[1],Mode::Free,&[],later).unwrap();
        fresh.cancel(later);fresh.committed(7,10,1,1,40,40,false,later);
        assert_eq!(fresh.snapshot(later).totals[0].hits,0);assert_eq!(fresh.snapshot(later).ended,Some(End::Cancelled));
        assert_eq!(m.snapshot(later),end);
    }
    #[test]
    fn local_measurement_validation_wide_totals_and_invalid_damage() {
        let now=Instant::now();
        for players in [vec![],vec![0],vec![1,1],vec![1,2,3,4,5]] {
            assert!(Measurement::new(7,9,&players,Mode::Free,&[],now).is_err());
        }
        assert!(Measurement::new(7,0,&[1],Mode::Free,&[],now).is_err());
        assert!(Measurement::new(7,9,&[1],Mode::Free,&vec![1;4097],now).is_err());
        let mut m=Measurement::new(7,9,&[1,2,3,4],Mode::Free,&[],now).unwrap();
        for _ in 0..3 {m.committed(7,9,1,1,i32::MAX,400_000_000,false,now);}
        assert_eq!(m.snapshot(now).totals[0].displayed,3*i32::MAX as u64);
        m.committed(7,9,2,1,-1,8,false,now);
        assert_eq!(m.snapshot(now).totals[1],Total{player:2,hits:1,displayed:0,hp_loss:8,invalid:true});
        m.snapshot.totals[0].displayed=u64::MAX;
        m.committed(7,9,1,1,1,1,false,now);
        assert!(m.snapshot(now).totals[0].invalid);
    }
}
