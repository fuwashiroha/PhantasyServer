//! Server-owned defeat objectives and fixed settlement profiles.
//! No installed Classic quest supplies a profile yet. A content author must
//! evidence objective counts, eligibility and every result value before import.
use crate::{Error,user::QuestMesetaReceipt};
use data_structs::quest::{QuestCompletionRule,QuestParticipantRule};
use pso2packetlib::protocol::{questlist::QuestResultPacket,Packet,PacketType,ProtocolRW};
use std::collections::HashSet;

pub(crate) struct QuestCompletion {
    run_id:[u8;16],
    quest_name_id:u32,
    rule:QuestCompletionRule,
    kills:HashSet<(u32,u32)>,
    participants:HashSet<(u32,u32)>,
    returned:HashSet<(u32,u32)>,
}
impl QuestCompletion {
    pub(crate) fn new(quest_name_id:u32,rule:QuestCompletionRule)->Result<Self,Error> {
        validate_rule(&rule)?;
        if quest_name_id==0 {return Err(Error::InvalidInput("quest_completion_identity"));}
        let mut run_id=rand::random::<[u8;16]>();
        while run_id==[0;16] {run_id=rand::random();}
        Ok(Self {run_id,quest_name_id,rule,kills:HashSet::new(),participants:HashSet::new(),returned:HashSet::new()})
    }
    // Called in the enemy-removal transaction, after all fallible EXP prepares.
    pub(crate) fn killed(&mut self,zone:u32,id:u32,name:&str,participants:&[(u32,u32)])->bool {
        if self.complete() || zone!=self.rule.zone_id || name!=self.rule.enemy_name {return false;}
        if self.kills.insert((zone,id)) {
            match self.rule.participants {
                QuestParticipantRule::AnyObjectiveKillRecipient=>self.participants.extend(participants.iter().copied()),
            }
        }
        self.complete()
    }
    pub(crate) fn completion_actors(&self)->&[u32] {&self.rule.activate_on_completion}
    fn complete(&self)->bool {self.kills.len()>=self.rule.required_kills as usize}
    pub(crate) fn can_return(&self,id:u32,character:u32)->bool {
        self.complete() && self.participants.contains(&(id,character))
    }
    pub(crate) fn returned(&mut self,id:u32,character:u32) {self.returned.insert((id,character));}
    pub(crate) fn settlement(&self,id:u32,character:u32)->Option<(QuestMesetaReceipt,QuestResultPacket)> {
        if !self.can_return(id,character) || !self.returned.contains(&(id,character)) {return None;}
        Some((QuestMesetaReceipt {run_id:self.run_id,character_id:character,quest_name_id:self.quest_name_id,
            difficulty:self.rule.difficulty,meseta:self.rule.result.meseta_earned},self.rule.result.clone()))
    }
}
pub(crate) fn validate_rule(rule:&QuestCompletionRule)->Result<(),Error> {
    if rule.difficulty>=8 || rule.required_kills==0 || rule.enemy_name.is_empty() || rule.evidence.is_empty() {
        return Err(Error::InvalidInput("quest_completion_rule"));
    }
    validate_result(&rule.result)
}
pub(crate) fn validate_result(result:&QuestResultPacket)->Result<(),Error> {
    // This implementation persists meseta only. Refuse unsupported reward,
    // unlock and collection payloads rather than advertise unsaved assets.
    let allowed=QuestResultPacket {
        enemy_kills:result.enemy_kills.clone(),
        total_score_achieved:result.total_score_achieved,
        total_score:result.total_score,
        rank:result.rank,
        meseta_earned:result.meseta_earned,
        ..Default::default()
    };
    // FixedVec/FixedBytes default to empty in memory; the Classic codec pads
    // them on the wire. Accept decoded default padding, not arbitrary payloads.
    // Reject overlong backing vectors before serialization can truncate them.
    if result.unk1.len()>3 || result.unk2.len()>3 || result.unk3.len()>5
        || result.gained_items.len()>8 || result.unlocked_quests.len()>51
        || result.unk1.iter().chain(result.unk2.iter()).any(|e|e.unk6.len()>12) {
        return Err(Error::InvalidInput("quest_completion_result_length"));
    }
    if Packet::QuestResult(result.clone()).write(PacketType::Classic)!=Packet::QuestResult(allowed).write(PacketType::Classic) {
        return Err(Error::InvalidInput("quest_completion_unsupported_result"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    pub(crate) fn rule()->QuestCompletionRule {
        QuestCompletionRule {difficulty:0,zone_id:7,enemy_name:"FixtureEnemy".into(),required_kills:2,
            participants:QuestParticipantRule::AnyObjectiveKillRecipient,activate_on_completion:vec![],
            result:QuestResultPacket {meseta_earned:50,..Default::default()},evidence:"synthetic test only; not original quest parameters".into()}
    }
    #[test]
    fn local_quest_completion_counts_only_committed_matching_unique_kills() {
        let mut c=QuestCompletion::new(200030,rule()).unwrap();
        let other=QuestCompletion::new(200030,rule()).unwrap();assert_ne!(c.run_id,other.run_id);
        c.killed(8,1,"FixtureEnemy",&[(1,10)]);c.killed(7,1,"Wrong",&[(1,10)]);
        assert!(!c.can_return(1,10));assert!(c.kills.is_empty());
        c.killed(7,1,"FixtureEnemy",&[(1,10),(2,20)]);c.killed(7,1,"FixtureEnemy",&[(3,30)]);
        assert!(!c.can_return(1,10));assert!(!c.participants.contains(&(3,30)));
        c.killed(7,2,"FixtureEnemy",&[(2,20)]);assert!(c.can_return(1,10));assert!(c.can_return(2,20));
        assert!(!c.can_return(1,11));assert!(!c.can_return(3,30));assert!(c.settlement(1,10).is_none());
        c.returned(1,10);let (receipt,result)=c.settlement(1,10).unwrap();assert_eq!(receipt.meseta,50);assert_eq!(result.meseta_earned,50);
        c.killed(7,3,"FixtureEnemy",&[(3,30)]);assert!(!c.can_return(3,30));assert_eq!(c.kills.len(),2);
        assert_eq!(c.settlement(1,10).unwrap().0,receipt);
    }
    #[test]
    fn local_quest_completion_rejects_unsupported_rewards_and_incomplete_rules() {
        let mut r=rule();r.result.exp_earned=1;assert!(QuestCompletion::new(1,r).is_err());
        let mut r=rule();r.required_kills=0;assert!(QuestCompletion::new(1,r).is_err());
        let mut r=rule();r.evidence.clear();assert!(QuestCompletion::new(1,r).is_err());
        assert!(QuestCompletion::new(0,rule()).is_err());
        let mut r=rule();r.result.unk4=1;assert!(QuestCompletion::new(1,r).is_err());
    }
    fn padded_result()->QuestResultPacket {
        let bytes=Packet::QuestResult(rule().result).write(PacketType::Classic);
        let mut packets=Packet::read(&bytes,PacketType::Classic).unwrap();assert_eq!(packets.len(),1);
        let Packet::QuestResult(result)=packets.remove(0) else {panic!()};result
    }
    #[test]
    fn local_quest_template_accepts_decoded_padding_without_changing_rewards() {
        let result=padded_result();assert_eq!(result.unk1.len(),3);assert_eq!(result.unk3.len(),5);
        assert_eq!(result.gained_items.len(),8);assert_eq!(result.unlocked_quests.len(),51);
        assert_eq!(result.unk1[0].unk6.len(),12);assert_ne!(result,rule().result);
        assert!(validate_result(&result).is_ok());assert_eq!(result.meseta_earned,50);assert_eq!(result.exp_earned,0);
        let mut profile=rule();profile.result=result;
        assert!(QuestCompletion::new(30010,profile).is_ok());
    }
    #[test]
    fn local_quest_template_rejects_unsupported_padded_values_and_truncated_tail() {
        for case in 0..10 {
            let mut result=padded_result();
            match case {
                0=>result.exp_earned=1,
                1=>result.unlocked_quests[0].name_id=30010,
                2=>result.unk1[0].unk1=1,
                3=>result.unk1[0].unk6[0]=1,
                4=>result.times_incapacitated.value=1,
                5=>result.gained_items.push(Default::default()),
                6=>result.unlocked_quests.push(Default::default()),
                7=>result.unk3.push(Default::default()),
                8=>result.unk2[0].unk6.push(1),
                9=>result.hide_results=1,
                _=>unreachable!(),
            }
            assert!(validate_result(&result).is_err(),"case {case}");
        }
    }

}
