use crate::{
    Action, BlockData, BlockInfo, Error, map,
    mutex::{Mutex, RwLock},
    sql,
    user::User,
};
use pso2packetlib::{PrivateKey, connection::ConnectionError, protocol::Packet};
use std::{
    io,
    sync::{Arc, atomic::AtomicU32},
};
use tokio::{
    net::{TcpListener, TcpStream},
    sync::mpsc,
};

pub async fn init_block(
    blocks: Arc<RwLock<Vec<BlockInfo>>>,
    this_block: BlockInfo,
    sql: Arc<sql::Sql>,
    key: PrivateKey,
    mut shutdown: tokio::sync::watch::Receiver<bool>,
) -> Result<(), Error> {
    let listener = TcpListener::bind(("127.0.0.1", this_block.port)).await?;

    let latest_mapid = AtomicU32::new(1);

    let Some(lobby) = this_block.server_data.maps.get(&this_block.lobby_map) else {
        return Err(Error::NoMapFound(this_block.lobby_map.clone()));
    };

    let lobby = Arc::new(Mutex::new({
        let mut map = map::Map::new_from_data(lobby.clone(), &latest_mapid)?;
        map.set_map_type(map::MapType::Lobby);
        map
    }));

    let block_data = Arc::new(BlockData {
        sql,
        blocks,
        block_id: this_block.id,
        block_name: this_block.name,
        lobby,
        key,
        latest_mapid,
        latest_partyid: AtomicU32::new(1),
        server_data: this_block.server_data,
        quests: this_block.quests,
        clients: Mutex::new(vec![]),
    });
    // we are the only owner of the map, so this never blocks
    block_data
        .lobby
        .lock_blocking()
        .set_block_data(block_data.clone());

    let mut conn_id = 0usize;
    let (send, mut recv) = mpsc::channel(10);
    let (stop, stop_rx) = tokio::sync::watch::channel(false);
    let mut tasks = tokio::task::JoinSet::new();
    let mut failure = None;

    loop {
        tokio::select! {
            // we opt out of random selection because the listener is rarely accepting
            biased;
            _ = shutdown.changed() => { break; }
            Some(result) = tasks.join_next() => {
                if let Err(e) = result { log::error!("Client task failed: {e}"); }
            }
            result = listener.accept() => {
                let (stream, _) = match result { Ok(value) => value, Err(e) => { failure = Some(Error::from(e)); break; } };
                if let Err(e) = new_conn_handler(
                    stream,
                    &block_data,
                    send.clone(),
                    this_block.id,
                    &mut conn_id,
                    &mut tasks,
                    stop_rx.clone(),
                ).await { log::warn!("Could not initialize client: {e}"); }
            }
            Some((id, action)) = recv.recv() => {
                match run_action(&block_data, id, action, &block_data).await {
                    Ok(_) => {}
                    Err(e) => log::warn!("Client error: {e}"),
                };
            }
        };
    }
    // Stop at packet boundaries, then continue consuming disconnect events
    // while readers finish so a full event channel cannot deadlock shutdown.
    let _ = stop.send(true);
    drop(listener);
    while !tasks.is_empty() {
        tokio::select! {
            Some(result) = tasks.join_next() => {
                if let Err(e) = result { log::error!("Client shutdown task failed: {e}"); }
            }
            Some((id, action)) = recv.recv() => {
                if let Err(e) = run_action(&block_data, id, action, &block_data).await {
                    log::error!("Disconnect cleanup failed: {e}");
                }
            }
        }
    }
    let clients = std::mem::take(&mut *block_data.clients.lock().await);
    for (_, client) in clients { client.lock().await.queue_disconnect(); }
    if let Some(e) = failure { return Err(e); }
    Ok(())
}

enum ClientEvent {
    Stop,
    Tick,
    Checkpoint,
    Packet(Result<Packet, ConnectionError>),
}

// A pending asset response blocks only this connection's next read. Do not
// poll/consume a buffered request until the durable acknowledgment completes.
async fn read_when_allowed(
    allowed: bool,
    packet: impl std::future::Future<Output = Result<Packet, ConnectionError>>,
) -> Result<Packet, ConnectionError> {
    if allowed { packet.await } else { std::future::pending().await }
}

async fn next_client_event(
    shutdown: &mut tokio::sync::watch::Receiver<bool>,
    interval: &mut tokio::time::Interval,
    checkpoint: &tokio::sync::Notify,
    packet: impl std::future::Future<Output = Result<Packet, ConnectionError>>,
) -> ClientEvent {
    tokio::select! {
        biased;
        _ = shutdown.changed() => ClientEvent::Stop,
        _ = checkpoint.notified() => ClientEvent::Checkpoint,
        _ = interval.tick() => ClientEvent::Tick,
        result = packet => ClientEvent::Packet(result),
    }
}

async fn new_conn_handler(
    s: TcpStream,
    block_data: &Arc<BlockData>,
    send: mpsc::Sender<(usize, Action)>,
    block_id: u32,
    conn_id_ref: &mut usize,
    tasks: &mut tokio::task::JoinSet<()>,
    mut shutdown: tokio::sync::watch::Receiver<bool>,
) -> Result<(), Error> {
    log::info!("Client connected");

    let conn_id = *conn_id_ref;
    let (client, mut read) = User::new(s, block_data.clone(), conn_id)?;
    let checkpoint = client.checkpoint_wakeup();
    let mut lock = block_data.blocks.write().await;
    if let Some(block) = lock.iter_mut().find(|x| x.id == block_id) {
        if block.players >= block.max_players {
            return Ok(());
        }
        block.players += 1;
    }
    drop(lock);

    let client = Arc::new(Mutex::new(client));
    let mut clients = block_data.clients.lock().await;
    clients.push((conn_id, client.clone()));
    tasks.spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_millis(100));
        interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        loop {
            let allowed = client.lock().await.accepts_client_packets();
            let result = match next_client_event(&mut shutdown, &mut interval, &checkpoint,
                read_when_allowed(allowed, read.read_packet_async())).await {
                ClientEvent::Stop => break,
                ClientEvent::Tick | ClientEvent::Checkpoint => User::tick(client.lock().await).await,
                ClientEvent::Packet(result) => {
                    match result {
                        Ok(a) => {
                            let lock = client.lock().await;
                            crate::user::packet_handler(lock, a).await
                        },
                        Err(ConnectionError::Io(e)) if matches!(e.kind(), io::ErrorKind::Interrupted) => Ok(Action::Nothing),
                        Err(ConnectionError::Io(e))
                            if matches!(
                                e.kind(),
                                io::ErrorKind::ConnectionAborted | io::ErrorKind::ConnectionReset | io::ErrorKind::UnexpectedEof | io::ErrorKind::BrokenPipe
                            ) =>
                        {
                            break;
                        }
                        Err(e) => {
                            let error_msg = format!("Client error: {e}");
                            let _ = client.lock().await.send_error(&error_msg).await;
                            log::warn!("{}", error_msg);
                            Ok(Action::Nothing)
                        }
                    }
                }
            };
            match result {
                Ok(Action::Nothing) => {}
                Ok(Action::Disconnect) => {
                    break;
                }
                Err(Error::IOError(e)) if matches!(e.kind(), io::ErrorKind::Interrupted) => {}
                Err(Error::IOError(e))
                    if matches!(
                        e.kind(),
                        io::ErrorKind::ConnectionAborted | io::ErrorKind::ConnectionReset | io::ErrorKind::UnexpectedEof | io::ErrorKind::BrokenPipe
                    ) =>
                {
                    break;
                }
                Err(e) => {
                    let error_msg = format!("Client error: {e}");
                    let _ = client.lock().await.send_error(&error_msg).await;
                    log::warn!("{}", error_msg);
                }
            }
        }
        client.lock().await.queue_disconnect();
        let _ = send.send((conn_id, Action::Disconnect)).await;
    });

    *conn_id_ref += 1;
    Ok(())
}

async fn run_action(
    block: &BlockData,
    conn_id: usize,
    action: Action,
    block_data: &Arc<BlockData>,
) -> Result<(), Error> {
    if let Action::Nothing = action {
        return Ok(());
    }
    let mut clients = block.clients.lock().await;
    let Some((pos, _)) = clients
        .iter()
        .enumerate()
        .find(|(_, (c_conn_id, _))| *c_conn_id == conn_id)
    else {
        return Ok(());
    };
    match action {
        Action::Nothing => {}
        Action::Disconnect => {
            log::info!("Client disconnected");
            let (_, client) = clients.remove(pos);
            drop(clients);
            client.lock().await.queue_disconnect();

            let mut lock = block_data.blocks.write().await;
            if let Some(block) = lock.iter_mut().find(|x| x.id == block_data.block_id) {
                block.players -= 1;
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod local_lifecycle_tests {
    use super::*;
    use crate::{Quests,SerDeFile,ServerData};

    #[tokio::test]
    async fn local_lifecycle_reader_eof_and_shutdown_finish_without_more_packets() {
        for peer_eof in [false,true] {
            let data=Arc::new(ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join("../data/com_data.mp")).unwrap());
            let ids=AtomicU32::new(1);
            let lobby=map::Map::new_from_data(data.maps["lobby"].clone(),&ids).unwrap();
            let block=Arc::new(BlockData {sql:Arc::new(sql::Sql::in_memory_for_test().await.unwrap()),
                block_id:1,block_name:"isolated reader shutdown".into(),blocks:Arc::new(RwLock::new(vec![])),
                lobby:Arc::new(Mutex::new(lobby)),key:PrivateKey::None,latest_mapid:ids,latest_partyid:AtomicU32::new(1),
                server_data:data.clone(),quests:Arc::new(Quests::load(data.quests.clone())),clients:Mutex::new(vec![])});
            let listener=TcpListener::bind("127.0.0.1:0").await.unwrap();
            let peer=TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
            let (stream,_)=listener.accept().await.unwrap();
            let (send,mut recv)=mpsc::channel(1);let (stop,rx)=tokio::sync::watch::channel(false);
            let mut tasks=tokio::task::JoinSet::new();let mut id=0;
            new_conn_handler(stream,&block,send,1,&mut id,&mut tasks,rx).await.unwrap();
            assert_eq!(block.clients.lock().await.len(),1);
            if peer_eof { drop(peer); } else { stop.send(true).unwrap(); }
            tokio::time::timeout(std::time::Duration::from_secs(3),tasks.join_next()).await.unwrap().unwrap().unwrap();
            let (id,action)=recv.recv().await.unwrap();run_action(&block,id,action,&block).await.unwrap();
            assert!(block.clients.lock().await.is_empty());assert!(tasks.is_empty());
            block.sql.drain_session_saves().await.unwrap();
        }
    }
}

#[cfg(test)]
mod local_checkpoint_scheduling_tests {
    use super::*;

    #[tokio::test]
    async fn local_checkpoint_wake_retains_early_notification_without_busy_loop() {
        let (_stop,mut shutdown)=tokio::sync::watch::channel(false);
        let checkpoint=tokio::sync::Notify::new();
        let mut interval=tokio::time::interval_at(tokio::time::Instant::now()+std::time::Duration::from_secs(60),std::time::Duration::from_secs(60));
        let polls=std::cell::Cell::new(0);
        checkpoint.notify_one(); // No waiter exists yet.
        let packet=async {polls.set(1);Ok(Packet::CharacterListRequest)};
        assert!(matches!(tokio::time::timeout(std::time::Duration::from_secs(2),
            next_client_event(&mut shutdown,&mut interval,&checkpoint,read_when_allowed(false,packet))).await.unwrap(),ClientEvent::Checkpoint));
        assert_eq!(polls.get(),0);
        assert!(tokio::time::timeout(std::time::Duration::from_millis(20),
            next_client_event(&mut shutdown,&mut interval,&checkpoint,std::future::pending())).await.is_err());
        // A genuinely new notification still wakes the next wait.
        checkpoint.notify_one();
        assert!(matches!(next_client_event(&mut shutdown,&mut interval,&checkpoint,std::future::pending()).await,ClientEvent::Checkpoint));
    }

    #[tokio::test]
    async fn local_checkpoint_wake_shutdown_wins_over_notification_timer_and_packet() {
        let (stop,mut shutdown)=tokio::sync::watch::channel(false);
        let checkpoint=tokio::sync::Notify::new();checkpoint.notify_one();
        let mut interval=tokio::time::interval(std::time::Duration::from_secs(60));
        stop.send(true).unwrap();
        assert!(matches!(next_client_event(&mut shutdown,&mut interval,&checkpoint,
            std::future::ready(Ok(Packet::CharacterListRequest))).await,ClientEvent::Stop));
    }

    #[tokio::test]
    async fn local_checkpoint_wake_real_equipment_save_and_reply_need_no_timer_tick() {
        use crate::{user::{local_equipment_save_tests::{fixture,request},packet_handler},sql::local_checkpoint_tests::ack};
        use data_structs::master_ship::{MasterShipAction,AccountCommitResult};
        use std::time::Duration;
        // One pass across all seven changed handlers; synthetic data, no load loop.
        for kind in 0..7 {
            let (sql,mut requests,user,mut peer)=fixture().await;
            let checkpoint=user.lock().await.checkpoint_wakeup();
            let (_stop,mut shutdown)=tokio::sync::watch::channel(false);
            let mut interval=tokio::time::interval_at(tokio::time::Instant::now()+Duration::from_secs(60),Duration::from_secs(60));
            packet_handler(user.lock().await,request(kind)).await.unwrap();
            assert!(!user.lock().await.accepts_client_packets());
            assert!(matches!(tokio::time::timeout(Duration::from_secs(2),next_client_event(
                &mut shutdown,&mut interval,&checkpoint,read_when_allowed(false,async{panic!("blocked packet read")}))).await.unwrap(),ClientEvent::Checkpoint));
            assert!(matches!(tokio::time::timeout(Duration::from_millis(200),User::tick(user.lock().await)).await.unwrap().unwrap(),Action::Nothing));
            let (action,send)=tokio::time::timeout(Duration::from_secs(2),requests.recv()).await.unwrap().unwrap();
            let MasterShipAction::CommitAccountSnapshot{commit,..}=action else{panic!()};
            assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
            assert!(tokio::time::timeout(Duration::from_millis(20),next_client_event(
                &mut shutdown,&mut interval,&checkpoint,std::future::pending())).await.is_err());
            send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed{commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
            assert!(matches!(tokio::time::timeout(Duration::from_secs(2),next_client_event(
                &mut shutdown,&mut interval,&checkpoint,std::future::pending())).await.unwrap(),ClientEvent::Checkpoint));
            User::tick(user.lock().await).await.unwrap();
            assert!(user.lock().await.accepts_client_packets());
            assert!(sql.pending_account_save(1).await.unwrap().is_none());
            if matches!(kind,2|3|5|6) {
                let packet=tokio::time::timeout(Duration::from_secs(2),peer.read_packet_async()).await.unwrap().unwrap();
                assert!(matches!(packet,Packet::LoadPalette(_)|Packet::NewDefaultPAs(_)));
            }
            assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
            user.lock().await.queue_disconnect();
            let (result,_)=tokio::time::timeout(Duration::from_secs(2),async{tokio::join!(sql.drain_session_saves(),ack(&mut requests,1,false))}).await.unwrap();result.unwrap();
        }
    }

    #[tokio::test]
    async fn local_checkpoint_wake_failed_save_disconnects_without_timer_or_success() {
        use crate::{user::{local_equipment_save_tests::{fixture,request},packet_handler},sql::local_checkpoint_tests::ack};
        use data_structs::master_ship::MasterShipAction;
        use std::time::Duration;
        let (sql,mut requests,user,mut peer)=fixture().await;
        let checkpoint=user.lock().await.checkpoint_wakeup();
        let (_stop,mut shutdown)=tokio::sync::watch::channel(false);
        let mut interval=tokio::time::interval_at(tokio::time::Instant::now()+Duration::from_secs(60),Duration::from_secs(60));
        packet_handler(user.lock().await,request(3)).await.unwrap();
        assert!(matches!(next_client_event(&mut shutdown,&mut interval,&checkpoint,std::future::pending()).await,ClientEvent::Checkpoint));
        User::tick(user.lock().await).await.unwrap();
        let (action,send)=tokio::time::timeout(Duration::from_secs(2),requests.recv()).await.unwrap().unwrap();
        let MasterShipAction::CommitAccountSnapshot{commit:original,..}=action else{panic!()};drop(send);
        assert!(matches!(tokio::time::timeout(Duration::from_secs(2),next_client_event(
            &mut shutdown,&mut interval,&checkpoint,std::future::pending())).await.unwrap(),ClientEvent::Checkpoint));
        assert!(matches!(User::tick(user.lock().await).await.unwrap(),Action::Disconnect));
        assert!(!user.lock().await.accepts_client_packets());
        assert!(tokio::time::timeout(Duration::from_millis(20),peer.read_packet_async()).await.is_err());
        let serve=async {
            let retry=ack(&mut requests,0,true).await;
            assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&original).unwrap());ack(&mut requests,1,false).await;
        };
        let (result,())=tokio::time::timeout(Duration::from_secs(2),async{tokio::join!(sql.drain_session_saves(),serve)}).await.unwrap();result.unwrap();
    }

    #[tokio::test]
    async fn local_asset_pending_read_is_unpolled_while_ticks_and_shutdown_continue() {
        let (stop, mut shutdown) = tokio::sync::watch::channel(false);
        let checkpoint = tokio::sync::Notify::new();
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(60));
        let polls = std::cell::Cell::new(0);
        let packet = || async {polls.set(polls.get() + 1); Ok(Packet::CharacterListRequest)};
        assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
            read_when_allowed(false, packet())).await, ClientEvent::Tick));
        // Unlike a ready timer, this actually polls the disabled read branch.
        assert!(tokio::time::timeout(std::time::Duration::from_millis(20),
            next_client_event(&mut shutdown, &mut interval, &checkpoint, read_when_allowed(false, packet()))).await.is_err());
        assert_eq!(polls.get(), 0);
        assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
            read_when_allowed(true, packet())).await, ClientEvent::Packet(Ok(Packet::CharacterListRequest))));
        assert_eq!(polls.get(), 1);
        stop.send(true).unwrap();
        assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
            read_when_allowed(false, packet())).await, ClientEvent::Stop));
        assert_eq!(polls.get(), 1);
    }

    #[tokio::test]
    async fn local_checkpoint_due_timer_is_not_starved_by_ready_packets_and_shutdown_wins() {
        let (stop, mut shutdown) = tokio::sync::watch::channel(false);
        let checkpoint = tokio::sync::Notify::new();
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(60));
        interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        for _ in 0..4 {
            // Make both branches genuinely ready despite timer-driver rounding.
            interval.reset_at(tokio::time::Instant::now() - std::time::Duration::from_secs(1));
            assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
                std::future::ready(Ok(Packet::CharacterListRequest))).await, ClientEvent::Tick));
            assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
                std::future::ready(Ok(Packet::CharacterListRequest))).await,
                ClientEvent::Packet(Ok(Packet::CharacterListRequest))));
        }
        interval.reset_at(tokio::time::Instant::now() - std::time::Duration::from_secs(1));
        stop.send(true).unwrap();
        assert!(matches!(next_client_event(&mut shutdown, &mut interval, &checkpoint,
            std::future::ready(Ok(Packet::CharacterListRequest))).await, ClientEvent::Stop));
    }
}
