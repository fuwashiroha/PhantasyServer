//! Te EWH uses displayed target weakness, never a numeric body-part threshold.
use crate::{techniques,weapon_element::WeaponElement};
use std::sync::OnceLock;
#[derive(serde::Deserialize)] struct Target {name:String,elements:Vec<u8>}
#[derive(serde::Deserialize)] struct Hit {id:u32}
#[derive(serde::Deserialize)] struct Catalogue {targets:Vec<Target>,unarmed:Vec<Hit>}
fn catalogue()-> &'static Catalogue {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-techer-element-weak.json"))
        .expect("sourced target weakness profiles"))
}
pub(crate) fn multiplier(rank:usize,id:u32,target:&str,weapon:WeaponElement)->f32 {
    if rank==0 {return 1.0;}
    let Some(profile)=catalogue().targets.iter().find(|t|t.name==target) else {
        // Unknown target weakness cannot be reconstructed from region factors.
        // Additional enemies require an explicit sourced profile.
        return 1.0;
    };
    let tech=techniques::attacks().get(&id).map(|a|a.element.as_str())
        .or_else(||techniques::compounds().get(&id).map(|a|a.element.as_str()));
    let element=if let Some(element)=tech {
        match element {"fire"=>1,"ice"=>2,"thunder"=>3,"wind"=>4,"light"=>5,"dark"=>6,_=>unreachable!("pinned element")}
    } else if let Some(element)=weapon.attack_element(id) {element}
    else if catalogue().unarmed.iter().any(|a|a.id==id) {0}
    else {return 1.0;};
    if profile.elements.contains(&element) {[1.0,1.03,1.06,1.12,1.20,1.20][rank]}
    else {[1.0,1.0,1.0,1.0,1.0,1.10][rank]}
}
