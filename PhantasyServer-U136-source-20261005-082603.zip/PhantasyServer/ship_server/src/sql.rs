use crate::{Error, inventory::Inventory, master_conn::MasterConnection, palette::Palette};
use data_structs::{
    flags::Flags,
    inventory::AccountStorages,
    master_ship::{MasterShipAction, SetNicknameResult, UserCreds, UserLoginResult},
};
use pso2packetlib::{
    AsciiString,
    protocol::{
        PacketType,
        login::{Language, LoginAttempt, UserInfoPacket},
        models::character::Character,
    },
};
use sqlx::{Executor, Row, migrate::MigrateDatabase};
use std::{net::Ipv4Addr, time::Duration};

#[cfg(test)]
mod local_character_tests;
#[cfg(test)]
mod local_session_tests;
// Durable handoff and session ordering share the same Sql instance across blocks.
mod save_journal;
mod session;
mod checkpoint;
pub(crate) use session::AccountSession;
#[cfg(test)]
mod local_journal_tests;
#[cfg(test)]
pub(crate) mod local_lifecycle_tests;
#[cfg(test)]
mod local_pair_tests;
#[cfg(test)]
pub(crate) mod local_checkpoint_tests;
#[cfg(test)]
mod local_deferred_tests;

#[cfg(test)]
async fn remove_test_db(path: &std::path::Path) {
    for attempt in 0..100 {
        match std::fs::remove_file(path) {
            Ok(())=>return,
            Err(e) if cfg!(windows) && e.raw_os_error()==Some(32) && attempt<99=>{
                tokio::time::sleep(Duration::from_millis(20)).await;
            },
            Err(e)=>panic!("Could not remove isolated test database {}: {e}",path.display()),
        }
    }
}
// Storage is prepared before the Classic deletion flag/time contract is wired.
// Keep it out of the live handlers until that contract is verified.
#[allow(dead_code)]
mod deletion;
#[cfg(test)]
mod deletion_tests;

pub struct Sql {
    connection: sqlx::SqlitePool,
    master_ship: MasterConnection,
    sessions: session::Sessions,
}

#[derive(Default, Clone)]
pub struct User {
    pub id: u32,
    pub nickname: String,
    pub lang: Language,
    pub packet_type: PacketType,
    pub accountflags: Flags,
    pub isgm: bool,
    pub last_uuid: u64,
}

#[derive(Default, serde::Serialize, serde::Deserialize)]
#[serde(default)]
struct UserData {
    character_ids: Vec<u32>,
    symbol_arts: Vec<u128>,
    unlocked_quests: Vec<u32>,
    unlocked_quests_notif: Vec<u32>,
}

#[derive(Default, serde::Serialize, serde::Deserialize, Clone)]
#[serde(default)]
pub struct CharData {
    pub character: Character,
    pub inventory: Inventory,
    pub palette: Palette,
    pub flags: Flags,
    pub unlocked_quests: Vec<u32>,
    pub unlocked_quests_notif: Vec<u32>,
    pub play_time: Duration,
    // Appended with serde(default) so older character snapshots still load.
    // Reward and receipt travel through the same character checkpoint.
    pub(crate) quest_meseta_receipts: Vec<crate::user::QuestMesetaReceipt>,
    // Appended: legacy snapshots load with no test overrides. Native skill-tree
    // learning is not yet decoded; never treat these as client skill IDs.
    pub(crate) hero_test_skills: crate::hero_skills::HeroSkills,
    // Appended for compatibility with pre-U092 snapshots. Native tree allocation
    // commits through the existing durable character/account checkpoint.
    pub(crate) native_hero_tree: Option<crate::native_hero_tree::HeroTree>,
    // U100 append-only: old saves keep their Hero tree and acquire no Ph ranks.
    pub(crate) native_phantom_tree: Option<crate::native_phantom_tree::PhantomTree>,
    // U101 append-only. Hr/Ph retain their existing fields and learned ranks.
    pub(crate) native_class_trees: std::collections::BTreeMap<u8,crate::native_class_tree::ClassTree>,
}

#[derive(Default, serde::Serialize, serde::Deserialize)]
pub struct ChallengeData {
    pub lang: Language,
    pub packet_type: PacketType,
}

impl Sql {
    pub async fn new(path: &str, master_ship: MasterConnection) -> Result<Self, Error> {
        sqlx::any::install_default_drivers();
        let conn = if !sqlx::Sqlite::database_exists(path).await.unwrap_or(false) {
            Self::create_db(path).await?
        } else {
            let conn = sqlx::SqlitePool::connect(path).await?;
            sqlx::query("delete from Challenges").execute(&conn).await?;
            conn
        };
        Self::create_schema(&conn).await?;
        Ok(Self {
            connection: conn,
            master_ship,
            sessions: Default::default(),
        })
    }

    async fn create_db(path: &str) -> Result<sqlx::SqlitePool, Error> {
        sqlx::Sqlite::create_database(path).await?;
        let conn = sqlx::SqlitePool::connect(path).await?;
        Self::create_schema(&conn).await?;
        Ok(conn)
    }

    async fn create_schema(conn: &sqlx::SqlitePool) -> Result<(), Error> {
        conn.execute(
            "
            create table if not exists Users (
                Id integer primary key autoincrement,
                Data blob
            );
        ",
        )
        .await?;
        conn.execute(
            "
            create table if not exists Characters (
                Id integer primary key autoincrement,
                Data blob
            );
        ",
        )
        .await?;
        conn.execute(
            "
            create table if not exists SymbolArts (
                UUID blob,
                Name blob,
                Data blob
            );
        ",
        )
        .await?;
        conn.execute(
            "
            create table if not exists Challenges (
                Challenge integer,
                Data blob
            );
        ",
        )
        .await?;
        conn.execute(
            "CREATE TABLE IF NOT EXISTS CharacterDeletions (
                CharacterId INTEGER PRIMARY KEY,
                OwnerId INTEGER NOT NULL,
                RequestedAt INTEGER NOT NULL CHECK (RequestedAt >= 0),
                DeleteAfter INTEGER NOT NULL CHECK (DeleteAfter >= RequestedAt)
            )",
        )
        .await?;
        Self::create_save_schema(conn).await?;
        Self::create_deferred_schema(conn).await?;
        Ok(())
    }

    pub async fn run_action(&self, action: MasterShipAction) -> Result<MasterShipAction, Error> {
        self.master_ship.run_action(action).await
    }

    pub async fn get_sega_user(
        &self,
        username: &str,
        password: &str,
        ip: Ipv4Addr,
    ) -> Result<User, Error> {
        let result = self
            .run_action(MasterShipAction::UserLogin(UserCreds {
                username: username.to_string(),
                password: password.to_string(),
                ip,
            }))
            .await?;
        match result {
            MasterShipAction::UserLoginResult(UserLoginResult::Success {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
            }) => {
                let _: UserData = if let Some(row) =
                    sqlx::query("select Data from Users where Id = ?")
                        .bind(id as i64)
                        .fetch_optional(&self.connection)
                        .await?
                {
                    rmp_serde::from_slice(row.try_get("Data")?)?
                } else {
                    self.insert_local_user(id).await?;
                    Default::default()
                };
                Ok(User {
                    id,
                    nickname,
                    accountflags,
                    isgm,
                    last_uuid,
                    ..Default::default()
                })
            }
            MasterShipAction::UserLoginResult(UserLoginResult::InvalidPassword(_)) => {
                Err(Error::InvalidPassword)
            }
            MasterShipAction::UserLoginResult(UserLoginResult::NotFound) => {
                self.create_sega_user(username, password).await
            }
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn get_psn_user(&self, username: &str, ip: Ipv4Addr) -> Result<User, Error> {
        let result = self
            .run_action(MasterShipAction::UserLoginVita(UserCreds {
                username: username.to_string(),
                password: String::new(),
                ip,
            }))
            .await?;
        match result {
            MasterShipAction::UserLoginResult(UserLoginResult::Success {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
            }) => {
                let _: UserData = if let Some(row) =
                    sqlx::query("select Data from Users where Id = ?")
                        .bind(id as i64)
                        .fetch_optional(&self.connection)
                        .await?
                {
                    rmp_serde::from_slice(row.try_get("Data")?)?
                } else {
                    self.insert_local_user(id).await?;
                    Default::default()
                };
                Ok(User {
                    id,
                    nickname,
                    accountflags,
                    isgm,
                    last_uuid,
                    ..Default::default()
                })
            }
            MasterShipAction::UserLoginResult(UserLoginResult::InvalidPassword(_)) => {
                Err(Error::MSUnexpected)
            }
            MasterShipAction::UserLoginResult(UserLoginResult::NotFound) => {
                self.create_psn_user(username).await
            }
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    async fn create_sega_user(&self, username: &str, password: &str) -> Result<User, Error> {
        let result = self
            .run_action(MasterShipAction::UserRegister(UserCreds {
                username: username.to_string(),
                password: password.to_string(),
                ip: Ipv4Addr::UNSPECIFIED,
            }))
            .await?;
        let user = match result {
            MasterShipAction::UserLoginResult(UserLoginResult::Success {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
            }) => Ok(User {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
                ..Default::default()
            }),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }?;
        self.insert_local_user(user.id).await?;
        Ok(user)
    }
    async fn create_psn_user(&self, username: &str) -> Result<User, Error> {
        let result = self
            .run_action(MasterShipAction::UserRegisterVita(UserCreds {
                username: username.to_string(),
                password: String::new(),
                ip: Ipv4Addr::UNSPECIFIED,
            }))
            .await?;
        let user = match result {
            MasterShipAction::UserLoginResult(UserLoginResult::Success {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
            }) => Ok(User {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
                ..Default::default()
            }),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }?;
        self.insert_local_user(user.id).await?;
        Ok(user)
    }

    async fn insert_local_user(&self, user_id: u32) -> Result<(), Error> {
        let user_data = UserData {
            symbol_arts: vec![0; 10],
            ..Default::default()
        };
        sqlx::query("insert into Users (Id, Data) values (?,?)")
            .bind(user_id as i64)
            .bind(rmp_serde::to_vec(&user_data)?)
            .execute(&self.connection)
            .await?;
        Ok(())
    }

    pub async fn get_user_info(&self, user_id: u32) -> Result<UserInfoPacket, Error> {
        let result = self
            .run_action(MasterShipAction::GetUserInfo(user_id))
            .await?;
        match result {
            MasterShipAction::UserInfo(info) => Ok(info),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn put_user_info(&self, user_id: u32, info: UserInfoPacket) -> Result<(), Error> {
        let result = self
            .run_action(MasterShipAction::PutUserInfo { id: user_id, info })
            .await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn put_account_flags(&self, user_id: u32, flags: Flags) -> Result<(), Error> {
        let result = self
            .run_action(MasterShipAction::PutAccountFlags { id: user_id, flags })
            .await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn new_challenge(
        &self,
        user_id: u32,
        challenge_data: ChallengeData,
    ) -> Result<u32, Error> {
        let result = self
            .run_action(MasterShipAction::NewBlockChallenge(user_id))
            .await?;
        match result {
            MasterShipAction::BlockChallengeResult(challenge) => {
                sqlx::query("insert into Challenges (Challenge, Data) values (?,?)")
                    .bind(challenge as i64)
                    .bind(rmp_serde::to_vec(&challenge_data)?)
                    .execute(&self.connection)
                    .await?;
                Ok(challenge)
            }
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn login_challenge(&self, user_id: u32, challenge: u32) -> Result<User, Error> {
        let result = self
            .run_action(MasterShipAction::ChallengeLogin {
                challenge,
                player_id: user_id,
            })
            .await?;
        match result {
            MasterShipAction::UserLoginResult(UserLoginResult::Success {
                id,
                nickname,
                accountflags,
                isgm,
                last_uuid,
            }) => {
                let row = sqlx::query("select * from Challenges where Challenge = ?")
                    .bind(challenge as i64)
                    .fetch_one(&self.connection)
                    .await?;
                let challenge_data: ChallengeData = rmp_serde::from_slice(row.try_get("Data")?)?;
                let _: UserData = rmp_serde::from_slice(
                    sqlx::query("select Data from Users where Id = ?")
                        .bind(id as i64)
                        .fetch_one(&self.connection)
                        .await?
                        .try_get("Data")?,
                )?;

                Ok(User {
                    id,
                    nickname,
                    lang: challenge_data.lang,
                    packet_type: challenge_data.packet_type,
                    accountflags,
                    isgm,
                    last_uuid,
                })
            }
            MasterShipAction::UserLoginResult(UserLoginResult::InvalidPassword(_)) => {
                Err(Error::MSUnexpected)
            }
            MasterShipAction::UserLoginResult(UserLoginResult::NotFound) => Err(Error::NoUser),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn get_logins(&self, id: u32) -> Result<Vec<LoginAttempt>, Error> {
        let result = self.run_action(MasterShipAction::GetLogins(id)).await?;
        match result {
            MasterShipAction::GetLoginsResult(d) => Ok(d),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn get_settings(&self, id: u32) -> Result<AsciiString, Error> {
        let result = self.run_action(MasterShipAction::GetSettings(id)).await?;
        match result {
            MasterShipAction::GetSettingsResult(d) => Ok(d),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn save_settings(&self, id: u32, settings: &str) -> Result<(), Error> {
        let result = self
            .run_action(MasterShipAction::PutSettings {
                id,
                settings: settings.into(),
            })
            .await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn get_characters(&self, id: u32) -> Result<Vec<CharData>, Error> {
        let mut chars = vec![];
        let mut transaction = self.connection.begin().await?;
        let user_data = Self::read_userdata(&mut transaction, id).await?;
        for char_id in user_data.character_ids {
            let row = sqlx::query("select Data from Characters where Id = ?")
                .bind(char_id as i64)
                .fetch_optional(&mut *transaction)
                .await?;
            if let Some(data) = row {
                let mut char: CharData = rmp_serde::from_slice(data.try_get("Data")?)?;
                char.character.player_id = id;
                char.character.character_id = char_id;
                chars.push(char);
            }
        }
        transaction.commit().await?;
        Ok(chars)
    }
    pub async fn get_character(&self, id: u32, char_id: u32) -> Result<CharData, Error> {
        let mut char = self.load_owned_character(id, char_id).await?;
        // Remote account storage is deliberately outside the local read
        // transaction; it is not a participant in SQLite atomicity.
        char.inventory.storages = self.get_account_storage(id).await?;
        Ok(char)
    }

    async fn load_owned_character(&self, id: u32, char_id: u32) -> Result<CharData, Error> {
        let mut transaction = self.connection.begin().await?;
        let owner = Self::read_userdata(&mut transaction, id).await?;
        Self::require_character_owner(&owner, char_id)?;
        let row = sqlx::query("select Data from Characters where Id = ?")
            .bind(char_id as i64)
            .fetch_one(&mut *transaction)
            .await?;
        let mut char: CharData = rmp_serde::from_slice(row.try_get("Data")?)?;
        char.character.player_id = id;
        char.character.character_id = char_id;
        transaction.commit().await?;
        Ok(char)
    }
    pub async fn update_character(&self, char: &CharData) -> Result<(), Error> {
        let data = rmp_serde::to_vec(&char)?;
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner = Self::read_userdata(&mut transaction, char.character.player_id).await?;
        Self::require_character_owner(&owner, char.character.character_id)?;
        let changed = sqlx::query("update Characters set Data = ? where Id = ?")
            .bind(data)
            .bind(char.character.character_id as i64)
            .execute(&mut *transaction)
            .await?;
        if changed.rows_affected() != 1 { return Err(Error::InvalidInput("character_missing")); }
        transaction.commit().await?;
        Ok(())
    }
    pub async fn put_character(&self, id: u32, char: CharData) -> Result<u32, Error> {
        let data = rmp_serde::to_vec(&char)?;
        // Reserve the local write transaction before reading the membership
        // list, so two writers cannot both replace it from a stale snapshot.
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let mut owner = Self::read_userdata(&mut transaction, id).await?;
        let char_id = sqlx::query("insert into Characters (Data) values (?) returning Id")
            .bind(&data)
            .fetch_one(&mut *transaction)
            .await?
            .try_get::<i64, _>("Id")?;
        let char_id = u32::try_from(char_id).map_err(|_| Error::InvalidInput("character_id_range"))?;
        owner.character_ids.push(char_id);
        Self::write_userdata(&mut transaction, id, &owner).await?;
        transaction.commit().await?;
        Ok(char_id)
    }
    pub async fn delete_character(&self, id: u32, char_id: u32) -> Result<(), Error> {
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let mut owner = Self::read_userdata(&mut transaction, id).await?;
        Self::require_character_owner(&owner, char_id)?;
        Self::delete_owned_character_row(&mut transaction, id, char_id).await?;
        owner.character_ids.retain(|id| *id != char_id);
        Self::write_userdata(&mut transaction, id, &owner).await?;
        transaction.commit().await?;
        Ok(())
    }
    pub async fn get_symbol_art_list(&self, id: u32) -> Result<Vec<u128>, Error> {
        let row = sqlx::query("select Data from Users where Id = ?")
            .bind(id as i64)
            .fetch_one(&self.connection)
            .await?;
        let user_data: UserData = rmp_serde::from_slice(row.try_get("Data")?)?;
        Ok(user_data.symbol_arts)
    }
    pub async fn set_symbol_art_list(&self, uuids: Vec<u128>, id: u32) -> Result<(), Error> {
        self.update_userdata(id, |user_data| user_data.symbol_arts = uuids)
            .await
    }
    pub async fn get_symbol_art(&self, uuid: u128) -> Result<Option<Vec<u8>>, Error> {
        let row = sqlx::query("select * from SymbolArts where UUID = ?")
            .bind(format!("{uuid:X}").as_bytes())
            .fetch_optional(&self.connection)
            .await?;
        match row {
            Some(data) => Ok(Some(data.try_get::<Vec<u8>, _>("Data")?)),
            None => Ok(None),
        }
    }
    pub async fn add_symbol_art(&self, uuid: u128, data: &[u8], name: &str) -> Result<(), Error> {
        sqlx::query("insert into SymbolArts (UUID, Name, Data) values (?, ?, ?)")
            .bind(format!("{uuid:X}").as_bytes())
            .bind(name.as_bytes())
            .bind(data)
            .execute(&self.connection)
            .await?;
        Ok(())
    }
    pub async fn get_account_storage(&self, user_id: u32) -> Result<AccountStorages, Error> {
        let result = self
            .run_action(MasterShipAction::GetStorage(user_id))
            .await?;
        match result {
            MasterShipAction::GetStorageResult(storages) => Ok(storages),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn update_account_storage(&self, user_id: u32, inv: &Inventory) -> Result<(), Error> {
        let result = self
            .run_action(MasterShipAction::PutStorage {
                id: user_id,
                storage: inv.storages.clone(),
            })
            .await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn save_session_account(&self, data: &User, inv: &Inventory) -> Result<(), Error> {
        let result = self.run_action(MasterShipAction::PutAccountSnapshot {
            id: data.id,
            snapshot: data_structs::master_ship::AccountSnapshot {
                storage: inv.storages.clone(),
                flags: data.accountflags.clone(),
                last_uuid: data.last_uuid,
            },
        }).await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn put_uuid(&self, user_id: u32, uuid: u64) -> Result<(), Error> {
        let result = self
            .run_action(MasterShipAction::PutUUID { id: user_id, uuid })
            .await?;
        match result {
            MasterShipAction::Ok => Ok(()),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn set_username(
        &self,
        user_id: u32,
        nickname: &str,
    ) -> Result<SetNicknameResult, Error> {
        let result = self
            .run_action(MasterShipAction::SetNickname {
                id: user_id,
                nickname: nickname.to_string(),
            })
            .await?;
        match result {
            MasterShipAction::SetNicknameResult(res) => Ok(res),
            MasterShipAction::Error(e) => Err(Error::MSError(e)),
            _ => Err(Error::MSUnexpected),
        }
    }
    pub async fn set_account_data(&self, data: User) -> Result<(), Error> {
        self.put_account_flags(data.id, data.accountflags).await?;
        self.put_uuid(data.id, data.last_uuid).await?;
        Ok(())
    }
    async fn update_userdata<F>(&self, user_id: u32, f: F) -> Result<(), Error>
    where
        F: FnOnce(&mut UserData) + Send,
    {
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let mut user_data = Self::read_userdata(&mut transaction, user_id).await?;
        f(&mut user_data);
        Self::write_userdata(&mut transaction, user_id, &user_data).await?;
        transaction.commit().await?;
        Ok(())
    }

    async fn read_userdata(connection: &mut sqlx::SqliteConnection, user_id: u32) -> Result<UserData, Error> {
        let row = sqlx::query("select Data from Users where Id = ?")
            .bind(user_id as i64)
            .fetch_one(connection)
            .await?;
        Ok(rmp_serde::from_slice(row.try_get("Data")?)?)
    }

    async fn write_userdata(connection: &mut sqlx::SqliteConnection, user_id: u32, data: &UserData) -> Result<(), Error> {
        let changed = sqlx::query("update Users set Data = ? where Id = ?")
            .bind(rmp_serde::to_vec(data)?)
            .bind(user_id as i64)
            .execute(connection)
            .await?;
        if changed.rows_affected() != 1 { return Err(Error::InvalidInput("character_owner_missing")); }
        Ok(())
    }

    fn require_character_owner(owner: &UserData, char_id: u32) -> Result<(), Error> {
        if !owner.character_ids.contains(&char_id) { return Err(Error::InvalidInput("character_ownership")); }
        Ok(())
    }
}

#[cfg(test)]
impl Sql {
    pub(crate) async fn in_memory_for_test() -> Result<Self, Error> {
        Ok(Self {
            connection: sqlx::sqlite::SqlitePoolOptions::new().max_connections(1)
                .connect("sqlite::memory:").await?,
            master_ship: MasterConnection::disconnected_for_test(),
            sessions: Default::default(),
        })
    }
}
