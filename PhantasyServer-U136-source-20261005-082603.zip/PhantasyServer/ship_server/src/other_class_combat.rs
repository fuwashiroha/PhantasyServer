//! Pinned unconditional Fi/Gu/Br/Bo/Su skill values, evaluated from validated saved trees.
//! Stance, gear, PP and pet stat inheritance require their own state models.
use crate::{Error,native_class_tree::{self,ClassTree},sql::CharData};
use std::sync::OnceLock;
#[derive(serde::Deserialize)]
struct Effect {slot:u8,name:String,kind:String,values:Vec<u32>}
#[derive(serde::Deserialize)]
struct Catalogue {effects:Vec<Effect>}
fn effects()-> &'static [Effect] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-other-class-stats.json")).expect("pinned ordinary class stats")).effects
}
#[derive(Debug,Clone)]
pub(crate) struct OtherClassCombat {
    pub hp:u32,pub mel:u32,pub rng:u32,pub tec:u32,pub dex:u32,
    pub mel_def:u32,pub rng_def:u32,pub tec_def:u32,pub outgoing:f32,
    halfline:u8,deadline:u8,perfect_keeper:u8,su_bonus1:u8,su_bonus2:u8,attack_advance:u8,charge_shoot:u8,
}
impl Default for OtherClassCombat {
    fn default()->Self {Self{hp:0,mel:0,rng:0,tec:0,dex:0,mel_def:0,rng_def:0,tec_def:0,outgoing:1.0,halfline:0,deadline:0,perfect_keeper:0,su_bonus1:0,su_bonus2:0,attack_advance:0,charge_shoot:0}}
}
impl OtherClassCombat {
    pub(crate) fn build(c:&CharData)->Result<Self,Error> {
        let mut result=Self::default();
        for slot in [3,4,6,7,9] {
            if c.character.classes.main_class as u8!=slot && c.character.classes.sub_class as u8!=slot {continue;}
            let info=native_class_tree::class_level(&c.character.classes,slot)?;
            let tree=c.native_class_trees.get(&slot).cloned().unwrap_or_default().at_level(slot,info.level1)?;
            tree.validate(slot,info.level1,info.level2)?;
            result.add_tree(slot,&tree);
        }
        Ok(result)
    }
    pub(crate) fn charged_shot_multiplier(&self,id:u32)->f32 {
        // Original charged normal root; a PA being charged is not sufficient.
        if id==data_structs::name_to_id("CompoundBow:A1c1") {
            [1.0,1.03,1.06,1.09,1.12,1.15][self.charge_shoot as usize]
        }else{1.0}
    }
    pub(crate) fn normal_multiplier(&self,id:u32)->f32 {
        #[derive(serde::Deserialize)] struct Attack {id:u32}
        #[derive(serde::Deserialize)] struct Normals {attacks:Vec<Attack>}
        static IDS:OnceLock<std::collections::HashSet<u32>>=OnceLock::new();
        let ids=IDS.get_or_init(||serde_json::from_str::<Normals>(include_str!("../testdata/classic-braver-normal-attacks.json"))
            .expect("pinned ordinary normal attacks").attacks.into_iter().map(|a|a.id).collect());
        if ids.contains(&id) {[1.0,1.10,1.20,1.25,1.30,1.35][self.attack_advance as usize]}else{1.0}
    }
    pub(crate) fn summoner_multiplier(&self,id:u32)->f32 {
        // Additional-damage accumulators/chases must not multiply this bonus twice.
        // Keep every original family alias excluded, even before its damage route exists.
        #[derive(serde::Deserialize)] struct Excluded {id:u32}
        #[derive(serde::Deserialize)] struct Exclusions {exclusions:Vec<Excluded>}
        static IDS:OnceLock<std::collections::HashSet<u32>>=OnceLock::new();
        if IDS.get_or_init(||serde_json::from_str::<Exclusions>(include_str!("../testdata/classic-summoner-all-attack.json"))
            .expect("pinned Su exclusions").exclusions.into_iter().map(|e|e.id).collect()).contains(&id) {return 1.0;}
        let values=[1.0,1.03,1.06,1.09,1.12,1.15];
        values[self.su_bonus1 as usize]*values[self.su_bonus2 as usize]
    }
    pub(crate) fn hp_attack(&self,hp:u32,max_hp:u32)->u32 {
        if hp==0 || max_hp==0 {return 0;}
        let half=if u64::from(hp)*2<=u64::from(max_hp) {[0,20,22,24,26,28,34,40,60,80,100][self.halfline as usize]}else{0};
        let dead=if u64::from(hp)*4<=u64::from(max_hp) {[0,40,44,49,54,60,67,75,100,125,150][self.deadline as usize]}else{0};
        half+dead
    }
    pub(crate) fn hp_multiplier(&self,hp:u32,max_hp:u32)->f32 {
        if hp==0 || max_hp==0 || u64::from(hp)*4<u64::from(max_hp)*3 {return 1.0;}
        [1.0,1.10,1.11,1.12,1.13,1.14,1.15,1.16,1.17,1.18,1.20][self.perfect_keeper as usize]
    }
    fn add_tree(&mut self,slot:u8,tree:&ClassTree) {
        if slot==3 {self.halfline=tree.rank("HalflineSlayer");self.deadline=tree.rank("DeadlineSlayer");}
        if slot==4 {self.perfect_keeper=tree.rank("PerfectKeeper");}
        if slot==6 {self.attack_advance=tree.rank("AttackAdvance");self.charge_shoot=tree.rank("ChargeShoot");}
        if slot==9 {self.su_bonus1=tree.rank("AllAttackBonus1");self.su_bonus2=tree.rank("AllAttackBonus2");}
        for e in effects().iter().filter(|e|e.slot==slot) {
            let rank=tree.rank(&e.name);if rank==0 {continue;}
            let value=e.values[rank as usize-1];
            match e.kind.as_str() {
                "hp"=>self.hp+=value,"mel"=>self.mel+=value,"rng"=>self.rng+=value,"tec"=>self.tec+=value,"dex"=>self.dex+=value,
                "mel_def"=>self.mel_def+=value,"rng_def"=>self.rng_def+=value,
                "all_attack"=>{self.mel+=value;self.rng+=value;self.tec+=value;},
                "all_defense"=>{self.mel_def+=value;self.rng_def+=value;self.tec_def+=value;},
                "outgoing"=>self.outgoing*=value as f32/100.0,
                _=>unreachable!("pinned stat effect kind"),
            }
        }
    }
}
