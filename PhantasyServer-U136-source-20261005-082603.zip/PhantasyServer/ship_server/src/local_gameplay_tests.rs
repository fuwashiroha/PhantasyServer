use super::*;
use pso2packetlib::protocol::{questlist::AcceptQuestPacket, server::MapLoadedPacket};
use std::time::Duration;
use tokio::net::{TcpListener, TcpStream};

// Exercise the real packet handler, party and both maps. Only transport/database
// setup is synthetic, and no test connects to the installed server or user saves.
#[tokio::test]
async fn local_gameplay_abandon_returns_all_members_and_finishes_loading() {
    exercise_party_transfers(false, false, None).await;
}

#[tokio::test]
async fn local_gameplay_telepipe_preserves_quest_and_other_member() {
    exercise_party_transfers(true, false, None).await;
}

#[tokio::test]
async fn local_gameplay_player_death_broadcasts_and_party_continues() {
    exercise_party_transfers(false, true, None).await;
}

#[tokio::test]
async fn local_reward_invalid_first_recipient_is_atomic_and_retryable() {
    exercise_party_transfers(false, false, Some("first")).await;
}

#[tokio::test]
async fn local_reward_invalid_later_recipient_is_atomic_and_retryable() {
    exercise_party_transfers(false, false, Some("later")).await;
}

#[tokio::test]
async fn local_reward_busy_recipient_releases_locks_and_handler_retries() {
    exercise_party_transfers(false, false, Some("busy")).await;
}

#[tokio::test]
async fn local_reward_cancelled_busy_attempt_has_no_partial_state() {
    exercise_party_transfers(false, false, Some("cancel")).await;
}

#[tokio::test]
async fn local_launcher_packet_kill_rewards_and_abandon_returns_to_lobby() {
    exercise_party_transfers(false, false, Some("launcher")).await;
}

async fn exercise_reward_transaction(
    players: &[Arc<Mutex<User>>],
    received: &[Arc<tokio::sync::Mutex<Vec<Packet>>>],
    quest_map: &Arc<Mutex<map::Map>>,
    case: &str,
) {
    use pso2packetlib::protocol::{ObjectHeader,ObjectType,playerstatus::DealDamagePacket};
    let actors=case=="completion_actors";
    let completion=case=="completion" || actors;
    let zone=players[0].lock().await.zone_pos;
    for index in 0..2 {
        Box::pin(user::packet_handler(players[index].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
        wait_for_finish(&received[index]).await;
        if actors {map::local_completion_actor_tests::assert_spawns(&received[index].lock().await,0);}
        received[index].lock().await.clear();
    }
    quest_map.lock().await.spawn_enemy(zone,"SoldierAnt",Default::default()).await.unwrap();
    let enemy=tokio::time::timeout(Duration::from_secs(2),async {
        loop {
            if let Some(object)=received[0].lock().await.iter().find_map(|p| match p {
                Packet::EnemySpawn(data)=>Some(data.object),_=>None,
            }) { break object; }
            tokio::task::yield_now().await;
        }
    }).await.unwrap();
    let attack=DealDamagePacket {
        inflicter:ObjectHeader {id:1,entity_type:ObjectType::Player,..Default::default()},
        target:enemy,attack_id:data_structs::name_to_id(if case=="launcher" {"Launcher:PA7"} else {"Rifle:A1"}),..Default::default()
    };
    assert_eq!(quest_map.lock().await.local_enemy_hp(zone,enemy.id),Some(1));
    let mut already_killed=false;
    if completion {
        assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::ReturnToCampshipFinal(Default::default()))).await.is_err());
        assert_eq!(players[0].lock().await.zone_pos,zone);
    }
    if case=="first" || case=="later" || completion {
        let index=if case=="first" {0} else {1};
        let saved=players[index].lock().await.character.as_ref().unwrap().character.classes.clone();
        // The second case previously committed player 1 before discovering
        // player 2's overflowing EXP, leaving the dead enemy reusable.
        {
            let mut user=players[index].lock().await;
            let level=user.character.as_mut().unwrap().character.get_level_mut();
            if case=="first" {level.level1=0;} else {level.exp=u32::MAX;}
        }
        for _ in 0..2 {
            let result=tokio::time::timeout(Duration::from_secs(2),Box::pin(user::packet_handler(
                players[0].lock().await,Packet::DealDamage(attack.clone())))).await.unwrap();
            assert!(matches!(result,Err(Error::InvalidInput(_))));
            assert_eq!(quest_map.lock().await.local_enemy_hp(zone,enemy.id),Some(1));
            if completion {assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::ReturnToCampshipFinal(Default::default()))).await.is_err());}
            let other=players[1-index].lock().await;
            let c=&other.character.as_ref().unwrap().character;
            assert_eq!(c.get_level().exp,0);
            assert_eq!(c.get_sublevel().exp,0);
            for packets in received {
                assert!(!packets.lock().await.iter().any(|p| matches!(p,Packet::DamageReceive(_)|Packet::EnemyKilled(_)|Packet::GainedEXP(_))));
                if actors {map::local_completion_actor_tests::assert_spawns(&packets.lock().await,0);}
            }
        }
        players[index].lock().await.character.as_mut().unwrap().character.classes=saved;
    } else if case=="busy" || case=="cancel" {
        let held=players[1].lock().await;
        let result=quest_map.lock().await.deal_damage(zone,attack.clone()).await;
        assert!(matches!(result,Err(Error::CombatBusy)));
        assert_eq!(quest_map.lock().await.local_enemy_hp(zone,enemy.id),Some(1));
        assert_eq!(players[0].lock().await.character.as_ref().unwrap().character.get_level().exp,0);
        let actor=players[0].clone();
        let hit=attack.clone();
        let job=tokio::spawn(async move {Box::pin(user::packet_handler(actor.lock().await,Packet::DealDamage(hit))).await});
        tokio::time::sleep(Duration::from_millis(10)).await;
        // While the other player remains locked, map and attacker must be free.
        let map_guard=tokio::time::timeout(Duration::from_millis(200),quest_map.lock()).await.unwrap();
        assert_eq!(map_guard.local_enemy_hp(zone,enemy.id),Some(1));
        drop(map_guard);
        let actor_guard=tokio::time::timeout(Duration::from_millis(200),players[0].lock()).await.unwrap();
        assert_eq!(actor_guard.character.as_ref().unwrap().character.get_level().exp,0);
        drop(actor_guard);
        assert!(!job.is_finished());
        if case=="cancel" {
            job.abort();
            assert!(matches!(job.await, Err(error) if error.is_cancelled()));
            drop(held);
        } else {
            drop(held);
            tokio::time::timeout(Duration::from_secs(2),job).await.unwrap().unwrap().unwrap();
            already_killed=true;
        }
    }
    if !already_killed {
        Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack.clone()))).await.unwrap();
    }
    assert_eq!(quest_map.lock().await.local_enemy_hp(zone,enemy.id),None);
    // Replaying the fatal hit after commit must not grant EXP or emit another kill.
    Box::pin(user::packet_handler(players[0].lock().await,Packet::DealDamage(attack))).await.unwrap();
    for index in 0..2 {
        Box::pin(user::packet_handler(players[index].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
        wait_for_finish(&received[index]).await; // Ordered transport barrier after the reward/replay.
        let packets=received[index].lock().await;
        if actors {map::local_completion_actor_tests::assert_spawns(&packets,1);}
        let awards:Vec<_>=packets.iter().filter_map(|p| match p {Packet::GainedEXP(p)=>Some(p),_=>None}).collect();
        assert_eq!(awards.len(),1);
        assert_eq!(packets.iter().filter(|p|matches!(p,Packet::EnemyKilled(_))).count(),1);
        assert_eq!(awards[0].receivers.len(),2);
        for recipient in &awards[0].receivers {
            assert_eq!((recipient.gained,recipient.total),(28,28));
            assert_eq!((recipient.gained_sub,recipient.total_sub),if recipient.object.id==1 {(14,14)} else {(7,7)});
        }
        let user=players[index].lock().await;
        let character=&user.character.as_ref().unwrap().character;
        assert_eq!(character.get_level().exp,28);
        assert_eq!(character.get_sublevel().exp,if index==0 {14} else {7});
    }
    if completion {
        for packets in received {packets.lock().await.clear();}
        quest_map.lock().await.local_rename_zone("campship","missing_campship");
        assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::ReturnToCampshipFinal(Default::default()))).await.is_err());
        assert_eq!(players[0].lock().await.zone_pos,zone);
        quest_map.lock().await.local_rename_zone("missing_campship","campship");
        let cid=players[0].lock().await.character.as_ref().unwrap().character.character_id;
        players[0].lock().await.character.as_mut().unwrap().character.character_id=9999;
        assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::ReturnToCampshipFinal(Default::default()))).await.is_err());
        players[0].lock().await.character.as_mut().unwrap().character.character_id=cid;
        for _ in 0..2 {Box::pin(user::packet_handler(players[0].lock().await,Packet::ReturnToCampshipFinal(Default::default()))).await.unwrap();}
        assert_ne!(players[0].lock().await.zone_pos,zone);assert_eq!(players[1].lock().await.zone_pos,zone);
        let before=serde_json::to_value(players[0].lock().await.character.as_ref().unwrap()).unwrap();
        // Missing lease must not mutate balance or send a result. The real
        // SQLite/result-ACK path is exercised by local_quest_completion_durable_.
        assert!(Box::pin(user::packet_handler(players[0].lock().await,Packet::MapLoaded(Default::default()))).await.is_err());
        wait_for_finish(&received[0]).await;
        assert_eq!(serde_json::to_value(players[0].lock().await.character.as_ref().unwrap()).unwrap(),before);
        let packets=received[0].lock().await;
        assert_eq!(packets.iter().filter(|p|matches!(p,Packet::MapTransfer(_))).count(),1);
        assert!(!packets.iter().any(|p|matches!(p,Packet::QuestResult(_)|Packet::InventoryMeseta(_))));
        assert!(!received[1].lock().await.iter().any(|p|matches!(p,Packet::MapTransfer(_)|Packet::QuestResult(_))));
        drop(packets);
        if actors {
            received[0].lock().await.clear();
            Box::pin(quest_map.lock().await.move_player_named(1,"campship_down")).await.unwrap();
            Box::pin(user::packet_handler(players[0].lock().await,Packet::MapLoaded(Default::default()))).await.unwrap();
            wait_for_finish(&received[0]).await;
            map::local_completion_actor_tests::assert_spawns(&received[0].lock().await,1);
        }
    }

}

#[tokio::test]
async fn local_quest_completion_real_kill_final_return_and_invalid_paths() {
    exercise_party_transfers(false,false,Some("completion")).await;
}

#[tokio::test]
async fn local_completion_actor_real_kill_once_and_reload() {
    exercise_party_transfers(false,false,Some("completion_actors")).await;
}

mod local_death_return_tests;
mod local_measurement_tests;
mod local_custom_rockbear_tests;
async fn exercise_party_transfers(test_telepipe: bool, test_death: bool, reward_case: Option<&str>) {
    exercise_party_transfers_with_revival(test_telepipe,test_death,reward_case,None).await;
}
async fn exercise_party_transfers_with_revival(test_telepipe: bool, test_death: bool, reward_case: Option<&str>, revival_case:Option<&str>) {
    let mut data = ServerData::load_from_mp_comp(
        std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")
    ).unwrap();
    if test_death {
        // In-memory deterministic fixture, not an original enemy-balance claim.
        for level in &mut data.enemy_stats.base.levels {
            level.min_mel_dmg=100.0; level.max_mel_dmg=100.0;
        }
        for level in &mut data.enemy_stats.enemies.get_mut("SoldierAnt").unwrap().levels {
            level.min_mel_dmg=1.0; level.max_mel_dmg=1.0;
        }
    }
    if reward_case.is_some() {
        // Deterministic synthetic enemy for reward transaction tests only.
        for level in &mut data.enemy_stats.base.levels { level.hp=1.0; level.exp=28.0; level.rng_def=0.0; }
        let enemy=data.enemy_stats.enemies.get_mut("SoldierAnt").unwrap();
        for level in &mut enemy.levels { level.hp=1.0; level.exp=1.0; }
        for hitbox in &mut enemy.hitboxes { hitbox.hitbox_id=0; hitbox.damage_mul=1.0; hitbox.rng_mul=1.0; }
    }
    if matches!(reward_case,Some("measurement"|"custom_rockbear")) {
        for level in &mut data.enemy_stats.base.levels {level.hp=10_000.0;}
        let normal=data.attack_stats.iter().find(|a|a.attack_id==data_structs::name_to_id("Rifle:A1")).unwrap().clone();
        for (name,mul) in [("MeasurementFixtureExcluded",1.0),("MeasurementFixtureKill",1_000_000.0)] {
            let mut row=normal.clone();row.attack_id=data_structs::name_to_id(name);row.damage=data_structs::stats::DamageType::Generic(mul);data.attack_stats.push(row);
        }
    }
    assert!(data.quests.iter().all(|q|q.completion.is_empty()),"No unverified production quest profile may be imported");
    if matches!(reward_case,Some("completion" | "completion_actors")) {
        let q=data.quests.iter_mut().find(|q|q.definition.name_id==200030).unwrap();
        let zone_id=q.map.zones.iter().find(|z|z.name=="campship_down").unwrap().zone_id;
        let activation=if reward_case==Some("completion_actors") {map::local_completion_actor_tests::add_fixture_actors(&mut q.map,zone_id);map::local_completion_actor_tests::IDS.to_vec()} else {vec![]};
        q.completion=vec![data_structs::quest::QuestCompletionRule {difficulty:0,zone_id,
            enemy_name:"SoldierAnt".into(),required_kills:1,participants:data_structs::quest::QuestParticipantRule::AnyObjectiveKillRecipient,activate_on_completion:activation,
            result:pso2packetlib::protocol::questlist::QuestResultPacket{meseta_earned:50,..Default::default()},
            evidence:"Synthetic integration fixture; not original objective/rank/eligibility".into()}];
    }
    let data=Arc::new(data);
    let ids = AtomicU32::new(1);
    let mut lobby = map::Map::new_from_data(data.maps["lobby"].clone(), &ids).unwrap();
    lobby.set_map_type(map::MapType::Lobby);
    let block = Arc::new(BlockData {
        sql: Arc::new(sql::Sql::in_memory_for_test().await.unwrap()),
        block_id: 1,
        block_name: "regression".into(),
        blocks: Arc::new(RwLock::new(vec![])),
        lobby: Arc::new(Mutex::new(lobby)),
        key: PrivateKey::None,
        latest_mapid: ids,
        latest_partyid: AtomicU32::new(1),
        server_data: data.clone(),
        quests: Arc::new(Quests::load(data.quests.clone())),
        clients: Mutex::new(vec![]),
    });
    block.lobby.lock().await.set_block_data(block.clone());
    let mut players = vec![];
    let mut received = vec![];
    let mut readers = vec![];
    let mut read_halves = vec![];
    for id in 1..=2 {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let client = TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
        let (stream, _) = listener.accept().await.unwrap();
        let (mut user, read_half) = User::new(stream, block.clone(), id as usize).unwrap();
        read_halves.push(read_half);
        user.user_data.id = id;
        user.state = user::UserState::InGame;
        let mut character = sql::CharData::default();
        character.character.player_id = id;
        character.character.character_id = id;
        if reward_case.is_some() {
            use pso2packetlib::protocol::models::character::{Class,ClassLevel};
            character.character.classes.main_class=if id==1 {Class::Summoner} else {Class::Hunter};
            character.character.classes.sub_class=Class::Ranger;
            *character.character.get_level_mut()=ClassLevel {level1:1,level2:1,exp:0};
            *character.character.get_sublevel_mut()=ClassLevel {level1:1,level2:1,exp:0};
        }
        user.character = Some(character);
        if reward_case.is_some() { *user.get_stats_mut()=battle_stats::PlayerStats::build(&user).unwrap(); }
        if test_death {
            *user.get_stats_mut()=battle_stats::local_player_with_hp(if id==1 {21} else {100});
        }
        let user = Arc::new(Mutex::new(user));
        let packets = Arc::new(tokio::sync::Mutex::new(vec![]));
        let output = packets.clone();
        readers.push(tokio::spawn(async move {
            let mut peer: Connection<Packet> = Connection::new_async(
                client, PacketType::Classic, PrivateKey::None, PublicKey::None);
            while let Ok(packet) = peer.read_packet_async().await {
                output.lock().await.push(packet);
            }
        }));
        players.push(user);
        received.push(packets);
    }
    party::Party::init_player(players[0].clone(), 1).await.unwrap();
    let party = players[0].lock().await.get_current_party().unwrap();
    party.write().await.add_player(players[1].clone()).await.unwrap();
    players[1].lock().await.party = Some(party.clone());

    // Cover abandonment from the campship, then the field; repeat in the lobby.
    for zone in ["campship", "campship_down"] {
        let quest = block.quests.get_quest(AcceptQuestPacket {
            quest_obj: block.quests.get_quest_by_nameid(if reward_case==Some("custom_rockbear") {161500} else {200030}).unwrap().definition.quest_obj,
            ..Default::default()
        }, &block.latest_mapid).unwrap();
        let quest_map = quest.get_map();
        quest_map.lock().await.set_block_data(block.clone());
        party.write().await.set_quest(quest).await;
        let mut campship_zone = None;
        for user in &players {
            let mut lock = user.lock().await;
            let id = lock.get_user_id();
            let old = lock.get_current_map();
            lock.set_map(quest_map.clone());
            drop(lock);
            if let Some(old) = old { old.lock().await.remove_player(id).await; }
            quest_map.lock().await.init_add_player(user.clone()).await.unwrap();
            campship_zone = Some(user.lock().await.zone_pos);
            if zone == "campship_down" {
                quest_map.lock().await.move_player_named(id, zone).await.unwrap();
            }
        }
        if let Some(case)=reward_case.filter(|_| zone=="campship_down") {
            if case=="custom_rockbear" {Box::pin(local_custom_rockbear_tests::exercise(&players,&received,&quest_map)).await;}
            else if case=="measurement" {Box::pin(local_measurement_tests::exercise(&players,&received,&quest_map)).await;}
            else {Box::pin(exercise_reward_transaction(&players,&received,&quest_map,case)).await;}
        }
        if test_death && zone == "campship_down" {
            exercise_lethal_damage(&players, &received, &quest_map).await;
            assert!(party.read().await.get_quest_map().is_some());
            if let Some(case)=revival_case {local_death_return_tests::exercise_revival(&players,&received,&quest_map,&party,campship_zone.unwrap(),case).await;}
        }
        if test_telepipe && zone == "campship_down" {
            let field_zone = players[1].lock().await.zone_pos;
            assert_ne!(Some(field_zone), campship_zone);
            // Synchronize pending field-load packets, so stale FinishLoading cannot pass.
            for index in 0..2 {
                user::packet_handler(players[index].lock().await,
                    Packet::MapLoaded(MapLoadedPacket::default())).await.unwrap();
                wait_for_finish(&received[index]).await;
                received[index].lock().await.clear();
            }
            for _ in 0..2 {
                tokio::time::timeout(Duration::from_secs(2), user::packet_handler(
                    players[0].lock().await, Packet::ReturnToCampship(Default::default())))
                    .await.expect("Telepipe must release player and party locks").unwrap();
                assert_eq!(Some(players[0].lock().await.zone_pos), campship_zone);
                assert_eq!(players[1].lock().await.zone_pos, field_zone);
                assert!(Arc::ptr_eq(&party.read().await.get_quest_map().unwrap(), &quest_map));
                assert!(Arc::ptr_eq(&players[0].lock().await.get_current_map().unwrap(), &quest_map));
                user::packet_handler(players[0].lock().await,
                    Packet::MapLoaded(MapLoadedPacket::default())).await.unwrap();
                wait_for_finish(&received[0]).await;
                let packets = std::mem::take(&mut *received[0].lock().await);
                let transfers: Vec<_> = packets.iter().filter_map(|p| match p {
                    Packet::MapTransfer(data) => Some(data), _ => None,
                }).collect();
                assert_eq!(transfers.len(), 1);
                assert_eq!(transfers[0].target.id, 1);
                assert!(!received[1].lock().await.iter().any(|p| matches!(p, Packet::MapTransfer(_))));
            }
            user::packet_handler(players[0].lock().await,
                Packet::CampshipDown(Default::default())).await.unwrap();
            assert_eq!(players[0].lock().await.zone_pos, field_zone);
        }
        tokio::time::timeout(Duration::from_secs(2),
            user::handlers::party::abandon_quest(players[0].lock().await))
            .await.expect("Abandon must release party lock before loading the lobby")
            .unwrap();
        assert!(party.read().await.get_quest_map().is_none());
        if test_telepipe {
            let result = user::packet_handler(players[0].lock().await,
                Packet::ReturnToCampship(Default::default())).await;
            assert!(matches!(result, Err(Error::InvalidInput("return_to_campship"))));
        }
        for (index, user) in players.iter().enumerate() {
            let current = user.lock().await.get_current_map().unwrap();
            assert!(Arc::ptr_eq(&current, &block.lobby));
            user::handlers::server::map_loaded(user.lock().await, MapLoadedPacket::default()).await.unwrap();
            tokio::time::timeout(Duration::from_secs(2), async {
                loop {
                    if received[index].lock().await.iter().any(|p| matches!(p, Packet::FinishLoading)) { break; }
                    tokio::task::yield_now().await;
                }
            }).await.expect("Client must receive FinishLoading");
            let packets = std::mem::take(&mut *received[index].lock().await);
            assert!(packets.iter().any(|p| matches!(p, Packet::LoadLevel(_))));
        }
        tokio::time::timeout(Duration::from_secs(2),
            user::handlers::party::abandon_quest(players[0].lock().await))
            .await.expect("Repeated abandon in lobby must be harmless").unwrap();
    }
    if reward_case==Some("custom_rockbear") {
        Box::pin(local_custom_rockbear_tests::chat(&players[1],"!rockbear enter")).await;
        assert!(party.read().await.get_quest_map().is_none());
        Box::pin(local_custom_rockbear_tests::chat(&players[0],"!rockbear enter")).await;
        assert!(party.read().await.get_quest_map().is_some());
        tokio::time::timeout(Duration::from_secs(2),Box::pin(user::handlers::party::abandon_quest(players[0].lock().await))).await.unwrap().unwrap();
    }
    for user in players {
        let mut lock = user.lock().await;
        lock.character = None;
        lock.party = None;
    }
    for reader in readers { reader.abort(); }
}

async fn wait_for_finish(packets: &Arc<tokio::sync::Mutex<Vec<Packet>>>) {
    tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            if packets.lock().await.iter().any(|p| matches!(p, Packet::FinishLoading)) { break; }
            tokio::task::yield_now().await;
        }
    }).await.expect("Client transport must receive FinishLoading");
}

async fn exercise_lethal_damage(
    players: &[Arc<Mutex<User>>],
    received: &[Arc<tokio::sync::Mutex<Vec<Packet>>>],
    quest_map: &Arc<Mutex<map::Map>>,
) {
    use pso2packetlib::protocol::{ObjectHeader, ObjectType, playerstatus::DealDamagePacket};
    let zone=players[0].lock().await.zone_pos;
    quest_map.lock().await.spawn_enemy(zone,"SoldierAnt",Default::default()).await.unwrap();
    let enemy=tokio::time::timeout(Duration::from_secs(2), async {
        loop {
            if let Some(object)=received[0].lock().await.iter().find_map(|p| match p {
                Packet::EnemySpawn(data)=>Some(data.object), _=>None,
            }) { break object; }
            tokio::task::yield_now().await;
        }
    }).await.expect("Spawned enemy must reach the peer");
    // First death, a repeated hit, then another party member taking damage.
    for (target_id, expected_hp) in [(1,0),(1,0),(2,79)] {
        let damage=DealDamagePacket {
            attack_id:data_structs::name_to_id("StrikeAdd"), inflicter:enemy,
            target:ObjectHeader { id:target_id,entity_type:ObjectType::Player,..Default::default() },
            ..Default::default()
        };
        tokio::time::timeout(Duration::from_secs(2),user::packet_handler(
            players[(target_id-1) as usize].lock().await,Packet::DealDamage(damage)))
            .await.expect("Lethal damage must not deadlock").unwrap();
        assert_eq!(players[(target_id-1) as usize].lock().await.get_stats().get_hp().0,expected_hp);
        assert_eq!(players[0].lock().await.get_stats().get_hp().0,0);
        for (index,packets) in received.iter().enumerate() {
            tokio::time::timeout(Duration::from_secs(2),async {
                loop {
                    if packets.lock().await.iter().any(|p| matches!(p,Packet::DamageReceive(_))) {break;}
                    tokio::task::yield_now().await;
                }
            }).await.expect("Both party members must receive damage notification");
            let packets=std::mem::take(&mut *packets.lock().await);
            let hits:Vec<_>=packets.iter().filter_map(|p| match p {Packet::DamageReceive(d)=>Some(d),_=>None}).collect();
            assert_eq!(hits.len(),1);
            assert_eq!(hits[0].receiver.id,(index+1) as u32);
            assert_eq!(hits[0].dmg_target.id,target_id);
            assert_eq!(hits[0].new_hp,expected_hp);
            assert!(!packets.iter().any(|p| matches!(p,Packet::EnemyKilled(_)|Packet::GainedEXP(_))));
        }
        assert_eq!(players[1].lock().await.get_stats().get_hp().0,if target_id==2 {79} else {100});
    }
}
