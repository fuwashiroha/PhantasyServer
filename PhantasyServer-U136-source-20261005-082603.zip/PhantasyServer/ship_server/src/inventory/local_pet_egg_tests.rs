//! Opaque transport tests use sentinels, not invented decoded pet statistics.
use super::*;
use pso2packetlib::protocol::items::{MoveStorageItemRequest,UUIDAmount};
fn egg(uuid:u64,subid:u16,variant:u8)->Item {
    Item {uuid,id:ItemId{item_type:12,id:1,subid,..Default::default()},data:ItemType::Unknown((0..40).map(|i|i^variant).collect::<Vec<u8>>().into())}
}
fn ids()->Vec<u16> {
    let f:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-pet-egg-instances.json")).unwrap();
    f["original_egg_rows"].as_array().unwrap().iter().map(|r|r["item_id"]["subid"].as_u64().unwrap() as u16).collect()
}
fn req(uuid:u64)->MoveStorageItemRequest {MoveStorageItemRequest{uuid,storage_id:0,amount:1,..Default::default()}}
fn transfer(inv:&mut Inventory,uuid:&mut u64,direction:usize,items:Vec<u64>)->Result<Packet,Error> {
    match direction {
        0=>inv.move_to_storage(MoveToStorageRequestPacket{uuids:items.into_iter().map(req).collect()},uuid),
        1=>inv.move_to_inventory(MoveToInventoryRequestPacket{uuids:items.into_iter().map(req).collect()},uuid),
        _=>inv.move_storages(MoveStoragesRequestPacket{old_id:0,new_id:14,items:items.into_iter().map(|uuid|UUIDAmount{uuid,amount:1,..Default::default()}).collect()},uuid),
    }
}
fn setup(direction:usize,subid:u16,variant:u8)->Inventory {
    let mut inv=Inventory::default();inv.character.storage_id=14;
    let existing=egg(10,subid,1);let moved=egg(20,subid,variant);
    match direction {0=>{inv.inventory.items=vec![moved];inv.storages.default.items=vec![existing];},
        1=>{inv.storages.default.items=vec![moved];inv.inventory.items=vec![existing];},
        _=>{inv.storages.default.items=vec![moved];inv.character.items=vec![existing];}}
    inv
}
fn destination(inv:&Inventory,direction:usize)->&[Item] {match direction {0=>&inv.storages.default.items,1=>&inv.inventory.items,_=>&inv.character.items}}
#[test]
fn local_pet_egg_all_original_identities_keep_distinct_instances_in_three_routes() {
    let ids=ids();assert_eq!(ids.len(),18);
    for subid in ids {for direction in 0..3 {for variant in [1,2] {
        let mut inv=setup(direction,subid,variant);let mut uuid=100;
        let result=transfer(&mut inv,&mut uuid,direction,vec![20]).unwrap();
        assert_eq!(destination(&inv,direction),&[egg(10,subid,1),egg(20,subid,variant)]);assert_eq!(uuid,100);
        match result {Packet::MoveToStorage(p)=>{assert_eq!(p.new_items[0].item,egg(20,subid,variant));assert!(p.updated.is_empty());},
            Packet::MoveToInventory(p)=>{assert_eq!(p.new_items[0].item,egg(20,subid,variant));assert_eq!(p.new_items[0].amount,1);assert_eq!(p.new_items[0].is_new,1);},
            Packet::MoveStorages(p)=>{assert_eq!(p.new_items[0].item,egg(20,subid,variant));assert!(p.updated_new.is_empty());},_=>panic!()}
    }}}
}
#[test]
fn local_pet_egg_full_destination_and_late_overflow_preserve_entire_batch() {
    for direction in 0..3 {for capacity in [1,2] {
        let mut inv=setup(direction,2,2);let mut uuid=100;
        let second=egg(21,2,3);
        match direction {0=>{inv.inventory.items.push(second);inv.storages.default.total_space=capacity;},
            1=>{inv.storages.default.items.push(second);inv.inventory.max_capacity=capacity;},
            _=>{inv.storages.default.items.push(second);inv.character.total_space=capacity;}}
        let before=format!("{inv:?}");
        assert!(matches!(transfer(&mut inv,&mut uuid,direction,vec![20,21]),Err(Error::InvalidInput("asset_destination_capacity"))));
        assert_eq!(format!("{inv:?}"),before);assert_eq!(uuid,100);
    }}
}
#[test]
fn local_pet_egg_malformed_payloads_fail_atomically_and_unmapped_ids_are_not_guessed() {
    for direction in 0..3 {for payload in [ItemType::Unknown(vec![7;39].into()),ItemType::Unknown(vec![7;41].into()),ItemType::NoItem] {
        let mut inv=setup(direction,2,1);let mut uuid=100;
        let source=if direction==0 {&mut inv.inventory.items}else{&mut inv.storages.default.items};source[0].data=payload;
        let before=format!("{inv:?}");assert!(matches!(transfer(&mut inv,&mut uuid,direction,vec![20]),Err(Error::InvalidInput("pet_egg_instance_payload"))));
        assert_eq!(format!("{inv:?}"),before);assert_eq!(uuid,100);
    }}
    for subid in [1,6,35,43,999] {assert!(!individual_item(&egg(20,subid,1)).unwrap());}
    let mut inv=setup(1,2,1);let mut uuid=100;let before=format!("{inv:?}");
    assert!(inv.move_to_inventory(MoveToInventoryRequestPacket{uuids:vec![MoveStorageItemRequest{uuid:20,storage_id:0,amount:2,..Default::default()}]},&mut uuid).is_err());
    assert_eq!(format!("{inv:?}"),before);assert_eq!(uuid,100);
}
