//! Capacity and carry limits through real atomic transfer operations.
use super::*;
use pso2packetlib::protocol::items::{ConsumableItem, MoveStorageItemRequest, UUIDAmount, WeaponItem};

fn stack(uuid:u64,id:u16,subid:u16,amount:u16)->Item {
    Item {uuid,id:ItemId {item_type:3,id,subid,..Default::default()},
        data:ItemType::Consumable(ConsumableItem {amount,..Default::default()}),..Default::default()}
}
fn storage(inv:&mut Inventory,id:u16)->&mut data_structs::inventory::StorageInventory {
    match id {0=>&mut inv.storages.default,1=>&mut inv.storages.premium,2=>&mut inv.storages.extend1,14=>&mut inv.character,_=>panic!()}
}
fn request(uuid:u64,id:u16,amount:u8)->MoveStorageItemRequest {
    MoveStorageItemRequest {uuid,storage_id:id,amount,..Default::default()}
}
fn state(inv:&Inventory,uuid:u64)->String {format!("{inv:?}; uuid={uuid}")}
fn quantity(item:&Item)->u16 {let ItemType::Consumable(c)=&item.data else {panic!()};c.amount}

#[test]
fn local_capacity_original_mate_identities_and_ten_limit_across_all_storages() {
    let evidence:serde_json::Value=serde_json::from_str(include_str!("../../testdata/classic-inventory-capacity.json")).unwrap();
    assert_eq!(evidence["original_consumable_rows"][1]["max_qty"],138,"packed Dimate byte must not become a carry allowance");
    for subid in 0..3 {
        assert_eq!(evidence["carry_limits"][subid as usize]["max_amount"],10);
        for source in [0,1,2,14] {
            let mut inv=Inventory::default();let mut uuid=100;
            inv.add_item(stack(10,1,subid,8));storage(&mut inv,source).items=vec![stack(20,1,subid,20)];
            inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,source,2)]},&mut uuid).unwrap();
            assert_eq!(quantity(&inv.get_inv_item(10).unwrap()),10);
            assert_eq!(quantity(&storage(&mut inv,source).items[0]),18);
            let before=state(&inv,uuid);
            assert!(matches!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,source,1)]},&mut uuid),Err(Error::InvalidInput("asset_carry_quantity"))));
            assert_eq!(state(&inv,uuid),before);
            // Bag carry cap does not limit how many can be returned to storage.
            inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![request(10,source,10)]},&mut uuid).unwrap();
            assert_eq!(quantity(&storage(&mut inv,source).items[0]),28);
        }
    }
    let mut inv=Inventory::default();let mut uuid=100;
    inv.add_item(stack(10,1,0,5));let mut duplicate=stack(11,1,0,5);duplicate.id.unk3=1;inv.add_item(duplicate);
    inv.storages.default.items=vec![stack(20,1,0,1)];let before=state(&inv,uuid);
    assert!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before,"duplicate/flagged stacks cannot bypass aggregate carry limit");
}

#[test]
fn local_capacity_bag_saved_slots_merge_when_full_and_equipment_is_individual() {
    for capacity in [1,50,150] {
        let mut inv=Inventory::default();let mut uuid=100;inv.inventory.max_capacity=capacity;
        for i in 0..capacity {inv.add_item(stack(1000+u64::from(i),0,i as u16,1));}
        inv.storages.default.items=vec![stack(20,0,500,5),stack(21,0,0,3)];let before=state(&inv,uuid);
        assert!(matches!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1)]},&mut uuid),Err(Error::InvalidInput("asset_destination_capacity"))));
        assert_eq!(state(&inv,uuid),before);
        inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(21,0,1)]},&mut uuid).unwrap();
        assert_eq!(quantity(&inv.get_inv_item(1000).unwrap()),2);assert_eq!(inv.inventory.items.len(),capacity as usize);
        // Overfull legacy bags may merge without gaining another slot.
        inv.inventory.max_capacity=0;
        inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(21,0,1)]},&mut uuid).unwrap();
        assert_eq!(quantity(&inv.get_inv_item(1000).unwrap()),3);
    }
    let mut inv=Inventory::default();inv.inventory.max_capacity=1;let mut uuid=100;
    let weapon=Item {uuid:10,id:ItemId {item_type:1,id:1,..Default::default()},data:ItemType::Weapon(WeaponItem::default()),..Default::default()};
    inv.add_item(weapon.clone());let mut other=weapon;other.uuid=20;inv.storages.default.items.push(other);
    let before=state(&inv,uuid);
    assert!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before);
    inv.inventory.max_capacity=2;
    inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1)]},&mut uuid).unwrap();
    assert_eq!(inv.inventory.items.len(),2);assert_eq!(uuid,100);
}

#[test]
fn local_capacity_all_storage_destinations_reject_new_slots_but_allow_merge() {
    for dst in [0,1,2,14] {
        for between in [false,true] {
            let mut inv=Inventory::default();let mut uuid=100;let src=if dst==0 {14} else {0};
            storage(&mut inv,dst).total_space=1;storage(&mut inv,dst).items=vec![stack(10,0,0,1)];
            let source=vec![stack(20,0,1,4),stack(21,0,0,4)];
            if between {storage(&mut inv,src).items=source;} else {inv.inventory.items=source;}
            let transfer=|inv:&mut Inventory,uuid:&mut u64,item_uuid| {
                if between {inv.move_storages(MoveStoragesRequestPacket {old_id:src,new_id:dst,items:vec![UUIDAmount {uuid:item_uuid,amount:1,..Default::default()}]},uuid)}
                else {inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![request(item_uuid,dst,1)]},uuid)}
            };
            let before=state(&inv,uuid);assert!(matches!(transfer(&mut inv,&mut uuid,20),Err(Error::InvalidInput("asset_destination_capacity"))));
            assert_eq!(state(&inv,uuid),before);
            transfer(&mut inv,&mut uuid,21).unwrap();
            assert_eq!(storage(&mut inv,dst).items.len(),1);assert_eq!(quantity(&storage(&mut inv,dst).items[0]),2);
            storage(&mut inv,dst).total_space=2;transfer(&mut inv,&mut uuid,20).unwrap();
            assert_eq!(storage(&mut inv,dst).items.len(),2);
        }
    }
}

#[test]
fn local_capacity_late_batch_failure_rolls_back_items_and_uuid_in_all_routes() {
    for direction in 0..3 {
        let mut inv=Inventory::default();let mut uuid=100;
        let source=vec![stack(20,0,1,4),stack(21,0,2,4)];
        match direction {
            0=>{inv.inventory.items=source;inv.storages.default.total_space=1;},
            1=>{inv.storages.default.items=source;inv.inventory.max_capacity=1;},
            _=>{inv.storages.default.items=source;inv.character.total_space=1;},
        }
        let before=state(&inv,uuid);
        let result=match direction {
            0=>inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![request(20,0,1),request(21,0,1)]},&mut uuid),
            1=>inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1),request(21,0,1)]},&mut uuid),
            _=>inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![UUIDAmount {uuid:20,amount:1,..Default::default()},UUIDAmount {uuid:21,amount:1,..Default::default()}]},&mut uuid),
        };
        assert!(matches!(result,Err(Error::InvalidInput("asset_destination_capacity"))));assert_eq!(state(&inv,uuid),before);
    }
    let mut inv=Inventory::default();let mut uuid=100;
    inv.add_item(stack(10,1,0,8));inv.storages.default.items=vec![stack(20,1,0,4)];let before=state(&inv,uuid);
    assert!(matches!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![request(20,0,1),request(20,0,2)]},&mut uuid),Err(Error::InvalidInput("asset_carry_quantity"))));
    assert_eq!(state(&inv,uuid),before);
}
