use super::*;
use pso2packetlib::protocol::items::{ConsumableItem,MoveStorageItemRequest,UUIDAmount};

#[test]
fn local_equip_inventory_missing_instance_keeps_occupied_and_dangling_slots() {
    let mut inv = Inventory::default();
    inv.add_item(Item {uuid: 10, ..Default::default()});
    inv.equip_item(10, 9).unwrap();
    for dangling in [false, true] {
        if dangling {inv.inventory.equiped.push((3, 999));}
        let before = rmp_serde::to_vec(&inv).unwrap();
        assert!(inv.equip_item(999, 9).is_err());
        assert_eq!(rmp_serde::to_vec(&inv).unwrap(), before);
    }
}

#[test]
fn local_equip_inventory_replace_repeat_and_unequip_preserve_other_slots() {
    let mut inv = Inventory::default();
    for uuid in [10, 20, 30] {inv.add_item(Item {uuid, ..Default::default()});}
    inv.equip_item(10, 9).unwrap(); inv.equip_item(30, 0).unwrap();
    inv.equip_item(20, 9).unwrap();
    assert_eq!(inv.inventory.equiped, vec![(0, 30), (9, 20)]);
    let before = rmp_serde::to_vec(&inv).unwrap();
    inv.equip_item(20, 9).unwrap();
    assert_eq!(rmp_serde::to_vec(&inv).unwrap(), before);
    inv.unequip_item(20).unwrap();
    assert_eq!(inv.inventory.equiped, vec![(0, 30)]);
    assert_eq!(inv.inventory.items.len(), 3);
}

fn stack(uuid:u64,subid:u16,amount:u16)->Item {
    Item {uuid,id:ItemId {item_type:3,subid,..Default::default()},
        data:ItemType::Consumable(ConsumableItem {amount,..Default::default()}),..Default::default()}
}
fn fixture()->Inventory {
    let mut inv=Inventory::default();
    inv.inventory.items=vec![stack(10,1,5),stack(11,2,7)];
    inv.storages.default.items=vec![stack(20,3,6),stack(21,4,8)];
    inv.character.storage_id=14;
    inv.loaded_items.push(ItemId {subid:55,..Default::default()});
    inv
}
fn state(inv:&Inventory,uuid:u64)->String {format!("{inv:?}; next UUID={uuid}")}
fn storage_request(uuid:u64,storage_id:u16,amount:u8)->MoveStorageItemRequest {
    MoveStorageItemRequest {uuid,storage_id,amount,..Default::default()}
}
fn amount(uuid:u64,n:u16)->UUIDAmount {UUIDAmount {uuid,amount:n,..Default::default()}}

#[test]
fn local_asset_late_to_storage_error_keeps_entire_batch_and_uuid() {
    let mut inv=fixture();let mut uuid=100;let before=state(&inv,uuid);
    assert!(inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(10,0,2),storage_request(999,0,1)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before,"late invalid item must not retain earlier movement or allocated UUID");
}
#[test]
fn local_asset_late_to_inventory_error_keeps_entire_batch_and_uuid() {
    let mut inv=fixture();let mut uuid=100;let before=state(&inv,uuid);
    assert!(inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(20,0,2),storage_request(999,0,1)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before,"late failure must restore account storage and player inventory together");
}
#[test]
fn local_asset_late_between_storage_error_keeps_entire_batch_and_uuid() {
    let mut inv=fixture();let mut uuid=100;let before=state(&inv,uuid);
    assert!(inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![amount(20,2),amount(999,1)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before,"late failure must preserve shared/character storage and UUID");
}
#[test]
fn local_asset_late_discard_inventory_error_keeps_entire_batch() {
    let mut inv=fixture();let before=state(&inv,100);
    assert!(inv.discard_inventory(DiscardItemRequestPacket {items:vec![amount(10,2),amount(999,1)]}).is_err());
    assert_eq!(state(&inv,100),before,"late invalid discard must not consume earlier items");
}
#[test]
fn local_asset_late_discard_storage_error_keeps_entire_batch() {
    let mut inv=fixture();let before=state(&inv,100);
    assert!(inv.discard_storage(DiscardStorageItemRequestPacket {items:vec![storage_request(20,0,2),storage_request(999,0,1)]}).is_err());
    assert_eq!(state(&inv,100),before,"late invalid storage discard must not consume earlier items");
}


#[test]
fn local_asset_invalid_destination_does_not_remove_source_or_allocate_uuid() {
    let mut inv=fixture();let mut uuid=100;let before=state(&inv,uuid);
    assert!(inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:99,items:vec![amount(20,2)]},&mut uuid).is_err());
    assert_eq!(state(&inv,uuid),before);
}

#[test]
fn local_asset_uuid_exhaustion_is_atomic_in_all_three_transfer_routes() {
    for direction in 0..3 {
        let mut inv=fixture();let mut uuid=u64::MAX;let before=state(&inv,uuid);
        let result=match direction {
            0=>inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(10,0,2)]},&mut uuid),
            1=>inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(20,0,2)]},&mut uuid),
            _=>inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![amount(20,2)]},&mut uuid),
        };
        assert!(matches!(result,Err(Error::InvalidInput("asset_uuid_exhausted"))));
        assert_eq!(state(&inv,uuid),before);
    }
}

#[test]
fn local_asset_unrepresentable_stack_sum_does_not_wrap_or_remove_source() {
    // Deliberately malformed max-u16 stacks test representation safety only;
    // real per-item stack limits and overflow splitting have separate gates.
    for direction in 0..3 {
        let mut inv=fixture();let mut uuid=100;
        match direction {
            0=>inv.storages.default.items.push(stack(30,1,u16::MAX)),
            1=>inv.inventory.items.push(stack(30,3,u16::MAX)),
            _=>inv.character.items.push(stack(30,3,u16::MAX)),
        }
        let before=state(&inv,uuid);
        let result=match direction {
            0=>inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(10,0,2)]},&mut uuid),
            1=>inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(20,0,2)]},&mut uuid),
            _=>inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![amount(20,2)]},&mut uuid),
        };
        assert!(matches!(result,Err(Error::InvalidInput("asset_stack_amount_overflow"))));
        assert_eq!(state(&inv,uuid),before);
    }
}

#[test]
fn local_asset_unrepresentable_meseta_sum_preserves_both_balances() {
    for direction in [MesetaDirection::ToStorage,MesetaDirection::ToInventory] {
        let mut inv=fixture();
        match direction {
            MesetaDirection::ToStorage=>{inv.inventory.meseta=1;inv.storages.storage_meseta=u64::MAX;},
            MesetaDirection::ToInventory=>{inv.inventory.meseta=u64::MAX;inv.storages.storage_meseta=1;},
        }
        let before=state(&inv,100);
        assert!(matches!(inv.move_meseta(MoveMesetaPacket {meseta:1,direction}),Err(Error::InvalidInput("asset_meseta_overflow"))));
        assert_eq!(state(&inv,100),before);
    }
}

#[test]
fn local_asset_transfer_roundtrip_packets_match_independent_amounts_and_ids() {
    let mut inv=fixture();let mut uuid=100;let cache=inv.loaded_items.clone();
    let Packet::MoveToStorage(out)=inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(10,0,2)]},&mut uuid).unwrap() else {panic!()};
    assert_eq!(uuid,101);assert_eq!(out.updated_inventory.len(),1);assert_eq!(out.new_items.len(),1);
    assert_eq!((out.updated_inventory[0].uuid,out.updated_inventory[0].new_amount,out.updated_inventory[0].moved),(10,3,2));
    assert_eq!(out.new_items[0].item,stack(101,1,2));assert_eq!(out.new_items[0].storage_id,0);
    assert_eq!(inv.get_inv_item(10).unwrap(),stack(10,1,3));
    let Packet::MoveToInventory(back)=inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(101,0,2)]},&mut uuid).unwrap() else {panic!()};
    assert_eq!(uuid,101);assert_eq!(inv.get_inv_item(10).unwrap(),stack(10,1,5));
    assert!(!inv.storages.default.items.iter().any(|i|i.uuid==101));
    assert_eq!((back.updated[0].uuid,back.updated[0].new_amount,back.updated[0].moved),(101,0,2));
    assert_eq!(back.new_items[0].item,stack(10,1,5));assert_eq!(back.new_items[0].is_new,0);
    assert_eq!(inv.loaded_items,cache);
}

#[test]
fn local_asset_successful_batch_commits_account_and_character_storage_together() {
    let mut inv=fixture();let mut uuid=100;
    let Packet::MoveToStorage(out)=inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(10,0,2),storage_request(11,14,3)]},&mut uuid).unwrap() else {panic!()};
    assert_eq!(uuid,102);assert_eq!(out.new_items.len(),2);
    assert_eq!(inv.get_inv_item(10).unwrap(),stack(10,1,3));assert_eq!(inv.get_inv_item(11).unwrap(),stack(11,2,4));
    assert_eq!(inv.storages.default.items.last().unwrap(),&stack(101,1,2));
    assert_eq!(inv.character.items,&[stack(102,2,3)]);
}

#[test]
fn local_asset_successful_discards_apply_exact_requested_amounts() {
    let mut inv=fixture();
    let Packet::UpdateInventory(out)=inv.discard_inventory(DiscardItemRequestPacket {items:vec![amount(10,2),amount(11,7)]}).unwrap() else {panic!()};
    assert_eq!(out.updated.len(),2);assert_eq!(inv.inventory.items,&[stack(10,1,3)]);
    let Packet::UpdateStorage(out)=inv.discard_storage(DiscardStorageItemRequestPacket {items:vec![storage_request(20,0,2),storage_request(21,0,8)]}).unwrap() else {panic!()};
    assert_eq!(out.updated.len(),2);assert_eq!(inv.storages.default.items,&[stack(20,3,4)]);
}

#[test]
fn local_asset_meseta_roundtrip_keeps_total_and_reports_new_balances() {
    let mut inv=fixture();inv.inventory.meseta=100;inv.storages.storage_meseta=200;
    let packets=inv.move_meseta(MoveMesetaPacket {meseta:40,direction:MesetaDirection::ToStorage}).unwrap();
    assert_eq!((inv.inventory.meseta,inv.storages.storage_meseta),(60,240));
    assert!(matches!(&packets[0],Packet::InventoryMeseta(p) if p.meseta==60));
    assert!(matches!(&packets[1],Packet::StorageMeseta(p) if p.meseta==240));
    inv.move_meseta(MoveMesetaPacket {meseta:40,direction:MesetaDirection::ToInventory}).unwrap();
    assert_eq!((inv.inventory.meseta,inv.storages.storage_meseta),(100,200));
}

#[test]
fn local_asset_empty_batches_preserve_state_and_existing_response_contract() {
    let mut inv=fixture();let mut uuid=100;let before=state(&inv,uuid);
    inv.move_to_storage(MoveToStorageRequestPacket::default(),&mut uuid).unwrap();
    inv.move_to_inventory(MoveToInventoryRequestPacket::default(),&mut uuid).unwrap();
    inv.move_storages(MoveStoragesRequestPacket::default(),&mut uuid).unwrap();
    inv.discard_inventory(DiscardItemRequestPacket::default()).unwrap();
    inv.discard_storage(DiscardStorageItemRequestPacket::default()).unwrap();
    assert_eq!(state(&inv,uuid),before);
}


// U028 synthetic instance sentinels. Values exercise payload preservation;
// they are not claimed to be original game item parameters or flag meanings.
fn equipment_instance(kind:u16,uuid:u64,variant:u8)->Item {
    use pso2packetlib::protocol::items::{WeaponItem,UnitItem,ClothingItem,CamoItem};
    let data=match kind {
        1=>ItemType::Weapon(WeaponItem {element:variant,grind:variant,affixes:[variant as u16;8],unk7:17+variant as u32,..Default::default()}),
        2=>{let mut data=ClothingItem::default();data.color.hue=100*variant as u16;data.unk1=17+variant as u16;ItemType::Clothing(data)},
        5=>ItemType::Unit(UnitItem {enh_level:variant,affixes:[variant as u16;8],unk5:17+variant as u16,..Default::default()}),
        10=>ItemType::Camo(CamoItem {unk1:variant,unk4:17+variant,..Default::default()}),
        _=>panic!("unsupported fixture kind"),
    };
    Item {uuid,id:ItemId {item_type:kind,subid:1,..Default::default()},data,..Default::default()}
}

fn equipment_transfer_case(kind:u16,direction:u8) {
    // Equal payload must also remain distinct: matching data is not identity.
    for variant in [1,2] {
        let existing=equipment_instance(kind,10,1);
        let moved=equipment_instance(kind,20,variant);
        let mut inv=Inventory::default();inv.character.storage_id=14;
        match direction {
            0=>{inv.inventory.items=vec![moved.clone()];inv.storages.default.items=vec![existing.clone()];},
            1=>{inv.storages.default.items=vec![moved.clone()];inv.inventory.items=vec![existing.clone()];},
            _=>{inv.storages.default.items=vec![moved.clone()];inv.character.items=vec![existing.clone()];},
        }
        let mut uuid=100;
        let reply=match direction {
            0=>inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(20,0,1)]},&mut uuid),
            1=>inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(20,0,1)]},&mut uuid),
            _=>inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![amount(20,1)]},&mut uuid),
        }.expect("distinct same-model equipment must transfer without merging");
        assert_eq!(uuid,100,"whole instance movement must not allocate an ID");
        let (src,dst)=match direction {
            0=>(&inv.inventory.items,&inv.storages.default.items),
            1=>(&inv.storages.default.items,&inv.inventory.items),
            _=>(&inv.storages.default.items,&inv.character.items),
        };
        assert!(src.is_empty());assert_eq!(dst,&vec![existing.clone(),moved.clone()]);
        match reply {
            Packet::MoveToStorage(p)=>{
                assert!(p.updated.is_empty());assert_eq!(p.new_items.len(),1);
                assert_eq!(p.new_items[0].item,moved);assert_eq!(p.new_items[0].storage_id,0);
                assert_eq!(p.updated_inventory.len(),1);
                assert_eq!((p.updated_inventory[0].uuid,p.updated_inventory[0].new_amount,p.updated_inventory[0].moved),(20,0,1));
            },
            Packet::MoveToInventory(p)=>{
                assert_eq!(p.new_items.len(),1);assert_eq!(p.new_items[0].item,moved);
                assert_eq!((p.new_items[0].amount,p.new_items[0].is_new),(1,1));
                assert_eq!(p.updated.len(),1);
                assert_eq!((p.updated[0].uuid,p.updated[0].new_amount,p.updated[0].moved,p.updated[0].storage_id),(20,0,1,0));
            },
            Packet::MoveStorages(p)=>{
                assert!(p.updated_new.is_empty());assert_eq!(p.new_items.len(),1);
                assert_eq!(p.new_items[0].item,moved);assert_eq!(p.new_items[0].storage_id,14);
                assert_eq!(p.updated_old.len(),1);
                assert_eq!((p.updated_old[0].uuid,p.updated_old[0].new_amount,p.updated_old[0].moved,p.updated_old[0].storage_id),(20,0,1,0));
            },
            other=>panic!("unexpected transfer reply {other:?}"),
        }
    }
}
macro_rules! equipment_transfer_test {
    ($name:ident,$kind:expr,$direction:expr)=>{#[test] fn $name(){equipment_transfer_case($kind,$direction);}};
}
equipment_transfer_test!(local_equipment_weapon_to_storage,1,0);
equipment_transfer_test!(local_equipment_weapon_to_inventory,1,1);
equipment_transfer_test!(local_equipment_weapon_between_storage,1,2);
equipment_transfer_test!(local_equipment_clothing_to_storage,2,0);
equipment_transfer_test!(local_equipment_clothing_to_inventory,2,1);
equipment_transfer_test!(local_equipment_clothing_between_storage,2,2);
equipment_transfer_test!(local_equipment_unit_to_storage,5,0);
equipment_transfer_test!(local_equipment_unit_to_inventory,5,1);
equipment_transfer_test!(local_equipment_unit_between_storage,5,2);
equipment_transfer_test!(local_equipment_camo_to_storage,10,0);
equipment_transfer_test!(local_equipment_camo_to_inventory,10,1);
equipment_transfer_test!(local_equipment_camo_between_storage,10,2);


#[test]
fn local_equipment_late_failure_keeps_both_instances_in_all_routes() {
    for kind in [1,2,5,10] {
        for direction in 0..3 {
            let mut inv=Inventory::default();inv.character.storage_id=14;
            let existing=equipment_instance(kind,10,1);let moved=equipment_instance(kind,20,2);
            match direction {
                0=>{inv.inventory.items=vec![moved];inv.storages.default.items=vec![existing];},
                1=>{inv.storages.default.items=vec![moved];inv.inventory.items=vec![existing];},
                _=>{inv.storages.default.items=vec![moved];inv.character.items=vec![existing];},
            }
            let mut uuid=100;let before=state(&inv,uuid);
            let result=match direction {
                0=>inv.move_to_storage(MoveToStorageRequestPacket {uuids:vec![storage_request(20,0,1),storage_request(999,0,1)]},&mut uuid),
                1=>inv.move_to_inventory(MoveToInventoryRequestPacket {uuids:vec![storage_request(20,0,1),storage_request(999,0,1)]},&mut uuid),
                _=>inv.move_storages(MoveStoragesRequestPacket {old_id:0,new_id:14,items:vec![amount(20,1),amount(999,1)]},&mut uuid),
            };
            assert!(result.is_err());assert_eq!(state(&inv,uuid),before);
        }
    }
}
