//! Player damage bonuses. Native tree/effect IDs and swiki tables are pinned
//! in classic-et-damage-skills.json. Pet and conditional bonuses are separate.
use crate::{Error, native_class_tree::ClassTree, sql::CharData};
use data_structs::stats::AttackType;
use pso2packetlib::protocol::models::character::Class;
use std::{collections::HashSet,sync::OnceLock};

pub(crate) fn new_doublesaber_attacks() -> &'static HashSet<u32> {
    #[derive(serde::Deserialize)]
    struct Attack {id:u32,added:bool}
    #[derive(serde::Deserialize)]
    struct Catalogue {attacks:Vec<Attack>}
    static IDS:OnceLock<HashSet<u32>>=OnceLock::new();
    IDS.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-et-doublesaber-attacks.json"))
        .expect("pinned Et doublesaber descriptors").attacks.into_iter().filter(|a|a.added).map(|a|a.id).collect())
}

#[derive(Debug, Clone, Default)]
pub(crate) struct EtoileCombat {
    tree: Option<ClassTree>,
    main: bool,
    weapon: Option<u16>,
}

impl EtoileCombat {
    pub(crate) fn validate_attack(&self,id:u32)->Result<(),Error> {
        // This establishes class/equipment scope only. Native action activation,
        // gear consumption and successful-guard authority remain separate work.
        if new_doublesaber_attacks().contains(&id) && (!self.main || self.weapon!=Some(5) || self.tree.is_none()) {
            return Err(Error::InvalidInput("etoile_attack_class_or_weapon"));
        }
        Ok(())
    }
    pub(crate) fn build(c: &CharData, weapon: Option<u16>) -> Result<Self, Error> {
        let classes = &c.character.classes;
        let main = classes.main_class == Class::Etole;
        if !main && classes.sub_class != Class::Etole { return Ok(Self::default()); }
        // Use Et's own earned level/SP, not the capped subclass stat level.
        let info = &classes.etole_info;
        let tree = c.native_class_trees.get(&13).cloned().unwrap_or_default()
            .at_level(13, info.level1)?;
        tree.validate(13, info.level1, info.level2)?;
        Ok(Self { tree: Some(tree), main, weapon })
    }

    pub(crate) fn multiplier(&self, attribute: AttackType) -> f32 {
        let Some(tree) = &self.tree else { return 1.0; };
        let rank = tree.rank("MasterAllAttackBonus") as usize;
        let mut power = match attribute {
            AttackType::Mel => [1.0,1.17,1.19,1.21,1.23,1.25,1.27,1.29,1.31,1.33,1.35][rank],
            AttackType::Rng => [1.0,1.12,1.14,1.16,1.18,1.20,1.22,1.24,1.26,1.28,1.30][rank],
            AttackType::Tec => [1.0,1.27,1.29,1.31,1.33,1.35,1.37,1.39,1.41,1.43,1.45][rank],
        };
        power *= [1.0,1.01,1.02,1.03,1.04,1.05][tree.rank("MasterHighLevelBonus") as usize];
        // Original item categories: double saber 5, wand 13, dual blades 17.
        if self.main && matches!(self.weapon, Some(5 | 13 | 17)) {
            let bonus = [1.0,1.10,1.15,1.20,1.25,1.30,1.35,1.40,1.45,1.50,1.55];
            power *= bonus[tree.rank("MasterWeaponBonus1") as usize]
                * bonus[tree.rank("MasterWeaponBonus2") as usize];
        }
        power
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_et_damage_every_rank_matches_saved_swiki_tables() {
        let f: serde_json::Value = serde_json::from_str(include_str!("../testdata/classic-et-damage-skills.json")).unwrap();
        for (skill, heading, label, attribute) in [
            ("MasterWeaponBonus1", "Etウェポンボーナス1", "威力", AttackType::Mel),
            ("MasterWeaponBonus2", "Etウェポンボーナス1", "威力", AttackType::Mel),
            ("MasterHighLevelBonus", "ハイレベルボーナスEt", "威力", AttackType::Mel),
            ("MasterAllAttackBonus", "オールアタックボーナスEt", "打撃威力", AttackType::Mel),
            ("MasterAllAttackBonus", "オールアタックボーナスEt", "射撃威力", AttackType::Rng),
            ("MasterAllAttackBonus", "オールアタックボーナスEt", "法撃威力", AttackType::Tec),
        ] {
            let section = f["sections"].as_array().unwrap().iter().find(|s| s["title"].as_str().unwrap().starts_with(heading)).unwrap();
            let row = section["tables"].as_array().unwrap().iter().flat_map(|t| t.as_array().unwrap()).find(|r| r.as_array().unwrap().iter().any(|v|v==label)).unwrap().as_array().unwrap();
            let values: Vec<_> = row.iter().filter_map(|c|c.as_str().unwrap().strip_suffix('%')).collect();
            assert_eq!(values.len(), if skill=="MasterHighLevelBonus" {5} else {10});
            for (i, value) in values.iter().enumerate() {
                // Isolated arithmetic test; production construction validates the entire tree.
                let mut tree = ClassTree::default(); tree.ranks.insert(skill.into(),i as u8+1);
                let combat = EtoileCombat {tree:Some(tree),main:true,weapon:Some(17)};
                assert!((combat.multiplier(attribute.clone())-value.parse::<f32>().unwrap()/100.0).abs()<1e-6);
            }
        }
    }
}
