//! Classic 6.1253.3 native tree contract, derived in U092 from private client code.
//! 04/28: mode, (count+0xA8)^0x49E3, 204-byte entries. See U092 evidence.
//! Native learning is separate from unimplemented Hero combat effects.
use crate::{Error,hero_skills::HeroSkills};
use pso2packetlib::protocol::{Packet,PacketHeader,Flags,ObjectHeader,HelperReadWrite,PacketType,objects::Unk042CPacket};
use std::{collections::BTreeMap,sync::OnceLock};

pub(crate) const HERO_SLOT:u8=11;
#[derive(serde::Deserialize)]
pub(crate) struct Node {
    pub name:String,pub x:u8,pub y:u8,pub max_rank:u8,pub cost:u8,pub initial:bool,
    pub minimum_level:u16,pub parent:Option<String>,pub parent_rank:u8,
    pub rank_byte:usize,pub rank_shift:u8,
}
#[derive(serde::Deserialize)]
struct Catalogue {nodes:Vec<Node>}
pub(crate) fn nodes()-> &'static [Node] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-hero-native-tree.json")).expect("pinned Hero SKT catalogue")).nodes
}
#[derive(Debug,Clone,Default,PartialEq,serde::Serialize,serde::Deserialize)]
#[serde(default)]
pub(crate) struct HeroTree {pub name:String,pub ranks:BTreeMap<String,u8>}
impl HeroTree {
    pub(crate) fn at_level(&self,level:u16)->Self {
        let mut tree=self.clone();
        if tree.name.is_empty(){tree.name="Hero 1".into();}
        // Only raw rank-0 nodes are initial skills. Zero SP does not mean automatic acquisition.
        for node in nodes() {
            if node.initial && level>=node.minimum_level && tree.parent_met(node) {
                tree.ranks.insert(node.name.clone(),1);
            }
        }
        tree
    }
    pub(crate) fn rank(&self,name:&str)->u8 {self.ranks.get(name).copied().unwrap_or(0)}
    fn parent_met(&self,node:&Node)->bool {node.parent.as_ref().is_none_or(|name|self.rank(name)>=node.parent_rank)}
    pub(crate) fn spent(&self)->u16 {nodes().iter().map(|n|u16::from(self.rank(&n.name))*u16::from(n.cost)).sum()}
    pub(crate) fn validate(&self,level:u16,total_sp:u16)->Result<(),Error> {
        for (name,rank) in &self.ranks {
            let node=nodes().iter().find(|n|&n.name==name).ok_or(Error::InvalidInput("native_hero_unknown_node"))?;
            if *rank>node.max_rank || (*rank>0 && (level<node.minimum_level || !self.parent_met(node))) {
                return Err(Error::InvalidInput("native_hero_rank_gate"));
            }
        }
        if self.spent()>total_sp || self.spent()>i16::MAX as u16 {return Err(Error::InvalidInput("native_hero_sp"));}
        Ok(())
    }
    pub(crate) fn learn(&self,x:u8,y:u8,amount:u8,level:u16,total_sp:u16)->Result<Self,Error> {
        let mut tree=self.at_level(level);tree.validate(level,total_sp)?;
        let node=nodes().iter().find(|n|n.x==x&&n.y==y).ok_or(Error::InvalidInput("native_hero_coordinate"))?;
        if node.initial || amount==0 {return Err(Error::InvalidInput("native_hero_not_allocatable"));}
        let next=tree.rank(&node.name).checked_add(amount).ok_or(Error::InvalidInput("native_hero_rank_overflow"))?;
        tree.ranks.insert(node.name.clone(),next);tree.validate(level,total_sp)?;
        Ok(tree.at_level(level))
    }
    pub(crate) fn effects(&self,level:u16)->Result<HeroSkills,Error> {
        let mut result=HeroSkills::default();
        for (node,key) in [("WpnmanWeaponBonus1","weapon1"),("WpnmanWeaponBonus2","weapon2"),
            ("WpnmanAttackBonus","normal"),("WpnmanHighLevelBonus","high"),("HFlushGuard","guard"),
            ("WpnmanHPUp1","hp"),("WpnmanAtpAllUp1","attack"),("WpnmanDfpAllUp1","defense"),
            ("WpnmanCounter","counter"),("SwordShotCharge2","aura"),
            ("WeakAttackCritical","weak"),("WpnmanWill","will")] {
            result=result.with_test_rank(key,self.rank(node),level)?;
        }
        Ok(result)
    }
    pub(crate) fn entry(&self,level:u16)->[u8;204] {
        let tree=self.at_level(level);let mut data=[0u8;204];
        data[0]=HERO_SLOT;data[4]=11;data[5]=3; // class Hero, occupied + selected
        data[6..8].copy_from_slice(&tree.spent().to_le_bytes());
        for (i,value) in tree.name.encode_utf16().take(31).enumerate(){data[8+i*2..10+i*2].copy_from_slice(&value.to_le_bytes());}
        for node in nodes(){data[4+node.rank_byte]|=(tree.rank(&node.name)&15)<<node.rank_shift;}
        data
    }
}
pub(crate) fn sheet(header:ObjectHeader,tree:&HeroTree,level:u16)->Packet {
    let mut body=Vec::new();
    header.write(&mut body,PacketType::Classic,0,0).expect("object header");
    header.write(&mut body,PacketType::Classic,0,0).expect("object header");
    body.extend_from_slice(&1u32.to_le_bytes()); // replace list, not append
    body.extend_from_slice(&((1u32+0xa8)^0x49e3).to_le_bytes());
    body.extend_from_slice(&tree.entry(level));
    Packet::Unknown((PacketHeader::new(4,0x28,Flags::OBJECT_RELATED|Flags::PACKED),body))
}
pub(crate) fn response(header:ObjectHeader,operation:u8,success:bool)->Packet {
    let mut detail=[0u8;16];detail[..4].copy_from_slice(&u32::from(operation).to_le_bytes());
    Packet::Unk042C(Unk042CPacket{unk1:header,unk2:header,unk3:0x27,unk4:u8::from(success),unk6:detail,..Default::default()})
}
#[derive(Debug)]
pub(crate) struct Request {pub operation:u8,pub slot:u8,pub x:u8,pub y:u8,pub amount:u8,pub name:String}
pub(crate) fn decode_request(body:&[u8],user:u32)->Result<Request,Error> {
    if body.len()!=68 || u32::from_le_bytes(body[12..16].try_into().unwrap())!=user {
        return Err(Error::InvalidInput("native_hero_request_envelope"));
    }
    let receiver=u32::from_le_bytes(body[..4].try_into().unwrap());
    if receiver!=0&&receiver!=user{return Err(Error::InvalidInput("native_hero_request_receiver"));}
    let words:Vec<u16>=body[36..68].chunks_exact(2).map(|b|u16::from_le_bytes([b[0],b[1]])).take_while(|&c|c!=0).collect();
    let name=String::from_utf16(&words).map_err(|_|Error::InvalidInput("native_hero_tree_name_encoding"))?;
    Ok(Request{operation:body[24],slot:body[25],x:body[26],y:body[27],amount:body[32],name})
}

#[cfg(test)]
mod tests {
    use super::*;
    use pso2packetlib::protocol::ProtocolRW;
    #[test]
    fn local_native_hero_sheet_matches_client_wire_offsets_and_rank_nibbles() {
        let tree=HeroTree::default().learn(0,0,5,85,85).unwrap().learn(0,3,2,85,85).unwrap();
        let bytes=sheet(ObjectHeader{id:1,..Default::default()},&tree,85).write(PacketType::Classic);
        assert_eq!(bytes.len(),244);assert_eq!(&bytes[4..8],&[4,0x28,0x44,0]);
        assert_eq!(u32::from_le_bytes(bytes[36..40].try_into().unwrap())^0x49e3,1+0xa8);
        let entry=&bytes[40..];assert_eq!(&entry[..8],&[11,0,0,0,11,3,7,0]);
        assert_eq!(entry[4+0x44],0x25); // original mapping A0=Boost, B0=Weapon1
        assert_eq!(Packet::read(&bytes,PacketType::Classic).unwrap().len(),1);
    }
    #[test]
    fn local_native_hero_prerequisites_levels_sp_and_bad_coordinates_are_atomic() {
        let tree=HeroTree::default();
        for (x,y,n,level,sp) in [(0,3,1,85,85),(0,0,11,85,85),(0,0,5,85,4),(2,1,1,79,85),(5,41,1,85,85),(0,0,0,85,85)] {
            assert!(tree.learn(x,y,n,level,sp).is_err());assert_eq!(tree,HeroTree::default());
        }
        let tree=tree.learn(0,0,5,85,85).unwrap().learn(0,3,5,85,85).unwrap();
        assert!(tree.learn(0,4,1,85,85).is_ok());
        assert_eq!(tree.at_level(85).rank("WpnmanRefresh"),0);
        let node=nodes().iter().find(|n|n.name=="WpnmanRefresh").unwrap();
        let learned=tree.learn(node.x,node.y,1,85,85).unwrap();
        assert_eq!(learned.rank("WpnmanRefresh"),1);assert_eq!(learned.spent(),tree.spent());
        assert_eq!(learned.at_level(85).rank("WpnmanRefresh"),1);
        assert_eq!(HeroTree::default().at_level(84).rank("WpnmanRefresh"),0);
    }
    #[test]
    fn local_native_hero_all_40_bindings_are_unique_and_auto_skills_cost_zero() {
        let mut bits=std::collections::BTreeSet::new();assert_eq!(nodes().len(),40);
        for n in nodes(){assert!(bits.insert((n.rank_byte,n.rank_shift)));assert!((68..200).contains(&n.rank_byte));}
        let tree=HeroTree::default().at_level(85);tree.validate(85,0).unwrap();assert_eq!(tree.spent(),0);
        assert_eq!(tree.rank("FirstBlood"),1);
    }
    #[test]
    fn local_native_hero_request_rejects_truncation_cross_account_and_invalid_utf16() {
        let mut b=vec![0;68];b[12..16].copy_from_slice(&1u32.to_le_bytes());
        assert!(decode_request(&b,1).is_ok());assert!(decode_request(&b,2).is_err());
        for len in [0,12,24,67]{assert!(decode_request(&b[..len],1).is_err());}
        b[36..38].copy_from_slice(&0xd800u16.to_le_bytes());assert!(decode_request(&b,1).is_err());
    }
}
