use super::*;
use data_structs::{SerDeFile, ServerData, quest::{QuestCompletionRule,QuestParticipantRule}};

pub(crate) const IDS:[u32;4]=[91001,91002,91003,91004];
pub(crate) fn add_fixture_actors(data:&mut MapData,zone_id:u32) {
    // Synthetic actors exercise all existing spawn families, not an original portal template.
    let mut a=ObjectData{zone_id,..Default::default()};a.data.object.id=IDS[0];a.data.name="fixture_object".to_string().into();data.objects.push(a);
    let mut a=EventData{zone_id,..Default::default()};a.data.object.id=IDS[1];data.events.push(a);
    let mut a=NPCData{zone_id,..Default::default()};a.data.object.id=IDS[2];a.data.name="fixture_npc".to_string().into();data.npcs.push(a);
    let mut a=TransporterData{zone_id,..Default::default()};a.data.object.id=IDS[3];data.transporters.push(a);
    let mut a=ObjectData{zone_id,..Default::default()};a.data.object.id=91005;data.objects.push(a);
}
pub(crate) fn fixture_spawn_id(packet:&Packet)->Option<u32> {
    let id=match packet {Packet::ObjectSpawn(a)=>a.object.id,Packet::EventSpawn(a)=>a.object.id,
        Packet::NPCSpawn(a)=>a.object.id,Packet::TransporterSpawn(a)=>a.object.id,_=>return None};
    (91001..=91005).contains(&id).then_some(id)
}
pub(crate) fn assert_spawns(packets:&[Packet],count:usize) {
    for id in IDS {assert_eq!(packets.iter().filter(|p|fixture_spawn_id(p)==Some(id)).count(),count,"actor {id}");}
    assert!(!packets.iter().any(|p|fixture_spawn_id(p)==Some(91005)));
    for p in packets {
        match fixture_spawn_id(p) {
            Some(91001)=>assert!(matches!(p,Packet::ObjectSpawn(_))),
            Some(91002)=>assert!(matches!(p,Packet::EventSpawn(_))),
            Some(91003)=>assert!(matches!(p,Packet::NPCSpawn(_))),
            Some(91004)=>assert!(matches!(p,Packet::TransporterSpawn(_))),_=>{}
        }
    }
}

#[test]
fn local_completion_actor_rejects_invalid_profiles_and_resets_new_instance() {
    let data=ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap();
    let mut data=data.quests.iter().find(|q|q.definition.name_id==200030).unwrap().map.clone();
    let zone_id=data.zones.iter().find(|z|z.name=="campship_down").unwrap().zone_id;
    add_fixture_actors(&mut data,zone_id);
    let rule=QuestCompletionRule{difficulty:0,zone_id,enemy_name:"SoldierAnt".into(),required_kills:1,
        participants:QuestParticipantRule::AnyObjectiveKillRecipient,activate_on_completion:IDS.to_vec(),
        result:Default::default(),evidence:"Synthetic actor validation fixture".into()};
    for case in ["missing","zero","duplicate_list","wrong_zone","active","duplicate_actor"] {
        let mut d=data.clone();let mut r=rule.clone();
        match case {
            "missing"=>r.activate_on_completion.push(99999),
            "zero"=>r.activate_on_completion.push(0),
            "duplicate_list"=>r.activate_on_completion.push(IDS[0]),
            "wrong_zone"=>d.objects.iter_mut().find(|a|a.data.object.id==IDS[0]).unwrap().zone_id=d.zones.iter().find(|z|z.name=="campship").unwrap().zone_id,
            "active"=>d.objects.iter_mut().find(|a|a.data.object.id==IDS[0]).unwrap().is_active=true,
            "duplicate_actor"=>{let mut a=EventData{zone_id,..Default::default()};a.data.object.id=IDS[0];d.events.push(a);},_=>unreachable!()
        }
        let mut m=Map::new_from_data(d,&AtomicU32::new(1)).unwrap();
        let before:Vec<_>=m.zones.iter().flat_map(|z|z.objects.activation_states()).collect();
        assert!(matches!(m.configure_completion(200030,0,&[r]),Err(Error::InvalidInput("quest_completion_actor"))),"{case}");
        assert!(m.completion.is_none());
        assert_eq!(m.zones.iter().flat_map(|z|z.objects.activation_states()).collect::<Vec<_>>(),before);
    }
    let mut m=Map::new_from_data(data.clone(),&AtomicU32::new(1)).unwrap();
    m.configure_completion(200030,0,&[rule]).unwrap();
    let o=&mut m.zones.iter_mut().find(|z|z.srv_zone_id==zone_id).unwrap().objects;
    assert_eq!(o.active_interaction_name(IDS[0]),None);assert_eq!(o.active_interaction_name(IDS[2]),None);
    assert_spawns(&o.activate_completion_actors(&IDS),1);
    assert!(o.activate_completion_actors(&IDS).is_empty());
    assert_eq!(o.active_interaction_name(IDS[0]),Some("fixture_object"));assert_eq!(o.active_interaction_name(IDS[2]),Some("fixture_npc"));
    let fresh=Map::new_from_data(data,&AtomicU32::new(1)).unwrap();
    assert!(fresh.zones.iter().flat_map(|z|z.objects.activation_states()).filter(|(id,_)|IDS.contains(id)).all(|(_,active)|!active));
}
