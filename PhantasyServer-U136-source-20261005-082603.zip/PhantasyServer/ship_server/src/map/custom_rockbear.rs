//! Authored, isolated training flow. No EXP, drops or persistent rewards.
use super::*;
use crate::damage_measurement::{Mode,End};
pub(crate) struct Session {
    rounds:u8,
    active:Option<(usize,u32)>,
    started:Instant,
    timed:bool,
    stationary:bool,
    retiring:Option<(usize,u32,Instant)>,
    results:Vec<String>,
}
impl Map {
    pub(crate) fn enable_custom_rockbear(&mut self) {
        self.custom_rockbear=Some(Session{rounds:0,active:None,started:Instant::now(),timed:true,stationary:false,retiring:None,results:vec![]});
    }
    pub(crate) async fn custom_message(&self,zone:usize,recipient:Option<u32>,message:&str) {
        let Some(z)=self.zones.get(zone) else{return;};
        let packet=Packet::SystemMessage(protocol::unk19::SystemMessagePacket {
            message:message.into(),msg_type:protocol::unk19::MessageType::SystemMessage,..Default::default()
        });
        exec_users(&z.players,|p,mut u|{if recipient.is_none_or(|id|id==p.player_id){let _=u.try_send_packet(&packet);}}).await;
    }
    pub(crate) async fn custom_command(&mut self,zone:usize,id:u32,action:&str,leader:bool)->Result<Option<u8>,Error> {
        if self.find_player(id)!=Some(zone) {return Err(Error::InvalidInput("custom_range_actor"));}
        if action=="help" || action.is_empty() {
            self.custom_message(zone,Some(id),crate::custom_rockbear::HELP).await;return Ok(None);
        }
        if self.custom_rockbear.is_none() {
            self.custom_message(zone,Some(id),"Use !rockbear enter in the lobby to accept the CUSTOM range.").await;return Ok(None);
        }
        if action=="status" {
            let state=self.custom_rockbear.as_ref().unwrap();
            let message=if state.results.is_empty(){"No finished rounds yet.".into()}else{state.results.join("\n")};
            self.custom_message(zone,Some(id),&message).await;return Ok(None);
        }
        if !leader {self.custom_message(zone,Some(id),"Only the party leader may start or stop a round.").await;return Ok(None);}
        if action=="stop" {self.custom_finish(None,true).await;return Ok(None);}
        if !matches!(action,"start"|"free"|"static"|"staticfree") {self.custom_message(zone,Some(id),crate::custom_rockbear::HELP).await;return Ok(None);}
        if self.zones[zone].data.name!="campship_down" {
            self.custom_message(zone,Some(id),"Enter the field through the campship exit first.").await;return Ok(None);
        }
        let state=self.custom_rockbear.as_ref().unwrap();
        if state.retiring.is_some() {self.custom_message(zone,Some(id),"Result review: wait for target removal before the next round.").await;return Ok(None);}
        if state.active.is_some() {self.custom_message(zone,Some(id),"A round is running. Use !rockbear stop before starting another.").await;return Ok(None);}
        if state.rounds>=5 {self.custom_message(zone,Some(id),"Five rounds complete. Abandon this quest and accept it again to reset.").await;return Ok(None);}
        let participants:Vec<_>=self.zones[zone].players.iter().filter(|p|p.user.upgrade().is_some()).map(|p|p.player_id).collect();
        if participants.is_empty() || participants.len()>4 {return Err(Error::InvalidInput("custom_range_party"));}
        let Some(player)=self.zones[zone].players.iter().find(|p|p.player_id==id).and_then(|p|p.user.upgrade()) else{return Err(Error::InvalidInput("custom_range_actor"));};
        let mut pos=player.lock().await.position;
        // Explicit authored position: 8m along local +Z from the caller.
        pos.pos_z=half::f16::from_f32(pos.pos_z.to_f32()+8.0);
        let enemy_id=self.max_id.checked_add(1).ok_or(Error::InvalidInput("custom_range_id"))?;
        let enemy=EnemyStats::custom_rockbear(pos);
        let packets=Zone::prepare_enemy_packets(enemy_id,&enemy);
        self.zones[zone].enemies.push((enemy_id,enemy));
        let timed=matches!(action,"start"|"static");
        let stationary=matches!(action,"static"|"staticfree");
        let mode=if timed {Mode::TwentySeconds}else{Mode::Free};
        if let Err(e)=self.start_damage_measurement(zone,enemy_id,&participants,mode,&[]) {self.zones[zone].enemies.pop();return Err(e);}
        self.max_id=enemy_id;
        let state=self.custom_rockbear.as_mut().unwrap();state.rounds+=1;state.active=Some((zone,enemy_id));state.started=Instant::now();state.timed=timed;state.stationary=stationary;
        let round=state.rounds;
        exec_users(&self.zones[zone].players,|_,mut u|{
            let _=u.try_send_packet(&packets.0);let mut action=packets.1.clone();
            if let Packet::EnemyAction(a)=&mut action {a.receiver=u.create_object_header();a.action_starter=a.receiver;}
            let _=u.try_send_packet(&action);
        }).await;
        self.custom_message(zone,None,&format!("[CUSTOM Rockbear] Round {round}/5 started: {}. Uniform regions x1.0; no rewards. Spawn test U089: BigBeastA / cleared model slot.",match (timed,stationary) {(true,false)=>"20 seconds",(false,false)=>"free mode",(true,true)=>"stationary 20 seconds (experimental)",(false,true)=>"stationary free mode (experimental)"})).await;
        Ok(Some(round))
    }
    pub(crate) async fn custom_finish(&mut self,token:Option<u8>,cancel:bool) {
        let Some(state)=self.custom_rockbear.as_ref() else{return;};
        let Some((zone,enemy))=state.active else{return;};
        if token.is_some_and(|t|t!=state.rounds){return;}
        let round=state.rounds;let elapsed=state.started.elapsed().as_secs_f64();let timed=state.timed;
        let Some(mut snapshot)=self.damage_measurement_snapshot() else{return;};
        if cancel {self.cancel_damage_measurement();snapshot=self.damage_measurement_snapshot().unwrap();}
        if snapshot.ended.is_none() {return;}
        let secs=if timed && snapshot.ended==Some(End::Elapsed){20.0}else{elapsed.max(0.001)};
        let mut lines=vec![format!("[CUSTOM Rockbear] Round {round}/5 {:?}; {secs:.3}s",snapshot.ended.unwrap())];
        let total:u64=snapshot.totals.iter().map(|r|r.displayed).sum();
        for r in snapshot.totals {
            lines.push(format!("Player {}: {} damage / {} hits / {:.1} DPS / HP loss {}{}",r.player,r.displayed,r.hits,r.displayed as f64/secs,r.hp_loss,if r.invalid{" [INVALID]"}else{""}));
        }
        lines.push(format!("Party total: {total}. No EXP/items/meseta."));
        if round==5 {lines.push("Five rounds complete. Abandon quest to return to lobby.".into());}
        let result=lines.join("\n");
        // Commit completion/despawn before sends; an old timer cannot end a new round.
        let killed=snapshot.ended==Some(End::TargetKilled);
        let state=self.custom_rockbear.as_mut().unwrap();state.active=None;state.results.push(result.clone());
        // The recording separates frozen ranking from target departure. Our
        // review interval is an authored 2s, not a claim about original timing.
        state.retiring=Some((zone,enemy,Instant::now()+std::time::Duration::from_secs(if killed {0}else{2})));
        if killed {self.custom_retire().await;}
        self.custom_message(zone,None,&result).await;
        log::info!("custom_rockbear_result {}",result.replace('\n'," | "));
    }
    async fn custom_retire(&mut self) {
        let Some((zone,enemy,_))=self.custom_rockbear.as_mut().and_then(|s|s.retiring.take()) else{return;};
        self.zones[zone].enemies.retain(|(id,_)|*id!=enemy);
        exec_users(&self.zones[zone].players,|_,mut u|{
            let p=Packet::DespawnObject(protocol::objects::DespawnObjectPacket {player:u.create_object_header(),item:ObjectHeader{id:enemy,entity_type:ObjectType::Object,..Default::default()}});
            let _=u.try_send_packet(&p);
        }).await;
    }
    pub(crate) async fn custom_tick(&mut self,token:u8)->bool {
        let Some(state)=self.custom_rockbear.as_ref() else{return false;};
        if state.rounds!=token {return false;}
        self.custom_finish(Some(token),false).await;
        let state=self.custom_rockbear.as_ref().unwrap();
        if state.retiring.is_some_and(|(_,_,at)|Instant::now()>=at) {self.custom_retire().await;}
        let state=self.custom_rockbear.as_ref().unwrap();state.active.is_some() || state.retiring.is_some()
    }
    pub(crate) fn custom_blocks_motion(&self,zone:usize,packet:&Packet)->bool {
        let Some(state)=self.custom_rockbear.as_ref() else{return false;};
        let Some((z,id))=state.active.or(state.retiring.map(|(z,id,_)|(z,id))) else{return false;};
        if z!=zone || !state.stationary {return false;}
        // Only known movement headers for this target; do not suppress players.
        // Suppression alone does not prove client-side AI/animation is frozen.
        crate::custom_rockbear::motion_targets(packet,id)
    }
    pub(crate) async fn custom_rockbear_damage(&mut self,zone:usize,dmg:&DealDamagePacket)->Result<bool,Error> {
        // This map has only authored targets. Enemy attacks, late hits and
        // packets for other regions cannot fall through into EXP/quest rewards.
        let Some((target_zone,target_id))=self.custom_rockbear.as_ref().and_then(|s|s.active) else{return Ok(true);};
        if zone!=target_zone || dmg.target.id!=target_id || dmg.target.entity_type!=ObjectType::Object || dmg.inflicter.entity_type!=ObjectType::Player {return Ok(true);}
        if self.damage_measurement_snapshot().is_some_and(|s|s.ended.is_some()) {self.custom_finish(None,false).await;return Ok(true);}
        let Some(player)=self.zones[zone].players.iter().find(|p|p.player_id==dmg.inflicter.id).and_then(|p|p.user.upgrade()) else{return Err(Error::InvalidInput("custom_range_attacker"));};
        // Late joiners must wait for the next round; never count unregistered participants.
        if !self.damage_measurement_snapshot().unwrap().totals.iter().any(|r|r.player==dmg.inflicter.id){return Ok(true);}
        let Some((idx,(_,enemy)))=self.zones[zone].enemies.iter().enumerate().find(|(_,e)|e.0==target_id) else{return Ok(true);};
        let prior=enemy.current_hp();let mut next=enemy.clone();
        let data=self.block_data.as_ref().ok_or(Error::InvalidInput("custom_range_data"))?.server_data.clone();
        let result=player.try_lock().ok_or(Error::CombatBusy)?.get_stats_mut().damage_enemy(&mut next,&data,dmg.clone())?;
        let (packet,killed)=match result {BattleResult::Damaged{dmg_packet}=>(dmg_packet,false),BattleResult::Killed{dmg_packet,..}=>(dmg_packet,true)};
        self.zones[zone].enemies[idx].1=next;
        self.measurement.as_mut().unwrap().committed(self.zones[zone].srv_zone_id,target_id,dmg.inflicter.id,dmg.attack_id,packet.dmg_amount,prior.saturating_sub(packet.new_hp),killed,Instant::now());
        exec_users(&self.zones[zone].players,|_,mut u|{let mut p=packet.clone();p.receiver=u.create_object_header();let _=u.try_send_packet(&Packet::DamageReceive(p));}).await;
        if killed {self.custom_finish(None,false).await;}
        Ok(true)
    }
}
