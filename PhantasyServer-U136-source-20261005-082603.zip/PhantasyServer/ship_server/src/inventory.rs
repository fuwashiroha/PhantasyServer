use crate::Error;
use data_structs::inventory::{AccountStorages, ItemParameters, StorageInventory};
use pso2packetlib::protocol::{
    ObjectHeader, Packet, ProtocolRW,
    items::{
        AddedItemPacket, DiscardItemRequestPacket, DiscardStorageItemRequestPacket, EquipedItem,
        InventoryMesetaPacket, Item, ItemId, ItemType, LoadEquipedPacket, LoadItemPacket,
        LoadPlayerInventoryPacket, LoadStoragesPacket, MesetaDirection, MoveMesetaPacket,
        MoveStoragesPacket, MoveStoragesRequestPacket, MoveToInventoryPacket,
        MoveToInventoryRequestPacket, MoveToStoragePacket, MoveToStorageRequestPacket, NamedId,
        NewInventoryItem, NewStorageItem, StorageMesetaPacket, UpdateInventoryPacket,
        UpdateStoragePacket,
    },
    login::Language,
};
use serde::{Deserialize, Serialize};

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Inventory {
    pub(crate) inventory: PlayerInventory,
    pub(crate) character: StorageInventory,
    #[serde(skip)]
    pub(crate) storages: AccountStorages,

    #[serde(skip)]
    loaded_items: Vec<ItemId>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct PlayerInventory {
    meseta: u64,
    max_capacity: u32,
    items: Vec<Item>,
    equiped: Vec<(u32, u64)>,
}

enum ChangeItemResult {
    Changed {
        uuid: u64,
        new_amount: u16,
        moved: u16,
        item: Item,
    },
    New {
        item: Item,
        amount: u16,
    },
    Removed {
        item: Item,
        amount: u16,
    },
}

impl Inventory {
    pub fn send(
        &mut self,
        player_id: u32,
        name: String,
        item_names: &ItemParameters,
        lang: Language,
    ) -> Vec<Packet> {
        let mut packets = vec![];

        // load inventory
        if let Some(x) = load_items_inner(
            &mut self.loaded_items,
            &self.inventory.items,
            item_names,
            lang,
        ) {
            packets.push(Packet::LoadItem(x));
        }
        packets.push(Packet::LoadPlayerInventory(LoadPlayerInventoryPacket {
            object: ObjectHeader {
                id: player_id,
                entity_type: pso2packetlib::protocol::ObjectType::Player,
                ..Default::default()
            },
            name,
            meseta: self.inventory.meseta,
            max_capacity: self.inventory.max_capacity,
            items: self.inventory.items.clone(),
        }));
        packets.push(self.send_equiped(player_id));

        // load storages
        //BUG: i think that this packet should be split if there are too many items
        let mut storage_items = vec![];
        let mut infos = vec![];
        // character storage
        if let Some(x) = load_items_inner(
            &mut self.loaded_items,
            &self.character.items,
            item_names,
            lang,
        ) {
            packets.push(Packet::LoadItem(x));
        }
        storage_items.extend_from_slice(&self.character.items);
        infos.push(self.character.generate_info());

        // default storage
        if let Some(x) = load_items_inner(
            &mut self.loaded_items,
            &self.storages.default.items,
            item_names,
            lang,
        ) {
            packets.push(Packet::LoadItem(x));
        }
        storage_items.extend_from_slice(&self.storages.default.items);
        infos.push(self.storages.default.generate_info());

        // premium storage
        if let Some(x) = load_items_inner(
            &mut self.loaded_items,
            &self.storages.premium.items,
            item_names,
            lang,
        ) {
            packets.push(Packet::LoadItem(x));
        }
        storage_items.extend_from_slice(&self.storages.premium.items);
        infos.push(self.storages.premium.generate_info());

        // extend1 storage
        if let Some(x) = load_items_inner(
            &mut self.loaded_items,
            &self.storages.extend1.items,
            item_names,
            lang,
        ) {
            packets.push(Packet::LoadItem(x));
        }
        storage_items.extend_from_slice(&self.storages.extend1.items);
        infos.push(self.storages.extend1.generate_info());

        packets.push(Packet::LoadStorages(LoadStoragesPacket {
            stored_meseta: self.storages.storage_meseta,
            unk1: infos,
            unk2: 2,
            items: storage_items,
        }));
        packets
    }
    pub fn send_equiped(&self, player_id: u32) -> Packet {
        let mut equiped_items = LoadEquipedPacket::default();
        for (pos, uuid) in &self.inventory.equiped {
            let Some(item) = self.inventory.items.iter().find(|x| x.uuid == *uuid) else {
                continue;
            };
            equiped_items.items.push(EquipedItem {
                item: item.clone(),
                // 0-back unit
                // 1-arm unit
                // 2-leg unit
                // 3-outfit
                // 9-weapon
                unk: *pos,
            });
        }
        equiped_items.player = ObjectHeader {
            id: player_id,
            entity_type: pso2packetlib::protocol::ObjectType::Player,
            ..Default::default()
        };
        Packet::LoadEquiped(equiped_items)
    }
    pub(crate) fn equipped_units(&self) -> Result<Vec<&Item>, Error> {
        let mut seen = std::collections::HashSet::new();
        let mut result = Vec::new();
        for (_, uuid) in &self.inventory.equiped {
            let item = self.inventory.items.iter().find(|i| i.uuid == *uuid)
                .ok_or(Error::InvalidInput("equipped_item_missing"))?;
            if matches!(item.data, ItemType::Unit(_)) {
                if !seen.insert(*uuid) { return Err(Error::InvalidInput("duplicate_equipped_unit")); }
                result.push(item);
            }
        }
        if result.len() > 3 { return Err(Error::InvalidInput("equipped_unit_count")); }
        Ok(result)
    }
    pub fn equip_item(&mut self, uuid: u64, pos: u32) -> Result<(), Error> {
        // Reject missing instances before touching the current slot, including
        // malformed saves whose equipped list refers to a missing item.
        self.inventory
            .items
            .iter()
            .find(|x| x.uuid == uuid)
            .ok_or(Error::InvalidInput("equip_item"))?;
        if self.inventory.equiped.iter().any(|&x| x.1 == uuid) {
            return Ok(());
        }
        if let Some((pos, _)) = self
            .inventory
            .equiped
            .iter()
            .enumerate()
            .find(|(_, (item_pos, _))| *item_pos == pos)
        {
            self.inventory.equiped.remove(pos);
        }
        self.inventory.equiped.push((pos, uuid));
        Ok(())
    }
    pub fn unequip_item(&mut self, uuid: u64) -> Result<(), Error> {
        if let Some((pos, _)) = self
            .inventory
            .equiped
            .iter()
            .enumerate()
            .find(|(_, x)| x.1 == uuid)
        {
            self.inventory.equiped.remove(pos);
        }
        Ok(())
    }
    pub(crate) fn clear_weapon_slot(&mut self) {
        // Slot 9 is the existing Classic weapon slot used by update_palette.
        self.inventory.equiped.retain(|(pos, _)| *pos != 9);
    }
    pub fn get_inv_item(&self, uuid: u64) -> Result<Item, Error> {
        self.inventory
            .items
            .iter()
            .find(|x| x.uuid == uuid)
            .ok_or(Error::InvalidInput("get_inv_item"))
            .cloned()
    }
    fn move_to_storage_inner(
        &mut self,
        packet: MoveToStorageRequestPacket,
        new_uuid: &mut u64,
    ) -> Result<Packet, Error> {
        let mut packet_out = MoveToStoragePacket::default();
        for info in packet.uuids {
            let storage = match info.storage_id {
                0 => &mut self.storages.default,
                1 => &mut self.storages.premium,
                2 => &mut self.storages.extend1,
                14 => &mut self.character,
                _ => return Err(Error::InvalidInput("move_to_storage")),
            };
            let result = decrease_item(&mut self.inventory.items, info.uuid, info.amount as u16)?;
            let (item, amount) = match result {
                ChangeItemResult::Changed {
                    uuid,
                    new_amount,
                    moved,
                    mut item,
                } => {
                    packet_out.updated_inventory.push(
                        pso2packetlib::protocol::items::UpdatedInventoryItem {
                            uuid,
                            new_amount,
                            moved,
                        },
                    );
                    *new_uuid = new_uuid.checked_add(1).ok_or(Error::InvalidInput("asset_uuid_exhausted"))?;
                    item.uuid = *new_uuid;
                    (item, moved)
                }
                ChangeItemResult::Removed { item, amount } => {
                    packet_out.updated_inventory.push(
                        pso2packetlib::protocol::items::UpdatedInventoryItem {
                            uuid: item.uuid,
                            new_amount: 0,
                            moved: amount,
                        },
                    );
                    (item, amount)
                }
                _ => unreachable!(),
            };
            check_item_capacity(&storage.items,&item,storage.total_space)?;
            match increase_item(&mut storage.items, item, amount)? {
                ChangeItemResult::Changed {
                    uuid, new_amount, ..
                } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedItem {
                            uuid,
                            new_amount: new_amount as u32,
                            storage_id: storage.storage_id as u32,
                        });
                }
                ChangeItemResult::New { item, .. } => {
                    packet_out.new_items.push(NewStorageItem {
                        item,
                        storage_id: storage.storage_id as u32,
                    });
                }
                _ => unreachable!(),
            }
        }
        Ok(Packet::MoveToStorage(packet_out))
    }
    fn move_to_inventory_inner(
        &mut self,
        packet: MoveToInventoryRequestPacket,
        new_uuid: &mut u64,
    ) -> Result<Packet, Error> {
        let mut packet_out = MoveToInventoryPacket::default();
        for info in packet.uuids {
            let storage = match info.storage_id {
                0 => &mut self.storages.default,
                1 => &mut self.storages.premium,
                2 => &mut self.storages.extend1,
                14 => &mut self.character,
                _ => return Err(Error::InvalidInput("move_to_inventory")),
            };
            let result = decrease_item(&mut storage.items, info.uuid, info.amount as u16)?;
            let (item, amount) = match result {
                ChangeItemResult::Changed {
                    uuid,
                    new_amount,
                    moved,
                    mut item,
                } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid,
                            new_amount,
                            storage_id: storage.storage_id as u32,
                            moved,
                        });
                    *new_uuid = new_uuid.checked_add(1).ok_or(Error::InvalidInput("asset_uuid_exhausted"))?;
                    item.uuid = *new_uuid;
                    (item, moved)
                }
                ChangeItemResult::Removed { item, amount } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid: item.uuid,
                            new_amount: 0,
                            storage_id: storage.storage_id as u32,
                            moved: amount,
                        });
                    (item, amount)
                }
                _ => unreachable!(),
            };
            check_item_capacity(&self.inventory.items,&item,self.inventory.max_capacity)?;
            check_mate_carry_limit(&self.inventory.items,&item,amount)?;
            match increase_item(&mut self.inventory.items, item, amount)? {
                ChangeItemResult::Changed {
                    new_amount, item, ..
                } => {
                    packet_out.new_items.push(NewInventoryItem {
                        item,
                        amount: new_amount,
                        is_new: 0,
                    });
                }
                ChangeItemResult::New { item, amount } => {
                    packet_out.new_items.push(NewInventoryItem {
                        item,
                        amount,
                        is_new: 1,
                    });
                }
                _ => unreachable!(),
            }
        }
        Ok(Packet::MoveToInventory(packet_out))
    }
    fn move_storages_inner(
        &mut self,
        packet: MoveStoragesRequestPacket,
        new_uuid: &mut u64,
    ) -> Result<Packet, Error> {
        let mut packet_out = MoveStoragesPacket::default();
        for info in packet.items {
            let storage_src = match packet.old_id {
                0 => &mut self.storages.default,
                1 => &mut self.storages.premium,
                2 => &mut self.storages.extend1,
                14 => &mut self.character,
                _ => return Err(Error::InvalidInput("move_storages")),
            };
            let result = decrease_item(&mut storage_src.items, info.uuid, info.amount)?;
            let (item, amount) = match result {
                ChangeItemResult::Changed {
                    uuid,
                    new_amount,
                    moved,
                    mut item,
                } => {
                    packet_out.updated_old.push(
                        pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid,
                            new_amount,
                            storage_id: storage_src.storage_id as u32,
                            moved,
                        },
                    );
                    *new_uuid = new_uuid.checked_add(1).ok_or(Error::InvalidInput("asset_uuid_exhausted"))?;
                    item.uuid = *new_uuid;
                    (item, moved)
                }
                ChangeItemResult::Removed { item, amount } => {
                    packet_out.updated_old.push(
                        pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid: item.uuid,
                            new_amount: 0,
                            storage_id: storage_src.storage_id as u32,
                            moved: amount,
                        },
                    );
                    (item, amount)
                }
                _ => unreachable!(),
            };
            let storage_dst = match packet.new_id {
                0 => &mut self.storages.default,
                1 => &mut self.storages.premium,
                2 => &mut self.storages.extend1,
                14 => &mut self.character,
                _ => return Err(Error::InvalidInput("move_storages")),
            };
            check_item_capacity(&storage_dst.items,&item,storage_dst.total_space)?;
            match increase_item(&mut storage_dst.items, item, amount)? {
                ChangeItemResult::Changed {
                    new_amount,
                    uuid,
                    moved,
                    ..
                } => {
                    packet_out.updated_new.push(
                        pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid,
                            new_amount,
                            moved,
                            storage_id: storage_dst.storage_id as u32,
                        },
                    );
                }
                ChangeItemResult::New { item, .. } => {
                    packet_out.new_items.push(NewStorageItem {
                        item,
                        storage_id: storage_dst.storage_id as u32,
                    });
                }
                _ => unreachable!(),
            }
        }
        Ok(Packet::MoveStorages(packet_out))
    }
    fn discard_inventory_inner(&mut self, packet: DiscardItemRequestPacket) -> Result<Packet, Error> {
        let mut packet_out = UpdateInventoryPacket {
            unk2: 1,
            ..Default::default()
        };
        for info in packet.items {
            match decrease_item(&mut self.inventory.items, info.uuid, info.amount)? {
                ChangeItemResult::Changed {
                    new_amount, moved, ..
                } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedInventoryItem {
                            uuid: info.uuid,
                            new_amount,
                            moved,
                        })
                }
                ChangeItemResult::Removed { amount, .. } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedInventoryItem {
                            uuid: info.uuid,
                            new_amount: 0,
                            moved: amount,
                        })
                }
                _ => unreachable!(),
            }
        }
        Ok(Packet::UpdateInventory(packet_out))
    }
    fn discard_storage_inner(
        &mut self,
        packet: DiscardStorageItemRequestPacket,
    ) -> Result<Packet, Error> {
        let mut packet_out = UpdateStoragePacket {
            unk2: 1,
            ..Default::default()
        };
        for info in packet.items {
            let storage = match info.storage_id {
                0 => &mut self.storages.default,
                1 => &mut self.storages.premium,
                2 => &mut self.storages.extend1,
                14 => &mut self.character,
                _ => return Err(Error::InvalidInput("discard_storage")),
            };
            match decrease_item(&mut storage.items, info.uuid, info.amount as u16)? {
                ChangeItemResult::Changed {
                    new_amount, moved, ..
                } => packet_out
                    .updated
                    .push(pso2packetlib::protocol::items::UpdatedStorageItem {
                        uuid: info.uuid,
                        new_amount,
                        moved,
                        storage_id: storage.storage_id as u32,
                    }),
                ChangeItemResult::Removed { amount, .. } => {
                    packet_out
                        .updated
                        .push(pso2packetlib::protocol::items::UpdatedStorageItem {
                            uuid: info.uuid,
                            new_amount: 0,
                            moved: amount,
                            storage_id: storage.storage_id as u32,
                        })
                }
                _ => unreachable!(),
            }
        }
        Ok(Packet::UpdateStorage(packet_out))
    }
    fn move_meseta_inner(&mut self, packet: MoveMesetaPacket) -> Result<Vec<Packet>, Error> {
        let mut packets = vec![];
        let (src, dest) = match packet.direction {
            MesetaDirection::ToStorage => (
                &mut self.inventory.meseta,
                &mut self.storages.storage_meseta,
            ),
            MesetaDirection::ToInventory => (
                &mut self.storages.storage_meseta,
                &mut self.inventory.meseta,
            ),
        };
        let to_move = u64::min(*src, packet.meseta);
        *dest = dest.checked_add(to_move).ok_or(Error::InvalidInput("asset_meseta_overflow"))?;
        *src -= to_move;
        packets.push(Packet::InventoryMeseta(InventoryMesetaPacket {
            meseta: self.inventory.meseta,
        }));
        packets.push(Packet::StorageMeseta(StorageMesetaPacket {
            meseta: self.storages.storage_meseta,
        }));
        Ok(packets)
    }
    pub fn add_item(&mut self, item: Item) -> Packet {
        let packet = Packet::AddedItem(AddedItemPacket {
            item: item.clone(),
            ..Default::default()
        });
        self.inventory.items.push(item);
        packet
    }
    pub fn add_default_item(&mut self, uuid: &mut u64, item_id: ItemId) -> Packet {
        let item = Item {
            uuid: *uuid,
            id: item_id,
            data: ItemType::default(),
        };
        *uuid += 1;

        // transform item data into known item data
        let packet = Packet::AddedItem(AddedItemPacket {
            item,
            ..Default::default()
        })
        .write(pso2packetlib::protocol::PacketType::NA);
        let packet = Packet::read(&packet, pso2packetlib::protocol::PacketType::NA)
            .expect("Reading from memory shouldn't fail")
            .pop()
            .expect("Should always contain an item");
        let Packet::AddedItem(added_item) = &packet else {
            unreachable!("Read and write impls should agree");
        };
        self.inventory.items.push(added_item.item.clone());

        packet
    }
}
fn load_items_inner(
    loaded: &mut Vec<ItemId>,
    items: &[Item],
    item_names: &ItemParameters,
    lang: Language,
) -> Option<LoadItemPacket> {
    let mut load_items = LoadItemPacket::default();
    for item in items {
        if !loaded.contains(&item.id) {
            loaded.push(item.id);
            match item_names.names.iter().find(|x| x.id == item.id) {
                Some(name) => load_items.items.push(NamedId {
                    name: match lang {
                        Language::English => name.en_name.clone(),
                        Language::Japanese => name.jp_name.clone(),
                    },
                    id: item.id,
                }),
                None => {
                    log::debug!("No item name for {:?}", item.id);
                    continue;
                }
            }
        }
    }
    if load_items.items.is_empty() {
        None
    } else {
        Some(load_items)
    }
}

fn decrease_item(items: &mut Vec<Item>, uuid: u64, amount: u16) -> Result<ChangeItemResult, Error> {
    let (pos, item) = items
        .iter_mut()
        .enumerate()
        .find(|(_, x)| x.uuid == uuid)
        .ok_or(Error::InvalidInput("decrease_item"))?;
    if let ItemType::Consumable(data) = &mut item.data {
        let taken = u16::min(amount, data.amount);
        let new_amount = data.amount.saturating_sub(taken);
        if new_amount == 0 {
            Ok(ChangeItemResult::Removed {
                item: items.swap_remove(pos),
                amount: taken,
            })
        } else {
            data.amount = new_amount;
            let mut data = data.clone();
            data.amount = taken;
            let item = Item {
                uuid: 0,
                id: item.id,
                data: ItemType::Consumable(data),
            };
            Ok(ChangeItemResult::Changed {
                uuid,
                new_amount,
                moved: taken,
                item,
            })
        }
    } else {
        if amount > 1 {
            return Err(Error::InvalidInput("decrease_item"));
        }
        Ok(ChangeItemResult::Removed {
            item: items.swap_remove(pos),
            amount: 1,
        })
    }
}

fn individual_item(item:&Item)->Result<bool,Error> {
    // Explicit original INCA pet-egg identities. No inference about neighboring
    // EXP/stat eggs or the incomplete appendix's missing species/rarities.
    if item.id.item_type==12 && item.id.id==1 && item.id.unk3==0
        && [2,3,4,5,12,13,14,15,22,23,24,25,63,64,65,70,71,72].contains(&item.id.subid) {
        // pso2packetlib preserves these native instances as opaque 0x28 bytes.
        // Keep every byte; this does not decode or invent pet growth fields.
        if !matches!(&item.data,ItemType::Unknown(bytes) if bytes.len()==0x28) {
            return Err(Error::InvalidInput("pet_egg_instance_payload"));
        }
        return Ok(true);
    }
    Ok(matches!(&item.data,ItemType::Weapon(_)|ItemType::Unit(_)|ItemType::Clothing(_)|ItemType::Camo(_)))
}

// Validate on the staged complete batch. A full destination can still merge a
// stack, while individual instances always need another slot.
fn check_item_capacity(items:&[Item],item:&Item,capacity:u32)->Result<(),Error> {
    let individual=individual_item(item)?;
    let new_slot=individual || !items.iter().any(|old|old.id==item.id);
    if new_slot && items.len() as u64>=u64::from(capacity) {return Err(Error::InvalidInput("asset_destination_capacity"));}
    Ok(())
}

fn check_mate_carry_limit(items:&[Item],item:&Item,amount:u16)->Result<(),Error> {
    // Original INCA identities; carry10 verified on swiki for each mate.
    // The raw Dimate max_qty byte is packed138, so do not generalize its bits
    // or apply a bag carry limit to a warehouse stack.
    if item.id.item_type!=3 || item.id.id!=1 || item.id.subid>2 {return Ok(());}
    if !matches!(&item.data,ItemType::Consumable(_)) {return Err(Error::InvalidInput("asset_carry_item_type"));}
    let mut total=u64::from(amount);
    for old in items.iter().filter(|old|old.id.item_type==3 && old.id.id==1 && old.id.subid==item.id.subid) {
        let ItemType::Consumable(data)=&old.data else{return Err(Error::InvalidInput("asset_carry_item_type"))};
        total+=u64::from(data.amount);
    }
    if total>10 {return Err(Error::InvalidInput("asset_carry_quantity"));}
    Ok(())
}

fn increase_item(
    items: &mut Vec<Item>,
    item: Item,
    amount: u16,
) -> Result<ChangeItemResult, Error> {
    // Equipment/pet eggs are individual instances even when catalogue ID and
    // payload match an existing item. Keep its UUID and complete payload.
    if individual_item(&item)? {
        items.push(item.clone());
        return Ok(ChangeItemResult::New { item, amount });
    }
    let inv_item = items.iter_mut().find(|x| x.id == item.id);
    match inv_item {
        Some(i_item) => {
            if let ItemType::Consumable(i_data) = &mut i_item.data {
                i_data.amount = i_data.amount.checked_add(amount).ok_or(Error::InvalidInput("asset_stack_amount_overflow"))?;
                Ok(ChangeItemResult::Changed {
                    uuid: i_item.uuid,
                    new_amount: i_data.amount,
                    moved: amount,
                    item: i_item.clone(),
                })
            } else {
                Err(Error::InvalidInput("increase_item"))
            }
        }
        None => {
            items.push(item.clone());
            Ok(ChangeItemResult::New { item, amount })
        }
    }
}

impl Default for PlayerInventory {
    fn default() -> Self {
        Self {
            meseta: 0,
            max_capacity: 50,
            items: vec![],
            equiped: vec![],
        }
    }
}

#[cfg(test)]
mod local_asset_tests;
#[cfg(test)]
mod local_capacity_tests;
#[cfg(test)]
mod local_pet_egg_tests;

impl Inventory {
    // Stage the complete batch, including UUID allocation. A later invalid row
    // must not leave earlier rows moved/discarded. This is in-memory atomicity;
    // handlers still require a separate durable-before-response barrier.
    fn atomic_asset_change<T>(&mut self, last_uuid: &mut u64,
        change: impl FnOnce(&mut Self, &mut u64) -> Result<T, Error>) -> Result<T, Error> {
        let mut candidate = self.clone();
        let mut candidate_uuid = *last_uuid;
        let response = change(&mut candidate, &mut candidate_uuid)?;
        *self = candidate;
        *last_uuid = candidate_uuid;
        Ok(response)
    }
    pub fn move_to_storage(&mut self, packet: MoveToStorageRequestPacket, last_uuid: &mut u64) -> Result<Packet, Error> {
        self.atomic_asset_change(last_uuid, |candidate, uuid| candidate.move_to_storage_inner(packet, uuid))
    }
    pub fn move_to_inventory(&mut self, packet: MoveToInventoryRequestPacket, last_uuid: &mut u64) -> Result<Packet, Error> {
        self.atomic_asset_change(last_uuid, |candidate, uuid| candidate.move_to_inventory_inner(packet, uuid))
    }
    pub fn move_storages(&mut self, packet: MoveStoragesRequestPacket, last_uuid: &mut u64) -> Result<Packet, Error> {
        self.atomic_asset_change(last_uuid, |candidate, uuid| candidate.move_storages_inner(packet, uuid))
    }
    pub fn discard_inventory(&mut self, packet: DiscardItemRequestPacket) -> Result<Packet, Error> {
        self.atomic_asset_change(&mut 0, |candidate, _| candidate.discard_inventory_inner(packet))
    }
    pub fn discard_storage(&mut self, packet: DiscardStorageItemRequestPacket) -> Result<Packet, Error> {
        self.atomic_asset_change(&mut 0, |candidate, _| candidate.discard_storage_inner(packet))
    }
    pub fn move_meseta(&mut self, packet: MoveMesetaPacket) -> Result<Vec<Packet>, Error> {
        self.atomic_asset_change(&mut 0, |candidate, _| candidate.move_meseta_inner(packet))
    }

    // Internal server reward component. This checks representation overflow,
    // not an unverified original-game wallet cap. Caller checkpoints before ACK.
    pub(crate) fn credit_quest_meseta(&mut self, amount: u32) -> Result<Packet, Error> {
        let balance = self.inventory.meseta.checked_add(u64::from(amount))
            .ok_or(Error::InvalidInput("quest_meseta_overflow"))?;
        self.inventory.meseta = balance;
        Ok(Packet::InventoryMeseta(InventoryMesetaPacket { meseta: balance }))
    }
}
