//! Learned native skill effects for ordinary/Et/Lu main classes and audited subclasses.
//! Exact intersection of original SKT nodes, native passive lists and kind-16
//! descriptors. This does not implement server damage formulas or active buffs.
use crate::{Error,sql::CharData,native_class_tree};
use pso2packetlib::protocol::{Packet,ObjectHeader,objects::{Unk0424Packet,Unk0425Packet}};
use std::sync::OnceLock;
#[derive(serde::Deserialize)]
pub(crate) struct Effect {pub slot:u8,pub name:String,pub id:u32,pub kind:u32,pub hash:u32}
#[derive(serde::Deserialize)]
struct Catalogue {effects:Vec<Effect>}
pub(crate) fn effects()-> &'static [Effect] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-class-passive-effects.json")).expect("pinned native class passive effects")).effects
}
fn remove(header:ObjectHeader,id:u32)->Packet {
    Packet::Unk0425(Unk0425Packet{unk1:header,unk2:header,unk3:id,..Default::default()})
}
pub(crate) fn subclass_effects()-> &'static [Effect] {
    static DATA:OnceLock<Catalogue>=OnceLock::new();
    &DATA.get_or_init(||serde_json::from_str(include_str!("../testdata/classic-subclass-native-effects.json"))
        .expect("pinned audited subclass effects")).effects
}
fn enable(header:ObjectHeader,id:u32,rank:u8)->Packet {
    let mut tail=[0;12];tail[4..8].copy_from_slice(&u32::from(rank).to_le_bytes());
    tail[8..12].copy_from_slice(&4u32.to_le_bytes());
    Packet::Unk0424(Unk0424Packet{unk1:header,unk2:header,unk3:header,
        unk4:id,unk5:u32::MAX,unk6:tail,unk7:[0;12]})
}
fn synchronize_subclass(header:ObjectHeader,c:&CharData,out:&mut Vec<Packet>)->Result<(),Error> {
    let main=c.character.classes.main_class as u8;let sub=c.character.classes.sub_class as u8;
    let tree=if matches!(main,0..=7|9) && sub!=main && subclass_effects().iter().any(|e|e.slot==sub) {
        let info=native_class_tree::class_level(&c.character.classes,sub)?;
        let tree=c.native_class_trees.get(&sub).cloned().unwrap_or_default().at_level(sub,info.level1)?;
        tree.validate(sub,info.level1,info.level2)?;Some(tree)
    }else{None};
    let mut removed:std::collections::HashSet<u32>=out.iter().filter_map(|p|match p {
        Packet::Unk0425(p)=>Some(p.unk3),_=>None
    }).collect();
    // Clear every audited non-main effect, including a former subclass when the
    // main stays unchanged. Area reloads use the same idempotent refresh path.
    for e in subclass_effects().iter().filter(|e|e.slot!=main) {
        if removed.insert(e.id) {out.push(remove(header,e.id));}
        let rank=tree.as_ref().filter(|_|e.slot==sub).map_or(0,|t|t.rank(&e.name));
        if rank>0 {out.push(enable(header,e.id,rank));}
    }
    Ok(())
}
#[cfg(test)]
mod local_subclass_tests;
pub(crate) fn synchronize(header:ObjectHeader,c:&CharData,previous:Option<u8>)->Result<Vec<Packet>,Error> {
    let slot=c.character.classes.main_class as u8;
    let mut out=Vec::new();
    if let Some(old)=previous.filter(|old|*old!=slot) {
        out.extend(effects().iter().filter(|e|e.slot==old).map(|e|remove(header,e.id)));
    }
    // Hr/Ph retain their separately verified state/effect synchronization.
    if native_class_tree::definition(slot).is_err() {
        synchronize_subclass(header,c,&mut out)?;return Ok(out);
    }
    let info=native_class_tree::class_level(&c.character.classes,slot)?;
    let tree=c.native_class_trees.get(&slot).cloned().unwrap_or_default().at_level(slot,info.level1)?;
    tree.validate(slot,info.level1,info.level2)?;
    for e in effects().iter().filter(|e|e.slot==slot) {
        // Original kind-16 factory retains an existing component: remove first
        // to refresh learned rank after a durable allocation acknowledgement.
        out.push(remove(header,e.id));
        let rank=tree.rank(&e.name);if rank==0 {continue;}
        out.push(enable(header,e.id,rank));
    }
    synchronize_subclass(header,c,&mut out)?;
    Ok(out)
}
#[cfg(test)]
mod tests {
    use super::*;
    use pso2packetlib::protocol::models::character::Class;
    #[test]
    fn local_class_passives_pinned_ids_are_unique_kind16_and_named_original_nodes() {
        assert_eq!(effects().len(),367);let mut ids=std::collections::BTreeSet::new();
        for e in effects() {
            assert!(ids.insert(e.id));assert_eq!(e.kind,16);
            assert_eq!(e.hash,data_structs::name_to_id(&e.name));
            assert!(native_class_tree::definition(e.slot).unwrap().nodes.iter().any(|n|n.name==e.name));
        }
    }
    #[test]
    fn local_class_passives_initial_actions_do_not_grant_zero_sp_luster_counters() {
        let mut c=CharData::default();c.character.classes.main_class=Class::Luster;
        c.character.classes.luster_info.level1=85;c.character.classes.luster_info.level2=85;
        let h=ObjectHeader::default();let before=synchronize(h,&c,None).unwrap();
        assert!(before.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==114020))); // initial Step JA
        for id in [114050,114051] {assert!(!before.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==id)));}
        let mut tree=native_class_tree::ClassTree::default();
        for name in ["SlayerDodgeCounter","SlayerStepGuard"] {
            let n=native_class_tree::definition(14).unwrap().nodes.iter().find(|n|n.name==name).unwrap();
            tree=tree.learn(14,n.x,n.y,1,85,85).unwrap();
        }
        c.native_class_trees.insert(14,tree);
        let learned=synchronize(h,&c,Some(14)).unwrap();
        for id in [114050,114051] {assert!(learned.iter().any(|p|matches!(p,Packet::Unk0424(p) if p.unk4==id && p.unk6[4..8]==1u32.to_le_bytes())));}
        c.character.classes.main_class=Class::Hero;
        let exited=synchronize(h,&c,Some(14)).unwrap();
        assert_eq!(exited.len(),63+subclass_effects().len());assert!(exited.iter().all(|p|matches!(p,Packet::Unk0425(_))));
        let cleared=synchronize(h,&c,None).unwrap();assert_eq!(cleared.len(),subclass_effects().len());
        assert!(cleared.iter().all(|p|matches!(p,Packet::Unk0425(p) if subclass_effects().iter().any(|e|e.id==p.unk3))));
    }
    #[test]
    fn local_class_passives_refresh_rank_clear_old_class_and_exclude_unaudited_subclass() {
        let mut c=CharData::default();c.character.classes.main_class=Class::Hunter;
        c.character.classes.sub_class=Class::Luster;c.character.classes.hunter_info.level1=85;
        c.character.classes.hunter_info.level2=85;
        let h=ObjectHeader::default();let p=synchronize(h,&c,Some(14)).unwrap();
        let split=p.iter().position(|p|matches!(p,Packet::Unk0424(_))).unwrap();
        assert!(p[..63].iter().all(|p|matches!(p,Packet::Unk0425(_))));assert!(split>=63);
        assert!(!p.iter().any(|p|matches!(p,Packet::Unk0424(p) if (114000..115000).contains(&p.unk4))));
        let e=effects().iter().find(|e|e.slot==0 && native_class_tree::definition(0).unwrap().nodes.iter()
            .any(|n|n.name==e.name && n.cost>0 && n.parent.is_none() && n.max_rank>=2)).unwrap();
        let n=native_class_tree::definition(0).unwrap().nodes.iter().find(|n|n.name==e.name).unwrap();
        c.native_class_trees.insert(0,native_class_tree::ClassTree::default().learn(0,n.x,n.y,2,85,85).unwrap());
        let p=synchronize(h,&c,Some(0)).unwrap();
        let pos=p.iter().position(|p|matches!(p,Packet::Unk0424(p) if p.unk4==e.id)).unwrap();
        assert!(matches!(&p[pos-1],Packet::Unk0425(p) if p.unk3==e.id));
        assert!(matches!(&p[pos],Packet::Unk0424(p) if p.unk6[4..8]==2u32.to_le_bytes() && p.unk6[8..12]==4u32.to_le_bytes()));
    }
}
