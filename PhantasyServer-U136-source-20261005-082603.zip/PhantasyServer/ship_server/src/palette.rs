use crate::{Error, inventory::Inventory};
use pso2packetlib::protocol::{
    ObjectHeader, Packet,
    items::{ChangeWeaponPalettePacket, EquipedWeaponPacket, Item},
    palette::{
        FullPaletteInfoPacket, LoadPalettePacket, NewDefaultPAsPacket, SetDefaultPAsPacket,
        SetPalettePacket, SetSubPalettePacket, SubPalette, UpdatePalettePacket,
        UpdateSubPalettePacket, WeaponPalette,
    },
};
use serde::{Deserialize, Serialize};

#[cfg(test)]
mod local_equip_tests {
    use super::*;
    fn fixture() -> (Palette, Inventory) {
        let mut inv = Inventory::default();
        for uuid in [10,20,30] {inv.add_item(Item {uuid, ..Default::default()});}
        inv.equip_item(10,9).unwrap(); inv.equip_item(30,0).unwrap();
        let mut palette = Palette::default(); palette.palettes[0].uuid=10;
        (palette, inv)
    }
    fn state(p: &Palette, i: &Inventory) -> Vec<u8> {rmp_serde::to_vec(&(p,i)).unwrap()}
    #[test]
    fn local_equip_palette_missing_replacement_keeps_old_weapon_and_all_palettes() {
        let (mut p, mut i)=fixture();let before=state(&p,&i);
        let mut packet=UpdatePalettePacket::default();packet.palettes[0].uuid=999;
        packet.palettes[1].uuid=20;
        assert!(p.update_palette(&mut i,packet).is_err());
        assert_eq!(state(&p,&i),before);
    }
    #[test]
    fn local_equip_palette_invalid_selection_preserves_state_without_panic() {
        for corrupt_saved_selection in [false,true] {
            let (mut p, mut i)=fixture();
            let mut packet=UpdatePalettePacket::default();packet.palettes[0].uuid=20;
            if corrupt_saved_selection {p.cur_palette=6;} else {packet.cur_palette=6;}
            let before=state(&p,&i);
            assert!(p.update_palette(&mut i,packet).is_err());assert_eq!(state(&p,&i),before);
        }
    }
    #[test]
    fn local_equip_palette_valid_replacement_and_empty_slot_preserve_other_equipment() {
        let (mut p, mut i)=fixture();let mut packet=UpdatePalettePacket::default();
        packet.palettes[0].uuid=20;
        let response=p.update_palette(&mut i,packet).unwrap();
        let Packet::LoadPalette(load)=response else {panic!()};assert_eq!(load.palettes[0].uuid,20);
        let Packet::LoadEquiped(e)=i.send_equiped(1) else {panic!()};
        assert_eq!(e.items.iter().map(|x| (x.unk,x.item.uuid)).collect::<Vec<_>>(),vec![(0,30),(9,20)]);
        p.update_palette(&mut i,UpdatePalettePacket::default()).unwrap();
        let Packet::LoadEquiped(e)=i.send_equiped(1) else {panic!()};
        assert_eq!(e.items.iter().map(|x| x.item.uuid).collect::<Vec<_>>(),vec![30]);
        assert!(i.get_inv_item(10).is_ok() && i.get_inv_item(20).is_ok());
    }
}

#[derive(Debug, Default, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Palette {
    cur_palette: u32,
    cur_subpalette: u32,
    cur_book: u32,
    palettes: [WeaponPalette; 6],
    subpalettes: [SubPalette; 6],
    default_pas: Vec<u32>,
}

impl Palette {
    pub fn send_palette(&self) -> Packet {
        Packet::LoadPalette(LoadPalettePacket {
            cur_palette: self.cur_palette,
            cur_subpalette: self.cur_subpalette,
            cur_book: self.cur_book,
            palettes: self.palettes.clone(),
            subpalettes: self.subpalettes.clone(),
        })
    }
    pub fn send_full_palette(&self) -> Packet {
        Packet::FullPaletteInfo(FullPaletteInfoPacket {
            cur_palette: self.cur_palette,
            cur_subpalette: self.cur_subpalette,
            cur_book: self.cur_book,
            palettes: self.palettes.clone(),
            subpalettes: self.subpalettes.clone(),
            default_pa: self.default_pas.clone().into(),
        })
    }
    pub fn send_default_pa(&self) -> Packet {
        Packet::NewDefaultPAs(NewDefaultPAsPacket {
            default: self.default_pas.clone().into(),
        })
    }
    pub const fn set_palette(&mut self, packet: SetPalettePacket) -> Result<(), Error> {
        if packet.palette > 5 {
            return Err(Error::InvalidInput("set_palette"));
        }
        self.cur_palette = packet.palette;
        Ok(())
    }
    pub const fn set_palette_data(&mut self, id: u32, palette: WeaponPalette) {
        self.palettes[id as usize] = palette;
    }
    pub const fn set_subpalette_data(&mut self, palettes: [SubPalette; 6]) {
        self.subpalettes = palettes;
    }
    pub fn send_change_palette(&self, playerid: u32) -> Packet {
        Packet::ChangeWeaponPalette(ChangeWeaponPalettePacket {
            player: ObjectHeader {
                id: playerid,
                entity_type: pso2packetlib::protocol::ObjectType::Player,
                ..Default::default()
            },
            cur_palette: self.cur_palette,
            ..Default::default()
        })
    }
    pub fn send_cur_weapon(&self, playerid: u32, inv: &Inventory) -> Packet {
        let uuid = self.palettes[self.cur_palette as usize].uuid;
        Packet::EquipedWeapon(EquipedWeaponPacket {
            player: ObjectHeader {
                id: playerid,
                entity_type: pso2packetlib::protocol::ObjectType::Player,
                ..Default::default()
            },
            item: inv.get_inv_item(uuid).unwrap_or_default(),
        })
    }
    pub fn update_palette(
        &mut self,
        inv: &mut Inventory,
        packet: UpdatePalettePacket,
    ) -> Result<Packet, Error> {
        if packet.cur_palette > 5 || self.cur_palette > 5 {
            return Err(Error::InvalidInput("update_palette"));
        }
        // Validate the replacement before unequipping the old weapon or
        // replacing any palette. Empty slots (UUID 0) remain valid.
        let next_item = packet.palettes[packet.cur_palette as usize].uuid;
        if next_item != 0 {
            inv.get_inv_item(next_item)?;
        }
        let old = &self.palettes;
        let item = old[self.cur_palette as usize].uuid;
        if item != 0 {
            inv.unequip_item(item)?;
        }
        self.palettes = packet.palettes;
        self.cur_palette = packet.cur_palette;
        let item = self.palettes[self.cur_palette as usize].uuid;
        if item != 0 {
            inv.equip_item(item, 9)?;
        }
        Ok(self.send_palette())
    }
    pub fn update_subpalette(&mut self, packet: UpdateSubPalettePacket) -> Result<Packet, Error> {
        if packet.cur_subpalette > 5 || packet.cur_book > 1 {
            return Err(Error::InvalidInput("update_subpalette"));
        }
        self.subpalettes = packet.subpalettes;
        Ok(self.send_palette())
    }
    pub const fn set_subpalette(&mut self, packet: SetSubPalettePacket) -> Result<(), Error> {
        if packet.subpalette > 5 {
            return Err(Error::InvalidInput("set_subpalette"));
        }
        self.cur_subpalette = packet.subpalette;
        Ok(())
    }
    pub fn set_default_pas(&mut self, packet: SetDefaultPAsPacket) -> Packet {
        self.default_pas = packet.default.into();
        Packet::NewDefaultPAs(NewDefaultPAsPacket {
            default: self.default_pas.clone().into(),
        })
    }
    pub fn get_current_item(&self, inv: &Inventory) -> Result<Option<Item>, Error> {
        let uuid = self.palettes.get(self.cur_palette as usize)
            .ok_or(Error::InvalidInput("current_weapon_palette"))?.uuid;

        if uuid != 0 {
            Ok(Some(inv.get_inv_item(uuid)?))
        } else {
            Ok(None)
        }
    }
}
