use super::*;
use data_structs::master_ship::{AccountCommit,AccountCommitResult,AccountSnapshot,AccountState};

#[derive(Clone)]
pub(crate) struct PendingAccountSave {
    pub user_id: u32,
    pub commit: AccountCommit,
    pub(super) payload: Vec<u8>,
}

impl Sql {
    pub async fn create_session_character(&self, session: &mut super::AccountSession,
        user: &mut User, mut character: CharData, next_uuid: u64) -> Result<u32, Error> {
        if session.id != user.id || next_uuid < user.last_uuid || session.revision >= i64::MAX as u64 {
            return Err(Error::InvalidInput("create_session_character_identity_or_revision"));
        }
        character.character.player_id = user.id;
        let commit = AccountCommit {commit_id: rand::random(), expected_revision: session.revision,
            snapshot: AccountSnapshot {storage: session.storage.clone(),
                flags: user.accountflags.clone(), last_uuid: next_uuid}};
        let payload = rmp_serde::to_vec(&commit)?;
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let mut owner = Self::read_userdata(&mut transaction, user.id).await?;
        let pending: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM PendingAccountSaves WHERE UserId=?)")
            .bind(user.id).fetch_one(&mut *transaction).await?;
        if pending { return Err(Error::InvalidInput("account_save_pending")); }
        let id: i64 = sqlx::query_scalar("INSERT INTO Characters (Data) VALUES (?) RETURNING Id")
            .bind(rmp_serde::to_vec(&character)?).fetch_one(&mut *transaction).await?;
        let id = u32::try_from(id).map_err(|_| Error::InvalidInput("character_id_range"))?;
        owner.character_ids.push(id);
        Self::write_userdata(&mut transaction, user.id, &owner).await?;
        let queued = sqlx::query("INSERT INTO PendingAccountSaves (UserId,CommitId,Data) VALUES (?,?,?)")
            .bind(user.id).bind(commit.commit_id.as_slice()).bind(payload).execute(&mut *transaction).await?;
        if queued.rows_affected() != 1 { return Err(Error::InvalidInput("save_journal_write")); }
        transaction.commit().await?;
        user.last_uuid = next_uuid;
        // A failure after this point has a recoverable record. The caller must
        // close this session rather than accept further character mutations.
        let revision = tokio::time::timeout(Duration::from_secs(15), self.deliver_pending_account_save(user.id))
            .await.map_err(|_| Error::MSNoResponse)??.ok_or(Error::InvalidInput("creation_journal_missing"))?;
        session.revision = revision;
        Ok(id)
    }

    pub(super) async fn create_save_schema(conn: &sqlx::SqlitePool) -> Result<(), Error> {
        conn.execute("CREATE TABLE IF NOT EXISTS PendingAccountSaves (
            UserId INTEGER PRIMARY KEY,
            CommitId BLOB NOT NULL CHECK (length(CommitId)=16),
            Data BLOB NOT NULL
        )").await?;
        Ok(())
    }

    pub async fn load_account_state(&self,id: u32) -> Result<AccountState, Error> {
        match self.run_action(MasterShipAction::GetAccountState(id)).await? {
            MasterShipAction::AccountState(state)=>Ok(state),
            MasterShipAction::Error(e)=>Err(Error::MSError(e)),
            _=>Err(Error::MSUnexpected),
        }
    }

    pub async fn stage_character_save(&self,char: &CharData,user: &User,expected_revision: u64) -> Result<PendingAccountSave,Error> {
        if char.character.player_id!=user.id || expected_revision>=i64::MAX as u64 {
            return Err(Error::InvalidInput("stage_character_save_identity_or_revision"));
        }
        let commit=AccountCommit {commit_id:rand::random(),expected_revision,
            snapshot:AccountSnapshot {storage:char.inventory.storages.clone(),flags:user.accountflags.clone(),last_uuid:user.last_uuid}};
        let payload=rmp_serde::to_vec(&commit)?;
        let data=rmp_serde::to_vec(char)?;
        let mut transaction=self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner=Self::read_userdata(&mut transaction,user.id).await?;
        Self::require_character_owner(&owner,char.character.character_id)?;
        // Never replace an unresolved delivery with a different snapshot.
        let pending:bool=sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM PendingAccountSaves WHERE UserId=?)")
            .bind(user.id).fetch_one(&mut *transaction).await?;
        if pending {return Err(Error::InvalidInput("account_save_pending"));}
        let changed=sqlx::query("UPDATE Characters SET Data=? WHERE Id=?")
            .bind(data).bind(char.character.character_id).execute(&mut *transaction).await?;
        if changed.rows_affected()!=1 {return Err(Error::InvalidInput("character_missing"));}
        let queued=sqlx::query("INSERT INTO PendingAccountSaves (UserId,CommitId,Data) VALUES (?,?,?)")
            .bind(user.id).bind(commit.commit_id.as_slice()).bind(&payload).execute(&mut *transaction).await?;
        if queued.rows_affected()!=1 {return Err(Error::InvalidInput("save_journal_write"));}
        transaction.commit().await?;
        Ok(PendingAccountSave {user_id:user.id,commit,payload})
    }

    pub async fn pending_account_save(&self,id: u32) -> Result<Option<PendingAccountSave>,Error> {
        let row=sqlx::query("SELECT CommitId,Data FROM PendingAccountSaves WHERE UserId=?")
            .bind(id).fetch_optional(&self.connection).await?;
        let Some(row)=row else {return Ok(None);};
        let payload:Vec<u8>=row.try_get("Data")?;
        let commit:AccountCommit=rmp_serde::from_slice(&payload)?;
        if row.try_get::<Vec<u8>,_>("CommitId")?!=commit.commit_id || commit.expected_revision>=i64::MAX as u64 {
            return Err(Error::InvalidInput("save_journal_corrupt"));
        }
        Ok(Some(PendingAccountSave {user_id:id,commit,payload}))
    }

    pub async fn pending_save_accounts(&self) -> Result<Vec<u32>,Error> {
        let ids=sqlx::query_scalar::<_,i64>("SELECT UserId FROM PendingAccountSaves ORDER BY UserId")
            .fetch_all(&self.connection).await?;
        ids.into_iter().map(|id|u32::try_from(id).map_err(|_|Error::InvalidInput("save_journal_owner"))).collect()
    }

    pub(super) async fn acknowledge_save(&self,pending: &PendingAccountSave,revision: u64) -> Result<(),Error> {
        if pending.commit.expected_revision.checked_add(1)!=Some(revision) {
            return Err(Error::MSUnexpected);
        }
        let removed=sqlx::query("DELETE FROM PendingAccountSaves WHERE UserId=? AND CommitId=? AND Data=?")
            .bind(pending.user_id).bind(pending.commit.commit_id.as_slice()).bind(&pending.payload)
            .execute(&self.connection).await?;
        if removed.rows_affected()!=1 {return Err(Error::InvalidInput("save_ack_missing_or_replaced"));}
        Ok(())
    }

    pub async fn deliver_pending_account_save(&self,id: u32) -> Result<Option<u64>,Error> {
        let Some(pending)=self.pending_account_save(id).await? else {return Ok(None);};
        let response=self.run_action(MasterShipAction::CommitAccountSnapshot {id,commit:pending.commit.clone()}).await?;
        match response {
            MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id,revision,..})=>{
                if commit_id!=pending.commit.commit_id {return Err(Error::MSUnexpected);}
                self.acknowledge_save(&pending,revision).await?;
                Ok(Some(revision))
            },
            MasterShipAction::AccountCommitResult(AccountCommitResult::Conflict {..})=>Err(Error::InvalidInput("account_save_revision_conflict")),
            MasterShipAction::Error(e)=>Err(Error::MSError(e)),
            _=>Err(Error::MSUnexpected),
        }
    }
}
