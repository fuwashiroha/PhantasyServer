use super::*;

#[tokio::test]
async fn local_session_account_sends_one_complete_snapshot_and_requires_ack() {
    for response in [MasterShipAction::Ok,MasterShipAction::Error("save rejected".into()),MasterShipAction::Pong] {
        let mut sql=Sql::in_memory_for_test().await.unwrap();
        let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
        let mut user=User {id:73,last_uuid:123,..Default::default()};user.accountflags.set(111,1);
        let mut inv=Inventory::default();inv.storages.storage_meseta=6789;
        let expected=match &response {MasterShipAction::Ok=>0,MasterShipAction::Error(_)=>1,_=>2};
        let responder=async {
            let (action,send)=requests.recv().await.unwrap();
            // Exercise the actual shared MessagePack model, not a substitute
            // test type. No character data or unrelated account fields travel.
            let bytes=rmp_serde::to_vec(&action).unwrap();
            let action:MasterShipAction=rmp_serde::from_slice(&bytes).unwrap();
            match action {
                MasterShipAction::PutAccountSnapshot {id,snapshot}=>{
                    assert_eq!(id,73);assert_eq!(snapshot.last_uuid,123);
                    assert_eq!(snapshot.flags.get(111),1);assert_eq!(snapshot.storage.storage_meseta,6789);
                }
                _=>panic!("unexpected save action"),
            }
            send.send(response).await.unwrap();
        };
        let (result,())=tokio::join!(sql.save_session_account(&user,&inv),responder);
        match expected {
            0=>result.unwrap(),
            1=>assert!(matches!(result,Err(Error::MSError(_)))),
            _=>assert!(matches!(result,Err(Error::MSUnexpected))),
        }
        assert!(requests.try_recv().is_err());
    }
}

#[tokio::test]
async fn local_session_master_disconnect_and_lost_ack_return_error_without_panic() {
    let mut sql=Sql::in_memory_for_test().await.unwrap();
    let user=User {id:1,..Default::default()};let inv=Inventory::default();
    assert!(matches!(sql.save_session_account(&user,&inv).await,Err(Error::MSNoResponse)));
    let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
    let responder=async {let (_,send)=requests.recv().await.unwrap();drop(send);};
    let (result,())=tokio::join!(sql.save_session_account(&user,&inv),responder);
    assert!(matches!(result,Err(Error::MSNoResponse)));
    drop(requests);
    assert!(matches!(sql.save_session_account(&user,&inv).await,Err(Error::MSNoResponse)));
}
