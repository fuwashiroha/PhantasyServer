use super::*;
use data_structs::master_ship::AccountCommitResult;

async fn fixture() -> (Sql,CharData,User) {
    let sql=Sql::in_memory_for_test().await.unwrap();Sql::create_schema(&sql.connection).await.unwrap();
    sql.insert_local_user(1).await.unwrap();sql.insert_local_user(2).await.unwrap();
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let mut char=sql.load_owned_character(1,id).await.unwrap();char.character.name="new state".into();
    char.inventory.storages.storage_meseta=123;
    let mut user=User {id:1,last_uuid:456,..Default::default()};user.accountflags.set(8,1);
    (sql,char,user)
}

async fn character_bytes(sql: &Sql,id: u32) -> Vec<u8> {
    sqlx::query_scalar("SELECT Data FROM Characters WHERE Id=?").bind(id).fetch_one(&sql.connection).await.unwrap()
}

async fn journal_bytes(sql: &Sql) -> Vec<u8> {
    sqlx::query_scalar("SELECT Data FROM PendingAccountSaves WHERE UserId=1").fetch_one(&sql.connection).await.unwrap()
}

#[tokio::test]
async fn local_journal_stage_persists_character_and_exact_account_payload() {
    let (sql,char,user)=fixture().await;
    let saved=sql.stage_character_save(&char,&user,19).await.unwrap();
    assert_eq!(character_bytes(&sql,char.character.character_id).await,rmp_serde::to_vec(&char).unwrap());
    let loaded=sql.pending_account_save(1).await.unwrap().unwrap();
    assert_eq!(loaded.commit.commit_id,saved.commit.commit_id);assert_eq!(loaded.commit.expected_revision,19);
    assert_eq!(loaded.commit.snapshot.last_uuid,456);assert_eq!(loaded.commit.snapshot.storage.storage_meseta,123);
    assert_eq!(loaded.commit.snapshot.flags.get(8),1);assert_eq!(sql.pending_save_accounts().await.unwrap(),vec![1]);
    assert!(sql.pending_account_save(2).await.unwrap().is_none());
    let before=journal_bytes(&sql).await;
    let mut changed=char.clone();changed.character.name="must not replace".into();
    assert!(sql.stage_character_save(&changed,&user,20).await.is_err());assert_eq!(before,journal_bytes(&sql).await);
    assert_eq!(character_bytes(&sql,char.character.character_id).await,rmp_serde::to_vec(&char).unwrap());
}

#[tokio::test]
async fn local_journal_stage_aborted_or_ignored_writes_roll_back_both_records() {
    for (table,event) in [("Characters","UPDATE"),("PendingAccountSaves","INSERT")] {
        for action in ["RAISE(ABORT,'injected')","RAISE(IGNORE)"] {
            let (sql,char,user)=fixture().await;let before=character_bytes(&sql,char.character.character_id).await;
            sql.connection.execute(format!("CREATE TRIGGER fail_stage BEFORE {event} ON {table} BEGIN SELECT {action}; END").as_str()).await.unwrap();
            assert!(sql.stage_character_save(&char,&user,0).await.is_err());
            assert_eq!(before,character_bytes(&sql,char.character.character_id).await);assert!(sql.pending_account_save(1).await.unwrap().is_none());
            sql.connection.execute("DROP TRIGGER fail_stage").await.unwrap();sql.stage_character_save(&char,&user,0).await.unwrap();
        }
    }
}

#[tokio::test]
async fn local_journal_wrong_owner_missing_character_and_bad_revision_do_not_stage() {
    let (sql,mut char,user)=fixture().await;
    assert!(sql.stage_character_save(&char,&user,i64::MAX as u64).await.is_err());
    char.character.player_id=2;assert!(sql.stage_character_save(&char,&user,0).await.is_err());
    let other=User {id:2,..Default::default()};assert!(sql.stage_character_save(&char,&other,0).await.is_err());
    char.character.player_id=1;
    sqlx::query("DELETE FROM Characters WHERE Id=?").bind(char.character.character_id).execute(&sql.connection).await.unwrap();
    assert!(sql.stage_character_save(&char,&user,0).await.is_err());assert!(sql.pending_save_accounts().await.unwrap().is_empty());
}

#[tokio::test]
async fn local_journal_network_failure_conflict_and_wrong_ack_keep_pending_payload() {
    let (mut sql,char,user)=fixture().await;let pending=sql.stage_character_save(&char,&user,3).await.unwrap();
    let bytes=journal_bytes(&sql).await;
    assert!(matches!(sql.deliver_pending_account_save(1).await,Err(Error::MSNoResponse)));
    let responses=[MasterShipAction::Error("remote fault".into()),MasterShipAction::Ok,
        MasterShipAction::AccountCommitResult(AccountCommitResult::Conflict {revision:9}),
        MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:[0;16],revision:4,duplicate:false}),
        MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:pending.commit.commit_id,revision:5,duplicate:false})];
    for response in responses {
        let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
        let server=async {let (_,send)=requests.recv().await.unwrap();send.send(response).await.unwrap();};
        let (result,())=tokio::join!(sql.deliver_pending_account_save(1),server);assert!(result.is_err());
        assert_eq!(bytes,journal_bytes(&sql).await);
    }
    let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
    let server=async {let (_,send)=requests.recv().await.unwrap();drop(send);};
    let (result,())=tokio::join!(sql.deliver_pending_account_save(1),server);assert!(matches!(result,Err(Error::MSNoResponse)));
    assert_eq!(bytes,journal_bytes(&sql).await);
}

#[tokio::test]
async fn local_journal_ack_failure_retry_and_stale_ack_do_not_delete_newer_save() {
    let (mut sql,char,user)=fixture().await;let pending=sql.stage_character_save(&char,&user,0).await.unwrap();
    sql.connection.execute("CREATE TRIGGER fail_ack BEFORE DELETE ON PendingAccountSaves BEGIN SELECT RAISE(IGNORE); END").await.unwrap();
    for duplicate in [false,true] {
        let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
        let server=async {
            let (action,send)=requests.recv().await.unwrap();
            let MasterShipAction::CommitAccountSnapshot {id,commit}=action else {panic!()};
            assert_eq!(id,1);assert_eq!(rmp_serde::to_vec(&commit).unwrap(),rmp_serde::to_vec(&pending.commit).unwrap());
            send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate})).await.unwrap();
        };
        let (result,())=tokio::join!(sql.deliver_pending_account_save(1),server);
        if !duplicate {
            assert!(result.is_err());assert!(sql.pending_account_save(1).await.unwrap().is_some());
            sql.connection.execute("DROP TRIGGER fail_ack").await.unwrap();
        } else {assert_eq!(result.unwrap(),Some(1));}
    }
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    let next=sql.stage_character_save(&char,&user,1).await.unwrap();
    assert!(sql.acknowledge_save(&pending,1).await.is_err());
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,next.commit.commit_id);
}

#[tokio::test]
async fn local_journal_legacy_schema_reopen_retains_pending_and_rejects_corruption() {
    let path=std::env::temp_dir().join(format!("pso2-u025-ship-{}-{}.db",std::process::id(),std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()));
    assert!(!path.exists());let url=format!("sqlite:{}",path.display());
    let sql=Sql::new(&url,MasterConnection::disconnected_for_test()).await.unwrap();
    sql.insert_local_user(1).await.unwrap();let id=sql.put_character(1,CharData::default()).await.unwrap();
    sql.connection.execute("DROP TABLE PendingAccountSaves").await.unwrap();
    let before=character_bytes(&sql,id).await;sql.connection.close().await;
    let sql=Sql::new(&url,MasterConnection::disconnected_for_test()).await.unwrap();assert_eq!(before,character_bytes(&sql,id).await);
    let char=sql.load_owned_character(1,id).await.unwrap();let user=User {id:1,..Default::default()};
    let pending=sql.stage_character_save(&char,&user,7).await.unwrap();let bytes=journal_bytes(&sql).await;sql.connection.close().await;
    let sql=Sql::new(&url,MasterConnection::disconnected_for_test()).await.unwrap();
    assert_eq!(bytes,journal_bytes(&sql).await);assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,pending.commit.commit_id);
    sqlx::query("UPDATE PendingAccountSaves SET Data=? WHERE UserId=1").bind(vec![0xc1u8]).execute(&sql.connection).await.unwrap();
    assert!(sql.pending_account_save(1).await.is_err());sql.connection.close().await;super::remove_test_db(&path).await;
}
