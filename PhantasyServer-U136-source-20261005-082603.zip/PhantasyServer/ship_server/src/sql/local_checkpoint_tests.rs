use super::*;
use data_structs::master_ship::{AccountCommit, AccountCommitResult, AccountSnapshot, AccountState};

pub(crate) type Requests = tokio::sync::mpsc::Receiver<(MasterShipAction,tokio::sync::mpsc::Sender<MasterShipAction>)>;

// Test-only readback while the real checkpoint worker owns the session lease.
pub(crate) async fn saved_character(sql: &Sql, owner: u32, character: u32) -> CharData {
    sql.load_owned_character(owner, character).await.unwrap()
}

pub(crate) async fn inject_asset_local_write_fault(sql: &Sql, enabled: bool) {
    let statement = if enabled {
        "CREATE TRIGGER fail_asset_checkpoint BEFORE INSERT ON PendingAccountSaves BEGIN SELECT RAISE(IGNORE); END"
    } else { "DROP TRIGGER fail_asset_checkpoint" };
    sql.connection.execute(statement).await.unwrap();
}

pub(super) fn state(revision: u64) -> AccountState {
    AccountState {revision, snapshot: AccountSnapshot {storage: AccountStorages::default(),
        flags: Flags::default(), last_uuid: 10}}
}

pub(crate) async fn fixture() -> (Sql,Requests,AccountSession,CharData,User) {
    fixture_with_sql(Sql::in_memory_for_test().await.unwrap()).await
}

pub(super) async fn fixture_with_sql(mut sql: Sql) -> (Sql,Requests,AccountSession,CharData,User) {
    Sql::create_schema(&sql.connection).await.unwrap();
    sql.insert_local_user(1).await.unwrap();sql.insert_local_user(2).await.unwrap();
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let char=sql.load_owned_character(1,id).await.unwrap();
    let (master,mut requests)=MasterConnection::channel_for_test();sql.master_ship=master;
    let mut user=User {id:1,..Default::default()};
    let serve=async {let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(0))).await.unwrap();};
    let (session,())=tokio::join!(sql.open_account_session(&mut user),serve);
    (sql,requests,session.unwrap(),char,user)
}

pub(crate) async fn ack(requests: &mut Requests, expected: u64, duplicate: bool) -> AccountCommit {
    let (action,send)=requests.recv().await.unwrap();
    let MasterShipAction::CommitAccountSnapshot {id,commit}=action else {panic!("expected snapshot")};
    assert_eq!(id,1);assert_eq!(commit.expected_revision,expected);
    send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
        commit_id:commit.commit_id,revision:expected+1,duplicate})).await.unwrap();commit
}

#[tokio::test]
async fn local_checkpoint_repeated_snapshots_advance_revision_and_preserve_latest_state() {
    let (sql,mut requests,mut session,mut char,mut user)=fixture().await;
    for index in 0..3u64 {
        char.character.name=format!("checkpoint {index}");char.inventory.storages.storage_meseta=100+index;
        char.play_time=Duration::from_secs(20+index);user.last_uuid=20+index;user.accountflags.set(17,(index & 1) as u8);
        let (result,commit)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),ack(&mut requests,index,false));
        result.unwrap();assert_eq!(session.revision,index+1);assert!(session.checkpoint.is_none());
        assert_eq!(commit.snapshot.last_uuid,user.last_uuid);assert_eq!(commit.snapshot.flags.get(17),(index & 1) as u8);
        assert_eq!(session.storage.storage_meseta,100+index);
        let saved=sql.load_owned_character(1,char.character.character_id).await.unwrap();
        assert_eq!(saved.character.name,char.character.name);assert_eq!(saved.play_time,char.play_time);
        assert!(sql.pending_account_save(1).await.unwrap().is_none());
    }
    assert!(requests.try_recv().is_err());session.release();
}

#[tokio::test]
async fn local_checkpoint_local_fault_retains_exact_older_snapshot_before_newer_progress() {
    let (sql,mut requests,mut session,mut char,mut user)=fixture().await;
    let before=sql.load_owned_character(1,char.character.character_id).await.unwrap().character.name;
    char.character.name="older prepared".into();char.inventory.storages.storage_meseta=500;user.last_uuid=25;
    sql.connection.execute("CREATE TRIGGER fail_checkpoint BEFORE INSERT ON PendingAccountSaves BEGIN SELECT RAISE(IGNORE); END").await.unwrap();
    assert!(sql.checkpoint_session(&mut session,&char,&user).await.is_err());
    let exact=session.checkpoint.as_ref().unwrap().pending.commit.clone();
    assert_eq!(sql.load_owned_character(1,char.character.character_id).await.unwrap().character.name,before);
    assert!(!sql.checkpoint_durable_for(&session,&char,&user).await.unwrap());
    assert!(sql.pending_account_save(1).await.unwrap().is_none());assert!(requests.try_recv().is_err());
    sql.connection.execute("DROP TRIGGER fail_checkpoint").await.unwrap();
    char.character.name="newer progress".into();char.inventory.storages.storage_meseta=900;user.last_uuid=30;
    let serve=async {
        let first=ack(&mut requests,0,false).await;
        assert_eq!(rmp_serde::to_vec(&first).unwrap(),rmp_serde::to_vec(&exact).unwrap());
        let second=ack(&mut requests,1,false).await;assert_ne!(first.commit_id,second.commit_id);
        assert_eq!(second.snapshot.last_uuid,30);assert_eq!(second.snapshot.storage.storage_meseta,900);
    };
    let (result,())=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),serve);result.unwrap();
    assert_eq!(session.revision,2);assert_eq!(sql.load_owned_character(1,char.character.character_id).await.unwrap().character.name,"newer progress");
    assert!(sql.pending_account_save(1).await.unwrap().is_none());session.release();
}

#[tokio::test]
async fn local_checkpoint_lost_reply_retries_same_identity_and_only_exact_latest_is_durable() {
    let (sql,mut requests,mut session,mut char,user)=fixture().await;
    char.character.name="durable lost reply".into();
    let lose=async {let (action,send)=requests.recv().await.unwrap();drop(send);
        let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};commit};
    let (result,original)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),lose);
    assert!(matches!(result,Err(Error::MSNoResponse)));assert_eq!(session.revision,0);
    assert!(sql.checkpoint_durable_for(&session,&char,&user).await.unwrap());
    let mut newer=char.clone();newer.character.name="not durable yet".into();
    assert!(!sql.checkpoint_durable_for(&session,&newer,&user).await.unwrap());
    let (result,retry)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),ack(&mut requests,0,true));
    result.unwrap();assert_eq!(rmp_serde::to_vec(&original).unwrap(),rmp_serde::to_vec(&retry).unwrap());
    assert_eq!(session.revision,1);assert!(requests.try_recv().is_err());session.release();
}

#[tokio::test]
async fn local_checkpoint_cancellation_and_already_deleted_ack_retry_exact_payload() {
    let (sql,mut requests,mut session,char,user)=fixture().await;
    let mut future=Box::pin(sql.checkpoint_session(&mut session,&char,&user));
    let (action,send)=tokio::select! {
        request=requests.recv()=>request.unwrap(),
        result=&mut future=>panic!("unexpected early result: {result:?}"),
    };
    let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
    drop(future);drop(send);
    // Model cancellation after the local delete has committed but before the
    // caller observed completion. Retained identity must recover this boundary.
    let pending=session.checkpoint.as_ref().unwrap().pending.clone();
    sql.acknowledge_save(&pending,1).await.unwrap();assert!(sql.pending_account_save(1).await.unwrap().is_none());
    let (result,retry)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),ack(&mut requests,0,true));
    result.unwrap();assert_eq!(retry.commit_id,commit.commit_id);assert_eq!(session.revision,1);
    assert!(sql.pending_account_save(1).await.unwrap().is_none());session.release();
}

#[tokio::test]
async fn local_checkpoint_conflict_wrong_reply_and_ack_fault_never_rebase_or_discard() {
    let (sql,mut requests,mut session,char,user)=fixture().await;
    for kind in 0..4 {
        if kind==3 {sql.connection.execute("CREATE TRIGGER fail_ack BEFORE DELETE ON PendingAccountSaves BEGIN SELECT RAISE(IGNORE); END").await.unwrap();}
        let serve=async {
            let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
            assert_eq!(commit.expected_revision,0);
            let response=match kind {
                0=>AccountCommitResult::Conflict {revision:9},
                1=>AccountCommitResult::Committed {commit_id:[0;16],revision:1,duplicate:false},
                2=>AccountCommitResult::Committed {commit_id:commit.commit_id,revision:2,duplicate:false},
                _=>AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:true},
            };
            send.send(MasterShipAction::AccountCommitResult(response)).await.unwrap();commit.commit_id
        };
        let (result,id)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),serve);
        assert!(result.is_err());assert_eq!(session.revision,0);
        assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,id);
        assert_eq!(session.checkpoint.as_ref().unwrap().pending.commit.commit_id,id);
    }
    sql.connection.execute("DROP TRIGGER fail_ack").await.unwrap();
    let (result,_)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),ack(&mut requests,0,true));result.unwrap();
    assert_eq!(session.revision,1);session.release();
}

#[tokio::test]
async fn local_checkpoint_foreign_journal_cannot_be_cleared_or_overwritten() {
    let (sql,mut requests,mut session,char,user)=fixture().await;
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
        let mut foreign=commit.clone();foreign.commit_id=[5;16];foreign.expected_revision=7;
        sqlx::query("UPDATE PendingAccountSaves SET CommitId=?,Data=? WHERE UserId=1")
            .bind(foreign.commit_id.as_slice()).bind(rmp_serde::to_vec(&foreign).unwrap()).execute(&sql.connection).await.unwrap();
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    };
    let (result,())=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),serve);assert!(result.is_err());
    let foreign=sql.pending_account_save(1).await.unwrap().unwrap();assert_eq!(foreign.commit.commit_id,[5;16]);
    assert!(sql.checkpoint_session(&mut session,&char,&user).await.is_err());
    assert!(!sql.checkpoint_durable_for(&session,&char,&user).await.unwrap());assert_eq!(session.revision,0);
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,[5;16]);
    assert!(requests.try_recv().is_err()); // Leave this isolated lease fenced on drop.
}

#[tokio::test]
async fn local_checkpoint_waiting_remote_holds_only_its_own_account_lease() {
    let (sql,mut requests,mut session,char,user)=fixture().await;
    let mut future=Box::pin(sql.checkpoint_session(&mut session,&char,&user));
    let (action,reply)=tokio::select! {r=requests.recv()=>r.unwrap(),r=&mut future=>panic!("{r:?}")};
    let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
    let mut same=User {id:1,..Default::default()};
    assert!(tokio::time::timeout(Duration::from_millis(20),sql.open_account_session(&mut same)).await.is_err());
    let mut other=User {id:2,..Default::default()};
    let serve=async {let (action,send)=requests.recv().await.unwrap();assert!(matches!(action,MasterShipAction::GetAccountState(2)));
        send.send(MasterShipAction::AccountState(state(0))).await.unwrap();};
    let (other,())=tokio::time::timeout(Duration::from_secs(2),async {tokio::join!(sql.open_account_session(&mut other),serve)}).await.unwrap();
    other.unwrap().release();
    reply.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    future.await.unwrap();assert_eq!(session.revision,1);session.release();
}

#[tokio::test]
async fn local_checkpoint_file_reopen_recovers_snapshot_after_lost_delivery() {
    let path=std::env::temp_dir().join(format!("pso2-u026-{}-{}.db",std::process::id(),rand::random::<u64>()));
    let url=format!("sqlite:{}",path.display());
    let (master,mut requests)=MasterConnection::channel_for_test();
    let sql=Sql::new(&url,master).await.unwrap();sql.insert_local_user(1).await.unwrap();
    let id=sql.put_character(1,CharData::default()).await.unwrap();let mut char=sql.load_owned_character(1,id).await.unwrap();
    let mut user=User {id:1,..Default::default()};
    let serve=async {let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(0))).await.unwrap();};
    let (session,())=tokio::join!(sql.open_account_session(&mut user),serve);let mut session=session.unwrap();
    char.character.name="reopen checkpoint".into();char.inventory.storages.storage_meseta=1234;char.play_time=Duration::from_secs(60);
    user.last_uuid=51;user.accountflags.set(17,1);
    let lose=async {let (_,send)=requests.recv().await.unwrap();drop(send);};
    let (result,())=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),lose);assert!(result.is_err());
    let exact=session.checkpoint.as_ref().unwrap().pending.commit.clone();drop(session);sql.connection.close().await;drop(sql);
    let (master,mut requests)=MasterConnection::channel_for_test();let sql=Sql::new(&url,master).await.unwrap();
    let serve=async {
        let retry=ack(&mut requests,0,true).await;assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&exact).unwrap());
        let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(AccountState {revision:1,snapshot:retry.snapshot})).await.unwrap();
    };
    let mut user=User {id:1,..Default::default()};
    let (session,())=tokio::join!(sql.open_account_session(&mut user),serve);let session=session.unwrap();
    assert_eq!(session.revision,1);assert_eq!(user.last_uuid,51);assert_eq!(user.accountflags.get(17),1);
    let saved=sql.session_character(&session,id).await.unwrap();assert_eq!(saved.character.name,"reopen checkpoint");
    assert_eq!(saved.inventory.storages.storage_meseta,1234);assert_eq!(saved.play_time,Duration::from_secs(60));
    assert!(sql.pending_account_save(1).await.unwrap().is_none());session.release();
    sql.connection.close().await;super::remove_test_db(&path).await;
}
