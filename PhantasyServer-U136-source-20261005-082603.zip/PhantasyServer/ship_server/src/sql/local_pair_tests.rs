//! Opt-in backend probe, run only against an explicitly marked isolated runtime.
use super::*;
use data_structs::master_ship::AccountCommitResult;

#[tokio::test]
#[ignore = "requires marked isolated candidate master process and explicit probe environment"]
async fn local_pair_transport_restart_recovers_lost_ack() {
    let root=std::path::PathBuf::from(std::env::var("PSO2_U025_PROBE_ROOT").expect("isolated probe root"))
        .canonicalize().unwrap();
    let normal=root.to_string_lossy().replace("\\\\?\\", "").to_ascii_lowercase();
    assert!(normal.starts_with("f:\\pso2classic\\setup\\m0-u025-control-drill\\"));
    assert_eq!(std::fs::read_to_string(root.join(".isolated-u025")).unwrap(),"isolated backend validation only\n");
    let phase=std::env::var("PSO2_U025_PROBE_PHASE").unwrap();assert!(matches!(phase.as_str(),"prepare"|"recover"));
    let address:std::net::SocketAddr=std::fs::read_to_string(root.join("probe-address.txt")).unwrap().trim().parse().unwrap();
    assert!(address.ip().is_loopback() && address.port()>20000);
    let hostkeys=root.join("hostkeys.toml");
    let master=MasterConnection::new(address,b"isolated-u025-probe",hostkeys.to_str().unwrap()).await.unwrap();
    let db=root.join("probe-ship.db");
    // Windows canonical paths contain a verbatim prefix with '?', which the
    // SQLite URL parser would treat as a query delimiter. Keep filesystem paths
    // canonical, but pass an explicit normalized SQLite URL to the driver.
    let db_url=format!("sqlite://{}",db.to_string_lossy().replace("\\\\?\\", "").replace('\\',"/"));
    let sql=Sql::new(&db_url,master).await.unwrap();
    let mut user=sql.get_sega_user("isolated_u025_probe","isolated_test_password",Ipv4Addr::LOCALHOST).await.unwrap();
    let mut session=sql.open_account_session(&mut user).await.unwrap();
    if phase=="prepare" {
        assert_eq!(session.revision,0);
        session.storage.storage_meseta=9123;
        let id=sql.create_session_character(&mut session,&mut user,CharData::default(),400).await.unwrap();
        assert_eq!(session.revision,1);
        let mut character=sql.session_character(&session,id).await.unwrap();
        character.character.name="paired recovery checkpoint".into();character.inventory.storages.storage_meseta=98765;
        user.last_uuid=401;user.accountflags.set(17,1);
        let pending=sql.stage_character_save(&character,&user,session.revision).await.unwrap();
        // Deliver over the real encrypted transport, then deliberately omit
        // local acknowledgment cleanup. This is the exact post-commit/lost-ack
        // state that must survive both service and probe process restarts.
        let reply=sql.run_action(MasterShipAction::CommitAccountSnapshot {id:user.id,commit:pending.commit.clone()}).await.unwrap();
        assert!(matches!(reply,MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision:2,duplicate:false,..})));
        assert!(sql.pending_account_save(user.id).await.unwrap().is_some());
        std::fs::write(root.join("expected.json"),serde_json::to_vec(&serde_json::json!({
            "user_id":user.id,"character_id":id,"commit":pending.commit,"revision":2
        })).unwrap()).unwrap();
        println!("PAIR_PREPARE_OK: real master committed revision 2; exact local journal retained for restart");
    } else {
        let expected:serde_json::Value=serde_json::from_slice(&std::fs::read(root.join("expected.json")).unwrap()).unwrap();
        assert_eq!(user.id,expected["user_id"].as_u64().unwrap() as u32);
        assert_eq!(session.revision,2);assert_eq!(user.last_uuid,401);assert_eq!(user.accountflags.get(17),1);
        assert_eq!(session.storage.storage_meseta,98765);
        assert!(sql.pending_account_save(user.id).await.unwrap().is_none());
        let character=sql.session_character(&session,expected["character_id"].as_u64().unwrap() as u32).await.unwrap();
        assert_eq!(character.character.name,"paired recovery checkpoint");
        let commit=serde_json::from_value(expected["commit"].clone()).unwrap();
        let reply=sql.run_action(MasterShipAction::CommitAccountSnapshot {id:user.id,commit}).await.unwrap();
        assert!(matches!(reply,MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision:2,duplicate:true,..})));
        println!("PAIR_RECOVER_OK: restarted master/probe preserve character, flags, UUID, storage and duplicate receipt");
    }
    session.release();sql.connection.close().await;
}

#[tokio::test]
#[ignore = "requires a newly marked isolated runtime; prepare deliberately exits this test process with code 77"]
async fn local_checkpoint_process_crash_probe() {
    use sha2::Digest;
    use std::io::Write;
    use data_structs::master_ship::{AccountCommit,AccountState};

    fn payload_hash(commit: &AccountCommit) -> String {
        sha2::Sha256::digest(rmp_serde::to_vec(commit).unwrap())
            .iter().map(|byte| format!("{byte:02x}")).collect()
    }
    fn abrupt_exit(root: &std::path::Path,point: &str,commit: &AccountCommit) -> ! {
        let marker=serde_json::json!({"point":point,"commit_id":commit.commit_id,
            "expected_revision":commit.expected_revision,"payload_sha256":payload_hash(commit),"exit_code":77});
        let mut file=std::fs::File::create(root.join("crash-marker.json")).unwrap();
        file.write_all(&serde_json::to_vec(&marker).unwrap()).unwrap();file.sync_all().unwrap();
        println!("U026_ABRUPT_EXIT: {point}; committed local state preserved without Rust cleanup");
        std::io::stdout().flush().unwrap();
        // This is the explicitly launched, marked test helper only. No signal
        // or termination request is sent to a server or game client process.
        std::process::exit(77)
    }

    let root=std::path::PathBuf::from(std::env::var("PSO2_U026_PROBE_ROOT").expect("isolated root"))
        .canonicalize().unwrap();
    let normal=root.to_string_lossy().replace("\\\\?\\", "").to_ascii_lowercase();
    assert!(normal.starts_with("f:\\pso2classic\\setup\\m0-u026-crash-drill\\"));
    assert_eq!(std::fs::read_to_string(root.join(".isolated-u026")).unwrap(),"isolated U026 process recovery only\n");
    let phase=std::env::var("PSO2_U026_PROBE_PHASE").unwrap();assert!(matches!(phase.as_str(),"prepare"|"recover"));
    let scenario:serde_json::Value=serde_json::from_slice(&std::fs::read(root.join("scenario.json")).unwrap()).unwrap();
    let point=scenario["point"].as_str().unwrap();
    assert!(matches!(point,"head_staged"|"head_committed"|"final_deferred"|"successor_promoted"));
    let iteration=scenario["iteration"].as_u64().unwrap();assert!(iteration<10);
    let username=scenario["username"].as_str().unwrap();
    assert!(username.starts_with("u026_") && username.chars().all(|c|c.is_ascii_alphanumeric()||c=='_'));
    let address:std::net::SocketAddr=std::fs::read_to_string(root.join("probe-address.txt")).unwrap().trim().parse().unwrap();
    assert!(address.ip().is_loopback()&&address.port()>20000);
    let db=root.join("probe-ship.db");
    if phase=="prepare" {assert!(!db.exists());} else {assert!(db.exists());}
    let master=MasterConnection::new(address,b"isolated-u026-probe",root.join("hostkeys.toml").to_str().unwrap()).await.unwrap();
    let url=format!("sqlite://{}",db.to_string_lossy().replace("\\\\?\\", "").replace('\\',"/"));
    let mut sql=Sql::new(&url,master).await.unwrap();
    let mut user=sql.get_sega_user(username,"isolated_u026_password",Ipv4Addr::LOCALHOST).await.unwrap();
    if phase=="prepare" {
        let mut session=sql.open_account_session(&mut user).await.unwrap();assert_eq!(session.revision,0);
        session.storage.storage_meseta=900+iteration;
        let id=sql.create_session_character(&mut session,&mut user,CharData::default(),400+iteration).await.unwrap();
        assert_eq!(session.revision,1);
        let mut character=sql.session_character(&session,id).await.unwrap();
        character.character.name=format!("U026 head {iteration}");character.inventory.storages.storage_meseta=10000+iteration;
        character.play_time=Duration::from_secs(30);user.last_uuid=500+iteration;user.accountflags.set(17,1);
        let final_case=matches!(point,"final_deferred"|"successor_promoted");
        let expected=serde_json::json!({"user_id":user.id,"character_id":id,"point":point,
            "revision":if final_case {3}else{2},
            "name":if final_case {format!("U026 final {iteration}")}else{format!("U026 head {iteration}")},
            "storage_meseta":if final_case {20000+iteration}else{10000+iteration},
            "last_uuid":if final_case {600+iteration}else{500+iteration},
            "flag17":if final_case {0}else{1},"flag18":if final_case {1}else{0},
            "play_seconds":if final_case {45}else{30}});
        std::fs::write(root.join("expected.json"),serde_json::to_vec(&expected).unwrap()).unwrap();
        let (proxy,mut requests)=MasterConnection::channel_for_test();
        let wire=std::mem::replace(&mut sql.master_ship,proxy);
        let route=async {
            let (action,reply)=requests.recv().await.unwrap();
            let MasterShipAction::CommitAccountSnapshot {commit,..}=&action else {panic!("expected online head")};
            assert_eq!(commit.expected_revision,1);
            if point=="head_staged" {abrupt_exit(&root,point,commit);}
            let result=wire.run_action(action.clone()).await.unwrap();
            assert!(matches!(result,MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision:2,..})));
            if point=="head_committed" {abrupt_exit(&root,point,commit);}
            // Actual remote commit, intentionally withhold its reply from the
            // checkpoint API so the older immutable head remains unresolved.
            drop(reply);
        };
        let (result,())=tokio::join!(sql.checkpoint_session(&mut session,&character,&user),route);
        assert!(matches!(result,Err(Error::MSNoResponse)));
        character.character.name=format!("U026 final {iteration}");character.inventory.storages.storage_meseta=20000+iteration;
        character.play_time=Duration::from_secs(45);user.last_uuid=600+iteration;
        user.accountflags.set(17,0);user.accountflags.set(18,1);
        sql.defer_final_session(&session,&character,&user).await.unwrap();
        let head=sql.pending_account_save(user.id).await.unwrap().unwrap();
        if point=="final_deferred" {abrupt_exit(&root,point,&head.commit);}
        assert_eq!(point,"successor_promoted");
        let route=async {
            let (action,reply)=requests.recv().await.unwrap();
            let MasterShipAction::CommitAccountSnapshot {commit,..}=&action else {panic!("expected predecessor retry")};
            assert_eq!(commit.expected_revision,1);
            reply.send(wire.run_action(action).await.unwrap()).await.unwrap();
            let (action,_reply)=requests.recv().await.unwrap();
            let MasterShipAction::CommitAccountSnapshot {commit,..}=&action else {panic!("expected promoted successor")};
            assert_eq!(commit.expected_revision,2);
            abrupt_exit(&root,point,commit);
        };
        let _=tokio::join!(sql.recover_session_saves(user.id),route);
        panic!("prepare must terminate only at its requested durable boundary");
    } else {
        let expected:serde_json::Value=serde_json::from_slice(&std::fs::read(root.join("expected.json")).unwrap()).unwrap();
        let marker:serde_json::Value=serde_json::from_slice(&std::fs::read(root.join("crash-marker.json")).unwrap()).unwrap();
        assert_eq!(marker["point"],point);assert_eq!(marker["exit_code"],77);
        assert_eq!(user.id,expected["user_id"].as_u64().unwrap() as u32);
        let pending=sql.pending_account_save(user.id).await.unwrap().unwrap();
        assert_eq!(payload_hash(&pending.commit),marker["payload_sha256"].as_str().unwrap());
        let checks:Vec<String>=sqlx::query_scalar("PRAGMA integrity_check").fetch_all(&sql.connection).await.unwrap();assert_eq!(checks,vec!["ok"]);
        // Authentication loaded an earlier account view. Login recovery must
        // refresh the full snapshot before returning the lease.
        user.last_uuid=0;user.accountflags=Flags::default();
        let (proxy,mut requests)=MasterConnection::channel_for_test();let wire=std::mem::replace(&mut sql.master_ship,proxy);
        let route=async {
            let mut latest=None;
            loop {
                let (action,reply)=requests.recv().await.unwrap();
                let terminal=matches!(action,MasterShipAction::GetAccountState(_));
                if let MasterShipAction::CommitAccountSnapshot {commit,..}=&action {latest=Some(commit.clone());}
                reply.send(wire.run_action(action).await.unwrap()).await.unwrap();
                if terminal {return latest.expect("recovery must deliver the durable journal");}
            }
        };
        let (session,latest)=tokio::time::timeout(Duration::from_secs(10),async {
            tokio::join!(sql.open_account_session(&mut user),route)
        }).await.unwrap();let session=session.unwrap();
        assert_eq!(session.revision,expected["revision"].as_u64().unwrap());
        assert_eq!(user.last_uuid,expected["last_uuid"].as_u64().unwrap());
        assert_eq!(u64::from(user.accountflags.get(17)),expected["flag17"].as_u64().unwrap());
        assert_eq!(u64::from(user.accountflags.get(18)),expected["flag18"].as_u64().unwrap());
        let character=sql.session_character(&session,expected["character_id"].as_u64().unwrap() as u32).await.unwrap();
        assert_eq!(character.character.name,expected["name"].as_str().unwrap());
        assert_eq!(character.inventory.storages.storage_meseta,expected["storage_meseta"].as_u64().unwrap());
        assert_eq!(character.play_time.as_secs(),expected["play_seconds"].as_u64().unwrap());
        assert!(sql.pending_account_save(user.id).await.unwrap().is_none());
        let deferred:i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves WHERE UserId=?")
            .bind(user.id).fetch_one(&sql.connection).await.unwrap();assert_eq!(deferred,0);
        let reply=wire.run_action(MasterShipAction::CommitAccountSnapshot {id:user.id,commit:latest}).await.unwrap();
        assert!(matches!(reply,MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision,duplicate:true,..}) if revision==session.revision));
        let MasterShipAction::AccountState(AccountState {revision,..})=wire.run_action(MasterShipAction::GetAccountState(user.id)).await.unwrap() else {panic!()};
        assert_eq!(revision,session.revision);
        session.release();sql.connection.close().await;
        println!("U026_PROCESS_RECOVERY_OK: {point} iteration {iteration}; latest state and duplicate receipt verified");
    }
}
