use super::*;
use std::path::PathBuf;

const NOW: u64 = 1_600_000_000;
const DAY: u64 = 86_400;
type Snapshot = (Vec<(i64, Vec<u8>)>, Vec<(i64, Vec<u8>)>, Vec<(i64, i64, i64, i64)>);

async fn fixture() -> Sql {
    let sql = Sql::in_memory_for_test().await.unwrap();
    Sql::create_schema(&sql.connection).await.unwrap();
    sql.insert_local_user(1).await.unwrap();
    sql.insert_local_user(2).await.unwrap();
    sql
}

async fn new_character(sql: &Sql, owner: u32) -> u32 {
    let mut data = CharData::default();
    data.character.name = "Pending character".into();
    data.play_time = Duration::from_secs(12345);
    data.unlocked_quests = vec![71, 93];
    sql.put_character(owner, data).await.unwrap()
}

async fn snapshot(sql: &Sql) -> Snapshot {
    (
        sqlx::query_as("SELECT Id,Data FROM Users ORDER BY Id").fetch_all(&sql.connection).await.unwrap(),
        sqlx::query_as("SELECT Id,Data FROM Characters ORDER BY Id").fetch_all(&sql.connection).await.unwrap(),
        sqlx::query_as("SELECT CharacterId,OwnerId,RequestedAt,DeleteAfter FROM CharacterDeletions ORDER BY CharacterId")
            .fetch_all(&sql.connection).await.unwrap(),
    )
}

async fn fail_write(sql: &Sql, event: &str, table: &str, mode: &str) {
    let action = match mode {
        "abort" => "RAISE(ABORT, 'injected deletion failure')",
        "ignore" => "RAISE(IGNORE)",
        _ => panic!(),
    };
    sql.connection.execute(format!(
        "CREATE TRIGGER fail_deletion BEFORE {event} ON {table} BEGIN SELECT {action}; END",
    ).as_str()).await.unwrap();
}

async fn file_fixture() -> (Sql, PathBuf) {
    let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
    let path = std::env::temp_dir().join(format!("pso2-local-deletion-{}-{nonce}.sqlite", std::process::id()));
    let options = sqlx::sqlite::SqliteConnectOptions::new().filename(&path).create_if_missing(true)
        .busy_timeout(Duration::from_secs(3));
    let sql = Sql {
        connection: sqlx::sqlite::SqlitePoolOptions::new().max_connections(2).connect_with(options).await.unwrap(),
        master_ship: MasterConnection::disconnected_for_test(),
        sessions: Default::default(),
    };
    Sql::create_schema(&sql.connection).await.unwrap();
    sql.insert_local_user(1).await.unwrap();
    sql.insert_local_user(2).await.unwrap();
    (sql, path)
}

#[tokio::test]
async fn local_deletion_schedule_retry_and_clear_preserve_character_and_slot() {
    let sql = fixture().await;
    let id = new_character(&sql, 1).await;
    let original = snapshot(&sql).await;
    let pending = sql.schedule_character_deletion(1, id, NOW).await.unwrap();
    assert_eq!((pending.character_id, pending.requested_at, pending.delete_after), (id, NOW, NOW + DAY));
    let scheduled = snapshot(&sql).await;
    assert_eq!(original.0, scheduled.0);
    assert_eq!(original.1, scheduled.1);
    assert_eq!(sql.get_characters(1).await.unwrap().len(), 1);
    assert_eq!(sql.pending_character_deletions(1).await.unwrap(), vec![pending.clone()]);
    assert_eq!(sql.schedule_character_deletion(1, id, NOW + 60).await.unwrap(), pending);
    assert_eq!(snapshot(&sql).await, scheduled);
    assert!(sql.clear_pending_character_deletion(1, id).await.unwrap());
    assert_eq!(snapshot(&sql).await, original);
    assert!(!sql.clear_pending_character_deletion(1, id).await.unwrap());
    assert_eq!(snapshot(&sql).await, original);
}

#[tokio::test]
async fn local_deletion_finalization_obeys_24_hours_and_account_scope() {
    let sql = fixture().await;
    let a = new_character(&sql, 1).await;
    let b = new_character(&sql, 1).await;
    let other = new_character(&sql, 2).await;
    sql.schedule_character_deletion(1, a, NOW).await.unwrap();
    sql.schedule_character_deletion(1, b, NOW + 1).await.unwrap();
    sql.schedule_character_deletion(2, other, NOW).await.unwrap();
    let before = snapshot(&sql).await;
    for now in [0, NOW, NOW + DAY - 1] {
        assert!(sql.finalize_due_character_deletions(1, now).await.unwrap().is_empty());
        assert_eq!(snapshot(&sql).await, before);
    }
    assert_eq!(sql.finalize_due_character_deletions(1, NOW + DAY).await.unwrap(), vec![a]);
    let remaining = sql.get_characters(1).await.unwrap();
    assert_eq!(remaining.len(), 1); assert_eq!(remaining[0].character.character_id, b);
    assert!(sql.finalize_due_character_deletions(1, NOW + DAY).await.unwrap().is_empty());
    assert_eq!(sql.finalize_due_character_deletions(1, NOW + DAY + 1).await.unwrap(), vec![b]);
    assert!(sql.get_characters(1).await.unwrap().is_empty());
    assert_eq!(sql.get_characters(2).await.unwrap().len(), 1);
    assert_eq!(sql.pending_character_deletions(2).await.unwrap().len(), 1);
}

#[tokio::test]
async fn local_deletion_schedule_and_clear_reject_aborted_or_ignored_writes() {
    for mode in ["abort", "ignore"] {
        let sql = fixture().await;
        let id = new_character(&sql, 1).await;
        let before = snapshot(&sql).await;
        fail_write(&sql, "INSERT", "CharacterDeletions", mode).await;
        assert!(sql.schedule_character_deletion(1, id, NOW).await.is_err());
        assert_eq!(snapshot(&sql).await, before);
        sql.connection.execute("DROP TRIGGER fail_deletion").await.unwrap();
        sql.schedule_character_deletion(1, id, NOW).await.unwrap();
        let pending = snapshot(&sql).await;
        fail_write(&sql, "DELETE", "CharacterDeletions", mode).await;
        assert!(sql.clear_pending_character_deletion(1, id).await.is_err());
        assert_eq!(snapshot(&sql).await, pending);
        sql.connection.execute("DROP TRIGGER fail_deletion").await.unwrap();
        assert!(sql.clear_pending_character_deletion(1, id).await.unwrap());
        assert_eq!(snapshot(&sql).await, before);
    }
}

#[tokio::test]
async fn local_deletion_finalize_rolls_back_all_characters_on_late_failure() {
    for mode in ["abort", "ignore"] {
        for (event, table) in [("UPDATE", "Users"), ("DELETE", "CharacterDeletions")] {
            let sql = fixture().await;
            let a = new_character(&sql, 1).await;
            let b = new_character(&sql, 1).await;
            let other = new_character(&sql, 2).await;
            sql.schedule_character_deletion(1, a, NOW).await.unwrap();
            sql.schedule_character_deletion(1, b, NOW).await.unwrap();
            sql.schedule_character_deletion(2, other, NOW).await.unwrap();
            let before = snapshot(&sql).await;
            fail_write(&sql, event, table, mode).await;
            for _ in 0..2 {
                assert!(sql.finalize_due_character_deletions(1, NOW + DAY).await.is_err());
                assert_eq!(snapshot(&sql).await, before);
            }
            sql.connection.execute("DROP TRIGGER fail_deletion").await.unwrap();
            assert_eq!(sql.finalize_due_character_deletions(1, NOW + DAY).await.unwrap(), vec![a, b]);
            assert_eq!(sql.get_characters(2).await.unwrap().len(), 1);
        }
    }
}

#[tokio::test]
async fn local_deletion_wrong_owner_and_malformed_later_state_are_atomic() {
    let sql = fixture().await;
    let a = new_character(&sql, 1).await;
    let b = new_character(&sql, 1).await;
    let before = snapshot(&sql).await;
    assert!(sql.schedule_character_deletion(2, a, NOW).await.is_err());
    assert!(sql.clear_pending_character_deletion(2, a).await.is_err());
    assert!(sql.schedule_character_deletion(1, u32::MAX, NOW).await.is_err());
    assert_eq!(snapshot(&sql).await, before);
    sql.schedule_character_deletion(1, a, NOW).await.unwrap();
    sql.schedule_character_deletion(1, b, NOW).await.unwrap();
    // The later malformed row is discovered after processing a valid due row.
    sqlx::query("UPDATE CharacterDeletions SET DeleteAfter=DeleteAfter+1 WHERE CharacterId=?")
        .bind(b).execute(&sql.connection).await.unwrap();
    let malformed = snapshot(&sql).await;
    assert!(sql.pending_character_deletions(1).await.is_err());
    assert!(sql.schedule_character_deletion(1, b, NOW).await.is_err());
    assert!(sql.clear_pending_character_deletion(1, b).await.is_err());
    assert!(sql.finalize_due_character_deletions(1, NOW + DAY + 1).await.is_err());
    assert_eq!(snapshot(&sql).await, malformed);
    sqlx::query("UPDATE CharacterDeletions SET DeleteAfter=DeleteAfter-1,OwnerId=2 WHERE CharacterId=?")
        .bind(b).execute(&sql.connection).await.unwrap();
    let wrong_owner = snapshot(&sql).await;
    assert!(sql.schedule_character_deletion(1, b, NOW).await.is_err());
    assert!(sql.clear_pending_character_deletion(1, b).await.is_err());
    assert!(sql.delete_character(1, b).await.is_err());
    assert!(sql.finalize_due_character_deletions(2, NOW + DAY).await.is_err());
    assert_eq!(snapshot(&sql).await, wrong_owner);
}

#[tokio::test]
async fn local_deletion_time_overflow_is_rejected_and_immediate_delete_cleans_marker() {
    let sql = fixture().await;
    let id = new_character(&sql, 1).await;
    let before = snapshot(&sql).await;
    for now in [u64::MAX, i64::MAX as u64, i64::MAX as u64 - DAY + 1] {
        assert!(sql.schedule_character_deletion(1, id, now).await.is_err());
        assert_eq!(snapshot(&sql).await, before);
    }
    let pending = sql.schedule_character_deletion(1, id, i64::MAX as u64 - DAY).await.unwrap();
    assert_eq!(pending.delete_after, i64::MAX as u64);
    let scheduled = snapshot(&sql).await;
    assert!(sql.finalize_due_character_deletions(1, u64::MAX).await.is_err());
    assert_eq!(snapshot(&sql).await, scheduled);
    sql.delete_character(1, id).await.unwrap();
    assert!(sql.pending_character_deletions(1).await.unwrap().is_empty());
    assert!(sql.get_characters(1).await.unwrap().is_empty());
}

#[tokio::test]
async fn local_deletion_legacy_schema_upgrade_and_restart_preserve_data() {
    let (sql, path) = file_fixture().await;
    let id = new_character(&sql, 1).await;
    let original = snapshot(&sql).await;
    sql.connection.execute("DROP TABLE CharacterDeletions").await.unwrap();
    sql.connection.close().await;
    let url = format!("sqlite://{}", path.to_string_lossy().replace('\\', "/"));
    let sql = Sql::new(&url, MasterConnection::disconnected_for_test()).await.unwrap();
    assert_eq!(snapshot(&sql).await, original);
    let pending = sql.schedule_character_deletion(1, id, NOW).await.unwrap();
    let scheduled = snapshot(&sql).await;
    sql.connection.close().await;
    let sql = Sql::new(&url, MasterConnection::disconnected_for_test()).await.unwrap();
    assert_eq!(snapshot(&sql).await, scheduled);
    assert_eq!(sql.pending_character_deletions(1).await.unwrap(), vec![pending]);
    assert!(sql.finalize_due_character_deletions(1, NOW + DAY - 1).await.unwrap().is_empty());
    assert_eq!(sql.finalize_due_character_deletions(1, NOW + DAY).await.unwrap(), vec![id]);
    sql.connection.close().await;
    super::remove_test_db(&path).await;
}

#[tokio::test]
async fn local_deletion_concurrent_schedule_clear_and_finalize_have_one_outcome() {
    let (sql, path) = file_fixture().await;
    let id = new_character(&sql, 1).await;
    let (a, b) = tokio::join!(sql.schedule_character_deletion(1, id, NOW), sql.schedule_character_deletion(1, id, NOW + 1));
    let (a, b) = (a.unwrap(), b.unwrap());
    assert_eq!(a, b);
    assert_eq!(sql.pending_character_deletions(1).await.unwrap().len(), 1);
    // Storage-level serialization only: future UI policy must determine which
    // cancellation requests are valid before invoking the clear operation.
    let (clear, finalize) = tokio::join!(
        sql.clear_pending_character_deletion(1, id),
        sql.finalize_due_character_deletions(1, NOW + DAY + 1),
    );
    let finalized = finalize.unwrap();
    if finalized.is_empty() {
        assert!(clear.unwrap());
        assert_eq!(sql.get_characters(1).await.unwrap().len(), 1);
    } else {
        assert_eq!(finalized, vec![id]);
        assert!(clear.is_err());
        assert!(sql.get_characters(1).await.unwrap().is_empty());
    }
    assert!(sql.pending_character_deletions(1).await.unwrap().is_empty());
    sql.connection.close().await;
    super::remove_test_db(&path).await;
}
