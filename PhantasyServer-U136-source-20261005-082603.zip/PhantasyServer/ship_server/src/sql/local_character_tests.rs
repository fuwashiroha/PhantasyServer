use super::*;

async fn fixture() -> Sql {
    let sql=Sql::in_memory_for_test().await.unwrap();
    Sql::create_schema(&sql.connection).await.unwrap();
    sql.insert_local_user(1).await.unwrap();
    sql.insert_local_user(2).await.unwrap();
    sql
}

fn character(name: &str) -> CharData {
    let mut data=CharData::default();
    data.character.name=name.into();
    // Account membership must come from the authenticated API argument, not
    // arbitrary identity fields serialized in a creation packet.
    data.character.player_id=9999;
    data.character.character_id=9999;
    data
}

async fn ids(sql: &Sql, owner: u32) -> Vec<u32> {
    let mut connection=sql.connection.acquire().await.unwrap();
    Sql::read_userdata(&mut connection,owner).await.unwrap().character_ids
}

async fn count(sql: &Sql) -> i64 {
    sqlx::query_scalar("SELECT COUNT(*) FROM Characters").fetch_one(&sql.connection).await.unwrap()
}

async fn fail_membership(sql: &Sql, mode: &str) {
    let action=match mode {"abort"=>"RAISE(ABORT, 'injected membership failure')","ignore"=>"RAISE(IGNORE)",_=>panic!()};
    sql.connection.execute(format!("CREATE TRIGGER fail_membership BEFORE UPDATE OF Data ON Users WHEN NEW.Id=1 BEGIN SELECT {action}; END").as_str()).await.unwrap();
}

#[tokio::test]
async fn local_character_create_update_delete_preserves_account_membership() {
    let sql=fixture().await;
    sql.update_userdata(1,|u| {u.symbol_arts=vec![42,99];u.unlocked_quests=vec![123];}).await.unwrap();
    let a=sql.put_character(1,character("First")).await.unwrap();
    let b=sql.put_character(1,character("Second")).await.unwrap();
    let c=sql.put_character(2,character("Other")).await.unwrap();
    assert_eq!(ids(&sql,1).await,vec![a,b]);
    assert_eq!(ids(&sql,2).await,vec![c]);
    let mut saved=sql.load_owned_character(1,a).await.unwrap();
    assert_eq!((saved.character.player_id,saved.character.character_id),(1,a));
    saved.character.name="Renamed".into();
    sql.update_character(&saved).await.unwrap();
    assert_eq!(sql.load_owned_character(1,a).await.unwrap().character.name,saved.character.name);
    sql.delete_character(1,a).await.unwrap();
    assert_eq!(ids(&sql,1).await,vec![b]);
    assert_eq!(ids(&sql,2).await,vec![c]);
    assert_eq!(count(&sql).await,2);
    let list=sql.get_characters(1).await.unwrap();
    assert_eq!(list.len(),1);assert_eq!(list[0].character.character_id,b);
    let mut conn=sql.connection.acquire().await.unwrap();
    let owner=Sql::read_userdata(&mut conn,1).await.unwrap();
    assert_eq!(owner.symbol_arts,vec![42,99]);assert_eq!(owner.unlocked_quests,vec![123]);
}

#[tokio::test]
async fn local_character_create_rolls_back_insert_on_membership_failure() {
    for mode in ["abort","ignore"] {
        let sql=fixture().await;
        let original=sql.put_character(1,character("Original")).await.unwrap();
        fail_membership(&sql,mode).await;
        for _ in 0..2 {
            assert!(sql.put_character(1,character("Rejected")).await.is_err());
            assert_eq!(ids(&sql,1).await,vec![original]);
            assert_eq!(count(&sql).await,1);
        }
        sql.connection.execute("DROP TRIGGER fail_membership").await.unwrap();
        let next=sql.put_character(1,character("Retry")).await.unwrap();
        assert_ne!(next,original);assert_eq!(ids(&sql,1).await,vec![original,next]);
        assert_eq!(count(&sql).await,2);
    }
}

#[tokio::test]
async fn local_character_delete_rolls_back_row_on_membership_failure() {
    for mode in ["abort","ignore"] {
        let sql=fixture().await;
        let original=sql.put_character(1,character("Original")).await.unwrap();
        let before=sqlx::query_scalar::<_,Vec<u8>>("SELECT Data FROM Characters WHERE Id=?")
            .bind(original).fetch_one(&sql.connection).await.unwrap();
        fail_membership(&sql,mode).await;
        for _ in 0..2 {
            assert!(sql.delete_character(1,original).await.is_err());
            assert_eq!(ids(&sql,1).await,vec![original]);
            assert_eq!(count(&sql).await,1);
            let after=sqlx::query_scalar::<_,Vec<u8>>("SELECT Data FROM Characters WHERE Id=?")
                .bind(original).fetch_one(&sql.connection).await.unwrap();
            assert_eq!(before,after);
        }
        sql.connection.execute("DROP TRIGGER fail_membership").await.unwrap();
        sql.delete_character(1,original).await.unwrap();
        assert!(ids(&sql,1).await.is_empty());assert_eq!(count(&sql).await,0);
    }
}

#[tokio::test]
async fn local_character_other_account_cannot_read_update_or_delete() {
    let sql=fixture().await;
    let original=sql.put_character(1,character("Owner")).await.unwrap();
    assert!(matches!(sql.get_character(2,original).await,Err(Error::InvalidInput("character_ownership"))));
    assert!(matches!(sql.delete_character(2,original).await,Err(Error::InvalidInput("character_ownership"))));
    let mut forged=sql.load_owned_character(1,original).await.unwrap();
    forged.character.player_id=2;forged.character.name="Wrong account".into();
    assert!(matches!(sql.update_character(&forged).await,Err(Error::InvalidInput("character_ownership"))));
    assert_eq!(sql.load_owned_character(1,original).await.unwrap().character.name,character("Owner").character.name);
    assert_eq!(ids(&sql,1).await,vec![original]);assert!(ids(&sql,2).await.is_empty());
    sql.delete_character(1,original).await.unwrap();
    assert!(sql.delete_character(1,original).await.is_err());
    assert_eq!(count(&sql).await,0);
}

#[tokio::test]
async fn local_character_missing_corrupt_owner_and_id_overflow_leave_no_orphans() {
    let sql=fixture().await;
    assert!(sql.put_character(99,character("Missing")).await.is_err());
    assert_eq!(count(&sql).await,0);
    sqlx::query("UPDATE Users SET Data=? WHERE Id=1").bind(vec![0xc1u8]).execute(&sql.connection).await.unwrap();
    assert!(sql.put_character(1,character("Corrupt")).await.is_err());
    assert_eq!(count(&sql).await,0);
    let original=sql.put_character(2,character("Before overflow")).await.unwrap();
    sqlx::query("UPDATE sqlite_sequence SET seq=? WHERE name='Characters'")
        .bind(i64::from(u32::MAX)).execute(&sql.connection).await.unwrap();
    assert!(matches!(sql.put_character(2,character("Overflow")).await,Err(Error::InvalidInput("character_id_range"))));
    assert_eq!(count(&sql).await,1);assert_eq!(ids(&sql,2).await,vec![original]);
}

#[tokio::test]
async fn local_character_two_database_connections_preserve_both_creations() {
    // Two writers on a private temporary DB exercise SQLite locking as well as
    // membership preservation. This is neither the live DB nor a stress test.
    let nonce=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
    let path=std::env::temp_dir().join(format!("pso2-local-character-{}-{nonce}.sqlite",std::process::id()));
    let options=sqlx::sqlite::SqliteConnectOptions::new().filename(&path).create_if_missing(true)
        .busy_timeout(Duration::from_secs(3));
    let sql=Sql {connection:sqlx::sqlite::SqlitePoolOptions::new().max_connections(2).connect_with(options).await.unwrap(),
        master_ship:MasterConnection::disconnected_for_test(),sessions:Default::default()};
    Sql::create_schema(&sql.connection).await.unwrap();sql.insert_local_user(1).await.unwrap();
    let (a,b)=tokio::join!(sql.put_character(1,character("Concurrent A")),sql.put_character(1,character("Concurrent B")));
    let (a,b)=(a.unwrap(),b.unwrap());assert_ne!(a,b);
    let mut list=ids(&sql,1).await;list.sort();let mut expected=vec![a,b];expected.sort();assert_eq!(list,expected);
    assert_eq!(count(&sql).await,2);
    let (a,b)=tokio::join!(sql.delete_character(1,a),sql.delete_character(1,b));a.unwrap();b.unwrap();
    assert!(ids(&sql,1).await.is_empty());assert_eq!(count(&sql).await,0);
    sql.connection.close().await;
    super::remove_test_db(&path).await;
}
