use super::*;
use std::{collections::HashMap, sync::Arc};
use tokio::sync::{Mutex, OwnedMutexGuard};

// These limits are server scheduling policy, not original game parameters.
const ACCOUNT_WAIT: Duration = Duration::from_secs(15);

#[derive(Default)]
pub(super) struct Sessions {
    accounts: parking_lot::Mutex<HashMap<u32, Arc<Mutex<bool>>>>,
    saves: parking_lot::Mutex<tokio::task::JoinSet<()>>,
    save_failed: std::sync::atomic::AtomicBool,
}

pub(crate) struct AccountSession {
    pub id: u32,
    pub revision: u64,
    pub storage: AccountStorages,
    pub(super) checkpoint: Option<super::checkpoint::SessionCheckpoint>,
    guard: OwnedMutexGuard<bool>,
}

impl AccountSession {
    // An unexpected drop leaves the gate fenced. Only a durable save (or a
    // session with no unsaved character) may explicitly release it.
    pub fn release(mut self) { *self.guard = false; }
}

impl Sessions {
    async fn lock(&self, id: u32) -> Result<OwnedMutexGuard<bool>, Error> {
        let account = {
            let mut accounts = self.accounts.lock();
            accounts.retain(|_, value| Arc::strong_count(value) != 1
                || value.try_lock().map(|guard| *guard).unwrap_or(true));
            match accounts.get(&id) {
                Some(account) => account.clone(),
                None => {
                    let account = Arc::new(Mutex::new(false));
                    accounts.insert(id, account.clone());
                    account
                }
            }
        };
        let guard = account.lock_owned().await;
        if *guard { return Err(Error::InvalidInput("account_session_fenced")); }
        Ok(guard)
    }
}

impl Sql {
    pub async fn open_account_session(&self, user: &mut User) -> Result<AccountSession, Error> {
        tokio::time::timeout(ACCOUNT_WAIT, async {
            let mut guard = self.sessions.lock(user.id).await?;
            // Authentication may have loaded stale flags/UUID before waiting.
            // Resolve the previous delivery, then refresh all three together.
            self.recover_session_saves(user.id).await?;
            let state = self.load_account_state(user.id).await?;
            if state.revision >= i64::MAX as u64 {
                return Err(Error::InvalidInput("account_revision_exhausted"));
            }
            user.accountflags = state.snapshot.flags;
            user.last_uuid = state.snapshot.last_uuid;
            *guard = true;
            Ok(AccountSession {id: user.id, revision: state.revision,
                storage: state.snapshot.storage, checkpoint: None, guard})
        }).await.map_err(|_| Error::InvalidInput("account_session_busy_or_unavailable"))?
    }

    pub async fn session_character(&self, session: &AccountSession, id: u32) -> Result<CharData, Error> {
        let mut character = self.load_owned_character(session.id, id).await?;
        character.inventory.storages = session.storage.clone();
        Ok(character)
    }

    pub fn track_save(&self, future: impl std::future::Future<Output=()> + Send + 'static) {
        let mut saves = self.sessions.saves.lock();
        while let Some(result) = saves.try_join_next() {
            if let Err(e) = result {
                self.sessions.save_failed.store(true, std::sync::atomic::Ordering::Relaxed);
                log::error!("Session cleanup task failed: {e}");
            }
        }
        saves.spawn(future);
    }

    // Call only after connection tasks stop producing saves.
    pub async fn drain_session_saves(&self) -> Result<(), Error> {
        loop {
            let mut saves = std::mem::take(&mut *self.sessions.saves.lock());
            if saves.is_empty() { break; }
            while let Some(result) = saves.join_next().await {
                if let Err(e) = result {
                    self.sessions.save_failed.store(true, std::sync::atomic::Ordering::Relaxed);
                    log::error!("Session cleanup task failed during drain: {e}");
                }
            }
        }
        if self.sessions.save_failed.load(std::sync::atomic::Ordering::Relaxed) {
            return Err(Error::InvalidInput("session_cleanup_failed"));
        }
        Ok(())
    }

    pub(crate) fn record_session_save_failure(&self, reason: &str) {
        self.sessions.save_failed.store(true, std::sync::atomic::Ordering::Relaxed);
        log::error!("Session persistence failure: {reason}");
    }

    pub async fn persist_session(&self, session: &mut AccountSession, character: &CharData, user: &User) {
        loop {
            let failure = match tokio::time::timeout(ACCOUNT_WAIT,
                self.checkpoint_session(session, character, user)).await {
                Ok(Ok(())) => return,
                Ok(Err(e)) => e.to_string(),
                Err(_) => "checkpoint delivery timed out".to_owned(),
            };
            // A previous online snapshot may still await its exact receipt.
            // Durably retain the final successor without waiting on the remote.
            match self.defer_final_session(session, character, user).await {
                Ok(()) => {
                    log::warn!("Account {} final snapshot is locally durable and awaits ordered recovery: {failure}", session.id);
                    return;
                },
                Err(e) => {
                    log::error!("Final save not durable for account {}; retaining lease and retrying: {e}; previous delivery: {failure}", session.id);
                    tokio::time::sleep(Duration::from_secs(2)).await;
                },
            }
        }
    }
}
