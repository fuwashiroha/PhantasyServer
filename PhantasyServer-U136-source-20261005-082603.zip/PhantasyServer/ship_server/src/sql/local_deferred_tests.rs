use super::*;
use super::local_checkpoint_tests::{fixture,fixture_with_sql,ack,Requests};
use data_structs::master_ship::{AccountCommit,AccountCommitResult,AccountState};

async fn prepare(input: (Sql,Requests,AccountSession,CharData,User))
    -> (Sql,Requests,AccountSession,CharData,User,AccountCommit) {
    let (sql,mut requests,mut session,mut char,mut user)=input;
    char.character.name="older online checkpoint".into();char.inventory.storages.storage_meseta=111;user.last_uuid=11;
    let lose=async {let (action,send)=requests.recv().await.unwrap();drop(send);
        let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};commit};
    let (result,head)=tokio::join!(sql.checkpoint_session(&mut session,&char,&user),lose);assert!(result.is_err());
    char.character.name="newest final snapshot".into();char.inventory.storages.storage_meseta=222;
    char.play_time=Duration::from_secs(67);user.last_uuid=12;user.accountflags.set(17,1);
    (sql,requests,session,char,user,head)
}

async fn deferred_bytes(sql: &Sql) -> Vec<u8> {
    sqlx::query_scalar("SELECT Data FROM DeferredSessionSaves WHERE UserId=1").fetch_one(&sql.connection).await.unwrap()
}

async fn assert_latest(sql: &Sql, session: &AccountSession, user: &User, id: u32) {
    assert_eq!(session.revision,2);assert_eq!(user.last_uuid,12);assert_eq!(user.accountflags.get(17),1);
    let char=sql.session_character(session,id).await.unwrap();
    assert_eq!(char.character.name,"newest final snapshot");assert_eq!(char.play_time,Duration::from_secs(67));
    assert_eq!(char.inventory.storages.storage_meseta,222);
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    let count:i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves").fetch_one(&sql.connection).await.unwrap();assert_eq!(count,0);
}

async fn final_ack_and_state(requests: &mut Requests, duplicate: bool) -> AccountCommit {
    let commit=ack(requests,1,duplicate).await;
    let (action,send)=requests.recv().await.unwrap();assert!(matches!(action,MasterShipAction::GetAccountState(1)));
    send.send(MasterShipAction::AccountState(AccountState {revision:2,snapshot:commit.snapshot.clone()})).await.unwrap();commit
}

#[tokio::test]
async fn local_deferred_offline_final_is_immutable_and_login_delivers_both_revisions() {
    let (sql,mut requests,session,char,user,head)=prepare(fixture().await).await;
    sql.defer_final_session(&session,&char,&user).await.unwrap();let bytes=deferred_bytes(&sql).await;
    assert!(requests.try_recv().is_err());
    assert_eq!(sql.load_owned_character(1,char.character.character_id).await.unwrap().character.name,"older online checkpoint");
    sql.defer_final_session(&session,&char,&user).await.unwrap();assert_eq!(deferred_bytes(&sql).await,bytes);
    let mut different=char.clone();different.character.name="must not replace final".into();
    assert!(sql.defer_final_session(&session,&different,&user).await.is_err());assert_eq!(deferred_bytes(&sql).await,bytes);
    session.release();let mut stale=User {id:1,..Default::default()};
    let serve=async {let retry=ack(&mut requests,0,true).await;assert_eq!(retry.commit_id,head.commit_id);final_ack_and_state(&mut requests,false).await};
    let (session,next)=tokio::join!(sql.open_account_session(&mut stale),serve);let session=session.unwrap();
    assert_ne!(next.commit_id,head.commit_id);assert_latest(&sql,&session,&stale,char.character.character_id).await;session.release();
}

#[tokio::test]
async fn local_deferred_promotion_aborted_or_ignored_writes_roll_back_all_three_records() {
    for (table,event) in [("Characters","UPDATE"),("PendingAccountSaves","INSERT"),("DeferredSessionSaves","DELETE")] {
        for fault in ["RAISE(ABORT,'injected')","RAISE(IGNORE)"] {
            let (sql,mut requests,session,char,user,_)=prepare(fixture().await).await;
            sql.defer_final_session(&session,&char,&user).await.unwrap();session.release();let bytes=deferred_bytes(&sql).await;
            let (result,_)=tokio::join!(sql.deliver_pending_account_save(1),ack(&mut requests,0,true));result.unwrap();
            sql.connection.execute(format!("CREATE TRIGGER fail_promote BEFORE {event} ON {table} BEGIN SELECT {fault}; END").as_str()).await.unwrap();
            assert!(sql.recover_session_saves(1).await.is_err());assert!(requests.try_recv().is_err());
            assert_eq!(deferred_bytes(&sql).await,bytes);assert!(sql.pending_account_save(1).await.unwrap().is_none());
            assert_eq!(sql.load_owned_character(1,char.character.character_id).await.unwrap().character.name,"older online checkpoint");
            sql.connection.execute("DROP TRIGGER fail_promote").await.unwrap();
            let mut stale=User {id:1,..Default::default()};
            let (session,_)=tokio::join!(sql.open_account_session(&mut stale),final_ack_and_state(&mut requests,false));let session=session.unwrap();
            assert_latest(&sql,&session,&stale,char.character.character_id).await;session.release();
        }
    }
}

#[tokio::test]
async fn local_deferred_lost_replies_keep_head_then_promoted_successor_for_exact_retry() {
    let (sql,mut requests,session,char,user,head)=prepare(fixture().await).await;
    sql.defer_final_session(&session,&char,&user).await.unwrap();session.release();let bytes=deferred_bytes(&sql).await;
    let lose=async {let (_,send)=requests.recv().await.unwrap();drop(send);};
    let (result,())=tokio::join!(sql.recover_session_saves(1),lose);assert!(result.is_err());
    assert_eq!(deferred_bytes(&sql).await,bytes);assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,head.commit_id);
    let lose_next=async {
        ack(&mut requests,0,true).await;
        let (action,send)=requests.recv().await.unwrap();drop(send);let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};commit
    };
    let (result,next)=tokio::join!(sql.recover_session_saves(1),lose_next);assert!(result.is_err());assert_eq!(next.expected_revision,1);
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,next.commit_id);
    let count:i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves").fetch_one(&sql.connection).await.unwrap();assert_eq!(count,0);
    let mut stale=User {id:1,..Default::default()};
    let (session,retry)=tokio::join!(sql.open_account_session(&mut stale),final_ack_and_state(&mut requests,true));
    assert_eq!(rmp_serde::to_vec(&retry).unwrap(),rmp_serde::to_vec(&next).unwrap());let session=session.unwrap();
    assert_latest(&sql,&session,&stale,char.character.character_id).await;session.release();
}

#[tokio::test]
async fn local_deferred_remote_conflict_prevents_login_and_never_rebases_successor() {
    let (sql,mut requests,session,char,user,_)=prepare(fixture().await).await;
    sql.defer_final_session(&session,&char,&user).await.unwrap();session.release();
    let serve=async {
        ack(&mut requests,0,true).await;
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
        assert_eq!(commit.expected_revision,1);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Conflict {revision:9})).await.unwrap();commit
    };
    let mut stale=User {id:1,last_uuid:3,..Default::default()};
    let (result,commit)=tokio::join!(sql.open_account_session(&mut stale),serve);assert!(result.is_err());
    assert_eq!(stale.last_uuid,3);assert!(requests.try_recv().is_err());
    assert_eq!(rmp_serde::to_vec(&sql.pending_account_save(1).await.unwrap().unwrap().commit).unwrap(),rmp_serde::to_vec(&commit).unwrap());
}

#[tokio::test]
async fn local_deferred_corruption_owner_and_predecessor_mismatch_fail_before_delivery() {
    let (sql,mut requests,session,char,user,head)=prepare(fixture().await).await;
    sql.defer_final_session(&session,&char,&user).await.unwrap();session.release();let bytes=deferred_bytes(&sql).await;
    sql.connection.execute("UPDATE DeferredSessionSaves SET UserId=2 WHERE UserId=1").await.unwrap();
    assert!(sql.recover_session_saves(2).await.is_err());assert!(requests.try_recv().is_err());
    sql.connection.execute("UPDATE DeferredSessionSaves SET UserId=1 WHERE UserId=2").await.unwrap();
    sqlx::query("UPDATE DeferredSessionSaves SET Data=? WHERE UserId=1").bind(vec![0xc1u8]).execute(&sql.connection).await.unwrap();
    assert!(sql.recover_session_saves(1).await.is_err());assert!(requests.try_recv().is_err());
    sqlx::query("UPDATE DeferredSessionSaves SET Data=? WHERE UserId=1").bind(bytes).execute(&sql.connection).await.unwrap();
    let mut foreign=head.clone();foreign.commit_id=[4;16];
    sqlx::query("UPDATE PendingAccountSaves SET CommitId=?,Data=? WHERE UserId=1")
        .bind(foreign.commit_id.as_slice()).bind(rmp_serde::to_vec(&foreign).unwrap()).execute(&sql.connection).await.unwrap();
    assert!(sql.recover_session_saves(1).await.is_err());assert!(requests.try_recv().is_err());
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,[4;16]);
    // A structurally valid change with the same identity/revision must also
    // fail before any remote write, not only a damaged MessagePack record.
    let mut modified=head;modified.snapshot.last_uuid+=100;
    sqlx::query("UPDATE PendingAccountSaves SET CommitId=?,Data=? WHERE UserId=1")
        .bind(modified.commit_id.as_slice()).bind(rmp_serde::to_vec(&modified).unwrap()).execute(&sql.connection).await.unwrap();
    assert!(sql.recover_session_saves(1).await.is_err());assert!(requests.try_recv().is_err());
}

#[tokio::test]
async fn local_deferred_failed_final_insert_preserves_head_and_can_retry() {
    for fault in ["RAISE(ABORT,'injected')","RAISE(IGNORE)"] {
        let (sql,mut requests,session,char,user,head)=prepare(fixture().await).await;
        sql.connection.execute(format!("CREATE TRIGGER fail_defer BEFORE INSERT ON DeferredSessionSaves BEGIN SELECT {fault}; END").as_str()).await.unwrap();
        assert!(sql.defer_final_session(&session,&char,&user).await.is_err());
        let count:i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves").fetch_one(&sql.connection).await.unwrap();assert_eq!(count,0);
        assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,head.commit_id);assert!(requests.try_recv().is_err());
        sql.connection.execute("DROP TRIGGER fail_defer").await.unwrap();sql.defer_final_session(&session,&char,&user).await.unwrap();
        assert!(!deferred_bytes(&sql).await.is_empty());session.release();
    }
}

#[tokio::test]
async fn local_deferred_rejects_other_account_or_character_without_writing_successor() {
    let (sql,mut requests,session,char,user,head)=prepare(fixture().await).await;
    let mut other_user=user.clone();other_user.id=2;
    assert!(sql.defer_final_session(&session,&char,&other_user).await.is_err());
    let mut other_char=char.clone();other_char.character.player_id=2;
    assert!(sql.defer_final_session(&session,&other_char,&user).await.is_err());
    other_char=char.clone();other_char.character.character_id=sql.put_character(1,CharData::default()).await.unwrap();
    assert!(sql.defer_final_session(&session,&other_char,&user).await.is_err());
    let count:i64=sqlx::query_scalar("SELECT COUNT(*) FROM DeferredSessionSaves").fetch_one(&sql.connection).await.unwrap();assert_eq!(count,0);
    assert_eq!(sql.pending_account_save(1).await.unwrap().unwrap().commit.commit_id,head.commit_id);
    assert!(requests.try_recv().is_err());session.release();
}

#[tokio::test]
async fn local_deferred_schema_upgrade_and_file_reopen_preserve_latest_final_snapshot() {
    let path=std::env::temp_dir().join(format!("pso2-u026-deferred-{}-{}.db",std::process::id(),rand::random::<u64>()));
    let url=format!("sqlite:{}",path.display());
    let sql=Sql::new(&url,MasterConnection::disconnected_for_test()).await.unwrap();
    sql.connection.execute("DROP TABLE DeferredSessionSaves").await.unwrap();sql.connection.close().await;drop(sql);
    let sql=Sql::new(&url,MasterConnection::disconnected_for_test()).await.unwrap();
    let (sql,_,session,char,user,head)=prepare(fixture_with_sql(sql).await).await;
    sql.defer_final_session(&session,&char,&user).await.unwrap();let exact=deferred_bytes(&sql).await;
    drop(session);sql.connection.close().await;drop(sql);
    let (master,mut requests)=MasterConnection::channel_for_test();let sql=Sql::new(&url,master).await.unwrap();
    assert_eq!(deferred_bytes(&sql).await,exact);
    let mut stale=User {id:1,..Default::default()};
    let serve=async {let retry=ack(&mut requests,0,true).await;assert_eq!(retry.commit_id,head.commit_id);final_ack_and_state(&mut requests,false).await};
    let (session,_)=tokio::join!(sql.open_account_session(&mut stale),serve);let session=session.unwrap();
    assert_latest(&sql,&session,&stale,char.character.character_id).await;session.release();
    sql.connection.close().await;super::remove_test_db(&path).await;
}
