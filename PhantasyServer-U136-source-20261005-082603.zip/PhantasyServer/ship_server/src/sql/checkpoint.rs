//! Ordered online snapshots. The owner keeps this state across cancellation;
//! no checkpoint may replace an unresolved earlier journal entry.
use super::*;
use super::save_journal::PendingAccountSave;
use data_structs::master_ship::{AccountCommit, AccountCommitResult, AccountSnapshot};

pub(super) struct SessionCheckpoint {
    pub(super) pending: PendingAccountSave,
    character_id: u32,
    character: Vec<u8>,
    snapshot: Vec<u8>,
    durable: bool,
}

// Only a disconnected session writes a deferred successor. Its full latest
// snapshot is durable even if the older remote commit cannot currently finish.
#[derive(serde::Serialize, serde::Deserialize)]
struct DeferredSessionSave {
    user_id: u32,
    predecessor_id: [u8; 16],
    predecessor_revision: u64,
    predecessor_payload: Vec<u8>,
    character_id: u32,
    character: Vec<u8>,
    commit: AccountCommit,
}

impl DeferredSessionSave {
    fn decode(id: u32, bytes: &[u8]) -> Result<Self, Error> {
        let saved: Self = rmp_serde::from_slice(bytes)?;
        let predecessor: AccountCommit = rmp_serde::from_slice(&saved.predecessor_payload)?;
        let character: CharData = rmp_serde::from_slice(&saved.character)?;
        if saved.user_id != id || character.character.player_id != id
            || character.character.character_id != saved.character_id
            || saved.predecessor_revision.checked_add(1) != Some(saved.commit.expected_revision)
            || saved.commit.expected_revision >= i64::MAX as u64
            || saved.predecessor_id == saved.commit.commit_id
            || predecessor.commit_id != saved.predecessor_id
            || predecessor.expected_revision != saved.predecessor_revision {
            return Err(Error::InvalidInput("deferred_save_identity_or_revision"));
        }
        Ok(saved)
    }
}

impl SessionCheckpoint {
    fn prepare(session: &AccountSession, character: &CharData, user: &User) -> Result<Self, Error> {
        if session.id != user.id || character.character.player_id != user.id
            || session.revision >= i64::MAX as u64 {
            return Err(Error::InvalidInput("checkpoint_identity_or_revision"));
        }
        let snapshot = AccountSnapshot {storage: character.inventory.storages.clone(),
            flags: user.accountflags.clone(), last_uuid: user.last_uuid};
        let encoded_snapshot = rmp_serde::to_vec(&snapshot)?;
        let commit = AccountCommit {commit_id: rand::random(), expected_revision: session.revision, snapshot};
        let payload = rmp_serde::to_vec(&commit)?;
        Ok(Self {pending: PendingAccountSave {user_id: user.id, commit, payload},
            character_id: character.character.character_id, character: rmp_serde::to_vec(character)?,
            snapshot: encoded_snapshot, durable: false})
    }

    fn matches(&self, character: &CharData, user: &User) -> Result<bool, Error> {
        let snapshot = AccountSnapshot {storage: character.inventory.storages.clone(),
            flags: user.accountflags.clone(), last_uuid: user.last_uuid};
        Ok(self.pending.user_id == user.id && character.character.player_id == user.id
            && self.character_id == character.character.character_id
            && self.character == rmp_serde::to_vec(character)?
            && self.snapshot == rmp_serde::to_vec(&snapshot)?)
    }
}

impl Sql {
    pub(super) async fn create_deferred_schema(conn: &sqlx::SqlitePool) -> Result<(), Error> {
        conn.execute("CREATE TABLE IF NOT EXISTS DeferredSessionSaves (
            UserId INTEGER PRIMARY KEY,
            Data BLOB NOT NULL
        )").await?;
        Ok(())
    }

    /// Persist the immutable final snapshot behind the outstanding checkpoint.
    /// Called only after online activity and its checkpoint worker have stopped.
    pub async fn defer_final_session(&self, session: &AccountSession,
        character: &CharData, user: &User) -> Result<(), Error> {
        let latest = SessionCheckpoint::prepare(session, character, user)?;
        let head = session.checkpoint.as_ref().ok_or(Error::InvalidInput("deferred_head_missing"))?;
        if head.pending.user_id != session.id || head.pending.commit.expected_revision != session.revision
            || latest.character_id != head.character_id {
            return Err(Error::InvalidInput("deferred_session_mismatch"));
        }
        // Also resolves an uncertain local COMMIT or cleanup cancellation.
        self.stage_checkpoint(head).await?;
        if head.matches(character, user)? {
            let deferred: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM DeferredSessionSaves WHERE UserId=?)")
                .bind(user.id).fetch_one(&self.connection).await?;
            if deferred {return Err(Error::InvalidInput("deferred_final_snapshot_replaced"));}
            return Ok(());
        }
        let mut commit = latest.pending.commit;
        commit.expected_revision = session.revision.checked_add(1).ok_or(Error::InvalidInput("deferred_revision_exhausted"))?;
        if commit.expected_revision >= i64::MAX as u64 {return Err(Error::InvalidInput("deferred_revision_exhausted"));}
        while commit.commit_id == head.pending.commit.commit_id {commit.commit_id = rand::random();}
        let deferred = DeferredSessionSave {user_id: user.id, predecessor_id: head.pending.commit.commit_id,
            predecessor_revision: session.revision, predecessor_payload: head.pending.payload.clone(),
            character_id: latest.character_id, character: latest.character, commit};
        let payload = rmp_serde::to_vec(&deferred)?;
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner = Self::read_userdata(&mut transaction, user.id).await?;
        Self::require_character_owner(&owner, deferred.character_id)?;
        let pending = sqlx::query("SELECT CommitId,Data FROM PendingAccountSaves WHERE UserId=?")
            .bind(user.id).fetch_optional(&mut *transaction).await?;
        if let Some(pending) = pending {
            if pending.try_get::<Vec<u8>, _>("CommitId")? != head.pending.commit.commit_id
                || pending.try_get::<Vec<u8>, _>("Data")? != head.pending.payload {
                return Err(Error::InvalidInput("deferred_head_replaced"));
            }
        }
        // A canceled matching ack may have deleted the head; the immutable
        // successor still requires precisely predecessor_revision + 1 remotely.
        let current: Vec<u8> = sqlx::query_scalar("SELECT Data FROM Characters WHERE Id=?")
            .bind(head.character_id).fetch_one(&mut *transaction).await?;
        if current != head.character {return Err(Error::InvalidInput("deferred_character_changed"));}
        let existing: Option<Vec<u8>> = sqlx::query_scalar("SELECT Data FROM DeferredSessionSaves WHERE UserId=?")
            .bind(user.id).fetch_optional(&mut *transaction).await?;
        if let Some(existing) = existing {
            let saved = DeferredSessionSave::decode(user.id, &existing)?;
            if saved.predecessor_id != deferred.predecessor_id || saved.predecessor_revision != deferred.predecessor_revision
                || saved.predecessor_payload != deferred.predecessor_payload
                || saved.character_id != deferred.character_id || saved.character != deferred.character
                || rmp_serde::to_vec(&saved.commit.snapshot)? != rmp_serde::to_vec(&deferred.commit.snapshot)? {
                return Err(Error::InvalidInput("deferred_final_snapshot_replaced"));
            }
            // Idempotent retry after an uncertain commit: retain the saved token.
        } else {
            let changed = sqlx::query("INSERT INTO DeferredSessionSaves (UserId,Data) VALUES (?,?)")
                .bind(user.id).bind(payload).execute(&mut *transaction).await?;
            if changed.rows_affected() != 1 {return Err(Error::InvalidInput("deferred_save_ignored"));}
        }
        transaction.commit().await?;
        Ok(())
    }

    async fn promote_deferred_session(&self, id: u32) -> Result<(), Error> {
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let row: Option<Vec<u8>> = sqlx::query_scalar("SELECT Data FROM DeferredSessionSaves WHERE UserId=?")
            .bind(id).fetch_optional(&mut *transaction).await?;
        let Some(bytes) = row else {return Ok(());};
        let deferred = DeferredSessionSave::decode(id, &bytes)?;
        let owner = Self::read_userdata(&mut transaction, id).await?;
        Self::require_character_owner(&owner, deferred.character_id)?;
        let pending: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM PendingAccountSaves WHERE UserId=?)")
            .bind(id).fetch_one(&mut *transaction).await?;
        if pending {return Err(Error::InvalidInput("deferred_predecessor_pending"));}
        let changed = sqlx::query("UPDATE Characters SET Data=? WHERE Id=?")
            .bind(&deferred.character).bind(deferred.character_id).execute(&mut *transaction).await?;
        if changed.rows_affected() != 1 {return Err(Error::InvalidInput("deferred_character_missing"));}
        let queued = sqlx::query("INSERT INTO PendingAccountSaves (UserId,CommitId,Data) VALUES (?,?,?)")
            .bind(id).bind(deferred.commit.commit_id.as_slice()).bind(rmp_serde::to_vec(&deferred.commit)?)
            .execute(&mut *transaction).await?;
        if queued.rows_affected() != 1 {return Err(Error::InvalidInput("deferred_promotion_ignored"));}
        let removed = sqlx::query("DELETE FROM DeferredSessionSaves WHERE UserId=? AND Data=?")
            .bind(id).bind(bytes).execute(&mut *transaction).await?;
        if removed.rows_affected() != 1 {return Err(Error::InvalidInput("deferred_removal_ignored"));}
        transaction.commit().await?;
        Ok(())
    }

    pub(super) async fn recover_session_saves(&self, id: u32) -> Result<(), Error> {
        let row: Option<Vec<u8>> = sqlx::query_scalar("SELECT Data FROM DeferredSessionSaves WHERE UserId=?")
            .bind(id).fetch_optional(&self.connection).await?;
        if let Some(bytes) = row {
            let deferred = DeferredSessionSave::decode(id, &bytes)?;
            if let Some(pending) = self.pending_account_save(id).await? {
                if pending.commit.commit_id != deferred.predecessor_id
                    || pending.commit.expected_revision != deferred.predecessor_revision
                    || pending.payload != deferred.predecessor_payload {
                    return Err(Error::InvalidInput("deferred_predecessor_mismatch"));
                }
            }
        }
        self.deliver_pending_account_save(id).await?;
        self.promote_deferred_session(id).await?;
        self.deliver_pending_account_save(id).await?;
        Ok(())
    }

    async fn stage_checkpoint(&self, checkpoint: &SessionCheckpoint) -> Result<(), Error> {
        let pending = &checkpoint.pending;
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner = Self::read_userdata(&mut transaction, pending.user_id).await?;
        Self::require_character_owner(&owner, checkpoint.character_id)?;
        let row = sqlx::query("SELECT CommitId,Data FROM PendingAccountSaves WHERE UserId=?")
            .bind(pending.user_id).fetch_optional(&mut *transaction).await?;
        if let Some(row) = row {
            if row.try_get::<Vec<u8>, _>("CommitId")? != pending.commit.commit_id
                || row.try_get::<Vec<u8>, _>("Data")? != pending.payload {
                return Err(Error::InvalidInput("checkpoint_pending_mismatch"));
            }
            // An uncertain COMMIT can already have persisted. Verify the exact
            // paired character instead of rewriting it or issuing a new token.
            let current: Vec<u8> = sqlx::query_scalar("SELECT Data FROM Characters WHERE Id=?")
                .bind(checkpoint.character_id).fetch_one(&mut *transaction).await?;
            if current != checkpoint.character {
                return Err(Error::InvalidInput("checkpoint_character_mismatch"));
            }
        } else {
            let changed = sqlx::query("UPDATE Characters SET Data=? WHERE Id=?")
                .bind(&checkpoint.character).bind(checkpoint.character_id).execute(&mut *transaction).await?;
            if changed.rows_affected() != 1 {return Err(Error::InvalidInput("character_missing"));}
            let queued = sqlx::query("INSERT INTO PendingAccountSaves (UserId,CommitId,Data) VALUES (?,?,?)")
                .bind(pending.user_id).bind(pending.commit.commit_id.as_slice()).bind(&pending.payload)
                .execute(&mut *transaction).await?;
            if queued.rows_affected() != 1 {return Err(Error::InvalidInput("save_journal_write"));}
        }
        transaction.commit().await?;
        Ok(())
    }

    async fn deliver_checkpoint(&self, pending: &PendingAccountSave) -> Result<u64, Error> {
        let response = self.run_action(MasterShipAction::CommitAccountSnapshot {
            id: pending.user_id, commit: pending.commit.clone()}).await?;
        let revision = match response {
            MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id, revision, ..})
                if commit_id == pending.commit.commit_id
                    && pending.commit.expected_revision.checked_add(1) == Some(revision) => revision,
            MasterShipAction::AccountCommitResult(AccountCommitResult::Conflict {..}) =>
                return Err(Error::InvalidInput("account_save_revision_conflict")),
            MasterShipAction::Error(e) => return Err(Error::MSError(e)),
            _ => return Err(Error::MSUnexpected),
        };
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let removed = sqlx::query("DELETE FROM PendingAccountSaves WHERE UserId=? AND CommitId=? AND Data=?")
            .bind(pending.user_id).bind(pending.commit.commit_id.as_slice()).bind(&pending.payload)
            .execute(&mut *transaction).await?;
        let still_pending: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM PendingAccountSaves WHERE UserId=?)")
            .bind(pending.user_id).fetch_one(&mut *transaction).await?;
        if removed.rows_affected() > 1 || still_pending {
            return Err(Error::InvalidInput("checkpoint_ack_not_cleared"));
        }
        // No row is also safe here: this exact captured request has just been
        // acknowledged remotely, and a canceled earlier cleanup may have won.
        // A different/newer row is never removed or accepted as success.
        transaction.commit().await?;
        Ok(revision)
    }

    async fn finish_checkpoint(&self, session: &mut AccountSession) -> Result<(), Error> {
        let checkpoint = session.checkpoint.as_mut().ok_or(Error::InvalidInput("checkpoint_missing"))?;
        if checkpoint.pending.user_id != session.id || checkpoint.pending.commit.expected_revision != session.revision {
            return Err(Error::InvalidInput("checkpoint_session_mismatch"));
        }
        checkpoint.durable = false;
        self.stage_checkpoint(checkpoint).await?;
        checkpoint.durable = true;
        let revision = self.deliver_checkpoint(&checkpoint.pending).await?;
        // No await between receiving the result and advancing this lease.
        session.revision = revision;
        session.storage = checkpoint.pending.commit.snapshot.storage.clone();
        session.checkpoint = None;
        Ok(())
    }

    /// Save the supplied snapshot, first finishing any exact older snapshot.
    /// Cancellation/errors retain the prepared payload in the same account lease.
    pub async fn checkpoint_session(&self, session: &mut AccountSession,
        character: &CharData, user: &User) -> Result<(), Error> {
        // Validate the new input before committing a previously retained save.
        let mut next = SessionCheckpoint::prepare(session, character, user)?;
        if let Some(checkpoint) = &session.checkpoint {
            let same = checkpoint.matches(character, user)?;
            self.finish_checkpoint(session).await?;
            if same {return Ok(());}
            next = SessionCheckpoint::prepare(session, character, user)?;
        }
        // Install identity and immutable bytes before the first database await.
        session.checkpoint = Some(next);
        self.finish_checkpoint(session).await
    }

    /// Used by final-disconnect integration: only the exact latest snapshot may
    /// be left for next-login delivery once its local transaction is confirmed.
    pub async fn checkpoint_durable_for(&self, session: &AccountSession,
        character: &CharData, user: &User) -> Result<bool, Error> {
        let Some(checkpoint) = &session.checkpoint else {return Ok(false);};
        if !checkpoint.durable || !checkpoint.matches(character, user)? {return Ok(false);}
        let mut transaction = self.connection.begin().await?;
        let pending = sqlx::query("SELECT CommitId,Data FROM PendingAccountSaves WHERE UserId=?")
            .bind(user.id).fetch_optional(&mut *transaction).await?;
        let Some(pending) = pending else {return Ok(false);};
        let data: Option<Vec<u8>> = sqlx::query_scalar("SELECT Data FROM Characters WHERE Id=?")
            .bind(checkpoint.character_id).fetch_optional(&mut *transaction).await?;
        let matches = pending.try_get::<Vec<u8>, _>("CommitId")? == checkpoint.pending.commit.commit_id
            && pending.try_get::<Vec<u8>, _>("Data")? == checkpoint.pending.payload
            && data.as_deref() == Some(checkpoint.character.as_slice());
        transaction.commit().await?;
        Ok(matches)
    }
}
