use super::*;
use data_structs::master_ship::{AccountState, AccountSnapshot, AccountCommitResult};
use std::sync::Arc;
type Requests = tokio::sync::mpsc::Receiver<(MasterShipAction,tokio::sync::mpsc::Sender<MasterShipAction>)>;

fn state(revision: u64, uuid: u64, meseta: u64) -> AccountState {
    let mut storage = AccountStorages::default(); storage.storage_meseta = meseta;
    let mut flags = Flags::default(); flags.set(8, 1);
    AccountState {revision, snapshot: AccountSnapshot {storage, flags, last_uuid: uuid}}
}

async fn fixture() -> (Sql, Requests, User) {
    let mut sql = Sql::in_memory_for_test().await.unwrap();
    Sql::create_schema(&sql.connection).await.unwrap(); sql.insert_local_user(1).await.unwrap();
    let (master, requests) = MasterConnection::channel_for_test(); sql.master_ship = master;
    (sql, requests, User {id:1, last_uuid:1, ..Default::default()})
}

async fn open(sql: &Sql, requests: &mut Requests, user: &mut User, value: AccountState) -> AccountSession {
    let serve = async {
        let (action, send) = requests.recv().await.unwrap();
        assert!(matches!(action, MasterShipAction::GetAccountState(1)));
        send.send(MasterShipAction::AccountState(value)).await.unwrap();
    };
    let (result, ()) = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(sql.open_account_session(user), serve)
    }).await.unwrap();
    result.unwrap()
}

#[tokio::test]
async fn local_lifecycle_reconnect_waits_for_save_and_refreshes_whole_account() {
    let (sql, mut requests, mut user) = fixture().await;
    let session = open(&sql, &mut requests, &mut user, state(2, 40, 500)).await;
    let mut next_user = User {id:1, last_uuid:1, ..Default::default()};
    let mut next = Box::pin(sql.open_account_session(&mut next_user));
    assert!(tokio::time::timeout(Duration::from_millis(20), &mut next).await.is_err());
    assert!(requests.try_recv().is_err());
    let id = sql.put_character(1, CharData::default()).await.unwrap();
    let mut character = sql.session_character(&session, id).await.unwrap();
    assert_eq!(character.inventory.storages.storage_meseta, 500);
    character.inventory.storages.storage_meseta = 900; user.last_uuid = 45;
    sql.stage_character_save(&character, &user, session.revision).await.unwrap();
    session.release();
    let serve = async {
        let (action, send) = requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot {id,commit} = action else {panic!()};
        assert_eq!(id,1); assert_eq!(commit.expected_revision,2);
        assert_eq!(commit.snapshot.last_uuid,45); assert_eq!(commit.snapshot.storage.storage_meseta,900);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
            commit_id:commit.commit_id, revision:3, duplicate:false})).await.unwrap();
        let (action, send) = requests.recv().await.unwrap();
        assert!(matches!(action,MasterShipAction::GetAccountState(1)));
        send.send(MasterShipAction::AccountState(AccountState {revision:3,snapshot:commit.snapshot})).await.unwrap();
    };
    let (result,()) = tokio::join!(&mut next, serve); let session = result.unwrap(); drop(next);
    assert_eq!(next_user.last_uuid,45); assert_eq!(next_user.accountflags.get(8),1);
    assert_eq!(session.storage.storage_meseta,900); assert_eq!(session.revision,3);
    assert!(sql.pending_account_save(1).await.unwrap().is_none()); session.release();
}

#[tokio::test]
async fn local_lifecycle_unexpected_lease_drop_fences_account_without_blocking_others() {
    let (sql, mut requests, mut user) = fixture().await;
    let session = open(&sql, &mut requests, &mut user, state(0,1,0)).await;
    drop(session);
    assert!(matches!(sql.open_account_session(&mut user).await,Err(Error::InvalidInput("account_session_fenced"))));
    assert!(requests.try_recv().is_err());
    let mut other = User {id:2,..Default::default()};
    let serve = async {
        let (action,send) = requests.recv().await.unwrap(); assert!(matches!(action,MasterShipAction::GetAccountState(2)));
        send.send(MasterShipAction::AccountState(state(0,80,70))).await.unwrap();
    };
    let (result,())=tokio::join!(sql.open_account_session(&mut other),serve); result.unwrap().release();
    // Pruning unused healthy gates must never remove a fenced account.
    assert!(sql.open_account_session(&mut user).await.is_err());
}

#[tokio::test]
async fn local_lifecycle_failed_recovery_never_exposes_stale_login_state() {
    let (sql,mut requests,mut user)=fixture().await;
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let character=sql.load_owned_character(1,id).await.unwrap();
    sql.stage_character_save(&character,&user,0).await.unwrap();
    let serve=async {let (action,send)=requests.recv().await.unwrap();
        assert!(matches!(action,MasterShipAction::CommitAccountSnapshot {..}));
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Conflict {revision:7})).await.unwrap();};
    let (result,())=tokio::join!(sql.open_account_session(&mut user),serve);
    assert!(result.is_err());assert_eq!(user.last_uuid,1);assert!(requests.try_recv().is_err());
    assert!(sql.pending_account_save(1).await.unwrap().is_some());
}

#[tokio::test]
async fn local_lifecycle_creation_rolls_back_character_membership_and_uuid_on_write_fault() {
    for (table,event) in [("Characters","INSERT"),("Users","UPDATE"),("PendingAccountSaves","INSERT")] {
        for fault in ["RAISE(ABORT,'injected')","RAISE(IGNORE)"] {
            let (sql,mut requests,mut user)=fixture().await;
            let mut session=open(&sql,&mut requests,&mut user,state(5,10,456)).await;
            sql.connection.execute(format!("CREATE TRIGGER fault BEFORE {event} ON {table} BEGIN SELECT {fault}; END").as_str()).await.unwrap();
            assert!(sql.create_session_character(&mut session,&mut user,CharData::default(),15).await.is_err());
            assert!(sql.get_characters(1).await.unwrap().is_empty());
            let count:i64=sqlx::query_scalar("SELECT COUNT(*) FROM Characters").fetch_one(&sql.connection).await.unwrap();
            assert_eq!(count,0);assert!(sql.pending_account_save(1).await.unwrap().is_none());
            assert_eq!(user.last_uuid,10);assert_eq!(session.revision,5);assert!(requests.try_recv().is_err());
            session.release();
        }
    }
}

#[tokio::test]
async fn local_lifecycle_creation_lost_ack_recovers_uuid_and_existing_shared_storage() {
    let (sql,mut requests,mut user)=fixture().await;
    let mut session=open(&sql,&mut requests,&mut user,state(9,100,9876)).await;
    let serve=async {let (action,send)=requests.recv().await.unwrap();drop(send);
        let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};commit};
    let (result,commit)=tokio::join!(sql.create_session_character(&mut session,&mut user,CharData::default(),107),serve);
    assert!(matches!(result,Err(Error::MSNoResponse)));assert_eq!(user.last_uuid,107);
    assert_eq!(sql.get_characters(1).await.unwrap().len(),1);
    assert_eq!(commit.snapshot.storage.storage_meseta,9876);assert_eq!(commit.snapshot.flags.get(8),1);
    let exact=rmp_serde::to_vec(&commit).unwrap();session.release();
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();
        let MasterShipAction::CommitAccountSnapshot {commit:retry,..}=action else {panic!()};
        assert_eq!(rmp_serde::to_vec(&retry).unwrap(),exact);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {
            commit_id:commit.commit_id,revision:10,duplicate:true})).await.unwrap();
        let (action,send)=requests.recv().await.unwrap();assert!(matches!(action,MasterShipAction::GetAccountState(1)));
        send.send(MasterShipAction::AccountState(AccountState {revision:10,snapshot:commit.snapshot})).await.unwrap();
    };
    let mut stale_user=User {id:1,last_uuid:1,..Default::default()};
    let (result,())=tokio::join!(sql.open_account_session(&mut stale_user),serve);let session=result.unwrap();
    assert_eq!(stale_user.last_uuid,107);assert_eq!(session.storage.storage_meseta,9876);
    assert!(sql.pending_account_save(1).await.unwrap().is_none());session.release();
}

#[tokio::test]
async fn local_lifecycle_tracked_save_retains_gate_until_failed_local_write_retries() {
    let (sql,mut requests,mut user)=fixture().await;
    let mut session=open(&sql,&mut requests,&mut user,state(0,10,500)).await;
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let mut character=sql.session_character(&session,id).await.unwrap();character.character.name="saved after retry".into();
    sql.connection.execute("CREATE TRIGGER fault BEFORE UPDATE ON Characters BEGIN SELECT RAISE(ABORT,'injected'); END").await.unwrap();
    let sql=Arc::new(sql);let worker=sql.clone();
    sql.track_save(async move {worker.persist_session(&mut session,&character,&user).await;session.release();});
    let mut drain=Box::pin(sql.drain_session_saves());
    assert!(tokio::time::timeout(Duration::from_millis(30),&mut drain).await.is_err());
    let mut next_user=User {id:1,..Default::default()};let mut next=Box::pin(sql.open_account_session(&mut next_user));
    assert!(tokio::time::timeout(Duration::from_millis(20),&mut next).await.is_err());assert!(requests.try_recv().is_err());
    sql.connection.execute("DROP TRIGGER fault").await.unwrap();
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
        let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(1,10,500))).await.unwrap();
    };
    let (drained,next,())=tokio::time::timeout(Duration::from_secs(5),async {tokio::join!(drain,next,serve)}).await.unwrap();
    drained.unwrap();next.unwrap().release();
    assert_eq!(sql.load_owned_character(1,id).await.unwrap().character.name,"saved after retry");
}

pub(crate) async fn connected_user(sql: Arc<Sql>) -> (crate::user::User,tokio::net::TcpStream) {
    use crate::{BlockData, Quests, ServerData, SerDeFile, map::Map, mutex::{Mutex,RwLock}};
    use std::sync::atomic::AtomicU32;
    use pso2packetlib::PrivateKey;
    let data=Arc::new(ServerData::load_from_mp_comp(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../data/com_data.mp")).unwrap());
    let ids=AtomicU32::new(1);let lobby=Map::new_from_data(data.maps["lobby"].clone(),&ids).unwrap();
    let block=Arc::new(BlockData {sql:sql.clone(),block_id:1,block_name:"isolated session test".into(),
        blocks:Arc::new(RwLock::new(vec![])),lobby:Arc::new(Mutex::new(lobby)),key:PrivateKey::None,
        latest_mapid:ids,latest_partyid:AtomicU32::new(1),server_data:data.clone(),
        quests:Arc::new(Quests::load(data.quests.clone())),clients:Mutex::new(vec![])});
    let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let peer=tokio::net::TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
    let (stream,_)=listener.accept().await.unwrap();let (mut user,_reader)=crate::user::User::new(stream,block,1).unwrap();
    user.user_data.id=1;
    (user,peer)
}

#[tokio::test]
async fn local_lifecycle_real_creation_handler_then_disconnect_without_entering_game() {
    use pso2packetlib::protocol::models::character::{Class,Race};
    let (sql,mut requests,_)=fixture().await;let sql=Arc::new(sql);
    let (mut user,_peer)=connected_user(sql.clone()).await;
    let data=user.get_blockdata().server_data.clone();
    let serve=async {let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(0,200,9000))).await.unwrap();};
    let (result,())=tokio::join!(user.begin_account_session(),serve);result.unwrap();
    let mut packet=pso2packetlib::protocol::login::CharacterCreatePacket::default();
    packet.character.classes.main_class=Class::Ranger;packet.character.look.race=Race::Cast;
    let expected=200+data.default_classes.classes[Class::Ranger as usize].items.len() as u64;
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
        assert_eq!(commit.snapshot.last_uuid,expected);assert_eq!(commit.snapshot.storage.storage_meseta,9000);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:1,duplicate:false})).await.unwrap();
    };
    let (result,())=tokio::join!(crate::user::handlers::login::new_character(&mut user,packet),serve);result.unwrap();
    assert!(user.character.is_none());assert_eq!(user.user_data.last_uuid,expected);
    user.queue_disconnect();drop(user);sql.drain_session_saves().await.unwrap();
    assert_eq!(sql.get_characters(1).await.unwrap().len(),1);assert!(sql.pending_account_save(1).await.unwrap().is_none());
    let mut stale=User {id:1,last_uuid:1,..Default::default()};
    let session=open(&sql,&mut requests,&mut stale,state(1,expected,9000)).await;
    assert_eq!(stale.last_uuid,expected);session.release();
}

#[tokio::test]
async fn local_lifecycle_real_disconnect_keeps_identity_and_delivers_one_snapshot() {
    let (sql,mut requests,_)=fixture().await;let sql=Arc::new(sql);
    let (mut user,_peer)=connected_user(sql.clone()).await;
    let serve=async {let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(5,30,700))).await.unwrap();};
    let (result,())=tokio::join!(user.begin_account_session(),serve);result.unwrap();
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let mut character=sql.load_owned_character(1,id).await.unwrap();
    character.inventory.storages.storage_meseta=12345;character.character.name="disconnect snapshot".into();
    user.character=Some(character);user.user_data.last_uuid=35;
    user.queue_disconnect();user.queue_disconnect();
    assert_eq!(user.get_user_id(),1);assert!(user.character.is_some());
    let wrapper=crate::mutex::Mutex::new(user);
    assert!(matches!(crate::user::packet_handler(wrapper.lock().await,pso2packetlib::protocol::Packet::CharacterListRequest).await.unwrap(),crate::Action::Disconnect));
    drop(wrapper);
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {id,commit}=action else {panic!()};
        assert_eq!(id,1);assert_eq!(commit.expected_revision,5);assert_eq!(commit.snapshot.last_uuid,35);
        assert_eq!(commit.snapshot.storage.storage_meseta,12345);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:6,duplicate:false})).await.unwrap();
    };
    let (result,())=tokio::join!(sql.drain_session_saves(),serve);result.unwrap();assert!(requests.try_recv().is_err());
    assert_eq!(sql.load_owned_character(1,id).await.unwrap().character.name,"disconnect snapshot");
    let mut next=User {id:1,..Default::default()};open(&sql,&mut requests,&mut next,state(6,35,12345)).await.release();
}

#[tokio::test]
async fn local_lifecycle_drain_reports_panics_but_waits_for_other_saves() {
    let (sql,_,_)=fixture().await;
    let (send,recv)=tokio::sync::oneshot::channel();
    let finished=Arc::new(std::sync::atomic::AtomicBool::new(false));let flag=finished.clone();
    sql.track_save(async {panic!("injected worker failure")});
    sql.track_save(async move {recv.await.unwrap();flag.store(true,std::sync::atomic::Ordering::Relaxed);});
    let mut drain=Box::pin(sql.drain_session_saves());
    assert!(tokio::time::timeout(Duration::from_millis(20),&mut drain).await.is_err());
    send.send(()).unwrap();assert!(drain.await.is_err());
    assert!(finished.load(std::sync::atomic::Ordering::Relaxed));
}

#[tokio::test]
async fn local_lifecycle_block_transfer_stops_old_packets_and_queues_durable_save() {
    let (sql,mut requests,_)=fixture().await;let sql=Arc::new(sql);
    let (mut user,_peer)=connected_user(sql.clone()).await;
    let serve=async {let (_,send)=requests.recv().await.unwrap();send.send(MasterShipAction::AccountState(state(3,70,1000))).await.unwrap();};
    let (result,())=tokio::join!(user.begin_account_session(),serve);result.unwrap();
    let id=sql.put_character(1,CharData::default()).await.unwrap();
    let mut character=sql.load_owned_character(1,id).await.unwrap();character.inventory.storages.storage_meseta=1111;
    user.character=Some(character);
    let data=user.get_blockdata();
    data.blocks.write().await.push(crate::BlockInfo {id:2,name:"test destination".into(),
        ip:Ipv4Addr::LOCALHOST,port:13003,max_players:10,players:0,lobby_map:"lobby".into(),
        server_data:data.server_data.clone(),quests:data.quests.clone()});
    let serve=async {
        let (action,send)=requests.recv().await.unwrap();assert!(matches!(action,MasterShipAction::NewBlockChallenge(1)));
        send.send(MasterShipAction::BlockChallengeResult(123)).await.unwrap();
        let (action,send)=requests.recv().await.unwrap();let MasterShipAction::CommitAccountSnapshot {commit,..}=action else {panic!()};
        assert_eq!(commit.expected_revision,3);assert_eq!(commit.snapshot.storage.storage_meseta,1111);
        send.send(MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:4,duplicate:false})).await.unwrap();
    };
    let packet=pso2packetlib::protocol::login::BlockSwitchRequestPacket {block_id:2,..Default::default()};
    let (result,())=tokio::join!(crate::user::handlers::login::switch_block(&mut user,packet),serve);result.unwrap();
    let wrapper=crate::mutex::Mutex::new(user);
    assert!(matches!(crate::user::User::tick(wrapper.lock().await).await.unwrap(),crate::Action::Disconnect));
    sql.drain_session_saves().await.unwrap();
    assert!(sql.pending_account_save(1).await.unwrap().is_none());
    let mut next=User {id:1,..Default::default()};open(&sql,&mut requests,&mut next,state(4,70,1111)).await.release();
}
