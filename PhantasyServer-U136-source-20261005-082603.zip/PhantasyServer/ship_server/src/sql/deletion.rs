//! Persistent deletion state. These APIs are not wired to the client yet.
//! Internal times use application UTC seconds, not an assumed wire epoch.
//! SEGA's 2013-12-11 Classic update specifies a 24-hour cancellable wait:
//! https://pso2.jp/players/news/2698/
use super::*;

const DELETION_WAIT_SECONDS: u64 = 24 * 60 * 60;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PendingDeletion {
    pub character_id: u32,
    pub requested_at: u64,
    pub delete_after: u64,
}

fn storage_time(time: u64) -> Result<i64, Error> {
    i64::try_from(time).map_err(|_| Error::InvalidInput("character_deletion_time"))
}

fn read_pending(row: &sqlx::sqlite::SqliteRow) -> Result<PendingDeletion, Error> {
    let character_id = u32::try_from(row.try_get::<i64, _>("CharacterId")?)
        .map_err(|_| Error::InvalidInput("character_id_range"))?;
    let requested_at = u64::try_from(row.try_get::<i64, _>("RequestedAt")?)
        .map_err(|_| Error::InvalidInput("character_deletion_time"))?;
    let delete_after = u64::try_from(row.try_get::<i64, _>("DeleteAfter")?)
        .map_err(|_| Error::InvalidInput("character_deletion_time"))?;
    if requested_at.checked_add(DELETION_WAIT_SECONDS) != Some(delete_after) {
        return Err(Error::InvalidInput("character_deletion_time"));
    }
    Ok(PendingDeletion { character_id, requested_at, delete_after })
}

impl Sql {
    /// Persist an owned deletion request without changing the character or slot.
    /// A retry preserves the first deadline; this is a server retry policy,
    /// not a claim about an undocumented original duplicate-request response.
    pub async fn schedule_character_deletion(
        &self, id: u32, char_id: u32, now: u64,
    ) -> Result<PendingDeletion, Error> {
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner = Self::read_userdata(&mut transaction, id).await?;
        Self::require_character_owner(&owner, char_id)?;
        Self::require_character_row(&mut transaction, char_id).await?;
        let row = sqlx::query("SELECT * FROM CharacterDeletions WHERE CharacterId=?")
            .bind(char_id).fetch_optional(&mut *transaction).await?;
        if let Some(row) = row {
            if row.try_get::<i64, _>("OwnerId")? != i64::from(id) {
                return Err(Error::InvalidInput("character_ownership"));
            }
            let pending = read_pending(&row)?;
            transaction.commit().await?;
            return Ok(pending);
        }
        let delete_after = now.checked_add(DELETION_WAIT_SECONDS)
            .ok_or(Error::InvalidInput("character_deletion_time"))?;
        let changed = sqlx::query(
            "INSERT INTO CharacterDeletions (CharacterId,OwnerId,RequestedAt,DeleteAfter) VALUES (?,?,?,?)",
        ).bind(char_id).bind(id).bind(storage_time(now)?).bind(storage_time(delete_after)?)
            .execute(&mut *transaction).await?;
        if changed.rows_affected() != 1 {
            return Err(Error::InvalidInput("character_deletion_write"));
        }
        transaction.commit().await?;
        Ok(PendingDeletion { character_id: char_id, requested_at: now, delete_after })
    }

    pub async fn pending_character_deletions(&self, id: u32) -> Result<Vec<PendingDeletion>, Error> {
        let mut transaction = self.connection.begin().await?;
        let owner = Self::read_userdata(&mut transaction, id).await?;
        let rows = sqlx::query("SELECT * FROM CharacterDeletions WHERE OwnerId=? ORDER BY CharacterId")
            .bind(id).fetch_all(&mut *transaction).await?;
        let mut pending = Vec::with_capacity(rows.len());
        for row in rows {
            let state = read_pending(&row)?;
            Self::require_character_owner(&owner, state.character_id)?;
            Self::require_character_row(&mut transaction, state.character_id).await?;
            pending.push(state);
        }
        transaction.commit().await?;
        Ok(pending)
    }

    /// Low-level cancellation storage operation. The future handler must apply
    /// the verified cancellation/selection deadline policy before calling this.
    /// No success is returned for an ignored write or an unowned character.
    pub async fn clear_pending_character_deletion(&self, id: u32, char_id: u32) -> Result<bool, Error> {
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let owner = Self::read_userdata(&mut transaction, id).await?;
        Self::require_character_owner(&owner, char_id)?;
        Self::require_character_row(&mut transaction, char_id).await?;
        let marker = sqlx::query("SELECT * FROM CharacterDeletions WHERE CharacterId=?")
            .bind(char_id).fetch_optional(&mut *transaction).await?;
        let present = if let Some(row) = marker {
            if row.try_get::<i64, _>("OwnerId")? != i64::from(id) {
                return Err(Error::InvalidInput("character_ownership"));
            }
            read_pending(&row)?;
            let changed = sqlx::query("DELETE FROM CharacterDeletions WHERE CharacterId=? AND OwnerId=?")
                .bind(char_id).bind(id).execute(&mut *transaction).await?;
            if changed.rows_affected() != 1 {
                return Err(Error::InvalidInput("character_deletion_write"));
            }
            true
        } else { false };
        transaction.commit().await?;
        Ok(present)
    }

    /// Finalize due requests for one account on this ship. The caller chooses
    /// the verified login checkpoint; there is no background deletion timer.
    pub async fn finalize_due_character_deletions(&self, id: u32, now: u64) -> Result<Vec<u32>, Error> {
        let now = storage_time(now)?;
        let mut transaction = self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let mut owner = Self::read_userdata(&mut transaction, id).await?;
        // Validate all of this account's pending rows, including future rows,
        // so malformed deadlines cannot evade validation by the SQL filter.
        let rows = sqlx::query("SELECT * FROM CharacterDeletions WHERE OwnerId=? ORDER BY CharacterId")
            .bind(id).fetch_all(&mut *transaction).await?;
        let mut removed = Vec::new();
        for row in rows {
            let pending = read_pending(&row)?;
            Self::require_character_owner(&owner, pending.character_id)?;
            Self::require_character_row(&mut transaction, pending.character_id).await?;
            if pending.delete_after > now as u64 { continue; }
            Self::delete_owned_character_row(&mut transaction, id, pending.character_id).await?;
            owner.character_ids.retain(|v| *v != pending.character_id);
            removed.push(pending.character_id);
        }
        if !removed.is_empty() {
            Self::write_userdata(&mut transaction, id, &owner).await?;
        }
        transaction.commit().await?;
        Ok(removed)
    }

    async fn require_character_row(connection: &mut sqlx::SqliteConnection, char_id: u32) -> Result<(), Error> {
        let present: bool = sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM Characters WHERE Id=?)")
            .bind(char_id).fetch_one(connection).await?;
        if !present { return Err(Error::InvalidInput("character_missing")); }
        Ok(())
    }

    pub(super) async fn delete_owned_character_row(
        connection: &mut sqlx::SqliteConnection, id: u32, char_id: u32,
    ) -> Result<(), Error> {
        let marker_owner: Option<i64> = sqlx::query_scalar("SELECT OwnerId FROM CharacterDeletions WHERE CharacterId=?")
            .bind(char_id).fetch_optional(&mut *connection).await?;
        if marker_owner.is_some_and(|owner| owner != i64::from(id)) {
            return Err(Error::InvalidInput("character_ownership"));
        }
        let changed = sqlx::query("DELETE FROM Characters WHERE Id=?")
            .bind(char_id).execute(&mut *connection).await?;
        if changed.rows_affected() != 1 { return Err(Error::InvalidInput("character_missing")); }
        if marker_owner.is_some() {
            let changed = sqlx::query("DELETE FROM CharacterDeletions WHERE CharacterId=? AND OwnerId=?")
                .bind(char_id).bind(id).execute(&mut *connection).await?;
            if changed.rows_affected() != 1 { return Err(Error::InvalidInput("character_deletion_write")); }
        }
        Ok(())
    }
}
