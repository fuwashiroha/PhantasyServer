//! Eight initial main-class rare masteries, post-2017 damage rule.
//! The below-10-star crafted branch awaits a verified per-item craft decoder.
use crate::{Error, native_class_tree::{self,ClassTree}, sql::CharData};
use pso2packetlib::protocol::{models::{character::Class,item_attrs::WeaponAttrs},items::ItemType};

pub(crate) fn active(c:&CharData,weapon:&WeaponAttrs)->Result<bool,Error> {
    let (slot,name)=match c.character.classes.main_class {
        Class::Hunter=>(0,"Rare10Hunter"),Class::Ranger=>(1,"Rare10Ranger"),
        Class::Force=>(2,"Rare10Force"),Class::Fighter=>(3,"Rare10Fighter"),
        Class::Gunner=>(4,"Rare10Gunner"),Class::Techer=>(5,"Rare10Techer"),
        Class::Braver=>(6,"Rare10Braver"),Class::Bouncer=>(7,"Rare10Bouncer"),
        _=>return Ok(false),
    };
    // Attribute rows are trusted server data, never a client-supplied rarity.
    // Tact is explicitly excluded, regardless of rarity or subclass.
    if weapon.id==18 || weapon.rarity<10 {return Ok(false);}
    let Some(item)=c.palette.get_current_item(&c.inventory)? else{return Ok(false)};
    if !matches!(item.data,ItemType::Weapon(_)) || item.id.item_type!=1
        || item.id.id!=weapon.id || item.id.subid!=weapon.subid {return Ok(false);}
    let level=native_class_tree::class_level(&c.character.classes,slot)?;
    let tree=c.native_class_trees.get(&slot).cloned().unwrap_or_else(ClassTree::default).at_level(slot,level.level1)?;
    tree.validate(slot,level.level1,level.level2)?;
    Ok(tree.rank(name)>0)
}
