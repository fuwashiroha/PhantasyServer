//! Scoped server effects; native allocation binding lives in native_hero_tree.
//! Parameters: pinned Classic Hero swiki tables in classic-hero-skill-catalogue.json.
use crate::Error;
use std::collections::BTreeMap;

#[derive(Debug,Default,Clone,serde::Serialize,serde::Deserialize,PartialEq)]
#[serde(default)]
pub(crate) struct HeroSkills {
    // Stable textual keys are internal save keys, never claimed as client skill IDs.
    ranks:BTreeMap<String,u8>,
}

impl HeroSkills {
    pub(crate) fn is_empty(&self)->bool {self.ranks.is_empty()}
    pub(crate) fn rank(&self,key:&str)->u8 {self.ranks.get(key).copied().unwrap_or(0)}
    pub(crate) fn validate(&self,level:u16)->Result<(),Error> {
        for (key,rank) in &self.ranks {
            let (max,min)=match key.as_str() {
                "weapon1"|"weapon2"|"guard"|"hp"|"attack"|"defense"=>(10,1),
                "normal"|"counter"|"aura"|"weak"|"will"=>(5,1),"high"=>(5,80),
                _=>return Err(Error::InvalidInput("hero_skill_unsupported")),
            };
            if *rank>max || (*rank>0 && level<min) {return Err(Error::InvalidInput("hero_skill_rank_or_level"));}
        }
        Ok(())
    }
    pub(crate) fn with_test_rank(&self,key:&str,rank:u8,level:u16)->Result<Self,Error> {
        let mut next=self.clone();
        next.ranks.insert(key.to_owned(),rank);next.validate(level)?;
        if rank==0 {next.ranks.remove(key);}
        Ok(next)
    }
    pub(crate) fn outgoing(&self,hero_weapon:bool,normal:bool)->f32 {
        let mut mul=1.0+0.01*self.rank("high") as f32;
        if hero_weapon {
            mul*=1.0+0.05*self.rank("weapon1") as f32;
            mul*=1.0+0.05*self.rank("weapon2") as f32;
            if normal {mul*=[1.0,1.08,1.12,1.16,1.18,1.20][self.rank("normal") as usize];}
        }
        mul
    }
    pub(crate) fn incoming(&self)->f32 {1.0-0.01*self.rank("guard") as f32}
    pub(crate) fn conditional_power(&self,id:u32)->f32 {
        let key=if is_counter(id) {"counter"} else if id==4293352205 {"aura"} else {return 1.0};
        [1.0,1.0,1.05,1.07,1.09,1.10][self.rank(key) as usize]
    }
    pub(crate) fn physical_weak_critical_bonus(&self)->u32 {
        [0,110,120,130,140,150][self.rank("weak") as usize]
    }
    pub(crate) fn hp(&self)->u32 {5*self.rank("hp") as u32}
    pub(crate) fn attack(&self)->u32 {5*self.rank("attack") as u32}
    pub(crate) fn defense(&self)->u32 {5*self.rank("defense") as u32}
}

// Only pinned normal/step/weapon-action roots; PA counter variants are excluded.
pub(crate) fn is_normal_attack(id:u32)->bool {
    matches!(id,
        1957098999 // WpnmanSword:GA1
        |         1957098996 // WpnmanSword:GA2
        |         2702021394 // WpnmanSword:GA3_1
        |         2702021395 // WpnmanSword:GA3_2
        |         1957107220 // WpnmanSword:AA1
        |         1957107221 // WpnmanSword:AA2
        |         2995404527 // WpnmanSword:AA3_1
        |         2995404520 // WpnmanSword:AA3_2
        |         2441696609 // WpnmanSword:Shot
        |         551703528 // WpnmanSword:ShotCharge
        |         4293352205 // WpnmanSword:ShotCharge2
        |         1957154738 // WpnmanSword:SA1
        |         2887649478 // WpnmanSword:HCSA1
        |         1266058081 // WpnmanTalis:GA1
        |         1266058094 // WpnmanTalis:GA2
        |         1266058095 // WpnmanTalis:GA3
        |         1266042237 // WpnmanTalis:SA1
        |         4173352466 // WpnmanTalis:HCSA1
        |         2178755895 // WpnmanTalis:HCSA1_op
        |         2888293241 // WpnmanTMachineGun:Shot1
        |         982770438 // WpnmanTMachineGun:HCShot
        |         1683315429 // WpnmanTMachineGun:SA1
    )
}
pub(crate) fn is_counter(id:u32)->bool {
    matches!(id,2887649478|4173352466|2178755895|982770438)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_hero_skill_parameters_match_saved_reference_at_every_rank() {
        let f:serde_json::Value=serde_json::from_str(include_str!("../testdata/classic-hero-skill-catalogue.json")).unwrap();
        assert_eq!(f["skills"].as_array().unwrap().len(),40);
        for row in f["skills"].as_array().unwrap().iter().filter(|r|r["implementation"]=="server_passive_test_override") {
            let key=row["key"].as_str().unwrap();
            for rank in 1..=row["max_rank"].as_u64().unwrap() {
                let skills=HeroSkills::default().with_test_rank(key,rank as u8,85).unwrap();
                let cell=row["parameter_rows"][1][rank as usize+1].as_str().unwrap();
                let expected=cell.trim_start_matches('+').trim_end_matches('%').parse::<f32>().unwrap();
                let actual=match key {"hp"=>skills.hp() as f32,"attack"=>skills.attack() as f32,"defense"=>skills.defense() as f32,
                    "guard"=>skills.incoming()*100.0,_=>skills.outgoing(true,true)*100.0};
                assert!((actual-expected).abs()<0.0001,"{key} rank {rank}");
            }
        }
    }
    #[test]
    fn local_hero_skill_invalid_rank_unknown_effect_and_level_are_atomic() {
        let skills=HeroSkills::default().with_test_rank("weapon1",10,85).unwrap();
        for (key,rank,level) in [("normal",6,85),("weapon1",11,85),("high",1,79),("hb",1,85),("unknown",0,85)] {
            assert!(skills.with_test_rank(key,rank,level).is_err());assert_eq!(skills.rank("weapon1"),10);
        }
        assert!(skills.with_test_rank("weapon1",0,85).unwrap().is_empty());
    }
    #[test]
    fn local_hero_skill_legacy_character_snapshot_defaults_and_new_ranks_roundtrip() {
        let mut c=crate::sql::CharData::default();
        // Serialize exactly the eight fields present before U090.
        let bytes=rmp_serde::to_vec(&(&c.character,&c.inventory,&c.palette,&c.flags,&c.unlocked_quests,
            &c.unlocked_quests_notif,&c.play_time,&c.quest_meseta_receipts)).unwrap();
        let old:crate::sql::CharData=rmp_serde::from_slice(&bytes).unwrap();assert!(old.hero_test_skills.is_empty());
        c.hero_test_skills=c.hero_test_skills.with_test_rank("weapon2",7,85).unwrap();
        let saved:crate::sql::CharData=rmp_serde::from_slice(&rmp_serde::to_vec(&c).unwrap()).unwrap();
        assert_eq!(saved.hero_test_skills.rank("weapon2"),7);
    }
}
