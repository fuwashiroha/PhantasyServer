//! Weapon element is separate from a hit's physical damage category.
//! Source routes are frozen to audited player weapon hits, not arbitrary TEC IDs.
use crate::{Error, sql::CharData};
use data_structs::stats::EnemyHitbox;
use pso2packetlib::protocol::{items::ItemType, models::{character::Class,item_attrs::WeaponAttrs}};
use std::{collections::HashSet,sync::OnceLock};

#[derive(Debug,Default,Clone,Copy)]
pub(crate) struct WeaponElement { element:u8, strength:u8, suppressed:bool }

fn eligible(id:u32)->bool {
    #[derive(serde::Deserialize)] struct Hit {id:u32}
    #[derive(serde::Deserialize)] struct Catalogue {attacks:Vec<Hit>}
    static IDS:OnceLock<HashSet<u32>>=OnceLock::new();
    IDS.get_or_init(||serde_json::from_str::<Catalogue>(include_str!("../testdata/classic-weapon-element.json"))
        .expect("audited weapon element routes").attacks.into_iter().map(|h|h.id).collect()).contains(&id)
}

impl WeaponElement {
    pub(crate) fn technique_conversion(&self,rank:usize,tech_element:&str)->f32 {
        if rank==0 || self.element==0 || self.strength==0 || self.suppressed {return 1.0;}
        let element=match tech_element {"fire"=>1,"ice"=>2,"thunder"=>3,"wind"=>4,"light"=>5,"dark"=>6,_=>return 1.0};
        let rate=if element==self.element {0.50}else{[0.0,0.35,0.37,0.39,0.42,0.45][rank]};
        1.0+self.strength as f32/100.0*rate
    }
    pub(crate) fn attack_element(&self,id:u32)->Option<u8> {
        eligible(id).then_some(if self.suppressed || self.strength==0 {0}else{self.element})
    }
    pub(crate) fn build(c:&CharData,attrs:&WeaponAttrs)->Result<Self,Error> {
        let Some(item)=c.palette.get_current_item(&c.inventory)? else{return Ok(Self::default())};
        let ItemType::Weapon(w)=&item.data else{return Err(Error::InvalidInput("weapon_element_item_type"))};
        // No elemental contribution to authorize. Preserve existing zero-element
        // equipment behavior; legacy/synthetic stat rows can omit item metadata.
        if w.element==0 && w.force==0 {return Ok(Self::default());}
        if item.id.item_type!=1 || item.id.id!=attrs.id || item.id.subid!=attrs.subid {
            return Err(Error::InvalidInput("weapon_element_identity"));
        }
        if w.element>6 || (w.force>0 && (!(1..=15).contains(&attrs.rarity)
            || w.force>if attrs.rarity>=13 {60}else{50})) {
            return Err(Error::InvalidInput("weapon_element_value"));
        }
        Ok(Self{element:w.element,strength:w.force,
            // Lu NonElement removes ordinary attribute damage even during purge.
            // Its separate 70% own-RNG-power stat conversion is still pending.
            suppressed:c.character.classes.main_class==Class::Luster && item.id.id==7})
    }
    pub(crate) fn power(&self,id:u32,weapon_power:u32,hitbox:&EnemyHitbox)->f32 {
        if self.suppressed || self.strength==0 || !eligible(id) {return 0.0;}
        let region=match self.element {
            1=>hitbox.fire_mul,2=>hitbox.ice_mul,3=>hitbox.thunder_mul,
            4=>hitbox.wind_mul,5=>hitbox.light_mul,6=>hitbox.dark_mul,_=>return 0.0,
        };
        weapon_power as f32 * (self.strength as f32/100.0) * region
    }
}
