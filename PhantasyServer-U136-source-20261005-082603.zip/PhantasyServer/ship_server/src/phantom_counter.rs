//! Native Phantom counter stock request bridge, not server dodge detection.
//! swiki: one stored projectile; weapon switches preserve it; area changes clear.
//! villain.ski: kind 13 Stock / kind 17 StockRemove; registry: 112037, kind 62.
use pso2packetlib::protocol::{Packet,ObjectHeader,ObjectType,objects::{Unk0424Packet,Unk0425Packet},playerstatus::DealDamagePacket};

#[derive(Default)]
pub(crate) struct PhantomCounter {stocked:bool}
pub(crate) fn is_request(id:u32)->bool {
    id==data_structs::name_to_id("VillainDodgeCounterStock") || id==data_structs::name_to_id("VillainDodgeCounterStockRemove")
}
impl PhantomCounter {
    pub(crate) fn clear(&mut self,owner:ObjectHeader)->Option<Packet> {
        if !self.stocked {return None;}
        Some(self.reset_area(owner))
    }
    pub(crate) fn reset_area(&mut self,owner:ObjectHeader)->Packet {
        self.stocked=false;
        Packet::Unk0425(Unk0425Packet{unk1:owner,unk2:owner,unk3:112037,..Default::default()})
    }
    pub(crate) fn handle(&mut self,owner:ObjectHeader,learned:bool,p:&DealDamagePacket)->Option<Packet> {
        if !learned || owner.entity_type!=ObjectType::Player || p.inflicter!=owner || p.target!=owner || !matches!(p.hitbox_id,0|u32::MAX) {return None;}
        if p.attack_id==data_structs::name_to_id("VillainDodgeCounterStockRemove") {return Some(self.reset_area(owner));}
        if p.attack_id!=data_structs::name_to_id("VillainDodgeCounterStock") || self.stocked {return None;}
        self.stocked=true;
        let mut tail=[0;12];tail[..4].copy_from_slice(&(-1f32).to_le_bytes());
        tail[4..8].copy_from_slice(&1u32.to_le_bytes());tail[8..].copy_from_slice(&4u32.to_le_bytes());
        Some(Packet::Unk0424(Unk0424Packet{unk1:owner,unk2:owner,unk3:owner,unk4:112037,unk5:u32::MAX,unk6:tail,unk7:[0;12]}))
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_phantom_counter_stock_owner_gate_single_slot_consume_and_restock() {
        let h=ObjectHeader{id:7,entity_type:ObjectType::Player,..Default::default()};
        let mut p=DealDamagePacket{inflicter:h,target:h,hitbox_id:u32::MAX,attack_id:data_structs::name_to_id("VillainDodgeCounterStock"),..Default::default()};
        let mut c=PhantomCounter::default();
        assert!(c.handle(h,false,&p).is_none());p.target.id=8;assert!(c.handle(h,true,&p).is_none());p.target=h;
        p.inflicter.id=8;assert!(c.handle(h,true,&p).is_none());p.inflicter=h;
        p.hitbox_id=3;assert!(c.handle(h,true,&p).is_none());p.hitbox_id=u32::MAX;
        assert!(matches!(c.handle(h,true,&p),Some(Packet::Unk0424(p)) if p.unk4==112037));
        assert!(c.handle(h,true,&p).is_none()); // never stacks a second projectile
        let mut end=p.clone();end.attack_id=data_structs::name_to_id("VillainDodgeCounterStockRemove");end.hitbox_id=0;
        assert!(matches!(c.handle(h,true,&end),Some(Packet::Unk0425(p)) if p.unk3==112037));
        assert!(c.handle(h,true,&p).is_some());
        assert!(c.clear(h).is_some());assert!(c.clear(h).is_none());
        // Area reset also removes client-local stock even if no server add was observed.
        assert!(matches!(c.reset_area(h),Packet::Unk0425(p) if p.unk3==112037));
        assert!(c.handle(h,true,&p).is_some());
    }
}
