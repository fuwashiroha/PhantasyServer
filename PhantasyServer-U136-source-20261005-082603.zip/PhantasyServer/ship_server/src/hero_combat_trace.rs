//! Opt-in private Hero action evidence, bounded by time, count, and payload size.
use pso2packetlib::protocol::Packet;
use std::{collections::BTreeMap,time::{Instant,Duration}};
#[derive(Default)]
pub(crate) struct HeroCombatTrace {start:Option<Instant>,left:u16,counts:BTreeMap<String,u8>}
impl HeroCombatTrace {
    pub(crate) fn arm(&mut self,authorized:bool,now:Instant)->Result<(),crate::Error>{
        if !authorized{return Err(crate::Error::InvalidInput("hero_trace_not_authorized"));}
        self.start=Some(now);self.left=256;self.counts.clear();Ok(())
    }
    pub(crate) fn sample(&mut self,p:&Packet,now:Instant)->Option<serde_json::Value>{
        let elapsed=now.checked_duration_since(self.start?)?;
        if elapsed>=Duration::from_secs(180)||self.left==0{return None;}
        let (key,mut v)=match p {
            Packet::SetPalette(p)=>("21/04".into(),serde_json::json!({"packet":"21/04","fields":p})),
            Packet::UpdatePalette(p)=>("21/06".into(),serde_json::json!({"packet":"21/06","selected":p.cur_palette,"weapon_uuids":p.palettes.iter().map(|v|v.uuid).collect::<Vec<_>>()})),
            Packet::MovementAction(p)=>(format!("action:{}",p.action),serde_json::json!({"packet":"04/08","action":p.action.to_string().chars().take(128).collect::<String>(),"fields":p})),
            Packet::ActionUpdate(p)=>("04/3c".into(),serde_json::json!({"packet":"04/3c","fields":p})),
            Packet::DealDamage(p)=>(format!("hit:{}",p.attack_id),serde_json::json!({"packet":"06/01","fields":p})),
            Packet::Unknown((h,b)) if matches!(h.id,4|6) && h.subid!=0x27 => {
                let prefix=&b[..b.len().min(512)];
                (format!("unknown:{:02x}/{:02x}",h.id,h.subid),serde_json::json!({"packet":[h.id,h.subid],"length":b.len(),"payload_hex":prefix.iter().map(|b|format!("{b:02x}")).collect::<String>(),"truncated":b.len()>512}))
            },
            _=>return None,
        };
        // Bound decoded action arrays too, without retaining oversized records.
        if v.to_string().len()>4096 {v=serde_json::json!({"key":key,"oversize_omitted":true});}
        let count=self.counts.entry(key).or_default();if *count>=8{return None;}
        *count+=1;self.left-=1;v["elapsed_ms"]=serde_json::json!(elapsed.as_millis());Some(v)
    }
    pub(crate) fn observe(&mut self,p:&Packet){if let Some(v)=self.sample(p,Instant::now()){log::warn!("hero_combat_trace {v}");}}
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn local_hero_combat_trace_records_palette_selection_and_bounded_weapon_ids(){
        let now=Instant::now();let mut t=HeroCombatTrace::default();t.arm(true,now).unwrap();
        let v=t.sample(&Packet::SetPalette(pso2packetlib::protocol::palette::SetPalettePacket{palette:2,..Default::default()}),now).unwrap();
        assert_eq!(v["fields"]["palette"],2);
        let mut p=pso2packetlib::protocol::palette::UpdatePalettePacket::default();p.cur_palette=1;p.palettes[1].uuid=42;
        let v=t.sample(&Packet::UpdatePalette(p),now).unwrap();
        assert_eq!(v["selected"],1);assert_eq!(v["weapon_uuids"][1],42);assert_eq!(v["weapon_uuids"].as_array().unwrap().len(),6);
    }
    #[test]
    fn local_hero_combat_trace_is_opt_in_and_bounded_without_chat_or_login(){
        use pso2packetlib::protocol::PacketHeader;
        let now=Instant::now();let mut t=HeroCombatTrace::default();let hit=Packet::DealDamage(Default::default());
        assert!(t.sample(&hit,now).is_none());assert!(t.arm(false,now).is_err());t.arm(true,now).unwrap();
        for id in [7,0x11,0x18,0x1a,0x1c,0x2f]{assert!(t.sample(&Packet::Unknown((PacketHeader::new(id,0,Default::default()),vec![0;800])),now).is_none());}
        assert!(t.sample(&Packet::ChatMessage(Default::default()),now).is_none());
        for _ in 0..8{assert!(t.sample(&hit,now).is_some());}assert!(t.sample(&hit,now).is_none());
        let p=Packet::Unknown((PacketHeader::new(4,0xff,Default::default()),vec![0;800]));
        let v=t.sample(&p,now).unwrap();assert_eq!(v["payload_hex"].as_str().unwrap().len(),1024);assert_eq!(v["truncated"],true);
        assert!(t.sample(&p,now+Duration::from_secs(180)).is_none());
        for sub in 0..300{let p=Packet::Unknown((PacketHeader::new(4,sub,Default::default()),vec![]));t.sample(&p,now);}
        assert_eq!(t.left,0);
    }
}
