#[tokio::main]
async fn main() -> std::process::ExitCode {
    match master_ship::run().await {
        Ok(_) => std::process::ExitCode::SUCCESS,
        Err(e) => { eprintln!("Master ship error: {e}"); std::process::ExitCode::FAILURE },
    }
}
