use super::*;
use data_structs::master_ship::{AccountCommit, AccountCommitResult, AccountState};

struct Receipt {
    revision: u64,
    commit_id: Option<Vec<u8>>,
    payload: Option<Vec<u8>>,
}

impl Sql {
    pub(super) async fn create_commit_schema(pool: &sqlx::SqlitePool) -> Result<(), Error> {
        pool.execute("CREATE TABLE IF NOT EXISTS AccountCommits (
            UserId INTEGER PRIMARY KEY,
            Revision INTEGER NOT NULL CHECK (Revision >= 0),
            CommitId BLOB,
            Payload BLOB,
            CHECK ((CommitId IS NULL AND Payload IS NULL) OR
                   (CommitId IS NOT NULL AND length(CommitId)=16 AND Payload IS NOT NULL))
        )").await?;
        Ok(())
    }

    fn snapshot(data: &UserData) -> AccountSnapshot {
        AccountSnapshot {storage:data.storage.clone(),flags:data.flags.clone(),last_uuid:data.last_uuid}
    }

    pub(super) fn snapshot_bytes(data: &UserData) -> Result<Vec<u8>, Error> {
        Ok(rmp_serde::to_vec(&Self::snapshot(data))?)
    }

    async fn receipt(conn: &mut sqlx::SqliteConnection, id: u32) -> Result<Receipt, Error> {
        let row=sqlx::query("SELECT Revision,CommitId,Payload FROM AccountCommits WHERE UserId=?")
            .bind(id).fetch_optional(conn).await?;
        let Some(row)=row else {return Ok(Receipt {revision:0,commit_id:None,payload:None});};
        let revision=u64::try_from(row.try_get::<i64,_>("Revision")?).map_err(|_|Error::InvalidData)?;
        let receipt=Receipt {revision,commit_id:row.try_get("CommitId")?,payload:row.try_get("Payload")?};
        match (&receipt.commit_id,&receipt.payload) {
            (None,None)=>{},
            (Some(id),Some(payload))=>{
                let saved:AccountCommit=rmp_serde::from_slice(payload)?;
                if id.as_slice()!=saved.commit_id || saved.expected_revision.checked_add(1)!=Some(revision) {
                    return Err(Error::InvalidData);
                }
            },
            _=>return Err(Error::InvalidData),
        }
        Ok(receipt)
    }

    async fn write_receipt(conn: &mut sqlx::SqliteConnection,id: u32, revision: u64,
        commit_id: Option<&[u8]>,payload: Option<&[u8]>) -> Result<(), Error> {
        let revision=i64::try_from(revision).map_err(|_|Error::InvalidData)?;
        let changed=sqlx::query("INSERT INTO AccountCommits (UserId,Revision,CommitId,Payload) VALUES (?,?,?,?)
            ON CONFLICT(UserId) DO UPDATE SET Revision=excluded.Revision,CommitId=excluded.CommitId,Payload=excluded.Payload")
            .bind(id).bind(revision).bind(commit_id).bind(payload).execute(conn).await?;
        if changed.rows_affected()!=1 {return Err(Error::InvalidData);}
        Ok(())
    }

    pub(super) async fn invalidate_commit_receipt(conn: &mut sqlx::SqliteConnection,id: u32) -> Result<(), Error> {
        let current=Self::receipt(conn,id).await?;
        let revision=current.revision.checked_add(1).ok_or(Error::InvalidData)?;
        Self::write_receipt(conn,id,revision,None,None).await
    }

    pub async fn get_account_state(&self,id: u32) -> Result<AccountState, Error> {
        let mut transaction=self.connection.begin().await?;
        let row=sqlx::query("SELECT Data FROM Users WHERE Id=?").bind(id).fetch_one(&mut *transaction).await?;
        let data:UserData=rmp_serde::from_slice(row.try_get("Data")?)?;
        let receipt=Self::receipt(&mut transaction,id).await?;
        transaction.commit().await?;
        Ok(AccountState {revision:receipt.revision,snapshot:Self::snapshot(&data)})
    }

    pub async fn commit_account_snapshot(&self,id: u32,commit: AccountCommit) -> Result<AccountCommitResult, Error> {
        let payload=rmp_serde::to_vec(&commit)?;
        let mut transaction=self.connection.begin_with("BEGIN IMMEDIATE").await?;
        let row=sqlx::query("SELECT Data FROM Users WHERE Id=?").bind(id).fetch_one(&mut *transaction).await?;
        let mut data:UserData=rmp_serde::from_slice(row.try_get("Data")?)?;
        let receipt=Self::receipt(&mut transaction,id).await?;
        if receipt.commit_id.as_deref()==Some(commit.commit_id.as_slice()) {
            if receipt.payload.as_deref()!=Some(payload.as_slice()) {return Err(Error::InvalidData);}
            transaction.commit().await?;
            return Ok(AccountCommitResult::Committed {commit_id:commit.commit_id,revision:receipt.revision,duplicate:true});
        }
        if receipt.revision!=commit.expected_revision {
            transaction.commit().await?;
            return Ok(AccountCommitResult::Conflict {revision:receipt.revision});
        }
        let revision=receipt.revision.checked_add(1).ok_or(Error::InvalidData)?;
        // Check representability before writing either side of the transaction.
        i64::try_from(revision).map_err(|_|Error::InvalidData)?;
        data.storage=commit.snapshot.storage;
        data.flags=commit.snapshot.flags;
        data.last_uuid=commit.snapshot.last_uuid;
        let changed=sqlx::query("UPDATE Users SET Data=? WHERE Id=?")
            .bind(rmp_serde::to_vec(&data)?).bind(id).execute(&mut *transaction).await?;
        if changed.rows_affected()!=1 {return Err(Error::InvalidData);}
        Self::write_receipt(&mut transaction,id,revision,Some(&commit.commit_id),Some(&payload)).await?;
        transaction.commit().await?;
        Ok(AccountCommitResult::Committed {commit_id:commit.commit_id,revision,duplicate:false})
    }
}
