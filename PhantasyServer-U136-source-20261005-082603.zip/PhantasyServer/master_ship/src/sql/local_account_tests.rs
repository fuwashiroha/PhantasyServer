use super::*;

async fn seed(sql: &Sql) {
    let data = UserData { nickname: "unchanged-name".into(), settings: "unchanged-settings".into(),
        isgm: true, last_uuid: 7,
        info: UserInfoPacket { free_sg:pso2packetlib::protocol::models::SGValue(43.0),
            premium_expiration:Duration::from_secs(4321), ..Default::default() },
        ..Default::default() };
    for id in [1i64, 2] {
        sqlx::query("INSERT INTO Users (Id,Data) VALUES (?,?)")
            .bind(id).bind(rmp_serde::to_vec(&data).unwrap()).execute(&sql.connection).await.unwrap();
    }
}

async fn fixture() -> Sql {
    // SQLite reports the special in-memory database as already existing.
    // Explicitly initialize its schema instead of taking the file reopen path.
    let sql=Sql::create_db("sqlite::memory:",false).await.unwrap();
    seed(&sql).await;
    sql
}

fn snapshot() -> AccountSnapshot {
    let mut storage=AccountStorages::default();storage.storage_meseta=123456;
    let mut item=pso2packetlib::protocol::items::Item::default();item.uuid=99;
    storage.default.items.push(item);
    let mut flags=Flags::new();flags.set(321,1);flags.set_param(17,765);
    AccountSnapshot {storage,flags,last_uuid:100}
}

async fn raw(sql: &Sql,id: u32) -> Vec<u8> {
    sqlx::query_scalar("SELECT Data FROM Users WHERE Id=?").bind(id).fetch_one(&sql.connection).await.unwrap()
}

async fn read(sql: &Sql,id: u32) -> UserData {
    rmp_serde::from_slice(&raw(sql,id).await).unwrap()
}

fn check_saved(data: &UserData) {
    assert_eq!(data.storage.storage_meseta,123456);
    assert_eq!(data.storage.default.items.len(),1);
    assert_eq!(data.storage.default.items[0].uuid,99);
    assert_eq!(data.flags.get(321),1);assert_eq!(data.flags.get_param(17),765);
    assert_eq!(data.last_uuid,100);
}

#[tokio::test]
async fn local_account_snapshot_all_fields_and_unrelated_fields_preserved() {
    let sql=fixture().await;let other=raw(&sql,2).await;
    sql.put_account_snapshot(1,snapshot()).await.unwrap();
    let data=read(&sql,1).await;check_saved(&data);
    assert_eq!(data.nickname,"unchanged-name");assert_eq!(data.settings,"unchanged-settings");assert!(data.isgm);
    assert_eq!(data.info.free_sg,pso2packetlib::protocol::models::SGValue(43.0));
    assert_eq!(data.info.premium_expiration,Duration::from_secs(4321));
    assert_eq!(other,raw(&sql,2).await);
    let once=raw(&sql,1).await;
    sql.put_account_snapshot(1,snapshot()).await.unwrap();
    assert_eq!(once,raw(&sql,1).await);
}

#[tokio::test]
async fn local_account_snapshot_abort_ignore_and_after_write_rollback() {
    for (timing,action) in [("BEFORE","RAISE(ABORT,'injected')"),("BEFORE","RAISE(IGNORE)"),("AFTER","RAISE(ABORT,'injected')")] {
        let sql=fixture().await;let before=raw(&sql,1).await;
        sql.connection.execute(format!("CREATE TRIGGER fail_save {timing} UPDATE OF Data ON Users WHEN NEW.Id=1 BEGIN SELECT {action}; END").as_str()).await.unwrap();
        for _ in 0..2 {
            assert!(sql.put_account_snapshot(1,snapshot()).await.is_err());
            assert_eq!(before,raw(&sql,1).await);
        }
        sql.connection.execute("DROP TRIGGER fail_save").await.unwrap();
        sql.put_account_snapshot(1,snapshot()).await.unwrap();
        check_saved(&read(&sql,1).await);
    }
}

#[tokio::test]
async fn local_account_snapshot_missing_and_corrupt_users_rejected() {
    let sql=fixture().await;let before=raw(&sql,2).await;
    assert!(sql.put_account_snapshot(999,snapshot()).await.is_err());
    sqlx::query("UPDATE Users SET Data=? WHERE Id=1").bind(vec![0xc1u8]).execute(&sql.connection).await.unwrap();
    assert!(sql.put_account_snapshot(1,snapshot()).await.is_err());
    assert_eq!(raw(&sql,1).await,vec![0xc1]);assert_eq!(raw(&sql,2).await,before);
}

#[tokio::test]
async fn local_account_legacy_field_update_detects_ignored_write() {
    let sql=fixture().await;
    sql.connection.execute("CREATE TRIGGER ignore_save BEFORE UPDATE ON Users BEGIN SELECT RAISE(IGNORE); END").await.unwrap();
    assert!(sql.save_settings(1,"must-not-succeed").await.is_err());
    assert_eq!(read(&sql,1).await.settings,"unchanged-settings");
}

#[tokio::test]
async fn local_account_two_connections_preserve_snapshot_and_settings_on_reopen() {
    let path=std::env::temp_dir().join(format!("pso2-u024-{}-{}.db",std::process::id(),SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()));
    assert!(!path.exists());
    let url=format!("sqlite:{}",path.display());
    let first=Sql::new(&url,false).await.unwrap();seed(&first).await;
    let second=Sql::new(&url,false).await.unwrap();
    // Separate connections begin concurrently. Both mutations must survive,
    // regardless of which writer acquires the database reservation first.
    for n in 0..12 {
        let settings=format!("settings-{n}");
        let (a,b)=tokio::join!(first.put_account_snapshot(1,snapshot()),second.save_settings(1,&settings));
        a.unwrap();b.unwrap();
        let data=read(&first,1).await;check_saved(&data);assert_eq!(data.settings,settings);
    }
    first.connection.close().await;second.connection.close().await;
    let reopened=Sql::new(&url,false).await.unwrap();
    let data=read(&reopened,1).await;check_saved(&data);assert_eq!(data.settings,"settings-11");
    reopened.connection.close().await;
    super::remove_test_db(&path).await;
}
