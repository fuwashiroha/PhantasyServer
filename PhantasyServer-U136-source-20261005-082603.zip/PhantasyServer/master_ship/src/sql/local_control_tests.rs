use super::*;
use crate::{MSData,connection_handler};
use data_structs::master_ship::{ShipConnection,MasterShipComm,MasterShipAction,ShipLogin,AccountCommit,AccountCommitResult};
use std::sync::Arc;

#[tokio::test]
async fn local_control_master_finishes_accepted_commit_before_connection_shutdown() {
    let path=std::env::temp_dir().join(format!("pso2-master-drain-{:032x}.sqlite",rand::random::<u128>()));
    let sql=Sql::create_db(path.to_str().unwrap(),false).await.unwrap();
    sql.put_ship_data(b"isolated-control-test").await.unwrap();
    let user=sql.create_sega_user("isolated_control_user","isolated_control_password").await.unwrap();
    let shared=Arc::new(MSData {sql,ships:parking_lot::RwLock::new(vec![]),srv_data:None});
    let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let client=tokio::net::TcpStream::connect(listener.local_addr().unwrap()).await.unwrap();
    let (server,_)=listener.accept().await.unwrap();
    let key=p256::ecdsa::SigningKey::from_slice(&[9;32]).unwrap();
    let public=key.verifying_key().to_sec1_bytes().to_vec();
    let (server,client)=tokio::join!(ShipConnection::new_server(server,&key,&public),ShipConnection::new_client(client,|_,offered|offered==public));
    let server=server.unwrap();let mut client=client.unwrap();
    let (stop,rx)=tokio::sync::watch::channel(false);let state=shared.clone();
    let task=tokio::spawn(async move {connection_handler(server,state,rx).await;});
    client.write(MasterShipComm {id:1,action:MasterShipAction::ShipLogin(ShipLogin {psk:b"isolated-control-test".to_vec()})}).await.unwrap();
    assert!(matches!(client.read_for(Duration::from_secs(3)).await.unwrap().action,MasterShipAction::ShipLoginResult(_)));
    let before=shared.sql.get_account_state(user.id).await.unwrap();
    let mut snapshot=before.snapshot;snapshot.last_uuid=333;snapshot.storage.storage_meseta=123456;
    let commit=AccountCommit {commit_id:[4;16],expected_revision:0,snapshot};
    // Reserve the writer. The accepted network request must then wait inside
    // its SQL transaction rather than being canceled by a shutdown signal.
    let writer=shared.sql.connection.begin_with("BEGIN IMMEDIATE").await.unwrap();
    client.write(MasterShipComm {id:2,action:MasterShipAction::CommitAccountSnapshot {id:user.id,commit}}).await.unwrap();
    tokio::time::timeout(Duration::from_secs(3),async {
        loop {
            let size=shared.sql.connection.size() as usize;
            if size>=2 && shared.sql.connection.num_idle()+2==size {break;}
            tokio::time::sleep(Duration::from_millis(5)).await;
        }
    }).await.unwrap();
    stop.send(true).unwrap();assert!(!task.is_finished());writer.rollback().await.unwrap();
    let reply=client.read_for(Duration::from_secs(3)).await.unwrap();
    assert!(matches!(reply.action,MasterShipAction::AccountCommitResult(AccountCommitResult::Committed {revision:1,duplicate:false,..})));
    tokio::time::timeout(Duration::from_secs(3),task).await.unwrap().unwrap();
    let saved=shared.sql.get_account_state(user.id).await.unwrap();
    assert_eq!(saved.revision,1);assert_eq!(saved.snapshot.last_uuid,333);assert_eq!(saved.snapshot.storage.storage_meseta,123456);
    shared.sql.close().await;drop(shared);remove_test_db(&path).await;
}
