use super::*;
use data_structs::master_ship::{AccountCommit,AccountCommitResult};

async fn seed(sql: &Sql) {
    for id in [1u32,2] {
        let data=UserData {nickname:format!("player-{id}"),settings:"settings".into(),..Default::default()};
        sqlx::query("INSERT INTO Users(Id,Data) VALUES (?,?)").bind(id)
            .bind(rmp_serde::to_vec(&data).unwrap()).execute(&sql.connection).await.unwrap();
    }
}

async fn fixture() -> Sql {
    let sql=Sql::create_db("sqlite::memory:",false).await.unwrap();seed(&sql).await;sql
}

fn commit(id: u8,expected_revision: u64) -> AccountCommit {
    let mut storage=AccountStorages::default();storage.storage_meseta=id as u64*100;
    let mut flags=Flags::new();flags.set(id as usize,1);
    AccountCommit {commit_id:[id;16],expected_revision,snapshot:AccountSnapshot {storage,flags,last_uuid:id as u64*1000}}
}

async fn raw(sql: &Sql,id: u32) -> Vec<u8> {
    sqlx::query_scalar("SELECT Data FROM Users WHERE Id=?").bind(id).fetch_one(&sql.connection).await.unwrap()
}

#[tokio::test]
async fn local_commit_snapshot_and_receipt_retry_are_atomic_and_idempotent() {
    let sql=fixture().await;let other=raw(&sql,2).await;
    assert_eq!(sql.get_account_state(1).await.unwrap().revision,0);
    let first=commit(4,0);
    assert_eq!(sql.commit_account_snapshot(1,first.clone()).await.unwrap(),AccountCommitResult::Committed {commit_id:[4;16],revision:1,duplicate:false});
    let saved=raw(&sql,1).await;
    assert_eq!(sql.commit_account_snapshot(1,first).await.unwrap(),AccountCommitResult::Committed {commit_id:[4;16],revision:1,duplicate:true});
    assert_eq!(saved,raw(&sql,1).await);assert_eq!(other,raw(&sql,2).await);
    let state=sql.get_account_state(1).await.unwrap();assert_eq!(state.revision,1);
    assert_eq!(state.snapshot.storage.storage_meseta,400);assert_eq!(state.snapshot.last_uuid,4000);assert_eq!(state.snapshot.flags.get(4),1);
    let data:UserData=rmp_serde::from_slice(&saved).unwrap();assert_eq!(data.nickname,"player-1");assert_eq!(data.settings,"settings");
}

#[tokio::test]
async fn local_commit_changed_token_payload_and_stale_replays_cannot_overwrite() {
    let sql=fixture().await;
    sql.commit_account_snapshot(1,commit(1,0)).await.unwrap();
    let before=raw(&sql,1).await;
    let mut altered=commit(1,0);altered.snapshot.last_uuid=77;
    assert!(sql.commit_account_snapshot(1,altered).await.is_err());
    assert_eq!(sql.commit_account_snapshot(1,commit(2,0)).await.unwrap(),AccountCommitResult::Conflict {revision:1});
    assert_eq!(before,raw(&sql,1).await);
    sql.commit_account_snapshot(1,commit(2,1)).await.unwrap();
    assert_eq!(sql.commit_account_snapshot(1,commit(1,0)).await.unwrap(),AccountCommitResult::Conflict {revision:2});
    let state=sql.get_account_state(1).await.unwrap();assert_eq!(state.snapshot.last_uuid,2000);
}

#[tokio::test]
async fn local_commit_faults_roll_back_account_and_receipt_together() {
    for (table,event) in [("Users","UPDATE"),("AccountCommits","INSERT"),("AccountCommits","UPDATE")] {
        for action in ["RAISE(ABORT,'injected')","RAISE(IGNORE)"] {
            let sql=fixture().await;let revision=if event=="UPDATE" && table=="AccountCommits" {
                sql.commit_account_snapshot(1,commit(1,0)).await.unwrap();1
            } else {0};
            let before=raw(&sql,1).await;
            sql.connection.execute(format!("CREATE TRIGGER fail_commit BEFORE {event} ON {table} BEGIN SELECT {action}; END").as_str()).await.unwrap();
            assert!(sql.commit_account_snapshot(1,commit(7,revision)).await.is_err());
            assert_eq!(before,raw(&sql,1).await);assert_eq!(sql.get_account_state(1).await.unwrap().revision,revision);
            sql.connection.execute("DROP TRIGGER fail_commit").await.unwrap();
            sql.commit_account_snapshot(1,commit(7,revision)).await.unwrap();
            assert_eq!(sql.get_account_state(1).await.unwrap().revision,revision+1);
        }
    }
}

#[tokio::test]
async fn local_commit_legacy_session_writes_fence_replay_but_settings_do_not() {
    let sql=fixture().await;sql.commit_account_snapshot(1,commit(3,0)).await.unwrap();
    sql.save_settings(1,"new-settings").await.unwrap();
    assert_eq!(sql.get_account_state(1).await.unwrap().revision,1);
    assert!(matches!(sql.commit_account_snapshot(1,commit(3,0)).await.unwrap(),AccountCommitResult::Committed {duplicate:true,..}));
    assert_eq!(sql.get_settings(1).await.unwrap().to_string(),"new-settings");
    sql.put_uuid(1,9999).await.unwrap();
    assert_eq!(sql.commit_account_snapshot(1,commit(3,0)).await.unwrap(),AccountCommitResult::Conflict {revision:2});
    assert_eq!(sql.get_account_state(1).await.unwrap().snapshot.last_uuid,9999);
}

#[tokio::test]
async fn local_commit_invalid_owner_corrupt_receipt_and_revision_overflow_rejected() {
    let sql=fixture().await;let before=raw(&sql,1).await;
    assert!(sql.commit_account_snapshot(99,commit(1,0)).await.is_err());
    sqlx::query("INSERT INTO AccountCommits(UserId,Revision) VALUES (1,?)").bind(i64::MAX).execute(&sql.connection).await.unwrap();
    assert!(sql.commit_account_snapshot(1,commit(1,i64::MAX as u64)).await.is_err());
    assert_eq!(before,raw(&sql,1).await);
    sqlx::query("UPDATE AccountCommits SET Revision=1,CommitId=?,Payload=? WHERE UserId=1")
        .bind([1u8;16].as_slice()).bind(vec![0xc1u8]).execute(&sql.connection).await.unwrap();
    assert!(sql.get_account_state(1).await.is_err());assert!(sql.commit_account_snapshot(1,commit(1,0)).await.is_err());
    assert_eq!(before,raw(&sql,1).await);
}

#[tokio::test]
async fn local_commit_legacy_upgrade_reopen_and_concurrent_compare_and_swap() {
    let path=std::env::temp_dir().join(format!("pso2-u025-master-{}-{}.db",std::process::id(),SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos()));
    assert!(!path.exists());let url=format!("sqlite:{}",path.display());
    let first=Sql::new(&url,false).await.unwrap();seed(&first).await;
    first.connection.execute("DROP TABLE AccountCommits").await.unwrap();
    let old=raw(&first,1).await;first.connection.close().await;
    let first=Sql::new(&url,false).await.unwrap();assert_eq!(old,raw(&first,1).await);
    let second=Sql::new(&url,false).await.unwrap();
    let (a,b)=tokio::join!(first.commit_account_snapshot(1,commit(1,0)),second.commit_account_snapshot(1,commit(2,0)));
    let outcomes=[a.unwrap(),b.unwrap()];
    assert_eq!(outcomes.iter().filter(|r|matches!(r,AccountCommitResult::Committed {duplicate:false,..})).count(),1);
    assert_eq!(outcomes.iter().filter(|r|matches!(r,AccountCommitResult::Conflict {revision:1})).count(),1);
    let winner=if matches!(outcomes[0],AccountCommitResult::Committed {..}) {1} else {2};
    let saved=raw(&first,1).await;first.connection.close().await;second.connection.close().await;
    let reopened=Sql::new(&url,false).await.unwrap();
    assert!(matches!(reopened.commit_account_snapshot(1,commit(winner,0)).await.unwrap(),AccountCommitResult::Committed {duplicate:true,revision:1,..}));
    assert_eq!(saved,raw(&reopened,1).await);reopened.connection.close().await;super::remove_test_db(&path).await;
}
