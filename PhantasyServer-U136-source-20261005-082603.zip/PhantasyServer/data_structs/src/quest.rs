use crate::map::{MapData, ZoneId};
use pso2packetlib::protocol::{
    questlist::{Quest, QuestDifficulty},
    spawn::EnemySpawnPacket,
};
use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
#[serde(default)]
pub struct QuestData {
    pub definition: Quest,
    pub difficulties: QuestDifficulty,
    pub map: MapData,
    pub enemies: Vec<EnemyData>,
    pub immediate_move: bool,
    // Empty for legacy quests. Import only fully sourced per-difficulty profiles.
    pub completion: Vec<QuestCompletionRule>,
}

#[derive(Serialize, Deserialize, Clone, Debug, Default)]
#[serde(default)]
pub struct EnemyData {
    pub difficulty: u16,
    pub mapid: ZoneId,
    pub data: EnemySpawnPacket,
}

// A fixed-result defeat objective, not a universal rank formula. Missing fields
// are errors; there is deliberately no default count, reward or eligibility.
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct QuestCompletionRule {
    pub difficulty: u16,
    pub zone_id: ZoneId,
    pub enemy_name: String,
    pub required_kills: u32,
    pub participants: QuestParticipantRule,
    pub result: pso2packetlib::protocol::questlist::QuestResultPacket,
    pub evidence: String,
    // Authored actor IDs only; empty for legacy profiles. No inferred portal type.
    #[serde(default)]
    pub activate_on_completion: Vec<u32>,
}
#[derive(Serialize, Deserialize, Clone, Debug)]
pub enum QuestParticipantRule { AnyObjectiveKillRecipient }
