//! Local, boot-specific stop requests for hidden server processes.
use std::{fs, io::{self, Read, Write}, path::{Path, PathBuf}, time::Duration};

pub struct LocalControl {
    ready: PathBuf,
    request: PathBuf,
    identity: String,
}

impl LocalControl {
    pub fn create(runtime: &Path, service: &str) -> io::Result<Self> {
        if !matches!(service, "ship" | "master") {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "unknown local service"));
        }
        let dir = runtime.canonicalize()?.join(".local-control");
        fs::create_dir_all(&dir)?;
        let pid = std::process::id();
        let nonce = format!("{:032x}", rand::random::<u128>());
        let identity = format!("PSO2_LOCAL_CONTROL_V1\n{service}\n{pid}\n{nonce}\n");
        let stem = format!("{service}.{pid}.{nonce}");
        let ready = dir.join(format!("{stem}.ready"));
        let request = dir.join(format!("{stem}.stop"));
        let mut file = fs::OpenOptions::new().write(true).create_new(true).open(&ready)?;
        file.write_all(identity.as_bytes())?;
        file.sync_all()?;
        Ok(Self {ready, request, identity})
    }

    pub fn requested(&self) -> io::Result<bool> {
        let file = match fs::File::open(&self.request) {
            Ok(file) => file,
            Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(false),
            Err(e) => return Err(e),
        };
        // Bound reads and ignore partial, stale or malformed request contents.
        let mut contents = Vec::new();
        file.take(257).read_to_end(&mut contents)?;
        Ok(contents == self.identity.as_bytes())
    }

    pub async fn wait(&self) -> io::Result<()> {
        let mut interval = tokio::time::interval(Duration::from_millis(250));
        loop {
            interval.tick().await;
            if self.requested()? { return Ok(()); }
        }
    }
}

impl Drop for LocalControl {
    fn drop(&mut self) {
        // Remove only the exact files created for this boot instance.
        let _ = fs::remove_file(&self.ready);
        let _ = fs::remove_file(&self.request);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn directory() -> PathBuf {
        let dir = std::env::temp_dir().join(format!("pso2-control-test-{:032x}", rand::random::<u128>()));
        fs::create_dir(&dir).unwrap(); dir
    }
    fn clean(dir: &Path) {
        fs::remove_dir(dir.join(".local-control")).unwrap();fs::remove_dir(dir).unwrap();
    }

    #[test]
    fn local_control_requests_require_exact_boot_identity() {
        let dir=directory();let control=LocalControl::create(&dir,"ship").unwrap();
        assert!(!control.requested().unwrap());
        for invalid in [Vec::new(),b"stop\n".to_vec(),vec![b'x';1024],
            control.identity.replace("ship","master").into_bytes(),
            control.identity.replace("PSO2_LOCAL_CONTROL_V1","PSO2_LOCAL_CONTROL_V0").into_bytes()] {
            fs::write(&control.request,invalid).unwrap();assert!(!control.requested().unwrap());
        }
        fs::write(&control.request,&control.identity).unwrap();assert!(control.requested().unwrap());
        drop(control);clean(&dir);
    }

    #[test]
    fn local_control_old_request_cannot_stop_new_boot_or_other_service() {
        let dir=directory();let old=LocalControl::create(&dir,"ship").unwrap();
        let next=LocalControl::create(&dir,"ship").unwrap();let master=LocalControl::create(&dir,"master").unwrap();
        fs::write(&old.request,&old.identity).unwrap();
        assert!(old.requested().unwrap());assert!(!next.requested().unwrap());assert!(!master.requested().unwrap());
        fs::write(&next.request,&old.identity).unwrap();assert!(!next.requested().unwrap());
        drop(old);assert!(next.ready.exists());assert!(master.ready.exists());
        drop(next);drop(master);clean(&dir);
    }

    #[tokio::test]
    async fn local_control_wait_survives_partial_request_then_accepts_complete_request() {
        let dir=directory();let control=LocalControl::create(&dir,"master").unwrap();
        fs::write(&control.request,b"partial").unwrap();
        let mut wait=Box::pin(control.wait());
        assert!(tokio::time::timeout(Duration::from_millis(20),&mut wait).await.is_err());
        fs::write(&control.request,&control.identity).unwrap();
        tokio::time::timeout(Duration::from_secs(2),&mut wait).await.unwrap().unwrap();
        drop(wait);drop(control);clean(&dir);
    }

    #[test]
    fn local_control_rejects_unknown_service_without_creating_files() {
        let dir=directory();assert!(LocalControl::create(&dir,"../other").is_err());
        assert!(!dir.join(".local-control").exists());fs::remove_dir(&dir).unwrap();
    }
}
